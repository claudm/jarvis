from flask import Blueprint, jsonify
import logging
from models.crossplane_manager import CrossplaneManager

bp = Blueprint('providers', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

# Provider CRD routes
@bp.route('/providers/<name>/crds', methods=['GET'])
def list_provider_crds(name):
    """List all CRDs installed by a specific provider"""
    try:
        manager = CrossplaneManager.get_instance()
        crds = manager.provider_manager.list_provider_crds(name)
        return jsonify({
            'crds': crds,
            'count': len(crds),
            'message': 'No CRDs found' if not crds else None
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing provider CRDs: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list provider CRDs"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": f"Provider '{name}' not found"}), 404
        else:
            return jsonify({"error": f"Failed to list provider CRDs: {error_msg}"}), 500

@bp.route('/providers/<name>/crds/status', methods=['GET'])
def get_provider_crds_status(name):
    """Get status of all CRDs for a provider including installation status"""
    try:
        manager = CrossplaneManager.get_instance()
        status = manager.provider_manager.get_provider_crds_status(name)
        return jsonify(status)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting provider CRDs status: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get provider CRDs status"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": f"Provider '{name}' not found"}), 404
        else:
            return jsonify({"error": f"Failed to get provider CRDs status: {error_msg}"}), 500

@bp.route('/providers', methods=['GET'])
def list_providers():
    """List all installed providers"""
    try:
        manager = CrossplaneManager.get_instance()
        providers = manager.list_providers()
        return jsonify({
            'providers': providers,
            'count': len(providers),
            'message': 'No providers found' if not providers else None
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing providers: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list providers"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Providers resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list providers: {error_msg}"}), 500

@bp.route('/providers/<name>', methods=['GET'])
def get_provider(name):
    """Get a specific provider by name"""
    try:
        manager = CrossplaneManager.get_instance()
        provider = manager.get_provider_status(name)
        if not provider:
            return jsonify({"error": f"Provider '{name}' not found"}), 404
        return jsonify(provider)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting provider {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get provider"}), 403
        else:
            return jsonify({"error": f"Failed to get provider: {error_msg}"}), 500
