from flask import Blueprint, jsonify
from models.crossplane_manager import CrossplaneManager
from models.claim_manager import ClaimManager
from models.provider_manager import ProviderManager
from models.composite_manager import CompositeManager
from models.composition_manager import CompositionManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

bp = Blueprint('overview', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

def get_crossplane_data():
    """Get Crossplane status and version"""
    try:
        manager = CrossplaneManager.get_instance()
        status = manager.get_crossplane_status()
        return {
            'health': status.get('health'),
            'version': status.get('version'),
            'pods': [{
                'name': pod.get('name'),
                'status': pod.get('status'),
                'containers': [{
                    'name': container.get('name'),
                    'status': container.get('status'),
                    'restarts': container.get('restarts')
                } for container in pod.get('containers', [])]
            } for pod in status.get('pods', [])]
        }
    except Exception as e:
        logger.error(f"Error getting Crossplane status: {e}")
        return {'health': 'Unknown', 'version': 'Unknown', 'pods': []}

def get_managed_resources_data():
    """Get managed resources data"""
    try:
        manager = CrossplaneManager.get_instance()
        resources = manager.get_managed_resources() or []
        
        # Process only essential fields and limit items
        processed_resources = []
        health_summary = {'healthy': 0, 'unhealthy': 0, 'unknown': 0}
        
        for resource in resources:
            status = resource.get('_health_status', 'Unknown')
            if status == 'Healthy':
                health_summary['healthy'] += 1
            elif status == 'Unhealthy':
                health_summary['unhealthy'] += 1
            else:
                health_summary['unknown'] += 1
            
            # Only include essential fields for recent activity
            processed_resources.append({
                'kind': resource.get('kind'),
                'metadata': {
                    'name': resource.get('metadata', {}).get('name'),
                    'creationTimestamp': resource.get('metadata', {}).get('creationTimestamp')
                },
                '_health_status': status,
                '_resource_type': {'kind': resource.get('kind')}
            })

        return {
            'items': processed_resources[:5],  # Only return latest 5 items
            'total_count': len(resources),
            'health_summary': health_summary
        }
    except Exception as e:
        logger.error(f"Error getting managed resources: {e}")
        return {'items': [], 'total_count': 0, 'health_summary': {'healthy': 0, 'unhealthy': 0, 'unknown': 0}}

def get_claims_data():
    """Get claims data"""
    try:
        manager = ClaimManager.get_instance()
        claims = manager.list_claims() or []
        # Only return essential fields for the 5 most recent claims
        processed_claims = [{
            'kind': claim.get('kind'),
            'metadata': {
                'name': claim.get('metadata', {}).get('name'),
                'creationTimestamp': claim.get('metadata', {}).get('creationTimestamp')
            },
            '_health_status': claim.get('_health_status', 'Unknown')
        } for claim in claims[:5]]
        return {'items': processed_claims, 'count': len(claims)}
    except Exception as e:
        logger.error(f"Error getting claims: {e}")
        return {'items': [], 'count': 0}

def get_composite_resources_data():
    """Get composite resources data"""
    try:
        manager = CompositeManager.get_instance()
        resources = manager.get_composite_resources() or []
        # Only return essential fields for the 5 most recent composite resources
        processed_resources = [{
            'kind': resource.get('kind'),
            'metadata': {
                'name': resource.get('metadata', {}).get('name'),
                'creationTimestamp': resource.get('metadata', {}).get('creationTimestamp')
            },
            '_health_status': resource.get('_health_status', 'Unknown')
        } for resource in resources[:5]]
        return {'items': processed_resources, 'count': len(resources)}
    except Exception as e:
        logger.error(f"Error getting composite resources: {e}")
        return {'items': [], 'count': 0}

def get_providers_data():
    """Get providers data"""
    try:
        manager = ProviderManager.get_instance()
        providers = manager.list_providers() or []
        # Only return essential fields
        processed_providers = [{
            'kind': provider.get('kind'),
            'metadata': {
                'name': provider.get('metadata', {}).get('name')
            }
        } for provider in providers]
        return {'items': processed_providers, 'count': len(providers)}
    except Exception as e:
        logger.error(f"Error getting providers: {e}")
        return {'items': [], 'count': 0}

def get_provider_configs_data():
    """Get provider configs data"""
    try:
        manager = ProviderManager.get_instance()
        configs = manager.list_provider_configs() or []
        # Only return essential fields
        processed_configs = [{
            'kind': config.get('kind'),
            'metadata': {
                'name': config.get('metadata', {}).get('name')
            }
        } for config in configs]
        return {'items': processed_configs, 'count': len(configs)}
    except Exception as e:
        logger.error(f"Error getting provider configs: {e}")
        return {'items': [], 'count': 0}

def get_compositions_data():
    """Get compositions data"""
    try:
        manager = CompositionManager.get_instance()
        compositions = manager.list_compositions() or []
        # Only return essential fields
        processed_compositions = [{
            'kind': composition.get('kind'),
            'metadata': {
                'name': composition.get('metadata', {}).get('name')
            }
        } for composition in compositions]
        return {'items': processed_compositions, 'count': len(compositions)}
    except Exception as e:
        logger.error(f"Error getting compositions: {e}")
        return {'items': [], 'count': 0}

def get_composite_resource_definitions_data():
    """Get composite resource definitions data"""
    try:
        manager = CompositionManager.get_instance()
        definitions = manager.list_composite_resource_definitions() or []
        # Only return essential fields
        processed_definitions = [{
            'kind': definition.get('kind'),
            'metadata': {
                'name': definition.get('metadata', {}).get('name')
            }
        } for definition in definitions]
        return {'items': processed_definitions, 'count': len(definitions)}
    except Exception as e:
        logger.error(f"Error getting composite resource definitions: {e}")
        return {'items': [], 'count': 0}

@bp.route('/overview', methods=['GET'])
def get_overview():
    """Get all overview data in parallel"""
    try:
        logger.info("Fetching overview data")
        
        # Define data fetching tasks
        tasks = {
            'crossplane': get_crossplane_data,
            'managed_resources': get_managed_resources_data,
            'claims': get_claims_data,
            'composite_resources': get_composite_resources_data,
            'providers': get_providers_data,
            'provider_configs': get_provider_configs_data,
            'compositions': get_compositions_data,
            'composite_resource_definitions': get_composite_resource_definitions_data
        }
        
        # Execute tasks in parallel using ThreadPoolExecutor
        results = {}
        with ThreadPoolExecutor(max_workers=8) as executor:
            future_to_key = {executor.submit(func): key for key, func in tasks.items()}
            for future in as_completed(future_to_key):
                key = future_to_key[future]
                try:
                    results[key] = future.result()
                except Exception as e:
                    logger.error(f"Error in {key} task: {e}")
                    results[key] = None

        logger.info("Successfully fetched overview data")
        return jsonify(results)
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting overview data: {error_msg}")
        return jsonify({"error": f"Failed to get overview data: {error_msg}"}), 500
