# app/controllers/claim_controller.py
from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager

bp = Blueprint('claims', __name__, url_prefix='/api')

@bp.route('/claims', methods=['GET'])
def list_claims():
    """List all claims in a namespace with related data"""
    try:
        namespace = request.args.get('namespace', 'default')
        manager = CrossplaneManager.get_instance()
        claims = manager.list_claims(namespace=namespace)
        
        # Format response with additional data
        formatted_claims = []
        for claim in claims:
            formatted_claim = {
                **claim,
                'composition': claim.get('composition'),
                'compositeResource': claim.get('compositeResource'),
                'events': sorted(
                    claim.get('events', []),
                    key=lambda x: x.get('timestamp', ''),
                    reverse=True
                )
            }
            formatted_claims.append(formatted_claim)

        return jsonify({
            'claims': formatted_claims,
            'count': len(formatted_claims),
            'namespace': namespace,
            'message': 'No claims found in this namespace' if not formatted_claims else None
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp.route('/claims/<name>', methods=['GET'])
def get_claim(name):
    """Get a specific claim by name"""
    try:
        namespace = request.args.get('namespace', 'default')
        manager = CrossplaneManager.get_instance()
        claim = manager.get_claim(name, namespace)
        if not claim:
            return jsonify({"error": "Claim not found"}), 404
        return jsonify(claim)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
