// api.js - API functions for providers

async function fetchProviderCRDs(providerName) {
    try {
        const response = await fetch(`/api/providers/${providerName}/crds`);
        if (!response.ok) {
            throw new Error(`Failed to fetch CRDs: ${response.statusText}`);
        }
        const data = await response.json();
        return data.crds;
    } catch (error) {
        console.error('Error fetching provider CRDs:', error);
        return [];
    }
}

async function fetchProviderCRDsStatus(providerName) {
    try {
        const response = await fetch(`/api/providers/${providerName}/crds/status`);
        if (!response.ok) {
            throw new Error(`Failed to fetch CRDs status: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching provider CRDs status:', error);
        return null;
    }
}

// Export functions
window.fetchProviderCRDs = fetchProviderCRDs;
window.fetchProviderCRDsStatus = fetchProviderCRDsStatus;
