/* styles.css */
/* Navigation */
[data-tab] {
    @apply transition-colors duration-150;
}

[data-tab]:hover {
    @apply text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700;
}

[data-tab].active {
    @apply text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900;
}

/* Content panels */
.tab-panel {
    @apply transition-opacity duration-200;
    display: none;
}

.tab-panel:not(.hidden) {
    @apply opacity-100;
    display: block;
}

.tab-panel.hidden {
    @apply opacity-0 pointer-events-none;
    display: none !important;
}

/* Resource cards */
.resource-card {
    @apply hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700;
}

.resource-card-header {
    @apply flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700;
}

.resource-card-content {
    @apply px-4 py-3 text-sm text-gray-500 dark:text-gray-400;
}

/* Status badges */
.status-badge {
    @apply inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium;
}

.status-badge-success {
    @apply bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200;
}

.status-badge-warning {
    @apply bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200;
}

.status-badge-error {
    @apply bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200;
}

.status-badge-info {
    @apply bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200;
}

/* Modal */
#yaml-modal {
    @apply z-50 fixed inset-0;
}

#yaml-editor {
    width: 100%;
    height: 100%;
    overflow: auto;
}

.monaco-editor {
    padding: 4px;
    border-radius: 4px;
    border: 1px solid #e5e7eb;
}

.monaco-editor.vs-dark {
    border-color: #374151;
}

.monaco-editor .overflow-guard {
    overflow: auto !important;
}

/* Loading overlay */
.loading-overlay {
    @apply fixed inset-0 bg-gray-900 bg-opacity-50 dark:bg-opacity-70 flex items-center justify-center z-50;
}

.loading-spinner {
    @apply animate-spin h-8 w-8 text-white;
}

.loading-spinner circle {
    @apply opacity-25;
}

.loading-spinner path {
    @apply opacity-75;
}

/* Health Status Graph */
.health-status-container {
    @apply max-h-[400px] overflow-y-auto;
}

.health-status-bar {
    @apply w-64 h-2 bg-gray-200 dark:bg-gray-700 rounded-full mr-2;
}

.health-status-wrapper {
    @apply flex justify-between items-center space-x-4 min-w-[300px];
}

.health-status-label {
    @apply text-sm font-medium text-gray-600 dark:text-gray-400 min-w-[80px];
}

.health-status-value {
    @apply text-sm font-medium text-gray-700 dark:text-gray-300 min-w-[40px] text-right;
}
