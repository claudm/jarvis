# app/controllers/composition_controller.py
from flask import Blueprint, jsonify
from models.crossplane_manager import CrossplaneManager

bp = Blueprint('compositions', __name__, url_prefix='/api')

@bp.route('/compositions', methods=['GET'])
def list_compositions():
    try:
        manager = CrossplaneManager.get_instance()
        compositions = manager.list_compositions()
        return jsonify({
            'compositions': compositions,
            'count': len(compositions),
            'message': 'No compositions found' if not compositions else None
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list compositions"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Compositions resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list compositions: {error_msg}"}), 500

@bp.route('/compositions/<name>', methods=['GET'])
def get_composition(name):
    """Get a specific composition by name"""
    try:
        manager = CrossplaneManager.get_instance()
        composition = manager.get_composition(name)
        if not composition:
            return jsonify({"error": f"Composition '{name}' not found"}), 404
        return jsonify(composition)
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get composition"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": f"Composition '{name}' not found"}), 404
        else:
            return jsonify({"error": f"Failed to get composition: {error_msg}"}), 500
