from flask import Blueprint, jsonify, request, render_template
from models.crossplane_manager import CrossplaneManager
from services.background_worker import BackgroundWorker
import logging

bp = Blueprint('overview', __name__, url_prefix='/api')
UPDATE_INTERVAL = BackgroundWorker().update_interval
logger = logging.getLogger(__name__)

@bp.route('/overview', methods=['GET'])
def get_overview():
    """Get system overview using the optimized get_system_overview method"""
    try:
        logger.info("Fetching system overview data from cache")
        manager = CrossplaneManager.get_instance()
        overview = manager.get_system_overview(use_cache=True)

        # Transform the data to match the expected format
        results = {
            'crossplane': {
                'health': overview['health'],
                'version': overview['version'],
                'pods': overview['pods']
            },
            'managed_resources': {
                'total_count': overview['counts']['managed_resources'],
                'health_summary': overview['health_summary']
            },
            'claims': {
                'count': overview['counts']['claims']
            },
            'composite_resources': {
                'count': overview['counts']['composite_resources']
            },
            'providers': {
                'count': overview['counts']['providers']
            },
            'provider_configs': {
                'count': overview['counts']['providers']  # Using providers count as proxy
            },
            'compositions': {
                'count': overview['counts']['compositions']
            },
            'composite_resource_definitions': {
                'count': overview['counts']['xrds']
            }
        }

        logger.info("Successfully fetched system overview data")
        return jsonify(results)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting system overview data: {error_msg}")
        return jsonify({"error": f"Failed to get system overview data: {error_msg}"}), 500
