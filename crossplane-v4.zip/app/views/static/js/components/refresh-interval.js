// refresh-interval.js - Handle refresh interval updates

document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing refresh interval handler');
    const intervalInput = document.getElementById('refresh-interval');
    const saveButton = document.getElementById('save-interval');

    console.log('Found elements:', { 
        intervalInput: !!intervalInput, 
        saveButton: !!saveButton 
    });

    if (intervalInput && saveButton) {
        console.log('Setting up event listeners');
        // Handle save button click
        saveButton.addEventListener('click', async (event) => {
            event.preventDefault();
            console.log('Save button clicked');
            const newInterval = parseInt(intervalInput.value, 10);
            
            // Validate input
            if (isNaN(newInterval) || newInterval < 3 || newInterval > 30) {
                showError('Interval must be between 3 and 30 seconds');
                return;
            }

            try {
                console.log('Sending update request with interval:', newInterval);
                // Add visual feedback
                saveButton.classList.add('text-blue-500');

                const response = await fetch('/api/overview/interval', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ interval: newInterval })
                });

                const data = await response.json();
                if (!response.ok) {
                    throw new Error(data.error || 'Failed to update interval');
                }
                showSuccess('Refresh interval updated successfully');
                
                // Update input value and header text
                intervalInput.value = data.interval;
                const headerText = document.querySelector('.text-gray-500.dark\\:text-gray-400.mt-1');
                if (headerText) {
                    const div = headerText.querySelector('div');
                    div.innerHTML = `
                        <svg class="w-4 h-4 mr-1 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        Auto-refresh every ${data.interval} seconds
                    `;
                }

                // Reset visual feedback after a short delay
                setTimeout(() => {
                    saveButton.classList.remove('text-blue-500');
                }, 500);
            } catch (error) {
                console.error('Error updating interval:', error);
                showError(error.message);
                saveButton.classList.remove('text-blue-500');
            }
        });

        // Handle input validation
        intervalInput.addEventListener('input', () => {
            const value = parseInt(intervalInput.value, 10);
            if (isNaN(value) || value < 3 || value > 30) {
                intervalInput.classList.add('border-red-500');
                saveButton.classList.add('opacity-50', 'cursor-not-allowed');
            } else {
                intervalInput.classList.remove('border-red-500');
                saveButton.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        });

        // Handle Enter key press
        intervalInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                const value = parseInt(intervalInput.value, 10);
                if (!isNaN(value) && value >= 3 && value <= 30) {
                    saveButton.click();
                }
            }
        });
    }
});
