// managed-resources.js - Managed Resources functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderManagedResourceDetails(resource) {
    const status = resource.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
    
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';
    const healthyTime = healthyCondition.lastTransitionTime ? 
        formatTimeAgo(healthyCondition.lastTransitionTime) : '';

    return `
        <div class="space-y-4">
            <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Provider</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.provider || resource.display_provider || 'Unknown'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(resource.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Status</h3>
                <div class="space-y-2">
                    <div class="flex items-center space-x-2">
                        <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                            ${resource._health_status || 'Unknown'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500 dark:text-gray-400">${readyTime}</span>` : ''}
                        ${readyCondition.message ? `<span class="text-sm text-gray-500 dark:text-gray-400">${readyCondition.message}</span>` : ''}
                    </div>
                </div>
            </div>

            ${conditions.length > 0 ? `
                <div>
                    <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Conditions</h3>
                    <div class="space-y-2">
                        ${conditions.map(condition => `
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-2">
                                    <span class="text-sm font-medium text-gray-900 dark:text-white">${condition.type}</span>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                        condition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' :
                                        condition.status === 'False' ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200' :
                                        'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                                    }">
                                        ${condition.status}
                                    </span>
                                </div>
                                ${condition.lastTransitionTime ? `
                                    <span class="text-xs text-gray-500 dark:text-gray-400">
                                        ${formatTimeAgo(condition.lastTransitionTime)}
                                    </span>
                                ` : ''}
                            </div>
                            ${condition.message ? `
                                <p class="text-sm text-gray-500 dark:text-gray-400 ml-4">
                                    ${condition.message}
                                </p>
                            ` : ''}
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

// Constants for virtual scrolling
const ROWS_PER_PAGE = 20;
const ROW_HEIGHT = 60;
const BUFFER_SIZE = 5; // Number of extra rows to keep above/below viewport

function createResourceRow(resource, index) {
    const row = document.createElement('div');
    row.className = 'grid grid-cols-4 gap-4 px-6 py-4 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer';
    row.dataset.index = index;
    
    row.innerHTML = `
        <div class="text-sm font-medium text-gray-900 dark:text-white">
            ${resource.metadata?.name || 'Unnamed'}
            <div class="text-xs text-gray-500 dark:text-gray-400">${resource.apiVersion || ''}</div>
        </div>
        <div class="text-sm text-gray-500 dark:text-gray-400">
            ${resource.provider || resource.display_provider || 'Unknown'}
            <div class="text-xs">${resource.providerconfig || ''}</div>
        </div>
        <div>
            <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                ${resource._health_status || 'Unknown'}
            </span>
        </div>
        <div class="text-sm text-gray-500 dark:text-gray-400 text-right">
            <button class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1 rounded-full yaml-view-btn"
                    type="button">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
            </button>
        </div>
        <div class="managed-resource-details col-span-4 bg-gray-50 dark:bg-gray-700 px-6 py-4" style="display: none;"></div>
    `;
    
    return row;
}

function renderManagedResources(container, data) {
    if (!data) {
        console.error('No data provided to renderManagedResources');
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No managed resources found</div>';
        return;
    }

    // Initialize empty data structure if needed
    data = {
        resources: data.resources || {},
        health_summary: data.health_summary || { healthy: 0, unhealthy: 0, unknown: 0 },
        total_count: data.total_count || 0
    };

    // Create DOM structure using DocumentFragment for better performance
    const fragment = document.createDocumentFragment();
    
    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'border-b border-gray-200';
    
    const tabsList = document.createElement('nav');
    tabsList.className = 'flex -mb-px';
    tabsContainer.appendChild(tabsList);

    const contentContainer = document.createElement('div');
    contentContainer.className = 'mt-4';

    fragment.appendChild(tabsContainer);
    fragment.appendChild(contentContainer);

    // Clear container once and append fragment
    container.innerHTML = '';
    container.appendChild(fragment);

    // Store the latest data
    window.originalResourceData = structuredClone(data);

    // Get current filters
    const filters = {
        status: document.getElementById('status-filter')?.value || '',
        search: document.getElementById('resource-search')?.value?.toLowerCase() || ''
    };

    // Apply filters and calculate health summary
    const filteredData = {
        resources: {},
        health_summary: { healthy: 0, unhealthy: 0, unknown: 0 },
        total_count: 0
    };

    // Data is already grouped by kind from the backend
    const resourceGroups = data.resources || {};
    
    // Apply filters to each group
    const filteredGroups = {};
    let totalFilteredCount = 0;
    const filteredHealthSummary = { healthy: 0, unhealthy: 0, unknown: 0 };

    Object.entries(resourceGroups).forEach(([kind, group]) => {
        const filteredResources = (group.resources || []).filter(resource => {
            // Status filter (case-insensitive)
            if (filters.status && resource._health_status?.toLowerCase() !== filters.status.toLowerCase()) {
                return false;
            }

            // Search filter
            if (filters.search) {
                const searchFields = [
                    resource.metadata?.name,
                    resource.kind,
                    resource.apiVersion,
                    resource.provider,
                    resource.display_provider,
                    resource.providerconfig
                ].map(field => (field || '').toLowerCase());
                
                if (!searchFields.some(field => field.includes(filters.search))) {
                    return false;
                }
            }

            // Provider config filter
            if (filters.providerconfig && resource.providerconfig !== filters.providerconfig) {
                return false;
            }

            // Update health summary for matched resources
            const status = (resource._health_status || 'Unknown').toLowerCase();
            filteredHealthSummary[status === 'healthy' ? 'healthy' : 
                                status === 'unhealthy' ? 'unhealthy' : 
                                'unknown']++;
            return true;
        });

        if (filteredResources.length > 0) {
            filteredGroups[kind] = {
                resources: filteredResources,
                count: filteredResources.length
            };
            totalFilteredCount += filteredResources.length;
        }
    });

    // Update filtered data
    filteredData.resources = filteredGroups;
    filteredData.total_count = totalFilteredCount;
    filteredData.health_summary = filteredHealthSummary;

    // Update data with filtered results and update summary
    data = filteredData;
    updateSummaryCounts(filteredData);

    if (!data.resources || Object.keys(data.resources).length === 0) {
        contentContainer.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        return;
    }

    let isFirstTab = true;
    const cleanupFunctions = [];

    Object.entries(data.resources).forEach(([kind, groupData]) => {
        const tab = document.createElement('button');
        tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
            isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
        }`;
        tab.setAttribute('data-tab', kind);
        tab.innerHTML = `
            <span>${kind}</span>
            <span class="ml-2 text-sm text-gray-400">(${groupData.count || 0})</span>
        `;

        const contentPanel = document.createElement('div');
        contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
        contentPanel.setAttribute('data-tab-content', kind);

        // Create table header
        const tableHeader = document.createElement('div');
        tableHeader.className = 'grid grid-cols-4 gap-4 px-6 py-3 bg-gray-50 dark:bg-gray-800 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider border-b border-gray-200 dark:border-gray-700';
        tableHeader.innerHTML = `
            <div>NAME</div>
            <div>PROVIDER</div>
            <div>STATUS</div>
            <div class="text-right">ACTIONS</div>
        `;
        contentPanel.appendChild(tableHeader);

        // Create virtual scroll container
        const scrollContainer = document.createElement('div');
        scrollContainer.className = 'virtual-scroll-container';
        scrollContainer.style.height = `${Math.min(groupData.resources.length * ROW_HEIGHT, ROWS_PER_PAGE * ROW_HEIGHT)}px`;
        scrollContainer.style.overflowY = 'auto';
        scrollContainer.style.position = 'relative';

        // Initial render of visible rows
        const initialFragment = document.createDocumentFragment();
        const initialEnd = Math.min(ROWS_PER_PAGE + BUFFER_SIZE, groupData.resources.length);
        
        for (let i = 0; i < initialEnd; i++) {
            const row = createResourceRow(groupData.resources[i], i);
            initialFragment.appendChild(row);
        }
        scrollContainer.appendChild(initialFragment);

        // Event delegation for row interactions
        const handleRowClick = function(e) {
            const row = e.target.closest('.grid');
            if (!row) return;

            const yamlBtn = e.target.closest('.yaml-view-btn');
            if (yamlBtn) {
                e.stopPropagation();
                const index = parseInt(row.dataset.index);
                showYAMLInMonaco(groupData.resources[index]);
                return;
            }

            // Lazy load details on first expansion
            const details = row.querySelector('.managed-resource-details');
            if (details) {
                const isExpanded = details.style.display !== 'none';
                if (!isExpanded && !details.dataset.loaded) {
                    const index = parseInt(row.dataset.index);
                    details.innerHTML = renderManagedResourceDetails(groupData.resources[index]);
                    details.dataset.loaded = 'true';
                }
                details.style.display = isExpanded ? 'none' : 'block';
            }
        };

        scrollContainer.addEventListener('click', handleRowClick);
        cleanupFunctions.push(() => scrollContainer.removeEventListener('click', handleRowClick));

        // Optimized virtual scrolling
        let scrollTimeout;
        const handleScroll = _.throttle(function() {
            if (scrollTimeout) {
                clearTimeout(scrollTimeout);
            }

            scrollTimeout = setTimeout(() => {
                const scrollTop = this.scrollTop;
                const viewportHeight = this.clientHeight;
                
                const startIndex = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - BUFFER_SIZE);
                const endIndex = Math.min(
                    groupData.resources.length,
                    Math.ceil((scrollTop + viewportHeight) / ROW_HEIGHT) + BUFFER_SIZE
                );

                const existingRows = new Set(
                    Array.from(this.children).map(row => parseInt(row.dataset.index))
                );

                // Add new rows
                const fragment = document.createDocumentFragment();
                for (let i = startIndex; i < endIndex; i++) {
                    if (!existingRows.has(i)) {
                        const row = createResourceRow(groupData.resources[i], i);
                        fragment.appendChild(row);
                    }
                }
                this.appendChild(fragment);

                // Remove out-of-view rows
                const rowsToRemove = Array.from(this.children).filter(row => {
                    const index = parseInt(row.dataset.index);
                    return index < startIndex || index >= endIndex;
                });
                rowsToRemove.forEach(row => row.remove());
            }, 50);
        }, 100);

        scrollContainer.addEventListener('scroll', handleScroll);
        cleanupFunctions.push(() => {
            scrollContainer.removeEventListener('scroll', handleScroll);
            if (scrollTimeout) {
                clearTimeout(scrollTimeout);
            }
        });

        contentPanel.appendChild(scrollContainer);

        const handleTabClick = () => {
            document.querySelectorAll('[data-tab]').forEach(t => {
                t.classList.remove('text-blue-600', 'border-blue-600');
                t.classList.add('text-gray-500', 'border-transparent');
            });
            tab.classList.remove('text-gray-500', 'border-transparent');
            tab.classList.add('text-blue-600', 'border-blue-600');

            document.querySelectorAll('[data-tab-content]').forEach(p => {
                p.classList.add('hidden');
            });
            contentPanel.classList.remove('hidden');
        };

        tab.addEventListener('click', handleTabClick);
        cleanupFunctions.push(() => tab.removeEventListener('click', handleTabClick));

        tabsList.appendChild(tab);
        contentContainer.appendChild(contentPanel);
        
        isFirstTab = false;
    });

    // Update URL params to match filters
    const url = new URL(window.location);
    Object.entries(filters).forEach(([key, value]) => {
        if (value) {
            url.searchParams.set(key, value);
        } else {
            url.searchParams.delete(key);
        }
    });
    window.history.replaceState({}, '', url);

    // Set up filter handlers
    const searchInput = document.getElementById('resource-search');
    const statusFilterSelect = document.getElementById('status-filter');
    const providerConfigFilterSelect = document.getElementById('providerconfig-filter');

    // Debounced filter handler
    const handleFilter = _.debounce(() => {
        // Clean up existing event listeners
        cleanupFunctions.forEach(cleanup => cleanup());
        // Re-render with current filters
        if (window.originalResourceData) {
            const filteredData = structuredClone(window.originalResourceData);
            renderManagedResources(container, filteredData);
        }
    }, 300);

    if (searchInput) {
        searchInput.addEventListener('input', handleFilter);
        cleanupFunctions.push(() => searchInput.removeEventListener('input', handleFilter));
    }

    if (statusFilterSelect) {
        statusFilterSelect.addEventListener('change', handleFilter);
        cleanupFunctions.push(() => statusFilterSelect.removeEventListener('change', handleFilter));
    }

    if (providerConfigFilterSelect) {
        providerConfigFilterSelect.addEventListener('change', handleFilter);
        cleanupFunctions.push(() => providerConfigFilterSelect.removeEventListener('change', handleFilter));
    }

    // Set initial filter values from URL if not already set
    if (!window.filtersInitialized) {
        const searchParams = new URLSearchParams(window.location.search);
        const hasInitialFilters = searchParams.has('search') || searchParams.has('status') || searchParams.has('providerconfig');
        
        if (hasInitialFilters) {
            if (searchInput && searchParams.has('search')) {
                searchInput.value = searchParams.get('search');
            }
            if (statusFilterSelect && searchParams.has('status')) {
                const status = searchParams.get('status');
                if (['Healthy', 'Unhealthy', 'Unknown', ''].includes(status)) {
                    statusFilterSelect.value = status;
                }
            }
            if (providerConfigFilterSelect && searchParams.has('providerconfig')) {
                providerConfigFilterSelect.value = searchParams.get('providerconfig');
            }
            if (hasInitialFilters) {
                handleFilter();
            }
        }
        window.filtersInitialized = true;
    }

    // Return cleanup function
    return () => {
        cleanupFunctions.forEach(cleanup => cleanup());
    };
}

function updateSummaryCounts(data) {
    const elements = {
        total: document.getElementById('total-resources-count'),
        healthy: document.getElementById('healthy-resources-count'),
        unhealthy: document.getElementById('unhealthy-resources-count'),
        unknown: document.getElementById('unknown-resources-count')
    };

    const summary = data?.health_summary || { healthy: 0, unhealthy: 0, unknown: 0 };
    const total = data?.total_count || 0;

    if (elements.total) elements.total.textContent = total;
    if (elements.healthy) elements.healthy.textContent = summary.healthy || '0';
    if (elements.unhealthy) elements.unhealthy.textContent = summary.unhealthy || '0';
    if (elements.unknown) elements.unknown.textContent = summary.unknown || '0';

    return { ...summary, total };
}

function getHealthStatusClass(status) {
    switch (status) {
        case 'Healthy':
            return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
        case 'Unhealthy':
            return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
        default:
            return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
    }
}

function setStatusFilter(status) {
    const statusFilter = document.getElementById('status-filter');
    if (statusFilter) {
        statusFilter.value = status;
        statusFilter.dispatchEvent(new Event('change'));
    }
}

window.renderManagedResources = renderManagedResources;
window.setStatusFilter = setStatusFilter;
