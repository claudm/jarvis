import threading
import time
import logging
from models.crossplane_manager import CrossplaneManager

logger = logging.getLogger(__name__)

class BackgroundWorker:
    def __init__(self):
        self._stop_event = threading.Event()
        self._thread = None
        self.update_interval = 3 # Update every 60 seconds

    def start(self):
        """Start the background worker thread"""
        if self._thread is not None:
            logger.warning("Background worker already running")
            return

        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("Background worker started")

    def stop(self):
        """Stop the background worker thread"""
        if self._thread is None:
            logger.warning("Background worker not running")
            return

        self._stop_event.set()
        self._thread.join()
        self._thread = None
        self._stop_event.clear()
        logger.info("Background worker stopped")

    def _run(self):
        """Main worker loop"""
        while not self._stop_event.is_set():
            try:
                self._update_overview_cache()
            except Exception as e:
                logger.error(f"Error updating overview cache: {e}")

            # Sleep for the update interval, but check stop event every second
            for _ in range(self.update_interval):
                if self._stop_event.is_set():
                    break
                time.sleep(1)

    def _update_overview_cache(self):
        """Update the overview cache"""
        try:
            logger.debug("Updating overview cache")
            manager = CrossplaneManager.get_instance()
            # Force cache update by setting use_cache=False
            manager.get_system_overview(use_cache=False)
            logger.debug("Overview cache updated successfully")
        except Exception as e:
            logger.error(f"Failed to update overview cache: {e}")

# Global instance
_worker = BackgroundWorker()

def start_background_worker():
    """Start the background worker"""
    _worker.start()

def stop_background_worker():
    """Stop the background worker"""
    _worker.stop()
