from threading import Thread, Lock
import queue
import time
from typing import Dict, Optional
from app.models.crossplane_manager import CrossplaneManager

# Thread-safe queues and storage
operation_queue = queue.Queue()
operation_results: Dict[str, dict] = {}
operation_lock = Lock()

class BackgroundWorker(Thread):
    def __init__(self):
        super().__init__()
        self.running = True
        self.manager = CrossplaneManager()
        
    def run(self):
        while self.running:
            try:
                operation = operation_queue.get(timeout=1)
                if operation:
                    operation_id = operation["id"]
                    action = operation["action"]
                    
                    try:
                        result = self._process_operation(action, operation.get("data", {}))
                        with operation_lock:
                            operation_results[operation_id] = {
                                "status": "completed",
                                "result": result
                            }
                    except Exception as e:
                        with operation_lock:
                            operation_results[operation_id] = {
                                "status": "failed",
                                "error": str(e)
                            }
                    
                    operation_queue.task_done()
            except queue.Empty:
                continue
                
    def _process_operation(self, action: str, data: dict) -> dict:
        """
        Process different types of operations
        """
        if action == "list_compositions":
            compositions = self.manager.list_compositions()
            return {"compositions": compositions}
            
        elif action == "list_claims":
            namespace = data.get("namespace", "default")
            claims = self.manager.list_claims(namespace)
            return {"claims": claims}
            
        elif action == "get_managed_resources":
            resources = self.manager.get_managed_resources()
            return {"resources": resources}
            
        elif action == "create_composition":
            result = self.manager.create_composition(data.get("composition"))
            return {"composition": result}
            
        elif action == "update_composition":
            name = data.get("name")
            composition = data.get("composition")
            result = self.manager.update_composition(name, composition)
            return {"composition": result}
            
        elif action == "get_crossplane_crds":
            crds = self.manager.get_crossplane_crds()
            return {"crds": crds}
            
        elif action == "list_templates":
            templates = self.manager.list_templates()
            return {"templates": templates}
            
        else:
            raise ValueError(f"Unknown action: {action}")
            
    def stop(self):
        """
        Stop the background worker thread
        """
        self.running = False

# Create and start the worker thread
worker = BackgroundWorker()
worker.start()

def add_operation(action: str, data: Optional[dict] = None) -> str:
    """
    Add a new operation to the queue
    Returns the operation ID
    """
    operation_id = str(time.time())
    operation_queue.put({
        "id": operation_id,
        "action": action,
        "data": data or {}
    })
    return operation_id

def get_operation_result(operation_id: str, timeout: int = 10) -> Optional[dict]:
    """
    Get the result of an operation with timeout
    Returns None if operation times out
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        with operation_lock:
            if operation_id in operation_results:
                return operation_results.pop(operation_id)
        time.sleep(0.1)
    return None
