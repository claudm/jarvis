from kubernetes import client, config
from typing import List, Dict, Optional
import logging
import os
import threading
import time
import urllib3
import warnings

# Disable SSL verification warnings for local development
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseManager:
    _instance = None
    _lock = threading.Lock()
    _initialized = False
    _connection_retries = 5
    _retry_delay = 2  # seconds

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self.namespace = None  # Current namespace from ServiceAccount
            self._initialized = True
            self._closed = False

    def get_current_namespace(self) -> str:
        """Get the current namespace, defaults to 'default'"""
        return self.namespace or 'default'

    @classmethod
    def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    cls._instance.initialize_client()
        elif cls._instance._closed:
            with cls._lock:
                cls._instance.initialize_client()
        return cls._instance

    def close(self):
        """Close all connections"""
        try:
            if self.api_client:
                try:
                    self.api_client.close()
                except Exception as e:
                    logger.warning(f"Error closing Kubernetes API client: {e}")
                finally:
                    self.api_client = None
                    self.custom_api = None
                    self.api_ext = None
                    self._closed = True
        except Exception as e:
            logger.error(f"Error during connection cleanup: {e}")
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self._closed = True

    def cleanup(self):
        """Cleanup resources when application shuts down"""
        try:
            self.close()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
        finally:
            BaseManager._instance = None
            self._initialized = False
            self._closed = True

    def _ensure_connection(self):
        """Ensure connection is active, retry if needed"""
        for attempt in range(self._connection_retries):
            try:
                if not self._closed and self.verify_connection():
                    return True
                self.initialize_client()
                return True
            except Exception as e:
                if attempt == self._connection_retries - 1:
                    logger.error(f"Failed to ensure connection after {self._connection_retries} attempts: {e}")
                    return False
                logger.warning(f"Connection attempt {attempt + 1} failed: {e}")
                time.sleep(self._retry_delay)
        return False

    def initialize_client(self):
        """Initialize Kubernetes client"""
        try:
            self.close()

            configuration = client.Configuration()
            
            # SSL settings
            configuration.verify_ssl = False
            configuration.ssl_ca_cert = None
            configuration.assert_hostname = False
            
            # Connection settings
            configuration.connection_pool_maxsize = 32
            configuration.retries = 5
            configuration.timeout = 60
            
            # Proxy settings
            http_proxy = os.getenv('HTTP_PROXY')
            https_proxy = os.getenv('HTTPS_PROXY')
            proxy_user = os.getenv('PROXY_USER')
            proxy_pass = os.getenv('PROXY_PASS')

            if http_proxy or https_proxy:
                if http_proxy:
                    configuration.proxy = http_proxy
                if https_proxy:
                    configuration.proxy = https_proxy
                if proxy_user and proxy_pass:
                    configuration.proxy_headers = urllib3.make_headers(
                        proxy_basic_auth=f"{proxy_user}:{proxy_pass}"
                    )

            # Try loading in-cluster config first (ServiceAccount)
            try:
                # Check for service account token
                if os.path.exists('/var/run/secrets/kubernetes.io/serviceaccount/token'):
                    with open('/var/run/secrets/kubernetes.io/serviceaccount/token', 'r') as token_file:
                        configuration.api_key = {"authorization": f"Bearer {token_file.read().strip()}"}
                    
                    # Load CA cert if available
                    if os.path.exists('/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'):
                        configuration.ssl_ca_cert = '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
                    
                    # Get namespace
                    if os.path.exists('/var/run/secrets/kubernetes.io/serviceaccount/namespace'):
                        with open('/var/run/secrets/kubernetes.io/serviceaccount/namespace', 'r') as ns_file:
                            self.namespace = ns_file.read().strip()
                    
                    # Set cluster info
                    configuration.host = os.getenv('KUBERNETES_SERVICE_HOST', 'https://kubernetes.default.svc')
                    if os.getenv('KUBERNETES_SERVICE_PORT'):
                        configuration.host += f":{os.getenv('KUBERNETES_SERVICE_PORT')}"
                    
                    logger.info("Using in-cluster ServiceAccount configuration")
                else:
                    # Try standard in-cluster config
                    config.load_incluster_config(client_configuration=configuration)
                    logger.info("Using standard in-cluster configuration")
            except Exception as e:
                logger.debug(f"Not running in-cluster, trying kubeconfig: {e}")
                if os.path.exists(os.path.expanduser('~/.kube/config')):
                    config.load_kube_config(client_configuration=configuration)
                    logger.info("Using local kubeconfig configuration")
                else:
                    raise Exception("No valid Kubernetes configuration found")

            # Initialize with retry
            max_retries = 5
            retry_delay = 2
            last_error = None

            for attempt in range(max_retries):
                try:
                    self.api_client = client.ApiClient(configuration)
                    self.custom_api = client.CustomObjectsApi(self.api_client)
                    self.api_ext = client.ApiextensionsV1Api(self.api_client)
                    
                    # Test connection
                    self.api_ext.get_api_resources()
                    logger.info("Successfully connected to Kubernetes cluster")
                    self._closed = False
                    return
                except Exception as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        logger.warning(f"Connection attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
                        self.close()
                        time.sleep(retry_delay)
                    else:
                        logger.error(f"Failed to initialize Kubernetes client after {max_retries} attempts: {last_error}")
                        raise last_error

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}")
            raise

    def verify_connection(self) -> bool:
        """Verify connection is active"""
        try:
            if not all([self.api_client, self.custom_api, self.api_ext]):
                return False
            self.api_ext.get_api_resources()
            return True
        except:
            return False
