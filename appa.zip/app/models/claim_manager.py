from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from .resource_manager import ResourceManager

logger = logging.getLogger(__name__)

class ClaimManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.resource_manager = ResourceManager()
        self.namespace = self.get_current_namespace()

    def get_claim_events(self, name: str, namespace: str = None) -> List[dict]:
        """Get events for a specific claim"""
        try:
            if not self._ensure_connection():
                return []

            core_v1 = client.CoreV1Api(self.api_client)
            field_selector = f'involvedObject.name={name}'
            events = core_v1.list_namespaced_event(namespace=namespace, field_selector=field_selector)
            return [
                {
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'timestamp': event.last_timestamp.isoformat() if event.last_timestamp else None,
                    'count': event.count
                }
                for event in events.items
            ]
        except Exception as e:
            logger.error(f"Error getting claim events: {e}")
            return []

    def list_claims(self, namespace: str = None) -> List[dict]:
        """Lista todas as claims em um namespace específico com dados relacionados"""
        try:
            if not self._ensure_connection():
                return []

            # Use ServiceAccount namespace if none provided
            namespace = namespace or self.namespace
            logger.debug(f"Listing claims in namespace {namespace}")

            claims = []
            crds = self.resource_manager.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'claim' in categories:
                    try:
                        response = self.custom_api.list_namespaced_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            namespace=namespace,
                            plural=crd['name'].split('.')[0].lower()
                        )
                        for item in response.get("items", []):
                            # Add resource type info
                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }

                            # Get composition reference
                            composition_ref = item.get('spec', {}).get('compositionRef', {})
                            if composition_ref and composition_ref.get('name'):
                                try:
                                    composition = self.custom_api.get_cluster_custom_object(
                                        group="apiextensions.crossplane.io",
                                        version="v1",
                                        plural="compositions",
                                        name=composition_ref['name']
                                    )
                                    item['composition'] = {
                                        'name': composition['metadata']['name'],
                                        'ready': True  # Compositions are always ready if they exist
                                    }
                                except:
                                    item['composition'] = {
                                        'name': composition_ref['name'],
                                        'ready': False
                                    }

                            # Get composite resource reference
                            composite_ref = item.get('spec', {}).get('resourceRef', {})
                            if composite_ref and composite_ref.get('name'):
                                try:
                                    composite = self.custom_api.get_cluster_custom_object(
                                        group=composite_ref.get('apiVersion', '').split('/')[0],
                                        version=composite_ref.get('apiVersion', '').split('/')[1],
                                        plural=composite_ref['kind'].lower() + 's',
                                        name=composite_ref['name']
                                    )
                                    conditions = composite.get('status', {}).get('conditions', [])
                                    ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
                                    item['compositeResource'] = {
                                        'name': composite['metadata']['name'],
                                        'ready': ready_condition.get('status') == 'True'
                                    }
                                except:
                                    item['compositeResource'] = {
                                        'name': composite_ref['name'],
                                        'ready': False
                                    }

                            # Get events for both claim and composite resource
                            claim_events = self.get_claim_events(item['metadata']['name'], namespace)
                            composite_events = []
                            if item.get('compositeResource', {}).get('name'):
                                composite_events = self.get_claim_events(
                                    item['compositeResource']['name'],
                                    namespace
                                )
                            
                            # Combine and sort events
                            all_events = [*claim_events, *composite_events]
                            all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
                            
                            # Keep only the 10 most recent events
                            item['events'] = all_events[:10]
                            claims.append(item)
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing claims for {crd['kind']}: {e}")
                    
            return claims
        except Exception as e:
            logger.error(f"Error listing claims: {e}")
            return []

    def get_claim(self, name: str, namespace: str = None) -> Optional[dict]:
        """Get a specific claim by name"""
        try:
            if not self._ensure_connection():
                return None

            # Use ServiceAccount namespace if none provided
            namespace = namespace or self.namespace
            logger.debug(f"Getting claim {name} in namespace {namespace}")

            crds = self.resource_manager.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'claim' in categories:
                    try:
                        # Try to get the claim from each claim CRD
                        try:
                            claim = self.custom_api.get_namespaced_custom_object(
                                group=crd['group'],
                                version=crd['version'],
                                namespace=namespace,
                                plural=crd['name'].split('.')[0].lower(),
                                name=name
                            )

                            # Add resource type info
                            claim['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }

                            # Get composition reference
                            composition_ref = claim.get('spec', {}).get('compositionRef', {})
                            if composition_ref and composition_ref.get('name'):
                                try:
                                    composition = self.custom_api.get_cluster_custom_object(
                                        group="apiextensions.crossplane.io",
                                        version="v1",
                                        plural="compositions",
                                        name=composition_ref['name']
                                    )
                                    claim['composition'] = {
                                        'name': composition['metadata']['name'],
                                        'ready': True
                                    }
                                except:
                                    claim['composition'] = {
                                        'name': composition_ref['name'],
                                        'ready': False
                                    }

                            # Get composite resource reference
                            composite_ref = claim.get('spec', {}).get('resourceRef', {})
                            if composite_ref and composite_ref.get('name'):
                                try:
                                    composite = self.custom_api.get_cluster_custom_object(
                                        group=composite_ref.get('apiVersion', '').split('/')[0],
                                        version=composite_ref.get('apiVersion', '').split('/')[1],
                                        plural=composite_ref['kind'].lower() + 's',
                                        name=composite_ref['name']
                                    )
                                    conditions = composite.get('status', {}).get('conditions', [])
                                    ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
                                    claim['compositeResource'] = {
                                        'name': composite['metadata']['name'],
                                        'ready': ready_condition.get('status') == 'True'
                                    }
                                except:
                                    claim['compositeResource'] = {
                                        'name': composite_ref['name'],
                                        'ready': False
                                    }

                            # Get events for both claim and composite resource
                            claim_events = self.get_claim_events(name, namespace)
                            composite_events = []
                            if claim.get('compositeResource', {}).get('name'):
                                composite_events = self.get_claim_events(
                                    claim['compositeResource']['name'],
                                    namespace
                                )
                            
                            # Combine and sort events
                            all_events = [*claim_events, *composite_events]
                            all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
                            
                            # Keep only the 10 most recent events
                            claim['events'] = all_events[:10]

                            return claim
                        except client.ApiException as e:
                            if e.status != 404:
                                logger.warning(f"Error getting claim {name} from {crd['kind']}: {e}")
                    except Exception as e:
                        logger.error(f"Error processing claim {name}: {e}")

            return None
        except Exception as e:
            logger.error(f"Error getting claim: {e}")
            return None
