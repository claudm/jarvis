from typing import List, Dict, Optional, Tuple
import logging
from kubernetes import client, watch
import threading
import time
from queue import Queue
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

# Cache for CRD scope information and resources
crd_scope_cache = {}
resource_cache = {}
resource_lock = threading.Lock()
resource_queue = Queue()

class ResourceWatcher(threading.Thread):
    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.daemon = True
        self._stop_event = threading.Event()
        self.w = watch.Watch()

    def stop(self):
        self._stop_event.set()
        self.w.stop()

    def run(self):
        while not self._stop_event.is_set():
            try:
                # Get initial resources
                resources = self.manager._fetch_all_resources()
                with resource_lock:
                    resource_cache.clear()
                    resource_cache.update(resources)

                # Watch for changes
                crds = self.manager.get_crossplane_crds()
                for crd in crds:
                    if 'managed' in crd.get('categories', []):
                        self._watch_resources(crd)

            except Exception as e:
                logger.error(f"Error in watch thread: {e}")
                time.sleep(5)  # Wait before retrying

    def _watch_resources(self, crd):
        """Watch resources for a specific CRD"""
        try:
            is_namespaced = self.manager._get_crd_scope(crd['name'])
            plural = crd['name'].split('.')[0].lower()

            if is_namespaced:
                stream = self.w.stream(
                    self.manager.custom_api.list_namespaced_custom_object,
                    group=crd['group'],
                    version=crd['version'],
                    namespace=self.manager.namespace,
                    plural=plural,
                    timeout_seconds=60
                )
            else:
                stream = self.w.stream(
                    self.manager.custom_api.list_cluster_custom_object,
                    group=crd['group'],
                    version=crd['version'],
                    plural=plural,
                    timeout_seconds=60
                )

            for event in stream:
                if self._stop_event.is_set():
                    break

                event_type = event['type']
                obj = event['object']
                
                with resource_lock:
                    kind = crd['kind']
                    if event_type in ['ADDED', 'MODIFIED']:
                        if kind not in resource_cache:
                            resource_cache[kind] = []
                        resource_cache[kind].append(obj)
                    elif event_type == 'DELETED':
                        if kind in resource_cache:
                            resource_cache[kind] = [
                                r for r in resource_cache[kind]
                                if r['metadata']['name'] != obj['metadata']['name']
                            ]

        except Exception as e:
            logger.error(f"Error watching resources for {crd['kind']}: {e}")

class ResourceManager(BaseManager):
    def __init__(self):
        super().__init__()
        if self._ensure_connection():
            self.namespace = self.get_current_namespace()
            self.watcher = ResourceWatcher(self)
            self.watcher.start()
        else:
            logger.error("Failed to initialize Kubernetes client")

    def get_crossplane_crds(self) -> List[dict]:
        """Get Crossplane CRDs"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            crd_list = self.api_ext.list_custom_resource_definition()
            
            if not crd_list or not hasattr(crd_list, 'items'):
                logger.warning("No CRDs found in the cluster")
                return []

            crossplane_crds = []
            for crd in crd_list.items:
                if not hasattr(crd, 'spec') or not hasattr(crd.spec, 'group'):
                    continue

                categories = getattr(crd.spec.names, 'categories', []) or []
                is_crossplane = (
                    'crossplane.io' in crd.spec.group or
                    any(cat in ['crossplane', 'managed', 'claim', 'composite']
                        for cat in categories)
                )

                if is_crossplane:
                    crossplane_crds.append({
                        'name': crd.metadata.name,
                        'kind': crd.spec.names.kind,
                        'group': crd.spec.group,
                        'version': crd.spec.versions[0].name if crd.spec.versions else '',
                        'scope': crd.spec.scope,
                        'categories': list(getattr(crd.spec.names, 'categories', []) or [])
                    })

            return crossplane_crds

        except Exception as e:
            logger.error(f"Error getting Crossplane CRDs: {e}")
            return []

    def _get_crd_scope(self, crd_name: str) -> bool:
        """Get CRD scope with caching"""
        if crd_name in crd_scope_cache:
            return crd_scope_cache[crd_name]
        
        try:
            crd_obj = self.api_ext.read_custom_resource_definition(crd_name)
            is_namespaced = crd_obj.spec.scope == "Namespaced"
            crd_scope_cache[crd_name] = is_namespaced
            return is_namespaced
        except Exception as e:
            logger.debug(f"Error checking CRD scope: {e}")
            return False

    def _extract_provider_info(self, group: str) -> Tuple[str, str]:
        """Extract provider and display provider from group"""
        if group.startswith('provider-'):
            provider = group.split('.')[0]
            display_provider = provider.replace('provider-', '')
        elif group.endswith('.crossplane.io'):
            base = group.replace('.crossplane.io', '')
            if '.' in base:
                provider = f"provider-{base.split('.')[1]}"
                display_provider = base
            else:
                provider = f"provider-{base}"
                display_provider = base
        elif '.' in group:
            parts = group.split('.')
            if len(parts) >= 2:
                provider = f"provider-{parts[1]}"
                display_provider = f"{parts[0]}.{parts[1]}"
            else:
                provider = group
                display_provider = group
        else:
            provider = group
            display_provider = group
        return provider, display_provider

    def _fetch_resources_for_crd(self, crd: dict) -> List[dict]:
        """Fetch resources for a single CRD"""
        try:
            is_namespaced = self._get_crd_scope(crd['name'])
            plural = crd['name'].split('.')[0].lower()

            if is_namespaced:
                response = self.custom_api.list_namespaced_custom_object(
                    group=crd['group'],
                    version=crd['version'],
                    namespace=self.namespace,
                    plural=plural
                )
            else:
                response = self.custom_api.list_cluster_custom_object(
                    group=crd['group'],
                    version=crd['version'],
                    plural=plural
                )

            resources = []
            provider, display_provider = self._extract_provider_info(crd['group'])

            for item in response.get("items", []):
                conditions = item.get('status', {}).get('conditions', [])
                health_status = next((
                    'Healthy' if c.get('status') == 'True' else 'Unhealthy'
                    for c in conditions if c.get('type') == 'Ready'
                ), 'Unknown')
                
                synced_status = next((
                    'Synced' if c.get('status') == 'True' else 'Not Synced'
                    for c in conditions if c.get('type') == 'Synced'
                ), 'Unknown')

                spec = item.get('spec', {})
                providerconfig_ref = (
                    spec.get('providerConfigRef', {}).get('name') or
                    spec.get('providerRef', {}).get('name')
                )

                item.update({
                    '_resource_type': {
                        'kind': crd['kind'],
                        'group': crd['group'],
                        'version': crd['version']
                    },
                    '_health_status': health_status,
                    '_synced_status': synced_status,
                    'provider': provider,
                    'display_provider': display_provider,
                    'providerconfig': providerconfig_ref
                })
                resources.append(item)

            return resources
        except client.ApiException as e:
            if e.status != 404:
                logger.warning(f"Error listing managed resources for {crd['kind']}: {e}")
            return []
        except Exception as e:
            logger.error(f"Error fetching resources for CRD {crd['name']}: {e}")
            return []

    def _fetch_all_resources(self) -> Dict:
        """Fetch all resources and return as a dictionary"""
        try:
            if not self._ensure_connection():
                return {}

            crds = self.get_crossplane_crds()
            managed_crds = [crd for crd in (crds or [])
                          if 'managed' in (crd.get('categories', []) or [])]

            all_resources = {}
            for crd in managed_crds:
                resources = self._fetch_resources_for_crd(crd)
                if resources:
                    all_resources[crd['kind']] = resources

            return all_resources

        except Exception as e:
            logger.error(f"Error fetching all resources: {e}")
            return {}

    def get_managed_resources(self) -> List[dict]:
        """Get all managed resources from cache"""
        with resource_lock:
            # Flatten the cached resources
            return [
                resource
                for resources in resource_cache.values()
                for resource in resources
            ]

    def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        """Get a specific resource"""
        try:
            if not self._ensure_connection():
                return None

            # Use ServiceAccount namespace if none provided and resource is namespaced
            try:
                crd = self.api_ext.read_custom_resource_definition(f"{plural}.{group}")
                if crd.spec.scope == "Namespaced":
                    namespace = namespace or self.namespace
            except Exception as e:
                logger.debug(f"Error checking CRD scope: {e}")

            if namespace:
                logger.debug(f"Getting namespaced resource {name} in namespace {namespace}")
                return self.custom_api.get_namespaced_custom_object(
                    group=group,
                    version=version,
                    namespace=namespace,
                    plural=plural,
                    name=name
                )
            else:
                logger.debug(f"Getting cluster-scoped resource {name}")
                return self.custom_api.get_cluster_custom_object(
                    group=group,
                    version=version,
                    plural=plural,
                    name=name
                )
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Resource {name} not found")
            else:
                logger.error(f"Error getting resource: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting resource: {e}")
            return None
