// providers.js - Providers functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderProviderDetails(provider) {
    const status = provider.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
    
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';
    const healthyTime = healthyCondition.lastTransitionTime ? 
        formatTimeAgo(healthyCondition.lastTransitionTime) : '';

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${provider.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${provider.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Package</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${provider.spec?.package || 'Unknown'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(provider.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            readyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${readyCondition.status === 'True' ? 'Ready' : 'Not Ready'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500">${readyTime}</span>` : ''}
                        ${readyCondition.message ? `<span class="text-sm text-gray-600">${readyCondition.message}</span>` : ''}
                    </div>
                    ${healthyCondition ? `
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                healthyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                            }">
                                ${healthyCondition.status === 'True' ? 'Healthy' : 'Not Healthy'}
                            </span>
                            ${healthyTime ? `<span class="text-xs text-gray-500">${healthyTime}</span>` : ''}
                        </div>
                    ` : ''}
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Custom Resource Definitions</h3>
                <div id="crds-${provider.metadata?.name}" class="space-y-3">
                    <div class="text-sm text-gray-500 dark:text-gray-400">Loading CRDs...</div>
                </div>
            </div>

            ${provider._config_type === 'aws' ? `
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">AWS Configuration</h3>
                    <div class="space-y-4">
                        ${provider._endpoint_type ? `
                            <div>
                                <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Endpoint</h4>
                                <div class="bg-gray-50 dark:bg-gray-700 rounded p-3">
                                    <div class="flex items-center space-x-2">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                            provider._endpoint_type === 'static' ?
                                            'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200' :
                                            'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200'
                                        }">
                                            ${provider._endpoint_type}
                                        </span>
                                        ${provider._endpoint_url ? `
                                            <span class="text-sm text-gray-600 dark:text-gray-300">${provider._endpoint_url}</span>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        ` : ''}
                        ${provider._credentials_type ? `
                            <div>
                                <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Credentials</h4>
                                <div class="bg-gray-50 dark:bg-gray-700 rounded p-3">
                                    <div class="flex items-center space-x-2">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                            provider._credentials_type === 'secret' ?
                                            'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' :
                                            'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                                        }">
                                            ${provider._credentials_type}
                                        </span>
                                        ${provider._credentials_secret ? `
                                            <span class="text-sm text-gray-600 dark:text-gray-300">
                                                Secret: ${provider._credentials_secret.name}
                                                ${provider._credentials_secret.namespace ? `(${provider._credentials_secret.namespace})` : ''}
                                            </span>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        ` : ''}
                    </div>
                </div>
            ` : ''}

            ${provider.events && provider.events.length > 0 ? `
                <div>
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                    <div class="space-y-3">
                        ${provider.events.slice(0, 10).map(event => `
                            <div class="flex items-start space-x-3">
                                <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                                    event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                                }"></span>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                                        ${event.reason}
                                        <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.timestamp)}</span>
                                    </p>
                                    <p class="text-sm text-gray-500">${event.message}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function renderProviders(container, providers) {
    if (!providers.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No providers found</div>';
        return;
    }

    container.innerHTML = ''; // Clear container before rendering
    providers.forEach(provider => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
        });
        
        let isExpanded = false;
        const expandedContent = renderProviderDetails(provider);
        
        // Add click handler to the entire card
        card.addEventListener('click', async () => {
            isExpanded = !isExpanded;
            const contentSection = card.querySelector('.provider-details');
            if (isExpanded) {
                contentSection.style.display = 'block';
                card.classList.add('expanded');
                // Load CRDs when expanded
                const providerName = provider.metadata?.name;
                if (providerName) {
                    await loadProviderCRDs(providerName);
                }
            } else {
                contentSection.style.display = 'none';
                card.classList.remove('expanded');
            }
        });

        const status = provider.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
        
        const isReady = readyCondition.status === 'True';
        const isHealthy = healthyCondition?.status === 'True';

        const creationTime = provider.metadata?.creationTimestamp ? 
            formatTimeAgo(provider.metadata.creationTimestamp) : 'Unknown';

        card.innerHTML = `
            <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700 sm:px-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <div>
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white cursor-pointer hover:underline" onclick="event.stopPropagation(); switchTab('managed-resources', { search: '${provider.metadata?.name || ''}' });">
                                ${provider.metadata?.name || 'Unnamed'}
                                <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${provider.apiVersion || ''}</span>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                Package: ${provider.spec?.package || 'Unknown'} | Created: ${creationTime}
                            </p>
                        </div>
                        <button onclick="event.stopPropagation(); copyToClipboard(${JSON.stringify(provider)})"
                                class="p-1 text-gray-400 hover:text-gray-500"
                                title="Copy YAML">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                    <div class="flex flex-col space-y-2">
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                            }">
                                ${isReady ? 'Ready' : 'Not Ready'}
                            </span>
                        </div>
                        ${healthyCondition ? `
                            <div class="flex items-center space-x-2">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                    isHealthy ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                                }">
                                    ${isHealthy ? 'Healthy' : 'Not Healthy'}
                                </span>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
            <div class="provider-details" style="display: none;">
                ${expandedContent}
            </div>
        `;

        container.appendChild(card);
    });

    // Initialize provider search
    initializeProviderSearch();
}

function initializeProviderSearch() {
    const providerSearch = document.getElementById('provider-search');
    if (providerSearch) {
        // Show the search container when on providers tab
        const searchContainer = document.getElementById('provider-search-container');
        if (searchContainer) {
            searchContainer.classList.remove('hidden');
        }

        providerSearch.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const providersList = document.getElementById('providers-list');
            if (providersList) {
                const providers = providersList.children;
                Array.from(providers).forEach(provider => {
                    const name = provider.querySelector('h3').textContent.toLowerCase();
                    const package = provider.querySelector('p').textContent.toLowerCase();
                    if (name.includes(searchTerm) || package.includes(searchTerm)) {
                        provider.style.display = '';
                    } else {
                        provider.style.display = 'none';
                    }
                });
            }
        });
    }
}

async function fetchProviderCRDs(providerName) {
    try {
        const response = await fetch(`/api/providers/${providerName}/crds`);
        if (!response.ok) {
            throw new Error(`Failed to fetch CRDs: ${response.statusText}`);
        }
        const data = await response.json();
        return data.crds;
    } catch (error) {
        console.error('Error fetching provider CRDs:', error);
        return [];
    }
}

async function fetchProviderCRDsStatus(providerName) {
    try {
        const response = await fetch(`/api/providers/${providerName}/crds/status`);
        if (!response.ok) {
            throw new Error(`Failed to fetch CRDs status: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching provider CRDs status:', error);
        return null;
    }
}

function renderCRDsList(crds, container) {
    if (!crds || crds.length === 0) {
        container.innerHTML = '<div class="text-sm text-gray-500 dark:text-gray-400">No CRDs found for this provider</div>';
        return;
    }

    const crdsList = crds.map(crd => `
        <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div class="flex items-center justify-between">
                <div>
                    <h4 class="text-sm font-medium text-gray-900 dark:text-white">${crd.kind}</h4>
                    <p class="text-xs text-gray-500 dark:text-gray-400">
                        Group: ${crd.group} | Versions: ${crd.versions.join(', ')}
                    </p>
                </div>
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    crd.scope === 'Cluster' ?
                    'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200' :
                    'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'
                }">
                    ${crd.scope}
                </span>
            </div>
            ${crd.description ? `
                <p class="mt-2 text-sm text-gray-600 dark:text-gray-300">
                    ${crd.description}
                </p>
            ` : ''}
        </div>
    `).join('');

    container.innerHTML = crdsList;
}

async function loadProviderCRDs(providerName) {
    const container = document.getElementById(`crds-${providerName}`);
    if (!container) return;

    try {
        const [crds, status] = await Promise.all([
            fetchProviderCRDs(providerName),
            fetchProviderCRDsStatus(providerName)
        ]);

        if (status) {
            container.innerHTML = `
                <div class="mb-4">
                    <div class="flex items-center space-x-4">
                        <div class="flex-1">
                            <div class="flex items-center space-x-2">
                                <span class="text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Total CRDs: ${status.total_crds}
                                </span>
                                <span class="text-sm text-gray-500 dark:text-gray-400">|</span>
                                <span class="text-sm font-medium text-green-700 dark:text-green-300">
                                    Established: ${status.established_crds}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            renderCRDsList(crds, container);
        } else {
            renderCRDsList(crds, container);
        }
    } catch (error) {
        console.error('Error loading provider CRDs:', error);
        container.innerHTML = `
            <div class="text-sm text-red-600 dark:text-red-400">
                Failed to load CRDs: ${error.message}
            </div>
        `;
    }
}

function copyToClipboard(data) {
    // Format the YAML content
    const yamlContent = `apiVersion: ${data.apiVersion}
kind: ${data.kind}
metadata:
  creationTimestamp: "${data.metadata?.creationTimestamp || ''}"
  finalizers:${data.metadata?.finalizers?.map(f => `\n    - ${f}`).join('') || ''}
  generation: ${data.metadata?.generation || 1}
  labels:${Object.entries(data.metadata?.labels || {}).map(([k, v]) => `\n    ${k}: ${v}`).join('')}
  name: ${data.metadata?.name || ''}
  resourceVersion: "${data.metadata?.resourceVersion || ''}"
  uid: ${data.metadata?.uid || ''}
spec:${Object.entries(data.spec || {}).map(([k, v]) => `\n  ${k}: ${JSON.stringify(v, null, 2).replace(/\n/g, '\n  ')}`).join('')}
status:${Object.entries(data.status || {}).map(([k, v]) => `\n  ${k}: ${JSON.stringify(v, null, 2).replace(/\n/g, '\n  ')}`).join('')}`;

    // Create temporary textarea
    const textarea = document.createElement('textarea');
    textarea.value = yamlContent;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'absolute';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);

    try {
        // Select and copy text
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);

        // Show success notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50';
        notification.textContent = 'YAML copied to clipboard';
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 2000);
    } catch (err) {
        console.error('Failed to copy YAML:', err);
        // Show error notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50';
        notification.textContent = 'Failed to copy YAML';
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 2000);
    } finally {
        // Cleanup
        if (document.body.contains(textarea)) {
            document.body.removeChild(textarea);
        }
    }
}

function showManagedResources(providerName) {
    // Update the managed resources view without URL navigation
    const managedResourcesContainer = document.getElementById('managed-resources-container');
    if (managedResourcesContainer) {
        // Hide other views
        document.querySelectorAll('.view-container').forEach(container => {
            container.style.display = 'none';
        });
        // Show managed resources view
        managedResourcesContainer.style.display = 'block';
        // Load managed resources for this provider
        if (window.loadManagedResources) {
            window.loadManagedResources(providerName);
        }
    }
}

// Export functions
window.renderProviders = renderProviders;
window.loadProviderCRDs = loadProviderCRDs;
window.showManagedResources = showManagedResources;
