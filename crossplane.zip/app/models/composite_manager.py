from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

logger = logging.getLogger(__name__)

# Constants for thread pooling
MAX_WORKERS = 10
BATCH_SIZE = 50

class CompositeManager(BaseManager):
    _thread_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
    _lock = threading.Lock()

    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def _fetch_managed_resources(self, owner_name: str) -> List[dict]:
        """Fetch and process managed resources concurrently"""
        try:
            managed_crds = [crd for crd in self.get_crossplane_crds() 
                          if 'managed' in (crd.get('categories', []) or [])]
            
            managed_resources = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = []
                for mcrd in managed_crds:
                    # Managed resources are cluster-scoped
                    future = executor.submit(
                        self.get_resource,
                        group=mcrd['group'],
                        version=mcrd['version'],
                        plural=mcrd['name'].split('.')[0].lower(),
                        name=""  # Empty name for list operation
                    )
                    futures.append(future)
                
                for future in as_completed(futures):
                    try:
                        response = future.result()
                        if response:
                            managed_resources.extend(response.get('items', []))
                    except Exception as e:
                        logger.debug(f"Error fetching managed resources: {e}")

            related_resources = []
            for resource in managed_resources:
                owner_refs = resource.get('metadata', {}).get('ownerReferences', [])
                if any(ref.get('name') == owner_name for ref in owner_refs):
                    conditions = resource.get('status', {}).get('conditions', [])
                    synced_condition = next((c for c in conditions if c['type'] == 'Synced'), {})
                    related_resources.append({
                        'name': resource['metadata']['name'],
                        'kind': resource.get('kind', ''),
                        'synced': synced_condition.get('status') == 'True',
                        'apiVersion': resource.get('apiVersion', ''),
                        'spec': resource.get('spec', {}),
                        'status': resource.get('status', {})
                    })
            return related_resources
        except Exception as e:
            logger.debug(f"Error processing managed resources: {e}")
            return []

    def _fetch_resources_for_crd(self, crd: dict) -> List[dict]:
        """Fetch resources for a specific CRD"""
        try:
            plural = crd['name'].split('.')[0].lower()
            # For composite resources, we want cluster-scoped resources
            response = self.get_resource(
                group=crd['group'],
                version=crd['version'],
                plural=plural,
                name=""  # Empty name for list operation
            )
            return response.get('items', []) if response else []
        except Exception as e:
            logger.debug(f"Error fetching resources for CRD {crd['name']}: {e}")
            return []

    def _process_composite_resource(self, item: dict, crd: dict) -> dict:
        """Process a single composite resource"""
        try:
            # Process conditions
            conditions = item.get('status', {}).get('conditions', [])
            health_status = 'Unknown'
            synced_status = 'Unknown'
            
            for condition in conditions:
                condition_type = condition.get('type')
                if condition_type == 'Ready':
                    health_status = 'Healthy' if condition.get('status') == 'True' else 'Unhealthy'
                elif condition_type == 'Synced':
                    synced_status = 'Synced' if condition.get('status') == 'True' else 'Not Synced'

            # Extract provider info
            group = crd['group']
            provider = None
            display_provider = None

            if group.startswith('provider-'):
                provider = group.split('.')[0]
                display_provider = provider.replace('provider-', '')
            elif group.endswith('.crossplane.io'):
                base = group.replace('.crossplane.io', '')
                if '.' in base:
                    provider = f"provider-{base.split('.')[1]}"
                    display_provider = base
                else:
                    provider = f"provider-{base}"
                    display_provider = base
            elif group.endswith('.upbound.io'):
                base = group.replace('.upbound.io', '')
                if '.' in base:
                    provider = f"provider-{base.split('.')[1]}"
                    display_provider = base
                else:
                    provider = f"provider-{base}"
                    display_provider = base
            elif '.' in group:
                parts = group.split('.')
                if len(parts) >= 2:
                    provider = f"provider-{parts[1]}"
                    display_provider = f"{parts[0]}.{parts[1]}"

            # Process Upbound info
            metadata = item.get('metadata', {})
            annotations = metadata.get('annotations', {})
            labels = metadata.get('labels', {})
            upbound_info = None

            if ('meta.upbound.io/configuration' in annotations or
                'upbound.io/configuration' in labels or
                any(key.startswith('upbound.io/') for key in labels.keys())):
                upbound_info = {
                    'configuration': (
                        labels.get('upbound.io/configuration') or 
                        annotations.get('meta.upbound.io/configuration')
                    ),
                    'version': labels.get('upbound.io/version'),
                    'source': 'upbound-format'
                }

            # Initialize processed item
            processed_item = {
                **item,
                '_resource_type': {
                    'kind': crd['kind'],
                    'group': crd['group'],
                    'version': crd['version']
                },
                '_health_status': health_status,
                '_synced_status': synced_status,
                'provider': provider,
                'display_provider': display_provider or provider
            }

            if upbound_info:
                processed_item['upbound'] = upbound_info

            # Process provider config
            provider_config_ref = item.get('spec', {}).get('providerConfigRef', {})
            if provider_config_ref and provider_config_ref.get('name'):
                try:
                    api_version = provider_config_ref.get('apiVersion', '').split('/')
                    provider_config = self.get_resource(
                        group=api_version[0],
                        version=api_version[1],
                        plural="providerconfigs",
                        name=provider_config_ref['name']
                    )
                    processed_item['providerConfig'] = {
                        'name': provider_config['metadata']['name'],
                        'ready': True
                    }
                except:
                    processed_item['providerConfig'] = {
                        'name': provider_config_ref['name'],
                        'ready': False
                    }

            # Process composition
            composition_ref = item.get('spec', {}).get('compositionRef', {})
            if composition_ref and composition_ref.get('name'):
                try:
                    composition = self.get_resource(
                        group="apiextensions.crossplane.io",
                        version="v1",
                        plural="compositions",
                        name=composition_ref['name']
                    )
                    processed_item['composition'] = {
                        'name': composition['metadata']['name'],
                        'ready': True
                    }

                    # Get provider config from composition if not already set
                    if not processed_item.get('providerConfig'):
                        comp_provider_config_ref = composition.get('spec', {}).get('providerConfigRef', {})
                        if comp_provider_config_ref and comp_provider_config_ref.get('name'):
                            try:
                                api_version = comp_provider_config_ref.get('apiVersion', '').split('/')
                                provider_config = self.get_resource(
                                    group=api_version[0],
                                    version=api_version[1],
                                    plural="providerconfigs",
                                    name=comp_provider_config_ref['name']
                                )
                                processed_item['providerConfig'] = {
                                    'name': provider_config['metadata']['name'],
                                    'ready': True,
                                    'from': 'composition'
                                }
                            except:
                                processed_item['providerConfig'] = {
                                    'name': comp_provider_config_ref['name'],
                                    'ready': False,
                                    'from': 'composition'
                                }
                except:
                    processed_item['composition'] = {
                        'name': composition_ref['name'],
                        'ready': False
                    }

            # Process managed resources and claims concurrently
            with ThreadPoolExecutor(max_workers=2) as executor:
                managed_resources_future = executor.submit(
                    self._fetch_managed_resources,
                    item['metadata']['name']
                )
                claims_future = executor.submit(
                    self._fetch_claims,
                    item['metadata']['name']
                )

                processed_item['managedResources'] = managed_resources_future.result()
                processed_item['claims'] = claims_future.result()

            return processed_item
        except Exception as e:
            logger.error(f"Error processing composite resource: {e}")
            return item

    def _fetch_claims(self, resource_name: str) -> List[dict]:
        """Fetch and process claims concurrently"""
        try:
            claim_crds = [crd for crd in self.get_crossplane_crds() 
                         if 'claim' in (crd.get('categories', []) or [])]
            
            claims = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = []
                for ccrd in claim_crds:
                    plural = ccrd['name'].split('.')[0].lower()
                    future = executor.submit(
                        self.get_resource,
                        group=ccrd['group'],
                        version=ccrd['version'],
                        plural=plural,
                        name="",  # Empty name for list operation
                        namespace=self.namespace
                    )
                    futures.append(future)
                
                for future in as_completed(futures):
                    try:
                        response = future.result()
                        if response:
                            claims.extend(response.get('items', []))
                    except Exception as e:
                        logger.debug(f"Error fetching claims: {e}")

            return [
                {
                    'name': claim['metadata']['name'],
                    'ready': claim.get('compositeResource', {}).get('ready', False),
                    'apiVersion': claim.get('apiVersion', ''),
                    'kind': claim.get('kind', ''),
                    'spec': claim.get('spec', {}),
                    'status': claim.get('status', {})
                }
                for claim in claims
                if claim.get('spec', {}).get('resourceRef', {}).get('name') == resource_name
            ]
        except Exception as e:
            logger.debug(f"Error processing claims: {e}")
            return []

    def get_composite_resources(self) -> List[dict]:
        """Get all composite resources with concurrent processing"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            # Get composite CRDs
            crds = self.get_crossplane_crds()
            composite_crds = [
                crd for crd in (crds or [])
                if 'composite' in (crd.get('categories', []) or [])
            ]

            resources = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                # First, fetch all resources for all CRDs concurrently
                crd_futures = {
                    executor.submit(self._fetch_resources_for_crd, crd): crd
                    for crd in composite_crds
                }

                # Process results as they complete
                for future in as_completed(crd_futures):
                    crd = crd_futures[future]
                    try:
                        items = future.result()
                        # Process each resource concurrently
                        resource_futures = [
                            executor.submit(self._process_composite_resource, item, crd)
                            for item in items
                        ]
                        
                        for resource_future in as_completed(resource_futures):
                            try:
                                processed_resource = resource_future.result()
                                if processed_resource:
                                    resources.append(processed_resource)
                            except Exception as e:
                                logger.error(f"Error processing resource: {e}")
                    except Exception as e:
                        logger.error(f"Error processing CRD {crd['kind']}: {e}")

            return resources
        except Exception as e:
            logger.error(f"Error getting composite resources: {e}")
            return []
