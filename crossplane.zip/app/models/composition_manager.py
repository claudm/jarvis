from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

logger = logging.getLogger(__name__)

# Constants for thread pooling
MAX_WORKERS = 10
BATCH_SIZE = 50

class CompositionManager(BaseManager):
    _thread_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
    _lock = threading.Lock()

    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def _process_upbound_info(self, metadata: dict) -> Optional[dict]:
        """Process Upbound-specific information"""
        annotations = metadata.get('annotations', {})
        labels = metadata.get('labels', {})

        if ('meta.upbound.io/configuration' in annotations or
            'upbound.io/configuration' in labels or
            any(key.startswith('upbound.io/') for key in labels.keys())):
            return {
                'configuration': (
                    labels.get('upbound.io/configuration') or 
                    annotations.get('meta.upbound.io/configuration')
                ),
                'version': labels.get('upbound.io/version'),
                'source': 'upbound-format'
            }
        return None

    def _fetch_provider_config(self, group: str, version: str, name: str) -> Optional[dict]:
        """Fetch provider config details"""
        try:
            return self.custom_api.get_cluster_custom_object(
                group=group,
                version=version,
                plural="providerconfigs",
                name=name
            )
        except Exception as e:
            logger.debug(f"Error fetching provider config {name}: {e}")
            return None

    def _fetch_composition(self, name: str) -> Optional[dict]:
        """Fetch composition details"""
        try:
            return self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=name
            )
        except Exception as e:
            logger.debug(f"Error fetching composition {name}: {e}")
            return None

    def _process_composition_resources(self, resources: List[dict]) -> set:
        """Process composition resources concurrently"""
        provider_configs = set()
        
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = []
            for resource in resources:
                base = resource.get('base', {})
                provider_config_ref = base.get('spec', {}).get('providerConfigRef', {})
                if provider_config_ref and provider_config_ref.get('name'):
                    api_version = base.get('apiVersion', '').split('/')
                    if len(api_version) == 2:
                        futures.append(
                            executor.submit(
                                self._fetch_provider_config,
                                api_version[0],
                                api_version[1],
                                provider_config_ref['name']
                            )
                        )
                        provider_configs.add(provider_config_ref['name'])

            # Wait for all futures to complete
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    logger.error(f"Error processing provider config: {e}")

        return provider_configs

    def _process_composition(self, composition: dict) -> Optional[dict]:
        """Process composition with concurrent provider config fetching"""
        try:
            metadata = composition.get('metadata', {})
            upbound_info = self._process_upbound_info(metadata)
            
            if upbound_info:
                composition['upbound'] = upbound_info

                # Process Upbound-specific fields
                spec = composition.get('spec', {})
                if 'patchSets' in spec:
                    patch_sets = spec['patchSets']
                    if isinstance(patch_sets, list):
                        for patch_set in patch_sets:
                            if 'patches' in patch_set:
                                for patch in patch_set['patches']:
                                    if 'type' not in patch and 'fromFieldPath' in patch:
                                        patch['type'] = 'FromCompositeFieldPath'

            # Process resources concurrently
            spec = composition.get('spec', {})
            resources = spec.get('resources', [])
            provider_configs = self._process_composition_resources(resources)

            if provider_configs:
                composition['providerConfigs'] = list(provider_configs)

            return composition
        except Exception as e:
            logger.error(f"Error processing composition {composition.get('metadata', {}).get('name')}: {e}")
            return None

    def list_compositions(self) -> List[dict]:
        """List all Crossplane compositions with concurrent processing"""
        try:
            if not self._ensure_connection():
                return []

            response = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions"
            )
            compositions = response.get("items", [])

            # Process compositions concurrently
            processed_compositions = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_comp = {
                    executor.submit(self._process_composition, comp): comp
                    for comp in compositions
                }
                
                for future in as_completed(future_to_comp):
                    try:
                        result = future.result()
                        if result:
                            processed_compositions.append(result)
                    except Exception as e:
                        logger.error(f"Error processing composition: {e}")

            return processed_compositions
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Compositions CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing compositions: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing compositions: {e}")
            return []

    def get_composition(self, name: str) -> Optional[dict]:
        """Get a specific composition by name"""
        try:
            composition = self.get_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=name
            )
            if composition:
                return self._process_composition(composition)
            return None
        except Exception as e:
            logger.error(f"Error getting composition {name}: {e}")
            return None

    def _process_xrd_provider_config(self, xrd: dict) -> dict:
        """Process XRD provider config"""
        provider_config_ref = xrd.get('spec', {}).get('providerConfigRef', {})
        if provider_config_ref and provider_config_ref.get('name'):
            try:
                api_version = provider_config_ref.get('apiVersion', '').split('/')
                if len(api_version) == 2:
                    provider_config = self._fetch_provider_config(
                        api_version[0],
                        api_version[1],
                        provider_config_ref['name']
                    )
                    if provider_config:
                        xrd['providerConfig'] = {
                            'name': provider_config['metadata']['name'],
                            'ready': True
                        }
                    else:
                        xrd['providerConfig'] = {
                            'name': provider_config_ref['name'],
                            'ready': False
                        }
            except Exception as e:
                logger.debug(f"Error processing provider config for XRD: {e}")
                xrd['providerConfig'] = {
                    'name': provider_config_ref['name'],
                    'ready': False
                }
        return xrd

    def _process_xrd(self, xrd: dict) -> dict:
        """Process a single XRD with concurrent provider config fetching"""
        try:
            metadata = xrd.get('metadata', {})
            upbound_info = self._process_upbound_info(metadata)
            if upbound_info:
                xrd['upbound'] = upbound_info

            # Process provider config
            return self._process_xrd_provider_config(xrd)
        except Exception as e:
            logger.error(f"Error processing XRD: {e}")
            return xrd

    def get_xrd(self, name: str) -> Optional[dict]:
        """Get a specific XRD by name"""
        try:
            xrd = self.get_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions",
                name=name
            )
            if xrd:
                return self._process_xrd(xrd)
            return None
        except Exception as e:
            logger.error(f"Error getting XRD {name}: {e}")
            return None

    def list_composite_resource_definitions(self) -> List[dict]:
        """List all Composite Resource Definitions with concurrent processing"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            response = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions"
            )
            xrds = response.get("items", [])

            # Process XRDs concurrently
            processed_xrds = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_xrd = {
                    executor.submit(self._process_xrd, xrd): xrd
                    for xrd in xrds
                }
                
                for future in as_completed(future_to_xrd):
                    try:
                        result = future.result()
                        if result:
                            processed_xrds.append(result)
                    except Exception as e:
                        logger.error(f"Error processing XRD: {e}")

            return processed_xrds
        except Exception as e:
            logger.error(f"Error listing Composite Resource Definitions: {e}")
            return []
