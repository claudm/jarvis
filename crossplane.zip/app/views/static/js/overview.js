// overview.js - Overview page functionality

async function loadOverviewData() {
    showLoading();
    try {
        // Fetch all overview data from the consolidated endpoint
        const response = await fetch('/api/overview');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        // Process the consolidated response
        const overview = {
            data: {
                crossplane: data.crossplane || { health: 'Unknown', version: 'Unknown', pods: [] },
                managed_resources: data.managed_resources || { items: [], total_count: 0, health_summary: { healthy: 0, unhealthy: 0, unknown: 0 } },
                claims: data.claims || { items: [], count: 0 },
                composite_resources: data.composite_resources || { items: [], count: 0 },
                providers: data.providers || { count: 0 },
                provider_configs: data.provider_configs || { count: 0 },
                compositions: data.compositions || { count: 0 },
                composite_resource_definitions: data.composite_resource_definitions || { count: 0 }
            }
        };

        // Log and render the overview data
        console.log('Final overview data:', overview);
        renderOverview(overview);
    } catch (error) {
        console.error('Error loading overview data:', error);
        showError('Failed to load overview data');
    } finally {
        hideLoading();
    }
}

function renderOverview(data) {
    console.log('Rendering overview with data:', data);

    // Update status cards
    updateStatusCards(data);

    // Update health status
    updateHealthStatus(data);

    // Update recent activity
    updateRecentActivity(data);
}

function updateStatusCards(data) {
    // Update card counts using the correct HTML IDs
    const countElements = {
        'claims-count': data.data.claims.count,
        'composite-resources-count': data.data.composite_resources.count,
        'managed-resources-count': data.data.managed_resources.total_count,
        'providerconfigs-count': data.data.provider_configs.count,
        'providers-count': data.data.providers.count,
        'compositions-count': data.data.compositions.count,
        'composite-resource-definitions-count': data.data.composite_resource_definitions.count
    };

    Object.entries(countElements).forEach(([id, count]) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = count || '0';
        }
    });
}

function updateHealthStatus(data) {
    const healthSummary = data.data.managed_resources.health_summary;
    const total = healthSummary.healthy + healthSummary.unhealthy + healthSummary.unknown;

    // Update health status numbers and percentages
    const statuses = ['healthy', 'unhealthy', 'unknown'];
    statuses.forEach(status => {
        const count = healthSummary[status];
        const percentage = total > 0 ? (count / total) * 100 : 0;

        // Update count
        const countElement = document.getElementById(`${status}-count`);
        if (countElement) {
            countElement.textContent = count;
        }

        // Update percentage bar
        const percentageElement = document.getElementById(`${status}-percentage`);
        if (percentageElement) {
            percentageElement.style.width = `${percentage}%`;
        }
    });

    // Update total count
    const totalCount = document.getElementById('total-count');
    if (totalCount) {
        totalCount.textContent = total;
    }

    // Update Crossplane status
    const crossplaneStatus = document.getElementById('crossplane-status');
    if (crossplaneStatus) {
        const health = data.data.crossplane.health;
        const version = data.data.crossplane.version;
        crossplaneStatus.innerHTML = `
            <div class="flex items-center space-x-2">
                <span class="px-2 py-1 text-sm rounded-full ${getHealthStatusClass(health)}">${health}</span>
                <span class="text-sm text-gray-500">Version: ${version}</span>
            </div>
        `;
    }

    // Update Crossplane pods
    const podsList = document.getElementById('crossplane-pods');
    if (podsList) {
        podsList.innerHTML = data.data.crossplane.pods.map(pod => `
            <div class="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded">
                <div class="flex-1">
                    <div class="font-medium text-gray-900 dark:text-white">${pod.name}</div>
                    <div class="text-sm text-gray-500">
                        ${pod.containers.map(c => `
                            <div class="flex items-center space-x-2">
                                <span class="text-xs px-2 py-1 rounded-full ${getHealthStatusClass(c.status)}">${c.status}</span>
                                <span>${c.name}</span>
                                ${c.restarts > 0 ? `<span class="text-red-500">(${c.restarts} restarts)</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `).join('');
    }
}

function updateRecentActivity(data) {
    const recentActivityContainer = document.getElementById('recent-activity');
    if (!recentActivityContainer) return;

    // Combine and sort all resources by creation timestamp
    const allResources = [
        ...(data.data.managed_resources.items || []),
        ...(data.data.claims.items || []),
        ...(data.data.composite_resources.items || [])
    ].sort((a, b) => {
        const dateA = new Date(a.metadata?.creationTimestamp || 0);
        const dateB = new Date(b.metadata?.creationTimestamp || 0);
        return dateB - dateA;
    }).slice(0, 5); // Get only the 5 most recent

    // Clear existing content
    recentActivityContainer.innerHTML = '';

    if (allResources.length === 0) {
        recentActivityContainer.innerHTML = '<div class="text-gray-500 text-center py-4">No recent activity</div>';
        return;
    }

    // Create activity items
    allResources.forEach(resource => {
        const item = document.createElement('div');
        item.className = 'flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700';
        
        const resourceType = resource._resource_type?.kind || resource.kind || 'Resource';
        const name = resource.metadata?.name || 'Unknown';
        const timestamp = formatDate(resource.metadata?.creationTimestamp);
        const status = resource._health_status || 'Unknown';
        
        item.innerHTML = `
            <div class="flex-1">
                <div class="flex items-center">
                    <span class="font-medium text-gray-900 dark:text-white">${resourceType}</span>
                    <span class="mx-2 text-gray-500">&bull;</span>
                    <span class="text-gray-500">${name}</span>
                </div>
                <div class="text-sm text-gray-500">${timestamp}</div>
            </div>
            <div class="ml-4">
                <span class="px-2 py-1 text-sm rounded-full ${getHealthStatusClass(status)}">${status}</span>
            </div>
        `;
        
        recentActivityContainer.appendChild(item);
    });
}

// Initialize overview when document is ready
document.addEventListener('DOMContentLoaded', () => {
    const overviewPanel = document.getElementById('overview-panel');
    if (overviewPanel && !overviewPanel.classList.contains('hidden')) {
        loadOverviewData();
    }
});

// Export functions
window.renderOverview = renderOverview;
window.loadOverviewData = loadOverviewData;

function formatDate(timestamp) {
    if (!timestamp) return 'Unknown';
    const date = new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);

    if (diffInSeconds < 60) {
        return 'Just now';
    }

    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
        return `${diffInMinutes}m ago`;
    }

    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }

    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) {
        return `${diffInDays}d ago`;
    }

    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths < 12) {
        return `${diffInMonths}mo ago`;
    }

    return date.toLocaleDateString();
}

function getHealthStatusClass(status) {
    switch (status?.toLowerCase()) {
        case 'healthy':
            return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
        case 'unhealthy':
            return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
        default:
            return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
    }
}
