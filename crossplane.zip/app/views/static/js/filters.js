document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('resource-search');
    const statusFilter = document.getElementById('status-filter');
    const claimsSearchInput = document.getElementById('claims-search');
    const claimsStatusFilter = document.getElementById('claims-status-filter');

    // Event listeners for managed resources
    if (searchInput) {
        searchInput.addEventListener('input', _.debounce(() => applyFilters(), 300));
    }
    if (statusFilter) {
        statusFilter.addEventListener('change', () => applyFilters());
    }
    
    // Add provider config filter listener
    const providerConfigFilter = document.getElementById('providerconfig-filter');
    if (providerConfigFilter) {
        providerConfigFilter.addEventListener('change', () => applyFilters());
        console.debug('Provider config filter listener added');
    }

    // Event listeners for claims
    if (claimsSearchInput) {
        claimsSearchInput.addEventListener('input', _.debounce(() => applyClaimsFilters(), 300));
    }
    if (claimsStatusFilter) {
        claimsStatusFilter.addEventListener('change', () => applyClaimsFilters());
    }

    // Initial load
    applyFilters();
});

async function applyFilters() {
    try {
        const searchInput = document.getElementById('resource-search');
        const statusFilter = document.getElementById('status-filter');
        const providerConfigFilter = document.getElementById('providerconfig-filter');
        
        const searchTerm = searchInput?.value || '';
        const status = statusFilter?.value || '';
        const providerConfig = providerConfigFilter?.value || '';

        const params = new URLSearchParams();
        if (searchTerm) params.append('search', searchTerm);
        if (status) params.append('status', status);
        if (providerConfig) params.append('providerconfig', providerConfig);

        // Debug filter values
        console.debug('Applying filters:', { searchTerm, status, providerConfig });

        const response = await fetch(`/api/managed-resources?${params.toString()}`);
        if (!response.ok) throw new Error(`Failed to fetch resources: ${response.status}`);
        
        const data = await response.json();
        if (!data) throw new Error('No data received from server');
        
        const container = document.getElementById('managed-resources-list');
        if (!container) throw new Error('Container not found');
        
        renderManagedResources(container, data);
    } catch (error) {
        console.error('Error applying filters:', error);
        showError('Failed to load resources');
    }
}

async function applyClaimsFilters() {
    try {
        const claimsSearchInput = document.getElementById('claims-search');
        const claimsStatusFilter = document.getElementById('claims-status-filter');
        const searchTerm = claimsSearchInput?.value || '';
        const status = claimsStatusFilter?.value || '';

        const params = new URLSearchParams();
        if (searchTerm) params.append('search', searchTerm);
        if (status) params.append('status', status);

        const response = await fetch(`/api/claims?${params.toString()}`);
        if (!response.ok) throw new Error('Failed to fetch claims');
        
        const data = await response.json();
        renderClaims(data);
    } catch (error) {
        console.error('Error applying claims filters:', error);
        showError('Failed to load claims');
    }
}
