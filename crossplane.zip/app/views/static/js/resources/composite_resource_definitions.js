// Store original data for filtering
window.originalCompositeResourceDefinitionsData = null;

function renderCompositeResourceDefinitions(container, data) {
    if (!data?.items?.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No Composite Resource Definitions found</div>';
        return;
    }

    // Store the original data for filtering
    window.originalCompositeResourceDefinitionsData = structuredClone(data);

    // Get current filters
    const filters = {       
        search: document.getElementById('composite-resource-definitions-search')?.value?.toLowerCase() || ''
    };

    // Apply filters
    const filteredData = {
        ...data,
        items: data.items.filter(definition => {
            // Search filter
            if (filters.search) {
                const searchFields = [
                    definition.metadata?.name,
                    definition.spec?.group,
                    definition.providerConfig?.name
                ].map(field => (field || '').toLowerCase());
                
                if (!searchFields.some(field => field.includes(filters.search))) {
                    return false;
                }
            }
            return true;
        })
    };

    // Set up filter handlers
    const searchInput = document.getElementById('composite-resource-definitions-search');
    if (searchInput && !searchInput.hasEventListener) {
        const handleSearch = _.debounce(() => {
            // Update URL params
            const url = new URL(window.location);
            if (searchInput.value) {
                url.searchParams.set('search', searchInput.value);
            } else {
                url.searchParams.delete('search');
            }
            window.history.replaceState({}, '', url);

            // Re-render with current filters
            if (window.originalCompositeResourceDefinitionsData) {
                renderCompositeResourceDefinitions(container, window.originalCompositeResourceDefinitionsData);
            }
        }, 300);

        searchInput.addEventListener('input', handleSearch);
        searchInput.hasEventListener = true;
    }

    const table = document.createElement('table');
    table.className = 'w-full table-fixed';
    table.innerHTML = `
        <thead class="bg-gray-50 dark:bg-gray-800">
            <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Name</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Provider</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Provider Config</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Status</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        </tbody>
    `;

    const tbody = table.querySelector('tbody');
    filteredData.items.forEach(definition => {
        const name = definition.metadata?.name || '';
        const provider = definition.spec?.group || '';
        // Extract status conditions
        const conditions = definition.status?.conditions || [];
        const isEstablished = conditions.find(c => c.type === 'Established')?.status === 'True';
        const isOffered = conditions.find(c => c.type === 'Offered')?.status === 'True';
        
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer';
        
        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">${name}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">${provider.toUpperCase()}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                ${definition.providerConfig ? `
                    <div class="flex items-center space-x-2">
                        <span class="text-sm">${definition.providerConfig.name}</span>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            definition.providerConfig.ready ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200' : 
                            'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200'
                        }">
                            ${definition.providerConfig.ready ? 'Ready' : 'Not Ready'}
                        </span>
                    </div>
                ` : '-'}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center space-x-2">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        isEstablished ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200' : 
                        'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isEstablished ? 'Established' : 'Not Established'}
                    </span>
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        isOffered ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200' : 
                        'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isOffered ? 'Offered' : 'Not Offered'}
                    </span>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <button 
                    class="text-gray-400 hover:text-gray-500"
                    data-resource='${JSON.stringify(definition).replace(/'/g, "&apos;")}'
                    onclick="event.stopPropagation(); showYAMLInMonaco(JSON.parse(this.dataset.resource))"
                    title="View YAML">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    container.innerHTML = ''; // Clear container before rendering
    container.appendChild(table);
}

// Initialize search from URL params
function initializeFilters() {
    const searchParams = new URLSearchParams(window.location.search);
    const searchInput = document.getElementById('composite-resource-definitions-search');
    
    if (searchInput && searchParams.has('search')) {
        searchInput.value = searchParams.get('search');
    }
}

// Export functions
window.renderCompositeResourceDefinitions = renderCompositeResourceDefinitions;
window.initializeFilters = initializeFilters;

// Initialize filters when document is ready
document.addEventListener('DOMContentLoaded', initializeFilters);
