from flask import Flask
from flask_cors import CORS
from multiprocessing import Process, cpu_count
from controllers.page_controller import page_bp
from controllers.provider_controller import bp as provider_bp
from controllers.composition_controller import bp as composition_bp
from controllers.composite_resource_definition_controller import bp as composite_resource_definition_bp
from controllers.claim_controller import bp as claim_bp
from controllers.resource_controller import bp as resource_bp
from controllers.provider_config_controller import bp as provider_config_bp
from controllers.overview_controller import bp as overview_bp
from models.crossplane_manager import CrossplaneManager
from services.background_worker import start_background_worker, stop_background_worker

# Create Flask app
app = Flask(__name__, 
    template_folder='views/templates',
    static_folder='views/static'
)

# Enable CORS
CORS(app)

# Register blueprints
app.register_blueprint(page_bp)
app.register_blueprint(provider_bp)
app.register_blueprint(composition_bp)
app.register_blueprint(composite_resource_definition_bp)
app.register_blueprint(claim_bp)
app.register_blueprint(resource_bp)
app.register_blueprint(provider_config_bp)
app.register_blueprint(overview_bp)

if __name__ == '__main__':
    # Start the background worker
    start_background_worker()

    try:
        import gunicorn.app.base
        
        class StandaloneApplication(gunicorn.app.base.BaseApplication):
            def __init__(self, app, options=None):
                self.options = options or {}
                self.application = app
                super().__init__()

            def load_config(self):
                for key, value in self.options.items():
                    self.cfg.set(key.lower(), value)

            def load(self):
                return self.application

        options = {
            'bind': '0.0.0.0:5000',
            'workers': cpu_count(),
            'timeout': 120,
            'keepalive': 5,  # Keep connections alive
            'max_requests': 150,  # Restart workers after max requests
            'max_requests_jitter': 10  # Add jitter to prevent all workers restarting at once
        }
        
        try:
            StandaloneApplication(app, options).run()
        finally:
            # Stop the background worker when the server stops
            stop_background_worker()
    except ImportError:
        try:
            # Fallback to basic Flask server if gunicorn is not available
            app.run(host="0.0.0.0", port=5000)
        finally:
            # Stop the background worker when the server stops
            stop_background_worker()
