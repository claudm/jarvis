from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager

api_bp = Blueprint('api', __name__)

@api_bp.route('/overview')
def get_overview():
    """Get system overview data"""
    try:
        manager = CrossplaneManager.get_instance()
        data = manager.get_system_overview()
        
        # Transform data to match frontend expectations
        overview_data = {
            'claims': {
                'count': data['counts']['claims']
            },
            'composite_resources': {
                'count': data['counts']['composite_resources']
            },
            'managed_resources': {
                'total_count': data['counts']['managed_resources'],
                'health_summary': data['health_summary']
            },
            'provider_configs': {
                'count': data['counts'].get('provider_configs', 0)
            },
            'providers': {
                'count': data['counts']['providers']
            },
            'compositions': {
                'count': data['counts']['compositions']
            },
            'composite_resource_definitions': {
                'count': data['counts']['composite_resource_definitions']
            },
            'crossplane': {
                'version': data['version'],
                'health': data['health'],
                'pods': data['pods']
            }
        }
        
        return jsonify(overview_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/managed-resources')
def get_managed_resources():
    try:
        manager = CrossplaneManager.get_instance()
        resources = manager.get_managed_resources()
        
        # Group resources by kind
        grouped_resources = {}
        health_summary = {'healthy': 0, 'unhealthy': 0, 'unknown': 0}
        
        # First pass: collect all resources and update health summary
        for resource in resources:
            # Get kind from _resource_type which is added by CrossplaneManager
            kind = resource.get('_resource_type', {}).get('kind', 'Unknown')
            if kind not in grouped_resources:
                grouped_resources[kind] = {
                    'resources': [],
                    'count': 0
                }
            
            # Update health summary based on resource status
            health_status = resource.get('_health_status', 'Unknown').lower()
            if health_status == 'healthy':
                health_summary['healthy'] += 1
            elif health_status == 'unhealthy':
                health_summary['unhealthy'] += 1
            else:
                health_summary['unknown'] += 1
            
            # Add resource to its kind group
            grouped_resources[kind]['resources'].append(resource)
            grouped_resources[kind]['count'] += 1
        
        # Second pass: remove kinds with no resources
        grouped_resources = {
            kind: group for kind, group in grouped_resources.items()
            if group['count'] > 0 and len(group['resources']) > 0
        }
        
        # Get total count from system overview
        overview = manager.get_system_overview()
        total_count = overview['counts']['managed_resources']
        
        return jsonify({
            'resources': grouped_resources,
            'health_summary': health_summary,
            'total_count': total_count
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/providers')
def get_providers():
    try:
        manager = CrossplaneManager.get_instance()
        providers = manager.list_providers()
        return jsonify({
            'providers': providers,
            'count': len(providers),
            'message': 'No providers found' if not providers else None
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list providers"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Providers resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list providers: {error_msg}"}), 500

@api_bp.route('/compositions')
def get_compositions():
    try:
        manager = CrossplaneManager.get_instance()
        compositions = manager.list_compositions()
        return jsonify({
            'compositions': compositions,
            'count': len(compositions),
            'message': 'No compositions found' if not compositions else None
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list compositions"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Compositions resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list compositions: {error_msg}"}), 500

@api_bp.route('/composite-resource-definitions')
def get_composite_resource_definitions():
    try:
        manager = CrossplaneManager.get_instance()
        definitions = manager.list_composite_resource_definitions()
        
        # Check if we only need summary data
        summary_only = request.args.get('summary', '').lower() == 'true'
        
        # If summary only, return just the count
        if summary_only:
            return jsonify({
                "count": len(definitions)
            })
        
        return jsonify({
            "items": definitions,
            "count": len(definitions),
            "message": "No Composite Resource Definitions found" if not definitions else None
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list Composite Resource Definitions"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Composite Resource Definitions resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list Composite Resource Definitions: {error_msg}"}), 500

@api_bp.route('/claims')
def get_claims():
    try:
        namespace = request.args.get('namespace', 'default')
        manager = CrossplaneManager.get_instance()
        claims = manager.list_claims(namespace=namespace)
        
        # Format response with additional data
        formatted_claims = []
        for claim in claims:
            # Get claim events
            events = manager.get_claim_events(claim['metadata']['name'], claim['metadata'].get('namespace'))
            
            # Get provider config details if referenced
            provider_config = None
            if 'providerConfigRef' in claim.get('spec', {}):
                provider_config_name = claim['spec']['providerConfigRef'].get('name')
                if provider_config_name:
                    config = manager.get_provider_config(provider_config_name)
                    if config:
                        ready_condition = next((c for c in config.get('status', {}).get('conditions', []) 
                                             if c.get('type') == 'Ready'), {})
                        provider_config = {
                            'name': provider_config_name,
                            'ready': ready_condition.get('status') == 'True'
                        }
            
            # Get composition details if referenced
            composition = None
            if 'compositionRef' in claim.get('spec', {}):
                composition_name = claim['spec']['compositionRef'].get('name')
                if composition_name:
                    comp = manager.get_composition(composition_name)
                    if comp:
                        composition = {
                            'name': composition_name,
                            'ready': True  # Compositions don't have a ready status
                        }
            
            # Get composite resource details if created
            composite_resource = None
            if 'resourceRef' in claim.get('status', {}):
                resource_name = claim['status']['resourceRef'].get('name')
                if resource_name:
                    resource = next((r for r in manager.get_composite_resources() 
                                   if r['metadata']['name'] == resource_name), None)
                    if resource:
                        ready_condition = next((c for c in resource.get('status', {}).get('conditions', [])
                                             if c.get('type') == 'Ready'), {})
                        composite_resource = {
                            'name': resource_name,
                            'ready': ready_condition.get('status') == 'True'
                        }
            
            # Add enhanced details to claim
            formatted_claim = {
                **claim,
                'events': sorted(events, key=lambda x: x.get('timestamp', ''), reverse=True),
                'providerConfig': provider_config,
                'composition': composition,
                'compositeResource': composite_resource
            }
            
            formatted_claims.append(formatted_claim)
        
        return jsonify({
            'claims': formatted_claims,
            'count': len(formatted_claims),
            'namespace': namespace,
            'message': 'No claims found in this namespace' if not formatted_claims else None
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/composite-resources')
def get_composite_resources():
    try:
        manager = CrossplaneManager.get_instance()
        resources = manager.get_composite_resources()
        
        # Enhance each resource with additional details
        enhanced_resources = []
        for resource in resources:
            # Get provider config if referenced
            provider_config = None
            if 'providerConfigRef' in resource.get('spec', {}):
                provider_config_name = resource['spec']['providerConfigRef'].get('name')
                if provider_config_name:
                    config = manager.get_provider_config(provider_config_name)
                    if config:
                        provider_config = {
                            'name': provider_config_name,
                            'ready': any(c.get('type') == 'Ready' and c.get('status') == 'True' 
                                       for c in config.get('status', {}).get('conditions', []))
                        }
            
            # Add enhanced details to resource
            enhanced_resource = {
                **resource,
                'providerconfig': provider_config['name'] if provider_config else None,
                'spec': {
                    **resource.get('spec', {}),
                    'claimRef': resource.get('spec', {}).get('claimRef'),
                    'compositionRef': resource.get('spec', {}).get('compositionRef'),
                    'resourceRefs': resource.get('spec', {}).get('resourceRefs', [])
                }
            }
            
            enhanced_resources.append(enhanced_resource)
        
        count = len(enhanced_resources)
        return jsonify({
            'resources': enhanced_resources,
            'count': count,
            'message': None if enhanced_resources else 'No composite resources found'
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list composite resources"}), 403
        else:
            return jsonify({"error": f"Failed to get composite resources: {error_msg}"}), 500

@api_bp.route('/providerconfigs')
def get_provider_configs():
    try:
        manager = CrossplaneManager.get_instance()
        
        # Check if we only need summary data
        summary_only = request.args.get('summary', '').lower() == 'true'
        
        # First check if we have any providers installed
        providers = manager.list_providers()
        if not providers:
            return jsonify({
                "count": 0,
                "message": "No providers installed in the cluster"
            }) if summary_only else jsonify({
                "items": [],
                "count": 0,
                "message": "No providers installed in the cluster"
            })
        
        # Get provider configurations
        configs = manager.list_provider_configs()
        
        # If summary only, return just the count
        if summary_only:
            return jsonify({
                "count": len(configs)
            })
        
        # Process configs to extract relevant data
        processed_configs = []
        for config in configs:
            processed_config = {
                'apiVersion': config.get('apiVersion'),
                'kind': config.get('kind'),
                'metadata': {
                    'name': config.get('metadata', {}).get('name'),
                    'creationTimestamp': config.get('metadata', {}).get('creationTimestamp')
                },
                'spec': config.get('spec', {}),
                'status': config.get('status', {})
            }
            processed_configs.append(processed_config)
        
        return jsonify({
            "items": processed_configs,
            "count": len(processed_configs),
            "message": "No Provider Configurations found" if not processed_configs else None
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list Provider Configurations"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Provider Configurations resource not found"}), 404
        else:
            return jsonify({"error": f"Failed to list Provider Configurations: {error_msg}"}), 500
