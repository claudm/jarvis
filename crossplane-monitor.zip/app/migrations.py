from flask import Flask
from models.auth import db, User
from models.cluster import Cluster
import sqlite3

import os

def migrate():
    # Get absolute path for instance directory
    base_dir = os.path.abspath(os.path.dirname(__file__))
    instance_dir = os.path.join(base_dir, 'instance')
    db_path = os.path.join(instance_dir, 'app.db')
    
    # Create instance directory if it doesn't exist
    os.makedirs(instance_dir, exist_ok=True)
    
    # Connect to the database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get existing data if possible
    clusters_data = []
    cluster_users_data = []
    try:
        # Get clusters data
        cursor.execute('SELECT id, name, endpoint, token FROM clusters')
        clusters_data = cursor.fetchall()
        
        # Get cluster-user relationships
        cursor.execute('SELECT user_id, cluster_id FROM cluster_user')
        cluster_users_data = cursor.fetchall()
    except sqlite3.OperationalError:
        # Tables don't exist yet, that's fine
        pass
    
    # Drop existing tables if they exist
    cursor.execute('DROP TABLE IF EXISTS cluster_user')
    cursor.execute('DROP TABLE IF EXISTS clusters')
    cursor.execute('DROP TABLE IF EXISTS users')
    
    # Create app context for SQLAlchemy
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    
    with app.app_context():
        # Create new tables
        db.create_all()
        
        # Create admin user
        admin = User(username='admin', is_admin=True)
        admin.set_password('admin123')
        db.session.add(admin)
        
        # Create regular user
        user = User(username='user', is_admin=False)
        user.set_password('user123')
        db.session.add(user)
        
        db.session.commit()
        
        # Create a map of user IDs to User objects
        users_map = {user.id: user for user in User.query.all()}
        
        # Restore clusters with their data
        clusters_map = {}  # To store cluster objects by ID
        for cluster_id, name, endpoint, token in clusters_data:
            cluster = Cluster(
                id=cluster_id,
                name=name,
                endpoint=endpoint,
                token=token,
                kubeconfig=None  # New clusters will have kubeconfig as None
            )
            clusters_map[cluster_id] = cluster
            db.session.add(cluster)
        
        # Restore cluster-user relationships
        for user_id, cluster_id in cluster_users_data:
            if user_id in users_map and cluster_id in clusters_map:
                clusters_map[cluster_id].users.append(users_map[user_id])
        
        db.session.commit()

if __name__ == '__main__':
    migrate()
