from flask_admin.contrib.sqla import ModelView
from flask_login import current_user
from flask import redirect, url_for
from wtforms import form, fields, SelectMultipleField
from models.auth import User
from models.cluster import Cluster
import os

class SecureModelView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin
        
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.login'))

class UserForm(form.Form):
    username = fields.StringField('Username')
    password = fields.PasswordField('Password')
    is_admin = fields.BooleanField('Admin')

class UserView(SecureModelView):
    column_list = ['username', 'is_admin']
    column_searchable_list = ['username']
    column_filters = ['is_admin']
    form = UserForm
    
    def on_model_change(self, form, model, is_created):
        if is_created or form.password.data:
            model.set_password(form.password.data)
            
        # Ensure admin user can't remove their own admin status
        if model.id == current_user.id and not form.is_admin.data:
            form.is_admin.data = True
            model.is_admin = True

from wtforms.validators import ValidationError
from flask_admin.form import FileUploadField
import yaml

class ClusterForm(form.Form):
    name = fields.StringField('Name')
    endpoint = fields.StringField('Endpoint', description='Optional if using kubeconfig')
    token = fields.TextAreaField('Token', description='Optional if using kubeconfig')
    kubeconfig = FileUploadField('Kubeconfig File', description='Optional if using endpoint/token')
    user_ids = SelectMultipleField('Users', coerce=int)

    def validate_kubeconfig(self, field):
        if not field.data and not (self.endpoint.data and self.token.data):
            raise ValidationError('Either kubeconfig file or endpoint/token pair is required')
        
        if field.data:
            try:
                # Read and validate kubeconfig content
                content = field.data.read().decode('utf-8')
                yaml.safe_load(content)  # Validate YAML format
                field.data.seek(0)  # Reset file pointer for later use
            except Exception as e:
                raise ValidationError(f'Invalid kubeconfig file: {str(e)}')

class ClusterView(SecureModelView):
    column_list = ['name', 'endpoint', 'users']
    column_searchable_list = ['name', 'endpoint']
    
    def __init__(self, model, session, **kwargs):
        # Set up file upload directory
        self.file_path = os.path.join(os.path.dirname(__file__), '..', 'instance', 'uploads')
        os.makedirs(self.file_path, exist_ok=True)
        
        # Create form with file path
        class ClusterFormWithPath(ClusterForm):
            kubeconfig = FileUploadField('Kubeconfig File', 
                                       description='Optional if using endpoint/token',
                                       base_path=self.file_path)
        
        self.form = ClusterFormWithPath
        super().__init__(model, session, **kwargs)
    
    def _handle_kubeconfig(self, form, model):
        if form.kubeconfig.data:
            # Get the uploaded file path
            file_path = os.path.join(self.file_path, form.kubeconfig.data.filename)
            
            try:
                # Read content and store in model
                with open(file_path, 'r') as f:
                    content = f.read()
                    model.kubeconfig = content
                    # Clear endpoint/token if using kubeconfig
                    model.endpoint = None
                    model.token = None
            finally:
                # Clean up the uploaded file
                try:
                    os.unlink(file_path)
                except:
                    pass
    
    def create_form(self, obj=None):
        form = super(ClusterView, self).create_form(obj)
        form.user_ids.choices = [(u.id, u.username) for u in User.query.all()]
        return form
        
    def edit_form(self, obj=None):
        form = super(ClusterView, self).edit_form(obj)
        form.user_ids.choices = [(u.id, u.username) for u in User.query.all()]
        if obj:
            form.user_ids.data = [user.id for user in obj.users]
        return form
    
    def create_model(self, form):
        try:
            model = self.model()
            form.populate_obj(model)
            
            # Handle kubeconfig file if provided
            self._handle_kubeconfig(form, model)
            
            # Handle user associations
            if hasattr(form, 'user_ids') and form.user_ids.data:
                selected_users = User.query.filter(User.id.in_(form.user_ids.data)).all()
                model.users.extend(selected_users)
            
            self.session.add(model)
            self.session.commit()
            return True
        except Exception as ex:
            self.session.rollback()
            raise

    def update_model(self, form, model):
        try:
            # Update basic fields
            form.populate_obj(model)
            
            # Handle kubeconfig file if provided
            self._handle_kubeconfig(form, model)
            
            # Handle user associations through the session
            if hasattr(form, 'user_ids'):
                # Get selected users
                selected_users = []
                if form.user_ids.data:
                    selected_users = User.query.filter(User.id.in_(form.user_ids.data)).all()
                
                # Clear existing users and set new ones
                model.users = selected_users
            
            self.session.commit()
            return True
        except Exception as ex:
            self.session.rollback()
            raise
