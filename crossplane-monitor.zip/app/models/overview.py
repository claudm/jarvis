from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum
import time

class SystemHealth(Enum):
    HEALTHY = "Healthy"
    UNHEALTHY = "Unhealthy"
    WARNING = "Warning"
    UNAVAILABLE = "Unavailable"
    ERROR = "Error"

class ContainerStatus(Enum):
    RUNNING = "Running"
    NOT_READY = "Not Ready"
    TERMINATED = "Terminated"
    WAITING = "Waiting"

@dataclass
class Container:
    name: str
    ready: bool
    restarts: int
    status: ContainerStatus

@dataclass
class Pod:
    name: str
    status: str
    containers: List[Container]

@dataclass
class ResourceCounts:
    claims: int = 0
    compositions: int = 0
    composite_resources: int = 0
    managed_resources: int = 0
    providers: int = 0
    xrds: int = 0

    @property
    def total(self) -> int:
        """Get total count of all resources"""
        return (
            self.claims +
            self.compositions +
            self.composite_resources +
            self.managed_resources +
            self.providers +
            self.xrds
        )

@dataclass
class HealthSummary:
    healthy: int = 0
    unhealthy: int = 0
    unknown: int = 0

@dataclass
class SystemOverview:
    health: SystemHealth
    version: str
    pods: List[Pod]
    counts: ResourceCounts
    health_summary: HealthSummary

class OverviewManager:
    """Manager for handling system overview data"""

    @staticmethod
    def parse_container(raw_container: Dict) -> Container:
        """Parse raw container data into Container object"""
        return Container(
            name=raw_container['name'],
            ready=raw_container['ready'],
            restarts=raw_container['restarts'],
            status=ContainerStatus(raw_container['status'])
        )

    @staticmethod
    def parse_pod(raw_pod: Dict) -> Pod:
        """Parse raw pod data into Pod object"""
        return Pod(
            name=raw_pod['name'],
            status=raw_pod['status'],
            containers=[OverviewManager.parse_container(c) for c in raw_pod.get('containers', [])]
        )

    @staticmethod
    def parse_overview(raw_overview: Dict) -> SystemOverview:
        """Parse raw overview data into SystemOverview object"""
        return SystemOverview(
            health=SystemHealth(raw_overview['health']),
            version=raw_overview['version'],
            pods=[OverviewManager.parse_pod(p) for p in raw_overview.get('pods', [])],
            counts=ResourceCounts(
                claims=raw_overview['counts']['claims'],
                compositions=raw_overview['counts']['compositions'],
                composite_resources=raw_overview['counts']['composite_resources'],
                managed_resources=raw_overview['counts']['managed_resources'],
                providers=raw_overview['counts']['providers'],
                xrds=raw_overview['counts']['xrds']
            ),
            health_summary=HealthSummary(
                healthy=raw_overview['health_summary']['healthy'],
                unhealthy=raw_overview['health_summary']['unhealthy'],
                unknown=raw_overview['health_summary']['unknown']
            )
        )

    @staticmethod
    def to_dict(overview: SystemOverview) -> Dict:
        """Convert SystemOverview to dictionary format"""
        return {
            'health': overview.health.value,
            'version': overview.version,
            'pods': [
                {
                    'name': pod.name,
                    'status': pod.status,
                    'containers': [
                        {
                            'name': container.name,
                            'ready': container.ready,
                            'restarts': container.restarts,
                            'status': container.status.value
                        }
                        for container in pod.containers
                    ]
                }
                for pod in overview.pods
            ],
            'counts': {
                'claims': overview.counts.claims,
                'compositions': overview.counts.compositions,
                'composite_resources': overview.counts.composite_resources,
                'managed_resources': overview.counts.managed_resources,
                'providers': overview.counts.providers,
                'xrds': overview.counts.xrds,
                'total': overview.counts.total
            },
            'health_summary': {
                'healthy': overview.health_summary.healthy,
                'unhealthy': overview.health_summary.unhealthy,
                'unknown': overview.health_summary.unknown
            }
        }

    def __init__(self, api_client=None):
        self.api_client = api_client
        self.core_v1_api = None
        self.custom_api = None
        self.OVERVIEW_CACHE_TTL = 60  # 1 minute
        self.resource_cache = {}
        self.last_cache_update = {}

    def _is_overview_cache_valid(self) -> bool:
        """Check if overview cache is valid with shorter TTL"""
        cache_key = 'system_overview'
        if cache_key not in self.last_cache_update:
            return False
        return (time.time() - self.last_cache_update[cache_key]) < self.OVERVIEW_CACHE_TTL

    def invalidate_cache(self):
        """Invalidate the overview cache"""
        cache_key = 'system_overview'
        if cache_key in self.resource_cache:
            del self.resource_cache[cache_key]
        if cache_key in self.last_cache_update:
            del self.last_cache_update[cache_key]

    def get_system_overview(self, use_cache: bool = True) -> SystemOverview:
        """Get system overview data"""
        if not self.api_client:
            return SystemOverview(
                health=SystemHealth.UNAVAILABLE,
                version="Unknown",
                pods=[],
                counts=ResourceCounts(),
                health_summary=HealthSummary()
            )

        try:
            # Check cache
            cache_key = 'system_overview'
            if use_cache and self._is_overview_cache_valid() and cache_key in self.resource_cache:
                return self.resource_cache[cache_key]

            # Get Crossplane deployment status
            try:
                deployment = self.custom_api.get_namespaced_custom_object(
                    group="apps",
                    version="v1",
                    namespace="crossplane-system",
                    plural="deployments",
                    name="crossplane"
                )
                
                version = "Unknown"
                if deployment and 'spec' in deployment:
                    containers = deployment['spec'].get('template', {}).get('spec', {}).get('containers', [])
                    if containers:
                        image = containers[0].get('image', '')
                        if ':' in image:
                            version = image.split(':')[1]

                health = SystemHealth.HEALTHY
                if deployment and 'status' in deployment:
                    if deployment['status'].get('availableReplicas') != deployment['status'].get('replicas'):
                        health = SystemHealth.UNHEALTHY
            except Exception as e:
                health = SystemHealth.UNAVAILABLE
                version = "Unknown"

            # Get Crossplane pods
            pods = []
            try:
                pod_list = self.core_v1_api.list_namespaced_pod(namespace="crossplane-system")
                
                for pod in pod_list.items:
                    if pod.status.phase in ['Succeeded', 'Failed']:
                        continue
                        
                    containers = []
                    if pod.status.container_statuses:
                        for container in pod.status.container_statuses:
                            containers.append(Container(
                                name=container.name,
                                ready=container.ready,
                                restarts=container.restart_count,
                                status=ContainerStatus.RUNNING if container.ready else ContainerStatus.NOT_READY
                            ))
                    
                    pods.append(Pod(
                        name=pod.metadata.name,
                        status=pod.status.phase,
                        containers=containers
                    ))
            except Exception:
                pass

            # Get resource counts from CrossplaneManager
            from .crossplane_manager import CrossplaneManager
            crossplane_manager = CrossplaneManager.get_instance()
            resource_counts = crossplane_manager.get_resource_counts()
            
            counts = ResourceCounts(
                claims=resource_counts['claims'],
                compositions=resource_counts['compositions'],
                composite_resources=resource_counts['composite_resources'],
                managed_resources=resource_counts['managed_resources'],
                providers=resource_counts['providers'],
                xrds=resource_counts['composite_resource_definitions']
            )

            # Get health summary from managed resources
            health_summary = HealthSummary()
            managed_resources = crossplane_manager.get_managed_resources()
            for resource in managed_resources:
                status = resource.get('_health_status', 'Unknown')
                if status == 'Healthy':
                    health_summary.healthy += 1
                elif status == 'Unhealthy':
                    health_summary.unhealthy += 1
                else:
                    health_summary.unknown += 1

            # Create overview object
            overview = SystemOverview(
                health=health,
                version=version,
                pods=pods,
                counts=counts,
                health_summary=health_summary
            )

            # Update cache
            self.resource_cache[cache_key] = overview
            self.last_cache_update[cache_key] = time.time()
            return overview

        except Exception:
            return SystemOverview(
                health=SystemHealth.ERROR,
                version="Unknown",
                pods=[],
                counts=ResourceCounts(),
                health_summary=HealthSummary()
            )

    @staticmethod
    def get_system_health(overview: SystemOverview) -> str:
        """Get a human-readable system health status"""
        if overview.health == SystemHealth.ERROR:
            return "System is in error state"
        elif overview.health == SystemHealth.UNAVAILABLE:
            return "System is unavailable"
        elif overview.health == SystemHealth.UNHEALTHY:
            return "System is unhealthy"
        elif overview.health == SystemHealth.WARNING:
            return "System has warnings"
        else:
            total_resources = (
                overview.counts.claims +
                overview.counts.compositions +
                overview.counts.composite_resources +
                overview.counts.managed_resources +
                overview.counts.providers +
                overview.counts.xrds
            )
            if total_resources == 0:
                return "No resources found"
            
            healthy_ratio = overview.health_summary.healthy / total_resources
            if healthy_ratio >= 0.9:
                return "System is healthy"
            elif healthy_ratio >= 0.7:
                return "System is mostly healthy"
            else:
                return "System needs attention"
