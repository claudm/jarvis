from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

logger = logging.getLogger(__name__)

# Constants for thread pooling
MAX_WORKERS = 10
BATCH_SIZE = 50

class ProviderManager(BaseManager):
    _thread_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
    _lock = threading.Lock()

    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def _process_upbound_info(self, item: dict) -> dict:
        """Process Upbound-specific information for a resource"""
        metadata = item.get('metadata', {})
        annotations = metadata.get('annotations', {})
        labels = metadata.get('labels', {})

        if ('meta.upbound.io/configuration' in annotations or
            'upbound.io/configuration' in labels or
            any(key.startswith('upbound.io/') for key in labels.keys())):
            item['upbound'] = {
                'configuration': (
                    labels.get('upbound.io/configuration') or 
                    annotations.get('meta.upbound.io/configuration')
                ),
                'version': labels.get('upbound.io/version'),
                'source': 'upbound-format'
            }
        return item

    def list_providers(self) -> List[dict]:
        """List all installed Crossplane providers with concurrent processing"""
        try:
            if not self._ensure_connection():
                logger.error("Failed to list providers: No connection to Kubernetes cluster")
                return []

            logger.info("Attempting to list providers")
            providers = self.get_resource(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=""  # Empty name for list operation
            )

            if not providers:
                return []

            items = providers.get("items", [])

            # Process providers concurrently
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(self._process_upbound_info, provider) 
                          for provider in items]
                processed_providers = [future.result() for future in as_completed(futures)]

            logger.info(f"Retrieved {len(processed_providers)} providers")
            return processed_providers
        except Exception as e:
            logger.error(f"Error listing providers: {e}")
            return []

    def get_provider_status(self, provider_name: str) -> Optional[dict]:
        """Get status of a specific provider"""
        try:
            provider = self.get_resource(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            return provider.get("status", {}) if provider else None
        except Exception as e:
            logger.error(f"Error getting provider status: {e}")
            return None

    def _fetch_provider_configs(self, crd: dict) -> List[dict]:
        """Fetch provider configs for a single CRD"""
        try:
            # Get the plural from the CRD name - it's the first part before the dot
            plural = crd['name'].split('.')[0].lower()
            configs = self.get_resource(
                group=crd['group'],
                version=crd['version'],
                plural=plural,
                name=""  # Empty name for list operation
            )

            if not configs:
                return []

            items = configs.get('items', [])
            
            # Process items concurrently
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(self._process_upbound_info, config) 
                          for config in items]
                processed_items = [future.result() for future in as_completed(futures)]
            
            return processed_items
        except Exception as e:
            logger.debug(f"Error listing provider configs for {crd['kind']}: {e}")
            return []

    def list_provider_configs(self) -> List[dict]:
        """List all provider configurations with concurrent processing"""
        try:
            if not self._ensure_connection():
                return []

            # Get all provider CRDs
            all_crds = self.get_crossplane_crds()
            provider_crds = [crd for crd in all_crds 
                           if any(g in crd.get('group', '') for g in ['.crossplane.io', '.upbound.io'])
                           and 'providerconfigs' in crd.get('name', '').lower()]

            logger.info(f"Found {len(provider_crds)} provider config CRDs")
            
            # Fetch configs concurrently
            configs = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_crd = {
                    executor.submit(self._fetch_provider_configs, crd): crd
                    for crd in provider_crds
                }
                
                for future in as_completed(future_to_crd):
                    try:
                        configs.extend(future.result())
                    except Exception as e:
                        logger.error(f"Error processing provider configs: {e}")

            return configs
        except Exception as e:
            logger.error(f"Error listing provider configs: {e}")
            return []

    def get_provider_config(self, name: str) -> Optional[dict]:
        """Get a specific provider configuration"""
        try:
            if not self._ensure_connection():
                return None

            provider_crds = [crd for crd in self.get_crossplane_crds() 
                           if any(g in crd.get('group', '') for g in ['.crossplane.io', '.upbound.io'])
                           and 'providerconfigs' in crd.get('name', '').lower()]

            # Try to get config from each CRD concurrently
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = []
                for crd in provider_crds:
                    future = executor.submit(self._get_provider_config_from_crd, crd, name)
                    futures.append(future)
                
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        if result:
                            return result
                    except Exception as e:
                        logger.debug(f"Error getting provider config: {e}")

            return None
        except Exception as e:
            logger.error(f"Error getting provider config: {e}")
            return None

    def _get_provider_config_from_crd(self, crd: dict, name: str) -> Optional[dict]:
        """Get provider config from a specific CRD"""
        try:
            plural = crd['name'].split('.')[0].lower()
            config = self.get_resource(
                group=crd['group'],
                version=crd['version'],
                plural=plural,
                name=name,
                namespace=self.namespace
            )
            return self._process_upbound_info(config) if config else None
        except Exception as e:
            logger.debug(f"Error getting provider config {name} from {crd['kind']}: {e}")
            return None

    def list_provider_crds(self, provider_name: str) -> List[dict]:
        """List all CRDs installed by a specific provider"""
        try:
            if not self._ensure_connection():
                return []

            # Get provider first to verify it exists
            provider = self.get_resource(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            if not provider:
                return []

            # List CRDs with provider label
            crds = self.get_resource(
                group="apiextensions.k8s.io",
                version="v1",
                plural="customresourcedefinitions",
                name=""
            )

            if not crds:
                return []

            # Filter CRDs installed by this provider
            provider_crds = [
                crd for crd in crds.get('items', [])
                if crd.get('metadata', {}).get('labels', {}).get('pkg.crossplane.io/provider') == provider_name
            ]

            return provider_crds
        except Exception as e:
            logger.error(f"Error listing provider CRDs: {e}")
            return []

    def get_provider_crds_status(self, provider_name: str) -> dict:
        """Get status of all CRDs for a provider including installation status"""
        try:
            crds = self.list_provider_crds(provider_name)
            total = len(crds)
            established = sum(1 for crd in crds 
                            if any(cond.get('type') == 'Established' and cond.get('status') == 'True'
                                  for cond in crd.get('status', {}).get('conditions', [])))

            return {
                'total': total,
                'established': established,
                'pending': total - established,
                'crds': [{
                    'name': crd.get('metadata', {}).get('name'),
                    'status': 'Established' if any(cond.get('type') == 'Established' and cond.get('status') == 'True'
                                                 for cond in crd.get('status', {}).get('conditions', []))
                                        else 'Pending'
                } for crd in crds]
            }
        except Exception as e:
            logger.error(f"Error getting provider CRDs status: {e}")
            return {
                'total': 0,
                'established': 0,
                'pending': 0,
                'crds': []
            }
