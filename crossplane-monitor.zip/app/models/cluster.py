from .auth import db, User

# Association table for many-to-many relationship between users and clusters
cluster_users = db.Table('cluster_user',  # Changed to match SQLAlchemy convention
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('cluster_id', db.Integer, db.ForeignKey('clusters.id'), primary_key=True)
)

class Cluster(db.Model):
    __tablename__ = 'clusters'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    endpoint = db.Column(db.String(200), nullable=True)  # Optional if using kubeconfig
    token = db.Column(db.String(500), nullable=True)     # Optional if using kubeconfig
    kubeconfig = db.Column(db.Text, nullable=True)       # Store kubeconfig content
    
    # Many-to-many relationship with users
    users = db.relationship('User', secondary=cluster_users,
                          backref=db.backref('accessible_clusters', lazy='dynamic'),
                          lazy='joined')
    
    def __repr__(self):
        return f'<Cluster {self.name}>'
