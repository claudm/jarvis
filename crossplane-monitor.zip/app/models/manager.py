from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum

class ResourceType(Enum):
    CLAIM = "claim"
    COMPOSITION = "composition"
    COMPOSITE = "composite"
    MANAGED = "managed"
    PROVIDER = "provider"
    XRD = "xrd"

class ResourceStatus(Enum):
    HEALTHY = "Healthy"
    UNHEALTHY = "Unhealthy"
    UNKNOWN = "Unknown"
    UNAVAILABLE = "Unavailable"

@dataclass
class ResourceMetadata:
    name: str
    namespace: Optional[str]
    kind: str
    group: str
    version: str
    plural: str
    categories: List[str]

@dataclass
class ResourceCondition:
    type: str
    status: str
    reason: Optional[str]
    message: Optional[str]
    last_transition_time: Optional[str]

@dataclass
class ResourceSpec:
    provider_ref: Optional[Dict]
    provider_config_ref: Optional[Dict]
    composition_ref: Optional[Dict]
    claim_ref: Optional[Dict]

@dataclass
class ResourceStatus:
    conditions: List[ResourceCondition]
    synced: bool
    ready: bool
    health_status: str

@dataclass
class KubernetesResource:
    metadata: ResourceMetadata
    spec: ResourceSpec
    status: ResourceStatus
    resource_type: ResourceType
    provider: Optional[str] = None
    display_provider: Optional[str] = None
    provider_config: Optional[str] = None
    upbound_info: Optional[Dict] = None

class ResourceManager:
    """Base class for managing Kubernetes resources"""
    
    def __init__(self, api_client=None):
        self.api_client = api_client
        self.group = None
        self.version = None
        self.plural = None
        self.kind = None
        self.resource_type = None

    def parse_resource(self, raw_resource: Dict) -> KubernetesResource:
        """Parse raw Kubernetes resource into structured format"""
        metadata = ResourceMetadata(
            name=raw_resource['metadata']['name'],
            namespace=raw_resource['metadata'].get('namespace'),
            kind=raw_resource.get('_resource_type', {}).get('kind', self.kind),
            group=raw_resource.get('_resource_type', {}).get('group', self.group),
            version=raw_resource.get('_resource_type', {}).get('version', self.version),
            plural=raw_resource.get('_resource_type', {}).get('plural', self.plural),
            categories=raw_resource.get('categories', [])
        )

        spec = ResourceSpec(
            provider_ref=raw_resource.get('spec', {}).get('providerRef'),
            provider_config_ref=raw_resource.get('spec', {}).get('providerConfigRef'),
            composition_ref=raw_resource.get('spec', {}).get('compositionRef'),
            claim_ref=raw_resource.get('spec', {}).get('claimRef')
        )

        conditions = []
        for cond in raw_resource.get('status', {}).get('conditions', []):
            conditions.append(ResourceCondition(
                type=cond.get('type'),
                status=cond.get('status'),
                reason=cond.get('reason'),
                message=cond.get('message'),
                last_transition_time=cond.get('lastTransitionTime')
            ))

        status = ResourceStatus(
            conditions=conditions,
            synced=any(c.type == 'Synced' and c.status == 'True' for c in conditions),
            ready=any(c.type == 'Ready' and c.status == 'True' for c in conditions),
            health_status=raw_resource.get('_health_status', ResourceStatus.UNKNOWN.value)
        )

        return KubernetesResource(
            metadata=metadata,
            spec=spec,
            status=status,
            resource_type=self.resource_type,
            provider=raw_resource.get('provider'),
            display_provider=raw_resource.get('display_provider'),
            provider_config=raw_resource.get('providerconfig'),
            upbound_info=raw_resource.get('upbound')
        )

    def to_dict(self, resource: KubernetesResource) -> Dict:
        """Convert resource to dictionary format"""
        return {
            'metadata': {
                'name': resource.metadata.name,
                'namespace': resource.metadata.namespace,
                'kind': resource.metadata.kind,
                'group': resource.metadata.group,
                'version': resource.metadata.version,
                'plural': resource.metadata.plural,
                'categories': resource.metadata.categories
            },
            'spec': {
                'providerRef': resource.spec.provider_ref,
                'providerConfigRef': resource.spec.provider_config_ref,
                'compositionRef': resource.spec.composition_ref,
                'claimRef': resource.spec.claim_ref
            },
            'status': {
                'conditions': [vars(c) for c in resource.status.conditions],
                'synced': resource.status.synced,
                'ready': resource.status.ready,
                'health_status': resource.status.health_status
            },
            'resource_type': resource.resource_type.value,
            'provider': resource.provider,
            'display_provider': resource.display_provider,
            'provider_config': resource.provider_config,
            'upbound_info': resource.upbound_info
        }
