// main.js
document.addEventListener('DOMContentLoaded', () => {
    // Get initial tab from URL or default to overview
    const searchParams = new URLSearchParams(window.location.search);
    const initialTab = searchParams.get('tab') || 'overview';
    
    // Set initial active state and load data
    switchTab(initialTab, {
        status: searchParams.get('status'),
        search: searchParams.get('search'),
        providerconfig: searchParams.get('providerconfig')
    });

    // Set up navigation click handlers
    document.querySelectorAll('[data-tab]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = link.dataset.tab;
            
            // Update active state
            document.querySelectorAll('[data-tab]').forEach(el => {
                el.classList.remove('text-blue-600', 'bg-blue-50');
                el.classList.add('text-gray-600', 'hover:bg-gray-50', 'hover:text-gray-900');
            });
            link.classList.remove('text-gray-600', 'hover:bg-gray-50', 'hover:text-gray-900');
            link.classList.add('text-blue-600', 'bg-blue-50');
            
            // Switch to the selected tab
            switchTab(tabId);
        });
    });

    // Handle browser back/forward
    window.addEventListener('popstate', () => {
        const searchParams = new URLSearchParams(window.location.search);
        const tabId = searchParams.get('tab') || 'overview';
        const params = {
            status: searchParams.get('status'),
            search: searchParams.get('search'),
            providerconfig: searchParams.get('providerconfig')
        };
        switchTab(tabId, params);
    });
});
