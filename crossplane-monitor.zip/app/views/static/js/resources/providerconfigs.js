// Store original data for filtering
window.originalProviderConfigsData = null;

function renderProviderConfigs(listElement, data) {
    if (!data?.items?.length) {
        listElement.innerHTML = '<div class="p-4 text-center text-gray-500">No provider configurations found</div>';
        return;
    }

    // Store the original data for filtering
    window.originalProviderConfigsData = structuredClone(data);

    // Get current filters
    const filters = {       
        search: document.getElementById('providerconfigs-search')?.value?.toLowerCase() || ''
    };

    // Apply filters
    const filteredData = data.items.filter(config => {
        // Search filter
        if (filters.search) {
            const searchFields = [
                config.metadata?.name,
                config.apiVersion?.split('/')[0],
                config.kind
            ].map(field => (field || '').toLowerCase());
            
            if (!searchFields.some(field => field.includes(filters.search))) {
                return false;
            }
        }
        return true;
    });

    // Set up filter handlers
    const searchInput = document.getElementById('providerconfigs-search');
    if (searchInput && !searchInput.hasEventListener) {
        const handleSearch = _.debounce(() => {
            // Update URL params
            const url = new URL(window.location);
            if (searchInput.value) {
                url.searchParams.set('search', searchInput.value);
            } else {
                url.searchParams.delete('search');
            }
            window.history.replaceState({}, '', url);

            // Re-render with current filters
            if (window.originalProviderConfigsData) {
                renderProviderConfigs(listElement, window.originalProviderConfigsData);
            }
        }, 300);

        searchInput.addEventListener('input', handleSearch);
        searchInput.hasEventListener = true;
    }

    const table = document.createElement('table');
    table.className = 'w-full table-fixed';
    table.innerHTML = `
        <thead class="bg-gray-50 dark:bg-gray-800">
            <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Provider</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        </tbody>
    `;

    const tbody = table.querySelector('tbody');
    filteredData.forEach(config => {
        const name = config.metadata?.name || '';
        const provider = config.apiVersion?.split('/')[0] || '';
        
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer';
        tr.onclick = () => {
            // Set filter values
            const statusFilter = document.getElementById('status-filter');
            const searchInput = document.getElementById('resource-search');
            const providerConfigFilter = document.getElementById('providerconfig-filter');

            if (providerConfigFilter) {
                providerConfigFilter.value = name;
                providerConfigFilter.dispatchEvent(new Event('change'));
            }
            if (searchInput) {
                searchInput.value = name;
                searchInput.dispatchEvent(new Event('input'));
            }
            if (statusFilter) {
                statusFilter.value = '';
                statusFilter.dispatchEvent(new Event('change'));
            }

            // Switch to managed resources tab
            switchTab('managed-resources');
        };
        
        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                ${name}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                ${provider.toUpperCase()}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                    Active
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <button 
                    class="text-gray-400 hover:text-gray-500"
                    data-resource='${JSON.stringify(config).replace(/'/g, "&apos;")}'
                    onclick="event.stopPropagation(); showYAMLInMonaco(JSON.parse(this.dataset.resource))"
                    title="View YAML">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    listElement.innerHTML = ''; // Clear container before rendering
    listElement.appendChild(table);
}

// Initialize search from URL params
function initializeFilters() {
    const searchParams = new URLSearchParams(window.location.search);
    const searchInput = document.getElementById('providerconfigs-search');
    
    if (searchInput && searchParams.has('search')) {
        searchInput.value = searchParams.get('search');
    }
}

// Export functions
window.renderProviderConfigs = renderProviderConfigs;
window.initializeFilters = initializeFilters;

// Initialize filters when document is ready
document.addEventListener('DOMContentLoaded', initializeFilters);
