"""Setup script for deploying the Crossplane Monitor application to Kubernetes."""

import os
import subprocess
from copy import deepcopy
from pathlib import Path

import yaml

# Configuration constants
namespace_name = "crossplane-monitor"
configmap_name = "crossplane-monitor-config"
deployment_name = "crossplane-monitor"
serviceaccount_name = "crossplane-monitor"


def find_all_files():
    """Find all relevant files in the app directory for ConfigMap creation."""
    base_path = Path("app")
    files = []

    for root, _, filenames in os.walk(base_path):
        for filename in filenames:
            if filename.endswith(('.py', '.css', '.js', '.html', '.txt')):
                file_path = os.path.join(root, filename)
                
                if filename == '__init__.py':
                    parent_dir = os.path.basename(root)
                    formatted_path = f"--from-file={parent_dir}_{filename}={file_path}"
                else:
                    formatted_path = f"--from-file={file_path}"
                
                files.append(formatted_path)

    return sorted(files)


def create_statefulset_yaml(files):
    """Create StatefulSet YAML configuration for the application."""
    copy_commands = []
    created_dirs = set()

    for file_path in files:
        file_path = Path(file_path.replace('--from-file=', '')).as_posix()
        dir_path = Path(file_path).parent.as_posix()

        if dir_path not in created_dirs:
            copy_commands.append(f"mkdir -p /{dir_path}")
            created_dirs.add(dir_path)

        if '__init__.py' in file_path:
            file_path_dest = Path(deepcopy(file_path).split('=')[1]).as_posix()
            file_path = file_path.split('=')[0]
        else:
            file_path_dest = deepcopy(file_path)
            file_path = file_path.split('/')[-1]

        copy_commands.append(f"cp /config/{file_path} /{file_path_dest}")

    statefulset = {
        'apiVersion': 'apps/v1',
        'kind': 'StatefulSet',
        'metadata': {
            'name': deployment_name,
            'namespace': namespace_name,
            'labels': {
                'app': deployment_name
            }
        },
        'spec': {
            'serviceName': deployment_name,
            'replicas': 1,
            'selector': {
                'matchLabels': {
                    'app': deployment_name
                }
            },
            'template': {
                'metadata': {
                    'labels': {
                        'app': deployment_name
                    }
                },
                'spec': {
                    'serviceAccountName': serviceaccount_name,
                    'initContainers': [{
                        'name': 'init-files',
                        'image': 'docker-remotes.artifactory.prod.aws.cloud.ihf/busybox',
                        'command': ['sh', '-c'],
                        'args': [' && '.join(copy_commands)],
                        'volumeMounts': [
                            {
                                'name': 'config-files',
                                'mountPath': '/config'
                            },
                            {
                                'name': 'app-files',
                                'mountPath': '/app'
                            },
                            {
                                'name': 'data',
                                'mountPath': '/data'
                            }
                        ]
                    }],
                    'containers': [{
                        'name': 'monitor',
                        'image': 'docker-remotes.artifactory.prod.aws.cloud.ihf/python:3.11-slim',
                        'command': ['sh', '-c'],
                        'args': ['pip install -r /app/requirements.txt && python /app/app.py'],
                        'ports': [{'containerPort': 5000}],
                        'env': [
                            {
                                'name': 'FLASK_ENV',
                                'value': 'development'
                            }
                        ],
                        'volumeMounts': [
                            {
                                'name': 'app-files',
                                'mountPath': '/app'
                            },
                            {
                                'name': 'data',
                                'mountPath': '/data'
                            }
                        ]
                    }],
                    'volumes': [
                        {
                            'name': 'config-files',
                            'configMap': {
                                'name': configmap_name
                            }
                        }
                    ]
                }
            },
            'volumeClaimTemplates': [
                {
                    'metadata': {
                        'name': 'app-files'
                    },
                    'spec': {
                        'storageClassName': 'efs-sc',
                        'accessModes': ['ReadWriteMany'],
                        'resources': {
                            'requests': {
                                'storage': '100Mi'
                            }
                        }
                    }
                },
                {
                    'metadata': {
                        'name': 'data'
                    },
                    'spec': {
                        'storageClassName': 'efs-sc',
                        'accessModes': ['ReadWriteMany'],
                        'resources': {
                            'requests': {
                                'storage': '100Mi'
                            }
                        }
                    }
                }
            ]
        }
    }

    with open('statefulset.yaml', 'w') as f:
        yaml.dump(statefulset, f, default_flow_style=False)


def create_rbac_yaml():
    """Create RBAC YAML configuration for the application."""
    rbac = [
        {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "ClusterRole",
            "metadata": {
                "name": "crossplane-monitor",
                "labels": {
                    "helm.sh/chart": "crossplane-monitor-0.1.0",
                    "app.kubernetes.io/name": "crossplane-monitor",
                    "app.kubernetes.io/instance": "release-name",
                    "app.kubernetes.io/version": "1.0.0",
                    "app.kubernetes.io/managed-by": "Helm"
                }
            },
            "rules": [
                {
                    "apiGroups": [""],
                    "resources": ["events", "namespaces", "pods"],
                    "verbs": ["get", "list", "watch"]
                },
                {
                    "apiGroups": ["apiextensions.crossplane.io"],
                    "resources": ["compositions", "compositeresourcedefinitions"],
                    "verbs": ["get", "list", "watch"]
                },
                {
                    "apiGroups": ["pkg.crossplane.io"],
                    "resources": ["providers", "configurations"],
                    "verbs": ["get", "list", "watch"]
                },
                {
                    "apiGroups": ["aws.crossplane.io", "azure.crossplane.io", "gcp.crossplane.io", "alibaba.crossplane.io"],
                    "resources": ["providerconfigs"],
                    "verbs": ["get", "list", "watch"]
                },
                {
                    "apiGroups": ["apiextensions.k8s.io"],
                    "resources": ["customresourcedefinitions"],
                    "verbs": ["get", "list", "watch"]
                },
                {
                    "apiGroups": ["*"],
                    "resources": ["*"],
                    "verbs": ["get", "list", "watch"]
                }
            ]
        },
        {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "ClusterRoleBinding",
            "metadata": {
                "name": "release-crossplane-monitor",
                "labels": {
                    "helm.sh/chart": "komoplane-0.1.0",
                    "app.kubernetes.io/name": "komoplane",
                    "app.kubernetes.io/instance": "release-name",
                    "app.kubernetes.io/version": "1.0.0",
                    "app.kubernetes.io/managed-by": "Helm"
                }
            },
            "roleRef": {
                "apiGroup": "rbac.authorization.k8s.io",
                "kind": "ClusterRole",
                "name": "crossplane-monitor"
            },
            "subjects": [
                {
                    "kind": "ServiceAccount",
                    "name": "crossplane-monitor",
                    "namespace": namespace_name
                }
            ]
        }
    ]

    with open("rbac.yaml", "w") as f:
        yaml.dump_all(rbac, f, default_flow_style=False)


def create_service_account_yaml():
    """Create ServiceAccount YAML configuration for the application."""
    service_account = {
        "apiVersion": "v1",
        "kind": "ServiceAccount",
        "metadata": {
            "name": serviceaccount_name,
            "namespace": namespace_name,
            "labels": {
                "helm.sh/chart": "crossplane-monitor-0.1.0",
                "app.kubernetes.io/name": "crossplane-monitor",
                "app.kubernetes.io/instance": "release-name",
                "app.kubernetes.io/version": "1.0.0",
                "app.kubernetes.io/managed-by": "Helm"
            }
        }
    }

    with open("service_account.yaml", "w") as f:
        yaml.dump(service_account, f, default_flow_style=False)


def create_service_yaml():
    """Create Service YAML configuration for the application."""
    service = {
        "apiVersion": "v1",
        "kind": "Service",
        "metadata": {
            "name": "crossplane-monitor",
            "namespace": namespace_name
        },
        "spec": {
            "selector": {
                "app": "crossplane-monitor"
            },
            "ports": [
                {"port": 80, "targetPort": 5000}
            ],
            "type": "ClusterIP"
        }
    }

    with open("service.yaml", "w") as f:
        yaml.dump(service, f)


def main():
    """Main function to deploy the application to Kubernetes."""
    # Find all files
    files = find_all_files()

    # Remove existing ConfigMap
    subprocess.run(["kubectl", "delete", "configmap", configmap_name, "-n", namespace_name], check=False)

    # Create ConfigMap command
    cmd = ["kubectl", "create", "configmap", configmap_name, "-n", namespace_name]
    cmd.extend(files)

    # Execute ConfigMap command
    subprocess.run(cmd)

    # Create YAML resources
    create_statefulset_yaml(files)
    create_service_yaml()
    create_rbac_yaml()
    create_service_account_yaml()

    # Apply resources to cluster
    subprocess.run(["kubectl", "delete", "-f", "statefulset.yaml"], check=False)
    subprocess.run(["kubectl", "apply", "-f", "statefulset.yaml"])
    subprocess.run(["kubectl", "apply", "-f", "rbac.yaml"])
    subprocess.run(["kubectl", "apply", "-f", "service_account.yaml"])
    subprocess.run(["kubectl", "apply", "-f", "service.yaml"])


if __name__ == "__main__":
    main()
