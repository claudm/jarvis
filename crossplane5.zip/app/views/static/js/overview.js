// overview.js - Overview page functionality

async function loadOverviewData(retryCount = 0) {
    const maxRetries = 5;
    const retryDelay = 2000; // 2 seconds

    try {
        showLoading();
        const response = await fetch('/api/overview');
        const data = await response.json();

        if (!response.ok) {
            if (data.error?.includes('not available yet') && retryCount < maxRetries) {
                console.log(`Data not ready, retrying in ${retryDelay}ms (attempt ${retryCount + 1}/${maxRetries})`);
                hideLoading();
                await new Promise(resolve => setTimeout(resolve, retryDelay));
                return loadOverviewData(retryCount + 1);
            }
            throw new Error(data.error || 'Failed to load overview data');
        }

        window.originalOverviewData = structuredClone(data);
        renderOverview(data);
    } catch (error) {
        console.error('Error loading overview data:', error);
        showError(error.message);
    } finally {
        hideLoading();
    }
}


function renderOverview(data) {
    // Update status cards
    updateStatusCards(data);

    // Update health status
    updateHealthStatus(data);

    // Update Crossplane status
    updateCrossplaneStatus(data);
}

function updateStatusCards(data) {
    // Use DocumentFragment for better performance
    const fragment = document.createDocumentFragment();
    const countElements = {
        'claims-count': data.claims.count,
        'composite-resources-count': data.composite_resources.count,
        'managed-resources-count': data.managed_resources.total_count,
        'providerconfigs-count': data.provider_configs.count,
        'providers-count': data.providers.count,
        'compositions-count': data.compositions.count,
        'composite-resource-definitions-count': data.composite_resource_definitions.count
    };

    Object.entries(countElements).forEach(([id, count]) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = count || '0';
        }
    });
}

function updateHealthStatus(data) {
    const healthSummary = data.managed_resources.health_summary;
    const total = healthSummary.healthy + healthSummary.unhealthy + healthSummary.unknown;

    // Update health status numbers and percentages
    const statuses = ['healthy', 'unhealthy', 'unknown'];
    statuses.forEach(status => {
        const count = healthSummary[status];
        const percentage = total > 0 ? (count / total) * 100 : 0;

        const countElement = document.getElementById(`${status}-count`);
        const percentageElement = document.getElementById(`${status}-percentage`);

        if (countElement) {
            countElement.textContent = count;
        }
        if (percentageElement) {
            percentageElement.style.width = `${percentage}%`;
        }
    });

    // Update total count
    const totalCount = document.getElementById('total-count');
    if (totalCount) {
        totalCount.textContent = total;
    }
}

function updateCrossplaneStatus(data) {
    // Update Crossplane version
    const versionElement = document.getElementById('crossplane-version');
    if (versionElement) {
        versionElement.textContent = `Version: ${data.crossplane.version}`;
    }

    // Update Crossplane health
    const healthElement = document.getElementById('crossplane-health');
    if (healthElement) {
        const health = data.crossplane.health;
        healthElement.className = `px-3 py-1 rounded-full text-sm font-medium ${getHealthStatusClass(health)}`;
        healthElement.textContent = health;
    }

    // Update Crossplane pods
    const podsList = document.getElementById('crossplane-pods');
    if (podsList) {
        const pods = data.crossplane.pods;
        const fragment = document.createDocumentFragment();
        
        pods.forEach(pod => {
            const div = document.createElement('div');
            div.className = 'flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded mb-2';
            div.innerHTML = `
                <div class="flex-1">
                    <div class="font-medium text-gray-900 dark:text-white">${pod.name}</div>
                    <div class="text-sm text-gray-500">
                        ${pod.containers.map(c => `
                            <div class="flex items-center space-x-2">
                                <span class="text-xs px-2 py-1 rounded-full ${getHealthStatusClass(c.status)}">${c.status}</span>
                                <span>${c.name}</span>
                                ${c.restarts > 0 ? `<span class="text-red-500">(${c.restarts} restarts)</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
            fragment.appendChild(div);
        });

        podsList.innerHTML = '';
        podsList.appendChild(fragment);
    }
}

function initializeCardClickHandlers() {
    const cards = document.querySelectorAll('[data-tab]');
    cards.forEach(card => {
        card.addEventListener('click', () => {
            const tabId = card.getAttribute('data-tab');
            if (window.switchTab) {
                window.switchTab(tabId);
            }
        });
    });
}

// Initialize overview when document is ready
document.addEventListener('DOMContentLoaded', () => {
    const overviewPanel = document.getElementById('overview-panel');
    if (overviewPanel && !overviewPanel.classList.contains('hidden')) {
        loadOverviewData();
        initializeCardClickHandlers();
    }
});

// Export functions for use in other modules
window.renderOverview = renderOverview;
window.loadOverviewData = loadOverviewData;

function getHealthStatusClass(status) {
    switch (status?.toLowerCase()) {
        case 'healthy':
            return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
        case 'unhealthy':
            return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
        default:
            return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
    }
}
