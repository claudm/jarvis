#instalar dependencias
pip install -r requirements.txt

#executar
python gnf config.yaml