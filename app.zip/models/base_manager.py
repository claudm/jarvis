from kubernetes import client, config
from typing import List, Dict, Optional
import logging
import threading
import warnings
import urllib3
import time

# Disable SSL verification warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

# Cache for CRD and resource information
crd_scope_cache = {}  # Cache for CRD scope information
crd_list_cache = {}   # Cache for CRD lists
resource_cache = {}   # Cache for resources
cache_ttl = 300      # Cache TTL in seconds (5 minutes)
last_cache_update = {}  # Track last update time for each cache

class BaseManager:
    _instance = None
    _lock = threading.Lock()
    _initialized = False
    _connection_retries = 5
    _retry_delay = 2  # seconds

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self.core_v1_api = None
            self.apps_v1_api = None
            self.namespace = None
            self._initialized = True
            self._closed = False

    @classmethod
    def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = cls()
                    instance.initialize_client()
                    cls._instance = instance
        elif cls._instance._closed:
            with cls._lock:
                cls._instance.initialize_client()
        return cls._instance

    def initialize_client(self, endpoint=None, token=None, kubeconfig=None):
        """Initialize Kubernetes client with flexible authentication options"""
        try:
            self.close()

            configuration = client.Configuration()
            
            # SSL settings
            configuration.verify_ssl = False
            configuration.ssl_ca_cert = None
            configuration.assert_hostname = False
            
            # Connection settings
            configuration.connection_pool_maxsize = 32
            configuration.retries = 5
            configuration.timeout = 60

            # Try authentication methods in order
            if endpoint and token:
                # 1. Use provided endpoint and token
                configuration.api_key = {"authorization": f"Bearer {token}"}
                configuration.host = endpoint
                client.Configuration.set_default(configuration)
                logger.info("Using provided endpoint/token configuration")
            elif kubeconfig:
                # 2. Use provided kubeconfig path
                try:
                    config.load_kube_config(config_file=kubeconfig, client_configuration=configuration)
                    logger.info(f"Using provided kubeconfig: {kubeconfig}")
                except Exception as e:
                    logger.error(f"Failed to load provided kubeconfig: {e}")
                    raise
            else:
                # 3. Try in-cluster config
                try:
                    config.load_incluster_config(client_configuration=configuration)
                    logger.info("Using in-cluster configuration")
                except Exception:
                    # 4. Try default kubeconfig location
                    try:
                        config.load_kube_config(client_configuration=configuration)
                        logger.info("Using default kubeconfig configuration")
                    except Exception as e:
                        logger.error(f"Failed to load kubeconfig: {e}")
                        raise Exception("No valid Kubernetes configuration found")

            # Initialize with retry
            max_retries = 5
            retry_delay = 2
            last_error = None

            for attempt in range(max_retries):
                try:
                    self.api_client = client.ApiClient(configuration)
                    self.custom_api = client.CustomObjectsApi(self.api_client)
                    self.api_ext = client.ApiextensionsV1Api(self.api_client)
                    self.core_v1_api = client.CoreV1Api(self.api_client)
                    self.apps_v1_api = client.AppsV1Api(self.api_client)
                    
                    # Test connection
                    self.api_ext.get_api_resources()
                    logger.info("Successfully connected to Kubernetes cluster")
                    self._closed = False
                    return
                except Exception as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        logger.warning(f"Connection attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
                        self.close()
                        time.sleep(retry_delay)
                    else:
                        logger.error(f"Failed to initialize Kubernetes client after {max_retries} attempts: {last_error}")
                        raise last_error

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}")
            raise

    def get_current_namespace(self):
        """Get the current namespace."""
        try:
            # Try to get namespace from service account first
            with open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r") as f:
                return f.read().strip()
        except:
            # If not running in cluster, return default namespace
            return "default"

    def _ensure_connection(self):
        """Ensure connection is active, retry if needed"""
        if not self._closed and self.api_client and self.custom_api and self.api_ext:
            return True

        for attempt in range(self._connection_retries):
            try:
                self.initialize_client()
                return True
            except Exception as e:
                if attempt == self._connection_retries - 1:
                    logger.error(f"Failed to ensure connection after {self._connection_retries} attempts: {e}")
                    return False
                logger.warning(f"Connection attempt {attempt + 1} failed: {e}")
                time.sleep(self._retry_delay)
        return False

    def close(self):
        """Close all connections and clear caches"""
        try:
            if self.api_client:
                try:
                    self.api_client.close()
                except Exception as e:
                    logger.warning(f"Error closing Kubernetes API client: {e}")
                finally:
                    self.api_client = None
                    self.custom_api = None
                    self.api_ext = None
                    self.core_v1_api = None
                    self.apps_v1_api = None
                    self._closed = True
                    self._clear_cache()  # Clear caches on close
        except Exception as e:
            logger.error(f"Error during connection cleanup: {e}")
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self.core_v1_api = None
            self.apps_v1_api = None
            self._closed = True
            self._clear_cache()  # Clear caches on error

    def _clear_cache(self):
        """Clear all caches"""
        crd_scope_cache.clear()
        crd_list_cache.clear()
        resource_cache.clear()
        last_cache_update.clear()

    def cleanup(self):
        """Cleanup resources when application shuts down"""
        try:
            self.close()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
        finally:
            BaseManager._instance = None
            self._initialized = False
            self._closed = True
            self._clear_cache()  # Clear caches on cleanup
