import boto3
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
import os

dynamodb = boto3.resource('dynamodb',
    aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
    region_name=os.environ.get('AWS_REGION', 'us-east-1')
)

class User(UserMixin):
    def __init__(self, username=None, password_hash=None, is_admin=False, id=None):
        self.id = int(id) if id else None
        self.username = username
        self.password_hash = password_hash
        self.is_admin = is_admin

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @classmethod
    def create_user(cls, username, password, is_admin=False):
        user = cls(username=username, is_admin=is_admin)
        user.set_password(password)
        user.save()
        return user

    @staticmethod
    def get_table():
        return dynamodb.Table('users')

    @classmethod
    def get(cls, user_id):
        table = cls.get_table()
        response = table.get_item(Key={'id': int(user_id)})
        if 'Item' not in response:
            return None
        item = response['Item']
        return cls(
            id=item['id'],
            username=item['username'],
            password_hash=item['password_hash'],
            is_admin=item.get('is_admin', False)
        )

    @classmethod
    def get_by_username(cls, username):
        table = cls.get_table()
        response = table.scan(
            FilterExpression='username = :username',
            ExpressionAttributeValues={':username': username}
        )
        if not response['Items']:
            return None
        item = response['Items'][0]
        return cls(
            id=item['id'],
            username=item['username'],
            password_hash=item['password_hash'],
            is_admin=item.get('is_admin', False)
        )

    def save(self):
        table = self.get_table()
        
        # Verifica se o username já existe
        existing_users = self.get_all_users()
        if existing_users and self.username not in [user.username for user in existing_users]:
            # Novo usuário, adiciona à lista existente
            self.id = max(user.id for user in existing_users) + 1
            existing_users.append(self)
            self._save_users(existing_users)
        elif self.id:
            # Usuário existente, atualiza o registro
            table.update_item(
                Key={'id': self.id},
                UpdateExpression="SET username = :username, password_hash = :password_hash, is_admin = :is_admin",
                ExpressionAttributeValues={
                    ':username': self.username,
                    ':password_hash': self.password_hash,
                    ':is_admin': self.is_admin
                }
            )
        else:
            # Novo usuário, cria um novo registro
            self.id = 1 if not existing_users else max(user.id for user in existing_users) + 1
            table.put_item(Item={
                'id': self.id,
                'username': self.username,
                'password_hash': self.password_hash,
                'is_admin': self.is_admin
            })
        
        return self

    def _save_users(self, users):
        table = self.get_table()
        with table.batch_writer() as batch:
            for user in users:
                batch.put_item(Item={
                    'id': user.id,
                    'username': user.username,
                    'password_hash': user.password_hash,
                    'is_admin': user.is_admin
                })

    @classmethod
    def get_all_users(cls):
        table = cls.get_table()
        response = table.scan()
        return [cls(**item) for item in response['Items']]

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def delete(self):
        table = self.get_table()
        table.delete_item(Key={'id': self.id})
        return True

    def __repr__(self):
        return f'<User {self.username}>'

    @staticmethod
    def create_table():
        table_name = 'users'
        existing_tables = [t.name for t in dynamodb.tables.all()]
        if table_name not in existing_tables:
            table = dynamodb.create_table(
                TableName=table_name,
                KeySchema=[
                    {
                        'AttributeName': 'id',
                        'KeyType': 'HASH'
                    }
                ],
                AttributeDefinitions=[
                    {
                        'AttributeName': 'id',
                        'AttributeType': 'N'
                    },
                    {
                        'AttributeName': 'username',
                        'AttributeType': 'S'
                    }
                ],
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': 'username-index',
                        'KeySchema': [
                            {
                                'AttributeName': 'username',
                                'KeyType': 'HASH'
                            }
                        ],
                        'Projection': {
                            'ProjectionType': 'ALL'
                        },
                        'ProvisionedThroughput': {
                            'ReadCapacityUnits': 5,
                            'WriteCapacityUnits': 5
                        }
                    }
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            )
            table.wait_until_exists()
