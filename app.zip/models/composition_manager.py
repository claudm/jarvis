from typing import List, Dict, Optional
import logging
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class CompositionManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.api_version = "v1"
        self.group = "apiextensions.crossplane.io"

    def list_composite_resource_definitions(self) -> List[dict]:
        """List all composite resource definitions."""
        if not self._ensure_connection():
            return []
        
        try:
            self.plural = "compositeresourcedefinitions"
            resources = self._list_resources()
            return resources
        except Exception as e:
            logger.error(f"Error listing composite resource definitions: {str(e)}")
            return []

    def get_xrd(self, name: str) -> Optional[dict]:
        """Get a specific composite resource definition."""
        if not self._ensure_connection():
            return None
        
        try:
            self.plural = "compositeresourcedefinitions"
            resource = self._get_resource(name)
            return resource
        except Exception as e:
            logger.error(f"Error getting composite resource definition: {str(e)}")
            return None

    def list_compositions(self) -> List[dict]:
        """List all compositions."""
        if not self._ensure_connection():
            return []
        
        try:
            self.plural = "compositions"
            resources = self._list_resources()
            return resources
        except Exception as e:
            logger.error(f"Error listing compositions: {str(e)}")
            return []

    def get_composition(self, name: str) -> Optional[dict]:
        """Get a specific composition."""
        if not self._ensure_connection():
            return None
        
        try:
            self.plural = "compositions"
            resource = self._get_resource(name)
            return resource
        except Exception as e:
            logger.error(f"Error getting composition: {str(e)}")
            return None
