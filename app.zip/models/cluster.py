import boto3
import os
from models.auth import User

dynamodb = boto3.resource('dynamodb',
    aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
    region_name=os.environ.get('AWS_REGION', 'us-east-1')
)

class Cluster:
    def __init__(self, name=None, endpoint=None, token=None, kubeconfig=None, id=None, user_ids=None):
        self.id = int(id) if id else None
        self.name = name
        self.endpoint = endpoint
        self.token = token
        self.kubeconfig = kubeconfig
        self.user_ids = user_ids or []

    @staticmethod
    def get_table():
        return dynamodb.Table('clusters')

    @classmethod
    def get(cls, cluster_id):
        table = cls.get_table()
        response = table.get_item(Key={'id': int(cluster_id)})
        if 'Item' not in response:
            return None
        item = response['Item']
        return cls(
            id=item['id'],
            name=item['name'],
            endpoint=item.get('endpoint'),
            token=item.get('token'),
            kubeconfig=item.get('kubeconfig'),
            user_ids=item.get('user_ids', [])
        )

    @classmethod
    def query(cls):
        table = cls.get_table()
        response = table.scan()
        return [cls(
            id=item['id'],
            name=item['name'],
            endpoint=item.get('endpoint'),
            token=item.get('token'),
            kubeconfig=item.get('kubeconfig'),
            user_ids=item.get('user_ids', [])
        ) for item in response['Items']]

    def save(self):
        table = self.get_table()
        
        if not self.id:
            # Get next ID for new records
            response = table.scan(
                Select='COUNT'
            )
            self.id = response['Count'] + 1
            
            # For new records, use put_item
            item = {
                'id': self.id,
                'name': self.name,
                'user_ids': self.user_ids
            }
            if self.endpoint:
                item['endpoint'] = self.endpoint
            if self.token:
                item['token'] = self.token
            if self.kubeconfig:
                item['kubeconfig'] = self.kubeconfig
            
            table.put_item(Item=item)
        else:
            # For existing records, use update_item
            update_expression = "SET #name = :name, #user_ids = :user_ids"
            expression_attribute_names = {
                '#name': 'name',
                '#user_ids': 'user_ids'
            }
            expression_attribute_values = {
                ':name': self.name,
                ':user_ids': self.user_ids
            }
            
            # Add optional fields if they exist
            if self.endpoint:
                update_expression += ", #endpoint = :endpoint"
                expression_attribute_names['#endpoint'] = 'endpoint'
                expression_attribute_values[':endpoint'] = self.endpoint
            
            if self.token:
                update_expression += ", #token = :token"
                expression_attribute_names['#token'] = 'token'
                expression_attribute_values[':token'] = self.token
            
            if self.kubeconfig:
                update_expression += ", #kubeconfig = :kubeconfig"
                expression_attribute_names['#kubeconfig'] = 'kubeconfig'
                expression_attribute_values[':kubeconfig'] = self.kubeconfig
            
            table.update_item(
                Key={'id': self.id},
                UpdateExpression=update_expression,
                ExpressionAttributeNames=expression_attribute_names,
                ExpressionAttributeValues=expression_attribute_values
            )
        
        return self

    def delete(self):
        table = self.get_table()
        table.delete_item(Key={'id': self.id})

    def add_users(self, user_ids):
        """Add users to the cluster"""
        new_user_ids = set(user_ids)
        existing_user_ids = set(self.user_ids)
        all_user_ids = existing_user_ids.union(new_user_ids)
        self.user_ids = list(all_user_ids)
        self._update_user_ids()

    def remove_users(self, user_ids):
        """Remove users from the cluster"""
        user_ids_to_remove = set(user_ids)
        remaining_user_ids = set(self.user_ids) - user_ids_to_remove
        self.user_ids = list(remaining_user_ids)
        self._update_user_ids()

    def _update_user_ids(self):
        """Update the user_ids field in DynamoDB"""
        table = self.get_table()
        table.update_item(
            Key={'id': self.id},
            UpdateExpression="SET #user_ids = :user_ids",
            ExpressionAttributeNames={
                '#user_ids': 'user_ids'
            },
            ExpressionAttributeValues={
                ':user_ids': self.user_ids
            }
        )

    def get_users(self):
        """Get list of user IDs who have access to this cluster"""
        return self.user_ids

    def get_user_list(self):
        """Get list of User objects who have access to this cluster"""
        users = []
        for user_id in self.user_ids:
            user = User.get(user_id)
            if user:
                users.append(user)
        return users

    def __repr__(self):
        return f'<Cluster {self.name}>'

    @staticmethod
    def create_table():
        table_name = 'clusters'
        existing_tables = [t.name for t in dynamodb.tables.all()]
        if table_name not in existing_tables:
            table = dynamodb.create_table(
                TableName=table_name,
                KeySchema=[
                    {
                        'AttributeName': 'id',
                        'KeyType': 'HASH'
                    }
                ],
                AttributeDefinitions=[
                    {
                        'AttributeName': 'id',
                        'AttributeType': 'N'
                    }
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            )
            table.wait_until_exists()
