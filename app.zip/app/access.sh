#!/bin/bash

# Obter o contexto atual
CURRENT_CONTEXT=$(kubectl config current-context)
echo "Contexto atual: $CURRENT_CONTEXT"

# Limpar recursos existentes
kubectl delete serviceaccount admin-user -n kube-system --ignore-not-found
kubectl delete clusterrolebinding admin-user -n kube-system --ignore-not-found 
kubectl delete secret admin-user-token -n kube-system --ignore-not-found

# Criar service account admin
echo "Criando service account admin..."
kubectl create serviceaccount admin-user -n kube-system

# Criar cluster role binding
echo "Criando cluster role binding..."
kubectl create clusterrolebinding admin-user --clusterrole=cluster-admin --serviceaccount=kube-system:admin-user

# Criar secret do tipo service account token
echo "Criando secret para o token..."
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
 name: admin-user-token
 namespace: kube-system
 annotations:
   kubernetes.io/service-account.name: admin-user
type: kubernetes.io/service-account-token
EOF

# Aguardar o token ser gerado
echo "aguardando token ser gerado..."
sleep 3

# Obter o host e o token
KUBERNETES_HOST=$(kubectl config view --minify -o jsonpath="{.clusters[0].cluster.server}")
KUBERNETES_TOKEN=$(kubectl get secret admin-user-token -n kube-system -o jsonpath="{.data.token}" | base64 -d)

if [ -z "$KUBERNETES_TOKEN" ]; then
 echo "Erro: Token não foi gerado!"
 exit 1
fi

echo -e "\nVariáveis para usar:"
echo "export KUBERNETES_HOST=\"$KUBERNETES_HOST\""
echo "export KUBERNETES_TOKEN=\"$KUBERNETES_TOKEN\""

echo $KUBERNETES_ENDPOINT
echo "autenticando o token:"
echo 'curl -k -H "Authorization: Bearer $KUBERNETES_TOKEN" $KUBERNETES_HOST/api/v1/namespaces'