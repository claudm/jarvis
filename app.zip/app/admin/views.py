from flask_admin.contrib.sqla import ModelView
from flask_login import current_user
from flask import redirect, url_for
from wtforms import form, fields, SelectMultipleField
from models.auth import User
from models.cluster import Cluster

class SecureModelView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin
        
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.login'))

class UserForm(form.Form):
    username = fields.StringField('Username')
    password = fields.PasswordField('Password')
    is_admin = fields.BooleanField('Admin')

class UserView(SecureModelView):
    column_list = ['username', 'is_admin']
    column_searchable_list = ['username']
    column_filters = ['is_admin']
    form = UserForm
    
    def on_model_change(self, form, model, is_created):
        if is_created or form.password.data:
            model.set_password(form.password.data)
            
        # Ensure admin user can't remove their own admin status
        if model.id == current_user.id and not form.is_admin.data:
            form.is_admin.data = True
            model.is_admin = True

class ClusterForm(form.Form):
    name = fields.StringField('Name')
    endpoint = fields.StringField('Endpoint')
    token = fields.TextAreaField('Token')
    user_ids = SelectMultipleField('Users', coerce=int)

class ClusterView(SecureModelView):
    column_list = ['name', 'endpoint', 'users']
    column_searchable_list = ['name', 'endpoint']
    form = ClusterForm
    
    def create_form(self, obj=None):
        form = super(ClusterView, self).create_form(obj)
        form.user_ids.choices = [(u.id, u.username) for u in User.query.all()]
        return form
        
    def edit_form(self, obj=None):
        form = super(ClusterView, self).edit_form(obj)
        form.user_ids.choices = [(u.id, u.username) for u in User.query.all()]
        if obj:
            form.user_ids.data = [user.id for user in obj.users]
        return form
    
    def on_model_change(self, form, model, is_created):
        # Get User objects from selected IDs
        selected_users = User.query.filter(User.id.in_(form.user_ids.data)).all()
        model.users = selected_users
