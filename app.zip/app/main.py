from flask import Flask, redirect, url_for
from flask_admin import Admin
from flask_login import LoginManager, current_user
from datetime import timedelta
from models.auth import db, User
from models.cluster import Cluster
from admin.views import UserView, ClusterView
from views.auth import auth, init_users
import os

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    
    # Initialize extensions
    db.init_app(app)
    
    # Setup Flask-Login
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)
    
    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))
    
    # Register blueprints
    app.register_blueprint(auth, url_prefix='/auth')
    
    # Root route redirects to admin or login
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            return redirect(url_for('admin.index'))
        return redirect(url_for('auth.login'))
    
    # Setup Flask-Admin
    admin = Admin(app, name='Crossplane Monitor', template_mode='bootstrap4')
    admin.add_view(UserView(User, db.session, name='Users', endpoint='user'))
    admin.add_view(ClusterView(Cluster, db.session, name='Clusters', endpoint='cluster'))
    
    # Create database tables
    with app.app_context():
        db.create_all()
        init_users()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
