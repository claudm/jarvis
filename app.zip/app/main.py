from flask import Flask
from flask_cors import CORS
import atexit
import asyncio
import uvicorn
from asgiref.wsgi import WsgiToAsgi
from controllers.page_controller import page_bp
from controllers.provider_controller import bp as provider_bp
from controllers.composition_controller import bp as composition_bp
from controllers.composite_resource_definition_controller import bp as composite_resource_definition_bp
from controllers.claim_controller import bp as claim_bp
from controllers.resource_controller import bp as resource_bp
from controllers.provider_config_controller import bp as provider_config_bp
from models.crossplane_manager import CrossplaneManager

# Create Flask app
app = Flask(__name__, 
    template_folder='views/templates',
    static_folder='views/static'
)

# Enable CORS
CORS(app)

# Register blueprints
app.register_blueprint(page_bp)
app.register_blueprint(provider_bp)
app.register_blueprint(composition_bp)
app.register_blueprint(composite_resource_definition_bp)
app.register_blueprint(claim_bp)
app.register_blueprint(resource_bp)
app.register_blueprint(provider_config_bp)

async def cleanup():
    """Cleanup function to be called when the application shuts down"""
    try:
        manager = await CrossplaneManager.get_instance()
        await manager.cleanup()
    except Exception as e:
        print(f"Error during cleanup: {e}")

def sync_cleanup():
    """Synchronous wrapper for cleanup function"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    loop.run_until_complete(cleanup())

# Register cleanup function
atexit.register(sync_cleanup)

# Convert Flask app to ASGI
asgi_app = WsgiToAsgi(app)

if __name__ == '__main__':
    uvicorn.run(asgi_app, host="0.0.0.0", port=5000)
