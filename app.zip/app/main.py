from flask import Flask
import atexit
import asyncio
from controllers.page_controller import page_bp
from controllers.provider_controller import bp as provider_bp
from controllers.composition_controller import bp as composition_bp
from controllers.composite_resource_definition_controller import bp as composite_resource_definition_bp
from controllers.claim_controller import bp as claim_bp
from controllers.resource_controller import bp as resource_bp
from controllers.provider_config_controller import bp as provider_config_bp
from models.crossplane_manager import CrossplaneManager

app = Flask(__name__,
    template_folder='views/templates',
    static_folder='views/static'
)

# Register blueprints
app.register_blueprint(page_bp)
app.register_blueprint(provider_bp)
app.register_blueprint(composition_bp)
app.register_blueprint(composite_resource_definition_bp)
app.register_blueprint(claim_bp)
app.register_blueprint(resource_bp)
app.register_blueprint(provider_config_bp)

async def cleanup():
    """Cleanup function to be called when the application shuts down"""
    try:
        manager = await CrossplaneManager.get_instance()
        await manager.cleanup()
    except Exception as e:
        print(f"Error during cleanup: {e}")

def sync_cleanup():
    """Synchronous wrapper for cleanup function"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    loop.run_until_complete(cleanup())

# Register cleanup function
atexit.register(sync_cleanup)

if __name__ == '__main__':
    app.run(debug=True)
