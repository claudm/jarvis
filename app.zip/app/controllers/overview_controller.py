from flask import Blueprint, jsonify, request, render_template, current_app
from models.crossplane_manager import CrossplaneManager
from services.background_worker import BackgroundWorker, _worker
import logging

bp = Blueprint('overview', __name__, url_prefix='/api')
UPDATE_INTERVAL = BackgroundWorker().update_interval
logger = logging.getLogger(__name__)

# Store the overview data at the application level
overview_data = None

@bp.route('/overview/interval', methods=['POST'])
def update_interval():
    """Update the refresh interval"""
    try:
        new_interval = request.json.get('interval')
        if not new_interval or not isinstance(new_interval, int):
            return jsonify({"error": "Invalid interval"}), 400
            
        if new_interval < 3 or new_interval > 3600:
            return jsonify({"error": "Interval must be between 3 and 3600 seconds"}), 400

        # Update the worker's interval
        _worker.update_interval = new_interval
        
        # Force an immediate update of the overview data
        _worker._update_overview_cache()
        
        return jsonify({
            "message": "Interval updated successfully",
            "interval": new_interval
        }), 200
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error updating interval: {error_msg}")
        return jsonify({"error": f"Failed to update interval: {error_msg}"}), 500

@bp.route('/overview', methods=['GET'])
def get_overview():
    """Get system overview from application cache"""
    try:
        logger.info("Returning overview data from application cache")
        
        global overview_data
        if overview_data is None:
            raise Exception("Overview data not available yet")

        # Transform the data to match the expected format
        results = {
            'crossplane': {
                'health': overview_data['health'],
                'version': overview_data['version'],
                'pods': overview_data['pods']
            },
            'managed_resources': {
                'total_count': overview_data['counts']['managed_resources'],
                'health_summary': overview_data['health_summary']
            },
            'claims': {
                'count': overview_data['counts']['claims']
            },
            'composite_resources': {
                'count': overview_data['counts']['composite_resources']
            },
            'providers': {
                'count': overview_data['counts']['providers']
            },
            'provider_configs': {
                'count': overview_data['counts']['providers']  # Using providers count as proxy
            },
            'compositions': {
                'count': overview_data['counts']['compositions']
            },
            'composite_resource_definitions': {
                'count': overview_data['counts']['xrds']
            }
        }

        logger.info("Successfully fetched system overview data")
        return jsonify(results)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting system overview data: {error_msg}")
        return jsonify({"error": f"Failed to get system overview data: {error_msg}"}), 500
