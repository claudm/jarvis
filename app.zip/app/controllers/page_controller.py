from flask import Blueprint, render_template

page_bp = Blueprint('page', __name__)

@page_bp.route('/')
@page_bp.route('/overview')
def index():
    return render_template('index.html')

@page_bp.route('/providers')
def providers():
    return render_template('providers.html')

@page_bp.route('/compositions')
def compositions():
    return render_template('compositions.html')

@page_bp.route('/composite-resource-definitions')
def composite_resource_definitions():
    return render_template('composite-resource-definitions.html')

@page_bp.route('/claims')
def claims():
    return render_template('claims.html')

@page_bp.route('/managed-resources')
def managed_resources():
    return render_template('managed-resources.html')

@page_bp.route('/composite-resources')
def composite_resources():
    return render_template('composite-resources.html')

@page_bp.route('/providerconfigs')
def provider_configs():
    return render_template('providerconfigs.html')
