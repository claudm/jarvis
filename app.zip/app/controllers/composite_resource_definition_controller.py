from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('composite_resource_definition', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

@bp.route('/composite-resource-definitions', methods=['GET'])
def list_composite_resource_definitions():
    """List all Composite Resource Definitions"""
    try:
        logger.info("Attempting to list Composite Resource Definitions from Kubernetes API")
        # Get XRDs using the manager
        manager = CrossplaneManager.get_instance()
        xrds = manager.list_composite_resource_definitions()
        
        logger.info(f"Retrieved {len(xrds)} Composite Resource Definitions")
        return jsonify({
            "items": xrds,
            "count": len(xrds),
            "message": "No Composite Resource Definitions found" if not xrds else None
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing XRDs: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list Composite Resource Definitions"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Composite Resource Definitions resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list Composite Resource Definitions: {error_msg}"}), 500

@bp.route('/composite-resource-definitions/<name>', methods=['GET'])
def get_composite_resource_definition(name):
    """Get a specific Composite Resource Definition by name"""
    try:
        logger.info(f"Attempting to get Composite Resource Definition: {name}")
        manager = CrossplaneManager.get_instance()
        xrd = manager.get_xrd(name)
        if not xrd:
            logger.warning(f"Composite Resource Definition not found: {name}")
            return jsonify({"error": f"Composite Resource Definition '{name}' not found"}), 404
        return jsonify(xrd)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting Composite Resource Definition {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get Composite Resource Definition"}), 403
        else:
            return jsonify({"error": f"Failed to get Composite Resource Definition: {error_msg}"}), 500
