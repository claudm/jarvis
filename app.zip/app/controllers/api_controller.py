from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager

api_bp = Blueprint('api', __name__)

@api_bp.route('/overview')
def get_overview():
    try:
        manager = CrossplaneManager.get_instance()
        overview_data = manager.get_system_overview()
        return jsonify(overview_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/managed-resources')
def get_managed_resources():
    try:
        manager = CrossplaneManager.get_instance()
        resources = manager.list_managed_resources()
        return jsonify(resources)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/providers')
def get_providers():
    try:
        manager = CrossplaneManager.get_instance()
        providers = manager.list_providers()
        return jsonify(providers)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/compositions')
def get_compositions():
    try:
        manager = CrossplaneManager.get_instance()
        compositions = manager.list_compositions()
        return jsonify(compositions)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/composite-resource-definitions')
def get_composite_resource_definitions():
    try:
        manager = CrossplaneManager.get_instance()
        definitions = manager.list_composite_resource_definitions()
        return jsonify(definitions)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/claims')
def get_claims():
    try:
        manager = CrossplaneManager.get_instance()
        claims = manager.list_claims()
        return jsonify(claims)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/composite-resources')
def get_composite_resources():
    try:
        manager = CrossplaneManager.get_instance()
        resources = manager.list_composite_resources()
        return jsonify(resources)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/provider-configs')
def get_provider_configs():
    try:
        manager = CrossplaneManager.get_instance()
        configs = manager.list_provider_configs()
        return jsonify(configs)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
