# app/controllers/resource_controller.py
from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('resources', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

@bp.route('/overview', methods=['GET'])
def get_overview():
    """Get overview data including status and counts"""
    try:
        logger.info("Fetching overview data")
        manager = CrossplaneManager.get_instance()
        
        # Get Crossplane status
        status = manager.get_crossplane_status()
        
        # Get minimal resource data for overview
        resources = manager.get_managed_resources()
        grouped_resources, total_count, health_summary = process_resources(resources)
        
        # Get minimal data for other resources
        claims = manager.list_claims()
        composite_resources = manager.get_composite_resources()
        providers = manager.list_providers()
        compositions = manager.list_compositions()
        xrds = manager.list_composite_resource_definitions()
        
        # Extract only necessary fields for recent activity
        def extract_minimal_resource_data(items):
            if not items:
                return []
            return [{
                'metadata': {
                    'name': item.get('metadata', {}).get('name'),
                    'creationTimestamp': item.get('metadata', {}).get('creationTimestamp')
                },
                'kind': item.get('kind'),
                '_health_status': item.get('_health_status'),
                '_resource_type': {
                    'kind': item.get('_resource_type', {}).get('kind') if item.get('_resource_type') else None
                }
            } for item in items]

        # Prepare minimal response
        return jsonify({
            'data': {
                'crossplane': {
                    'health': status.get('health'),
                    'version': status.get('version'),
                    'pods': [{
                        'name': pod.get('name'),
                        'status': pod.get('status'),
                        'containers': [{
                            'name': container.get('name'),
                            'status': container.get('status'),
                            'restarts': container.get('restarts')
                        } for container in pod.get('containers', [])]
                    } for pod in status.get('pods', [])]
                },
                'managed_resources': {
                    'items': extract_minimal_resource_data(resources),
                    'total_count': total_count,
                    'health_summary': health_summary
                },
                'claims': {
                    'items': extract_minimal_resource_data(claims),
                    'count': len(claims) if claims else 0
                },
                'composite_resources': {
                    'items': extract_minimal_resource_data(composite_resources),
                    'count': len(composite_resources) if composite_resources else 0
                },
                'providers': {
                    'count': len(providers) if providers else 0
                },
                'compositions': {
                    'count': len(compositions) if compositions else 0
                },
                'composite_resource_definitions': {
                    'count': len(xrds) if xrds else 0
                }
            }
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting overview data: {error_msg}")
        return jsonify({"error": f"Failed to get overview data: {error_msg}"}), 500

def process_resources(resources):
    """Process and group resources by kind with health status summary"""
    if not resources:
        return {}, 0, {'healthy': 0, 'unhealthy': 0, 'unknown': 0}

    resource_groups = {}
    total_count = 0
    health_summary = {'healthy': 0, 'unhealthy': 0, 'unknown': 0}
    kinds = set()

    # Step 1: Collect all available resource kinds
    for resource in resources:
        kind = resource.get('kind', 'Unknown')
        kinds.add(kind)

    # Step 2: Initialize groups for all kinds
    for kind in kinds:
        resource_groups[kind] = {
            'resources': [],
            'count': 0,
            'health_summary': {'healthy': 0, 'unhealthy': 0, 'unknown': 0}
        }

    # Step 3: Process each resource
    for resource in resources:
        kind = resource.get('kind', 'Unknown')
        health_status = resource.get('_health_status', 'Unknown')
        group = resource_groups[kind]
        
        # Add resource to its kind group
        group['resources'].append(resource)
        group['count'] += 1
        total_count += 1
        
        # Update health status counters
        if health_status == 'Healthy':
            group['health_summary']['healthy'] += 1
            health_summary['healthy'] += 1
        elif health_status == 'Unhealthy':
            group['health_summary']['unhealthy'] += 1
            health_summary['unhealthy'] += 1
        else:
            group['health_summary']['unknown'] += 1
            health_summary['unknown'] += 1
    
    return resource_groups, total_count, health_summary

@bp.route('/managed-resources', methods=['GET'])
def get_managed_resources():
    """Get all managed resources with filtering and grouping by kind"""
    try:
        logger.info("Fetching managed resources")
        manager = CrossplaneManager.get_instance()
        resources = manager.get_managed_resources()
        
        # Apply filters if they exist
        filters = {k: v for k, v in request.args.items() 
                  if k in ['providerconfig', 'kind', 'status', 'search'] and v}
        
        if filters:
            logger.debug(f"Applying filters: {filters}")
            logger.debug("Initial resources count: %d", len(resources))
            logger.debug("Sample initial resources:")
            for r in resources[:3]:
                logger.debug("Resource: %s, Status: %s", 
                           r.get('metadata', {}).get('name'),
                           r.get('_health_status'))
            
            resources = filter_resources(resources, filters)
            
            logger.debug("Filtered resources count: %d", len(resources))
            logger.debug("Sample filtered resources:")
            for r in resources[:3]:
                logger.debug("Resource: %s, Status: %s", 
                           r.get('metadata', {}).get('name'),
                           r.get('_health_status'))
        
        # Process and group resources
        grouped_resources, total_count, health_summary = process_resources(resources)
        
        logger.info(f"Retrieved {total_count} managed resources")
        return jsonify({
            'resources': grouped_resources,
            'total_count': total_count,
            'health_summary': health_summary,
            'message': 'No managed resources found' if total_count == 0 else None
        })

    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting managed resources: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list managed resources"}), 403
        else:
            return jsonify({"error": f"Failed to get managed resources: {error_msg}"}), 500

@bp.route('/managed-resources/<name>', methods=['GET'])
def get_managed_resource(name):
    """Get a specific managed resource by name"""
    try:
        logger.info(f"Fetching managed resource: {name}")
        manager = CrossplaneManager.get_instance()
        
        namespace = request.args.get('namespace', 'default')
        group = request.args.get('group')
        version = request.args.get('version')
        plural = request.args.get('plural')
        
        if not all([group, version, plural]):
            return jsonify({"error": "group, version, and plural are required query parameters"}), 400
            
        resource = manager.get_resource(
            group=group,
            version=version,
            plural=plural,
            name=name,
            namespace=namespace
        )
        
        if not resource:
            return jsonify({"error": f"Resource '{name}' not found"}), 404
            
        logger.info(f"Successfully retrieved resource: {name}")
        return jsonify(resource)
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting resource {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get resource"}), 403
        else:
            return jsonify({"error": f"Failed to get resource: {error_msg}"}), 500

@bp.route('/composite-resources', methods=['GET'])
def get_composite_resources():
    """Get all composite resources"""
    try:
        logger.info("Fetching composite resources")
        manager = CrossplaneManager.get_instance()
        resources = manager.get_composite_resources()
        
        count = len(resources) if resources else 0
        logger.info(f"Retrieved {count} composite resources")
        
        return jsonify({
            'resources': resources,
            'count': count,
            'message': None if resources else 'No composite resources found'
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting composite resources: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list composite resources"}), 403
        else:
            return jsonify({"error": f"Failed to get composite resources: {error_msg}"}), 500

@bp.route('/status', methods=['GET'])
def get_status():
    """Check Crossplane status"""
    try:
        logger.info("Checking Crossplane status")
        manager = CrossplaneManager.get_instance()
        crds = manager.get_crossplane_crds()
        
        status = 'ok' if crds else 'no_crossplane'
        logger.info(f"Crossplane status: {status}")
        
        return jsonify({
            'status': status,
            'crds': crds,
            'message': 'Crossplane CRDs found' if crds else 'No Crossplane CRDs found.'
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error checking Crossplane status: {error_msg}")
        return jsonify({
            'status': 'error',
            'error': error_msg,
            'message': 'Failed to check Crossplane status'
        }), 500

def filter_resources(resources, filters):
    """Filter resources based on provided criteria"""
    if not resources:
        return []

    filtered = resources or []
    logger.debug(f"Initial resource count: {len(filtered)}")

    try:
        for key, value in filters.items():
            if not value:  # Skip empty filters
                continue

            # Log filter being applied
            logger.debug(f"Applying filter: {key}={value}")
            initial_count = len(filtered)
                
            if key == 'status':
                # Status filter (case-sensitive)
                filtered = [r for r in filtered if r and (
                    r.get('_health_status', 'Unknown') == value
                )]
                
                # Log filtering results
                logger.debug(f"Status filter results:")
                logger.debug(f"- Filter value: {value}")
                logger.debug(f"- Before filtering: {initial_count} resources")
                logger.debug(f"- After filtering: {len(filtered)} resources")
                logger.debug("Sample filtered resources:")
                for r in filtered[:3]:
                    logger.debug(f"Resource: {r.get('metadata', {}).get('name')}")
                    logger.debug(f"Status: {r.get('_health_status')}")
                    logger.debug(f"Raw conditions: {r.get('status', {}).get('conditions', [])}")
                    logger.debug(f"Raw resource: {r}")

            elif key == 'providerconfig':
                value = value.lower()
                filtered = [r for r in filtered if r and (
                    str(r.get('providerconfig', '')).lower() == value or
                    value in str(r.get('providerconfig', '')).lower()
                )]
                
            elif key == 'kind':
                value = value.lower()
                filtered = [r for r in filtered if r and (
                    str(r.get('kind', '')).lower() == value or
                    value in str(r.get('kind', '')).lower()
                )]
                
            elif key == 'search':
                value = value.lower()
                filtered = [r for r in filtered if r and
                    any(str(search_field or '').lower().find(value) >= 0 for search_field in [
                        r.get('metadata', {}).get('name', ''),
                        r.get('kind', ''),
                        r.get('provider', ''),
                        r.get('display_provider', ''),
                        r.get('providerconfig', ''),
                        r.get('_health_status', ''),
                        r.get('_synced_status', '')
                    ])
                ]

            logger.debug(f"After applying {key} filter: {len(filtered)} resources remaining")

    except Exception as e:
        logger.error(f"Error filtering resources: {e}")
        return []
    
    return filtered
