// managed-resources.js - Managed Resources functionality
let originalData = null;
let currentFilter = {
    status: '',
    search: '',
    providerconfig: ''
};

function calculateSummaryCounts(data, useFiltered = false) {
    console.debug('Calculating summary counts:', { data, useFiltered });
    
    if (!data) {
        console.error('No data provided to calculateSummaryCounts');
        return {
            healthy: 0,
            unhealthy: 0,
            unknown: 0,
            total: 0
        };
    }
    
    // Process data from API format
    const processedData = data?.data?.managed_resources || data;
    
    // Get the summary data from either filtered data or original data
    const summary = useFiltered ? processedData.health_summary : (processedData?.health_summary || {
        healthy: 0,
        unhealthy: 0,
        unknown: 0
    });
    const total = useFiltered ? processedData.total_count : (processedData?.total_count || 0);

    console.debug('Summary data:', { summary, total, processedData });

    // Update UI
    try {
        document.getElementById('total-resources-count').textContent = total;
        document.getElementById('healthy-resources-count').textContent = summary.healthy || 0;
        document.getElementById('unhealthy-resources-count').textContent = summary.unhealthy || 0;
        document.getElementById('unknown-resources-count').textContent = summary.unknown || 0;
    } catch (error) {
        console.error('Error updating summary UI:', error);
    }

    return { ...summary, total };
}

function applyFilters(data) {
    console.debug('Applying filters to data:', data);
    
    // Handle both direct API response and nested data
    const processedData = data?.data?.managed_resources || data;
    
    if (!processedData) {
        console.error('No data to filter');
        return { 
            resources: {},
            health_summary: { healthy: 0, unhealthy: 0, unknown: 0 },
            total_count: 0
        };
    }

    if (!processedData.resources && !processedData.items) {
        console.error('Invalid data format - missing resources or items:', processedData);
        return { 
            resources: {},
            health_summary: { healthy: 0, unhealthy: 0, unknown: 0 },
            total_count: 0
        };
    }

    // Convert items array to grouped resources if needed
    let resourcesData = processedData.resources;
    if (Array.isArray(processedData.items)) {
        console.debug('Converting items array to grouped resources:', processedData.items);
        resourcesData = {};
        processedData.items.forEach(item => {
            if (!item) {
                console.debug('Skipping null/undefined item');
                return;
            }
            const kind = item.kind || 'Unknown';
            if (!resourcesData[kind]) {
                resourcesData[kind] = {
                    resources: [],
                    count: 0
                };
            }
            resourcesData[kind].resources.push(item);
            resourcesData[kind].count++;
        });
        console.debug('Converted to grouped resources:', resourcesData);
    } else {
        console.debug('Using existing grouped resources:', resourcesData);
    }

    // Calculate health summary for filtered resources
    const health_summary = { healthy: 0, unhealthy: 0, unknown: 0 };
    let total_count = 0;

    // Create result object with filtered resources
    const result = { resources: {} };

    // Apply filters to each resource group
    Object.entries(resourcesData).forEach(([kind, group]) => {
        console.debug(`Processing group ${kind}:`, group);
        
        if (!group || !Array.isArray(group.resources)) {
            console.debug(`Invalid group data for kind ${kind}`);
            return;
        }

        const filteredResources = group.resources.filter(resource => {
            if (!resource) {
                console.debug('Skipping null/undefined resource');
                return false;
            }

            try {
                // Status filter
                if (currentFilter.status && resource._health_status !== currentFilter.status) {
                    return false;
                }

                // Search filter
                if (currentFilter.search) {
                    const searchTerm = currentFilter.search.toLowerCase();
                    const searchFields = [
                        resource.metadata?.name,
                        resource.kind,
                        resource.apiVersion,
                        resource.provider,
                        resource.display_provider,
                        resource.providerconfig
                    ].map(field => (field || '').toLowerCase());

                    if (!searchFields.some(field => field.includes(searchTerm))) {
                        return false;
                    }
                }

                // Provider config filter
                if (currentFilter.providerconfig && resource.providerconfig !== currentFilter.providerconfig) {
                    return false;
                }

                return true;
            } catch (error) {
                console.error('Error filtering resource:', error, resource);
                return false;
            }
        });

        console.debug(`Filtered resources for ${kind}:`, filteredResources);

        if (filteredResources.length > 0) {
            // Update health summary for filtered resources
            filteredResources.forEach(resource => {
                const status = resource._health_status || 'Unknown';
                if (status === 'Healthy') health_summary.healthy++;
                else if (status === 'Unhealthy') health_summary.unhealthy++;
                else health_summary.unknown++;
                total_count++;
            });

            result.resources[kind] = {
                ...group,
                resources: filteredResources,
                count: filteredResources.length
            };
        }
    });

    // Add health summary and total count to result
    result.health_summary = health_summary;
    result.total_count = total_count;

    console.debug('Filter result:', result);
    return result;
}

function setStatusFilter(status) {
    console.debug('Setting status filter:', status);
    try {
        // Validate status
        const validStatuses = ['', 'Healthy', 'Unhealthy', 'Unknown'];
        if (!validStatuses.includes(status)) {
            console.error('Invalid status value:', status);
            showError('Invalid status filter value');
            return;
        }

        currentFilter.status = status;
        document.getElementById('status-filter').value = status;
        
        if (originalData) {
            console.debug('Re-rendering with status filter:', status);
            renderManagedResources(originalData);
        } else {
            console.debug('No original data to filter');
        }
    } catch (error) {
        console.error('Error setting status filter:', error);
        showError('Failed to apply status filter');
    }
}

function setSearchFilter(search) {
    console.debug('Setting search filter:', search);
    try {
        // Normalize search term
        const normalizedSearch = (search || '').trim();
        currentFilter.search = normalizedSearch;
        document.getElementById('resource-search').value = normalizedSearch;
        
        if (originalData) {
            console.debug('Re-rendering with search filter:', normalizedSearch);
            renderManagedResources(originalData);
        } else {
            console.debug('No original data to filter');
        }
    } catch (error) {
        console.error('Error setting search filter:', error);
        showError('Failed to apply search filter');
    }
}

function setProviderConfigFilter(providerconfig) {
    console.debug('Setting provider config filter:', providerconfig);
    try {
        // Normalize provider config
        const normalizedConfig = (providerconfig || '').trim();
        currentFilter.providerconfig = normalizedConfig;
        document.getElementById('providerconfig-filter').value = normalizedConfig;
        
        if (originalData) {
            console.debug('Re-rendering with provider config filter:', normalizedConfig);
            renderManagedResources(originalData);
        } else {
            console.debug('No original data to filter');
        }
    } catch (error) {
        console.error('Error setting provider config filter:', error);
        showError('Failed to apply provider config filter');
    }
}

function setupEventListeners() {
    try {
        // Search input
        const searchInput = document.getElementById('resource-search');
        if (searchInput) {
            console.debug('Setting up search input listener');
            const debouncedSearch = _.debounce((value) => {
                console.debug('Debounced search triggered:', value);
                setSearchFilter(value);
            }, 300);
            searchInput.addEventListener('input', (event) => {
                debouncedSearch(event.target.value);
            });
        } else {
            console.debug('Search input element not found');
        }

        // Status filter
        const statusFilter = document.getElementById('status-filter');
        if (statusFilter) {
            console.debug('Setting up status filter listener');
            statusFilter.addEventListener('change', (event) => {
                console.debug('Status filter changed:', event.target.value);
                setStatusFilter(event.target.value);
            });
        } else {
            console.debug('Status filter element not found');
        }

        // Provider config filter
        const providerConfigFilter = document.getElementById('providerconfig-filter');
        if (providerConfigFilter) {
            console.debug('Setting up provider config filter listener');
            providerConfigFilter.addEventListener('change', (event) => {
                console.debug('Provider config filter changed:', event.target.value);
                setProviderConfigFilter(event.target.value);
            });
        } else {
            console.debug('Provider config filter element not found');
        }

        console.debug('Event listeners setup complete');
    } catch (error) {
        console.error('Error setting up event listeners:', error);
        showError('Failed to set up filters. Some functionality may be limited.');
    }
}

function renderManagedResourceDetails(resource) {
    if (!resource) {
        console.debug('No resource provided to renderManagedResourceDetails');
        return '';
    }

    try {
        console.debug('Rendering details for resource:', resource);
        const status = resource.status || {};
        const conditions = Array.isArray(status.conditions) ? status.conditions : [];
        const readyCondition = conditions.find(c => c?.type === 'Ready') || {};
        const syncedCondition = conditions.find(c => c?.type === 'Synced') || {};

        return `
            <div class="px-4 py-5">
                <div class="space-y-4">
                    <div>
                        <h4 class="text-sm font-medium text-gray-900 dark:text-white">Status</h4>
                        <div class="mt-2 space-y-2">
                            <div class="flex items-center">
                                <span class="text-sm text-gray-500 dark:text-gray-400 w-24">Ready:</span>
                                <span class="text-sm ${readyCondition.status === 'True' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                    ${readyCondition.status || 'Unknown'}
                                </span>
                            </div>
                            <div class="flex items-center">
                                <span class="text-sm text-gray-500 dark:text-gray-400 w-24">Synced:</span>
                                <span class="text-sm ${syncedCondition.status === 'True' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                    ${syncedCondition.status || 'Unknown'}
                                </span>
                            </div>
                        </div>
                    </div>
                    ${conditions.length > 0 ? `
                        <div>
                            <h4 class="text-sm font-medium text-gray-900 dark:text-white">Conditions</h4>
                            <div class="mt-2 space-y-2">
                                ${conditions.map(condition => `
                                    <div class="flex items-start">
                                        <span class="text-sm text-gray-500 dark:text-gray-400 w-24">${condition.type}:</span>
                                        <div class="flex-1">
                                            <span class="text-sm ${condition.status === 'True' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                                ${condition.status}
                                            </span>
                                            ${condition.message ? `
                                                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                                    ${condition.message}
                                                </p>
                                            ` : ''}
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    } catch (error) {
        console.error('Error rendering resource details:', error);
        return '';
    }
}

function formatTimeAgo(timestamp) {
    if (!timestamp) {
        console.debug('No timestamp provided to formatTimeAgo');
        return '';
    }

    try {
        const now = new Date();
        const past = new Date(timestamp);
        
        if (isNaN(past.getTime())) {
            console.error('Invalid timestamp format:', timestamp);
            return '';
        }

        const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
        
        if (diffInHours < 24) {
            return `${diffInHours}h ago`;
        }
        const diffInDays = Math.floor(diffInHours / 24);
        return `${diffInDays}d ago`;
    } catch (error) {
        console.error('Error formatting time:', error, timestamp);
        return '';
    }
}

function getHealthStatusClass(status) {
    try {
        if (!status) {
            console.debug('No status provided to getHealthStatusClass');
            return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
        }

        const normalizedStatus = String(status).trim();
        switch (normalizedStatus) {
            case 'Healthy':
                return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
            case 'Unhealthy':
                return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
            default:
                console.debug('Unknown health status:', status);
                return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
        }
    } catch (error) {
        console.error('Error getting health status class:', error, status);
        return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
    }
}

function renderManagedResources(data) {
    console.debug('Rendering managed resources with data:', data);

    if (!data) {
        console.error('No data provided to renderManagedResources');
        calculateSummaryCounts({});
        return;
    }

    // Get the container early
    const container = document.getElementById('managed-resources-list');
    if (!container) {
        console.error('Resources list container not found');
        return;
    }

    // Store original data on first render
    if (!originalData) {
        // Handle both direct API response and nested data
        const processedData = data?.data?.managed_resources || data;
        if (!processedData) {
            console.error('Invalid data format:', data);
            calculateSummaryCounts({});
            container.innerHTML = `
                <div class="p-4 text-center text-gray-500">
                    No resources found
                </div>
            `;
            return;
        }

        // Convert items array to grouped resources if needed
        if (Array.isArray(processedData.items)) {
            const grouped = {
                resources: {},
                total_count: processedData.total_count,
                health_summary: processedData.health_summary
            };
            processedData.items.forEach(item => {
                const kind = item.kind || 'Unknown';
                if (!grouped.resources[kind]) {
                    grouped.resources[kind] = {
                        resources: [],
                        count: 0
                    };
                }
                grouped.resources[kind].resources.push(item);
                grouped.resources[kind].count++;
            });
            originalData = grouped;
        } else {
            originalData = processedData;
        }
        console.debug('Stored original data:', originalData);
    }

    // Apply filters
    const filteredData = applyFilters(originalData);
    console.debug('Filtered data:', filteredData);

    // Clear existing content
    container.innerHTML = '';

    // Early return if no resources
    if (!filteredData || !filteredData.resources || Object.keys(filteredData.resources).length === 0) {
        container.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        // Still update summary counts with empty data
        calculateSummaryCounts({});
        return;
    }

    // Update summary counts with filtered data when filters are active
    if (currentFilter.status || currentFilter.search || currentFilter.providerconfig) {
        calculateSummaryCounts(filteredData, true);
    } else {
        // Show total counts when no filters are active
        calculateSummaryCounts(originalData);
    }

    try {
        // Create tabs container
        const tabsContainer = document.createElement('div');
        tabsContainer.className = 'border-b border-gray-200';
        const tabsList = document.createElement('nav');
        tabsList.className = 'flex -mb-px';
        tabsContainer.appendChild(tabsList);
        container.appendChild(tabsContainer);

        // Create content container
        const contentContainer = document.createElement('div');
        contentContainer.className = 'mt-4';
        container.appendChild(contentContainer);

        let isFirstTab = true;
        Object.entries(filteredData.resources).forEach(([kind, groupData]) => {
            if (!groupData || !Array.isArray(groupData.resources)) {
                console.debug(`Skipping invalid group data for kind ${kind}`);
                return;
            }

            // Create tab
            const tab = document.createElement('button');
            tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
                isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
            }`;
            tab.setAttribute('data-tab', kind);
            tab.innerHTML = `
                <span>${kind}</span>
                <span class="ml-2 text-sm text-gray-400">(${groupData.resources.length || 0})</span>
            `;

            // Create content panel
            const contentPanel = document.createElement('div');
            contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
            contentPanel.setAttribute('data-tab-content', kind);

            // Create resources container
            const resourcesContainer = document.createElement('div');
            resourcesContainer.className = 'divide-y divide-gray-200';

            // Add resources
            groupData.resources.forEach(resource => {
                const resourceElement = document.createElement('div');
                resourceElement.className = 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150';
                
                resourceElement.innerHTML = `
                    <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <h4 class="text-lg font-medium text-gray-900 dark:text-white">
                                    ${resource.metadata?.name || 'Unnamed'}
                                    <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${resource.apiVersion || ''}</span>
                                </h4>
                                <div class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                    <p>Provider: ${resource.provider || resource.display_provider || 'Unknown'}</p>
                                    <p>Provider Config: ${resource.providerconfig || 'Unknown'}</p>
                                    <p class="mt-1 text-xs text-gray-400">
                                        Created: ${formatTimeAgo(resource.metadata?.creationTimestamp)}
                                    </p>
                                </div>
                            </div>
                            <div class="ml-4 flex items-center">
                                <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                                    ${resource._health_status || 'Unknown'}
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="managed-resource-details" style="display: none;">
                        ${renderManagedResourceDetails(resource)}
                    </div>
                `;

                // Add click event listener for details toggle
                resourceElement.addEventListener('click', function() {
                    const details = this.querySelector('.managed-resource-details');
                    if (details) {
                        const isExpanded = details.style.display !== 'none';
                        details.style.display = isExpanded ? 'none' : 'block';
                        this.classList.toggle('expanded', !isExpanded);
                    }
                });

                resourcesContainer.appendChild(resourceElement);
            });

            contentPanel.appendChild(resourcesContainer);

            // Add tab click handler
            tab.addEventListener('click', () => {
                document.querySelectorAll('[data-tab]').forEach(t => {
                    t.classList.remove('text-blue-600', 'border-blue-600');
                    t.classList.add('text-gray-500', 'border-transparent');
                });
                tab.classList.remove('text-gray-500', 'border-transparent');
                tab.classList.add('text-blue-600', 'border-blue-600');

                document.querySelectorAll('[data-tab-content]').forEach(p => {
                    p.classList.add('hidden');
                });
                contentPanel.classList.remove('hidden');
            });

            tabsList.appendChild(tab);
            contentContainer.appendChild(contentPanel);
            
            isFirstTab = false;
        });
    } catch (error) {
        console.error('Error rendering resources:', error);
        container.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                Error rendering resources. Please try refreshing the page.
                ${error.message ? `<br><span class="text-xs text-red-500">${error.message}</span>` : ''}
            </div>
        `;
        showError('Failed to render resources. Please try refreshing the page.');
    }

    // Setup event listeners if not already set up
    setupEventListeners();
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});

// Export functions
window.renderManagedResources = renderManagedResources;
window.setStatusFilter = setStatusFilter;
window.setSearchFilter = setSearchFilter;
window.setProviderConfigFilter = setProviderConfigFilter;
