// claims.js - Claims functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderClaimDetails(claim) {
    const status = claim.status || {};
    const conditions = status.conditions || [];
    const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const reconcileCondition = conditions.find(c => c.type === 'ReconcileSuccess') || {};
    
    const syncedTime = syncedCondition.lastTransitionTime ? 
        formatTimeAgo(syncedCondition.lastTransitionTime) : '';
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${claim.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${claim.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Namespace</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${claim.metadata?.namespace || 'default'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(claim.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            syncedCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${syncedCondition.status === 'True' ? 'Synced' : 'Not Synced'}
                        </span>
                        ${syncedTime ? `<span class="text-xs text-gray-500">${syncedTime}</span>` : ''}
                        ${syncedCondition.message ? `<span class="text-sm text-gray-600">${syncedCondition.message}</span>` : ''}
                    </div>
                    ${reconcileCondition.status === 'True' ? `
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                                ReconcileSuccess
                            </span>
                        </div>
                    ` : ''}
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            readyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${readyCondition.status === 'True' ? 'Ready' : 'Not Ready'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500">${readyTime}</span>` : ''}
                        ${!readyCondition.status === 'True' ? `
                            <span class="text-sm text-yellow-600">Waiting: Claim is waiting for composite resource to become Ready</span>
                        ` : ''}
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Relations Graph</h3>
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4" style="height: 800px;">
                    <div id="relations-graph-${claim.metadata?.name}" style="width: 100%; height: 100%;"></div>
                </div>
            </div>

                ${claim.events && claim.events.length > 0 ? `
                    <div>
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                        <div class="space-y-3">
                            ${claim.events.slice(0, 10).map(event => `
                                <div class="flex items-start space-x-3">
                                    <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                                        event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                                    }"></span>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                                            ${event.reason}
                                            <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.timestamp)}</span>
                                        </p>
                                        <p class="text-sm text-gray-500">${event.message}</p>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

function renderClaimGraph(claim, containerId) {
    try {
        const graphElement = document.getElementById(containerId);
        if (!graphElement) {
            console.error(`Graph container ${containerId} not found`);
            return null;
        }

        const chart = echarts.init(graphElement);
        const isDarkMode = document.documentElement.classList.contains('dark');
        
        // Prepare nodes and links data
        const nodes = [];
        const links = [];

        // Icons for nodes
        const icons = {
            claim: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
            composition: 'path://M3 3h18v18H3z M7 7h10v10H7z',
            resource: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
        };

        // Node colors with improved contrast
        const colors = {
            claim: '#6B7CFF',      // Light purple for claims
            composition: '#4ADE80', // Light green for compositions
            resource: '#FBBF24'    // Light orange/yellow for composite resources
        };

        // Get claim status
        const status = claim.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isReady = readyCondition.status === 'True';

        // Add claim node with improved styling
        nodes.push({
            id: claim.metadata?.name,
            name: claim.metadata?.name,
            symbol: icons.claim,
            symbolSize: [50, 50],
            category: 0,
            itemStyle: {
                color: colors.claim,
                opacity: isReady ? 1 : 0.7
            },
            label: {
                show: true,
                formatter: '{b}',
                position: 'right',
                distance: 5,
                color: isReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
            },
            tooltip: {
                formatter: () => `
                    ${claim.metadata?.name}
                    Status: ${isReady ? 'Ready' : 'Not Ready'}
                `
            }
        });

        // Add composition node and link if exists with improved styling
        if (claim.composition?.name) {
            nodes.push({
                id: claim.composition.name,
                name: claim.composition.name,
                symbol: icons.composition,
                symbolSize: [45, 45],
                category: 1,
                itemStyle: {
                color: colors.composition,
                    opacity: claim.composition.ready ? 1 : 0.7
                },
                label: {
                    show: true,
                    formatter: '{b}',
                    position: 'right',
                    distance: 5,
                    color: claim.composition.ready ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
                },
                tooltip: {
                    formatter: () => `
                        ${claim.composition.name}
                        Status: ${claim.composition.ready ? 'Ready' : 'Not Ready'}
                    `
                }
            });
            links.push({
                source: claim.metadata?.name,
                target: claim.composition.name,
                lineStyle: {
                    color: '#4ADE80', // Green for uses relationship
                    width: 2,
                    opacity: 0.8,
                    type: 'dashed',
                    curveness: 0.4
                }
            });
        }

        // Add composite resource node and link if exists with improved styling
        if (claim.compositeResource?.name) {
            nodes.push({
                id: claim.compositeResource.name,
                name: claim.compositeResource.name,
                symbol: icons.resource,
                symbolSize: [45, 45],
                category: 2,
                itemStyle: {
                color: colors.resource,
                    opacity: claim.compositeResource.ready ? 1 : 0.7
                },
                label: {
                    show: true,
                    formatter: '{b}',
                    position: 'right',
                    distance: 5,
                    color: claim.compositeResource.ready ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
                },
                tooltip: {
                    formatter: () => `
                        ${claim.compositeResource.name}
                        Status: ${claim.compositeResource.ready ? 'Ready' : 'Not Ready'}
                    `
                }
            });
            links.push({
                source: claim.metadata?.name,
                target: claim.compositeResource.name,
                lineStyle: {
                    color: '#A78BFA', // Purple for claims relationship
                    width: 2,
                    opacity: 0.8,
                    type: 'solid',
                    curveness: 0.4
                }
            });
        }

        const option = {
            backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
            tooltip: {
                trigger: 'item',
                formatter: (params) => {
                    if (params.dataType === 'node') {
                        return params.data.tooltip?.formatter() || params.name;
                    }
                    return params.name;
                }
            },
            legend: {
                show: true,
                top: '20',
                left: '20',
                orient: 'vertical',
                itemGap: 20,
                itemWidth: 30,
                itemHeight: 16,
                data: [
                    {
                        name: 'Claim',
                        icon: icons.claim,
                        itemStyle: { color: colors.claim }
                    },
                    {
                        name: 'Composition',
                        icon: icons.composition,
                        itemStyle: { color: colors.composition }
                    },
                    {
                        name: 'Composite Resource',
                        icon: icons.resource,
                        itemStyle: { color: colors.resource }
                    }
                ],
                textStyle: {
                    color: isDarkMode ? '#e5e7eb' : '#374151'
                }
            },
            animationDurationUpdate: 1500,
            animationEasingUpdate: 'quinticInOut',
            series: [{
                type: 'graph',
                layout: 'force',
                data: nodes,
                links: links,
                categories: [
                    { name: 'Claim' },
                    { name: 'Composition' },
                    { name: 'Composite Resource' }
                ],
                roam: true,
                force: {
                    repulsion: 1500,
                    edgeLength: 200,
                    gravity: 0.05,
                    friction: 0.3,
                    layoutAnimation: true
                },
                draggable: true,
                emphasis: {
                    focus: 'adjacency',
                    scale: 1.1
                },
                edgeSymbol: ['circle', 'arrow'],
                edgeSymbolSize: [4, 10],
                label: {
                    show: true,
                    position: 'right',
                    color: isDarkMode ? '#e5e7eb' : '#374151',
                    formatter: '{b}'
                }
            }]
        };

        chart.setOption(option);
        
        // Handle window resize with debouncing
        const resizeHandler = () => {
            if (chart) {
                chart.resize();
            }
        };
        window.addEventListener('resize', resizeHandler);

        // Prevent graph clicks from propagating to card
        graphElement.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        return chart;
    } catch (error) {
        console.error('Error rendering graph:', error);
        return null;
    }
}

function renderClaims(container, claims) {
    if (!claims || claims.length === 0) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500 dark:text-gray-400">No claims found</div>';
        return;
    }

    claims.forEach(claim => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
        });
        
        let isExpanded = false;
        let chart = null;
        const expandedContent = renderClaimDetails(claim);
        
        // Add click handler to the entire card
        card.addEventListener('click', () => {
            isExpanded = !isExpanded;
            const contentSection = card.querySelector('.claim-details');
            if (isExpanded) {
                contentSection.style.display = 'block';
                card.classList.add('expanded');
                // Initialize graph after content is visible
                requestAnimationFrame(() => {
                    const graphId = `relations-graph-${claim.metadata?.name}`;
                    chart = renderClaimGraph(claim, graphId);
                }, 100);
            } else {
                contentSection.style.display = 'none';
                card.classList.remove('expanded');
                if (chart) {
                    chart.dispose();
                    chart = null;
                }
            }
        });

        const status = claim.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const reconcileCondition = conditions.find(c => c.type === 'ReconcileSuccess') || {};
        
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';
        const isReconciled = reconcileCondition.status === 'True';

        const creationTime = claim.metadata?.creationTimestamp ? 
            formatTimeAgo(claim.metadata.creationTimestamp) : 'Unknown';
        
        const syncedTime = syncedCondition.lastTransitionTime ? 
            formatTimeAgo(syncedCondition.lastTransitionTime) : '';
        const readyTime = readyCondition.lastTransitionTime ? 
            formatTimeAgo(readyCondition.lastTransitionTime) : '';

        card.innerHTML = `
            <div class="px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700">
                <div class="flex items-center min-w-0">
                    <div class="min-w-0">
                        <h3 class="text-sm font-medium truncate ${isReady ? 'text-gray-900 dark:text-white' : 'text-red-600 dark:text-red-400'}">
                            ${claim.metadata?.name || 'Unnamed'}
                        </h3>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                            ${claim.kind || 'Unknown'} • ${claim.metadata?.namespace || 'default'} • ${creationTime}
                        </p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button onclick="event.stopPropagation(); showYAMLInMonaco(${JSON.stringify(claim).replace(/'/g, "\\'").replace(/"/g, "&quot;")})"
                                class="p-1 text-gray-400 hover:text-gray-500" title="View YAML">
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                        <button class="p-1 text-gray-400 hover:text-gray-500" title="Toggle Details">
                            <svg class="h-4 w-4 transform transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isSynced ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                    }">
                        ${isSynced ? 'Synced' : 'Not Synced'}
                    </span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isReady ? 'Ready' : 'Not Ready'}
                    </span>
                </div>
            </div>
            <div class="claim-details" style="display: none;">
                ${expandedContent}
            </div>
        `;

        container.appendChild(card);
    });
}

// Export functions
window.renderClaims = renderClaims;
