// managed-resources.js - Managed Resources functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderManagedResourceDetails(resource) {
    const status = resource.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
    
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';
    const healthyTime = healthyCondition.lastTransitionTime ? 
        formatTimeAgo(healthyCondition.lastTransitionTime) : '';

    return `
        <div class="space-y-4">
            <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Provider</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.provider || resource.display_provider || 'Unknown'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(resource.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Status</h3>
                <div class="space-y-2">
                    <div class="flex items-center space-x-2">
                        <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                            ${resource._health_status || 'Unknown'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500 dark:text-gray-400">${readyTime}</span>` : ''}
                        ${readyCondition.message ? `<span class="text-sm text-gray-500 dark:text-gray-400">${readyCondition.message}</span>` : ''}
                    </div>
                </div>
            </div>

            ${conditions.length > 0 ? `
                <div>
                    <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Conditions</h3>
                    <div class="space-y-2">
                        ${conditions.map(condition => `
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-2">
                                    <span class="text-sm font-medium text-gray-900 dark:text-white">${condition.type}</span>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                        condition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' :
                                        condition.status === 'False' ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200' :
                                        'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                                    }">
                                        ${condition.status}
                                    </span>
                                </div>
                                ${condition.lastTransitionTime ? `
                                    <span class="text-xs text-gray-500 dark:text-gray-400">
                                        ${formatTimeAgo(condition.lastTransitionTime)}
                                    </span>
                                ` : ''}
                            </div>
                            ${condition.message ? `
                                <p class="text-sm text-gray-500 dark:text-gray-400 ml-4">
                                    ${condition.message}
                                </p>
                            ` : ''}
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function renderManagedResources(data) {
    if (!data) {
        console.error('No data provided to renderManagedResources');
        return;
    }

    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'border-b border-gray-200';
    
    const tabsList = document.createElement('nav');
    tabsList.className = 'flex -mb-px';
    tabsContainer.appendChild(tabsList);

    const contentContainer = document.createElement('div');
    contentContainer.className = 'mt-4';

    const container = document.getElementById('managed-resources-list');
    if (!container) return;

    container.innerHTML = '';
    container.appendChild(tabsContainer);
    container.appendChild(contentContainer);

    // Store original data for filtering (before any filters are applied)
    // Reset if data format changes
    const dataFormat = data.resources ? 'grouped' : 'items';
    if (!window.originalResourceData || window.originalDataFormat !== dataFormat) {
        console.debug('Storing original data with format:', dataFormat);
        const originalData = {
            resources: data.resources || {},
            health_summary: data.health_summary || { healthy: 0, unhealthy: 0, unknown: 0 },
            total_count: data.total_count || 0
        };
        window.originalResourceData = JSON.parse(JSON.stringify(originalData));
        window.originalDataFormat = dataFormat;
        window.filtersInitialized = false; // Reset filters when data format changes
    }

    // Get current filters
    const filters = {
        status: document.getElementById('status-filter')?.value || '',
        search: document.getElementById('resource-search')?.value?.toLowerCase() || '',
        providerconfig: document.getElementById('providerconfig-filter')?.value || ''
    };

    // Apply filters and calculate health summary
    const filteredData = {
        resources: {},
        health_summary: { healthy: 0, unhealthy: 0, unknown: 0 },
        total_count: 0
    };

    // Handle both data formats
    const resourcesData = data.resources || {};
    if (Array.isArray(data.items)) {
        // Convert items array to grouped format first
        data.items.forEach(item => {
            const kind = item.kind || 'Unknown';
            if (!resourcesData[kind]) {
                resourcesData[kind] = {
                    resources: [],
                    count: 0
                };
            }
            resourcesData[kind].resources.push(item);
            resourcesData[kind].count++;
        });
    }

    let allResources = [];
    Object.entries(resourcesData).forEach(([kind, group]) => {
        const filteredResources = (group.resources || []).filter(resource => {
            // Status filter
            if (filters.status && resource._health_status !== filters.status) {
                return false;
            }

            // Search filter
            if (filters.search) {
                const searchFields = [
                    resource.metadata?.name,
                    resource.kind,
                    resource.apiVersion,
                    resource.provider,
                    resource.display_provider,
                    resource.providerconfig
                ].map(field => (field || '').toLowerCase());
                
                if (!searchFields.some(field => field.includes(filters.search))) {
                    return false;
                }
            }

            // Provider config filter
            if (filters.providerconfig && resource.providerconfig !== filters.providerconfig) {
                return false;
            }

            // Update health summary for matched resources
            const status = resource._health_status || 'Unknown';
            switch (status) {
                case 'Healthy':
                    filteredData.health_summary.healthy++;
                    break;
                case 'Unhealthy':
                    filteredData.health_summary.unhealthy++;
                    break;
                default:
                    filteredData.health_summary.unknown++;
            }
            filteredData.total_count++;

            return true;
        });

        if (filteredResources.length > 0) {
            filteredData.resources[kind] = {
                ...group,
                resources: filteredResources,
                count: filteredResources.length
            };
            allResources = allResources.concat(filteredResources);
        }
    });

    // Update data with filtered results and update summary
    data = filteredData;
    updateSummaryCounts(filteredData);

    if (!data.resources || Object.keys(data.resources).length === 0) {
        contentContainer.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        return;
    }

    let isFirstTab = true;
    Object.entries(data.resources).forEach(([kind, groupData]) => {
        const tab = document.createElement('button');
        tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
            isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
        }`;
        tab.setAttribute('data-tab', kind);
        tab.innerHTML = `
            <span>${kind}</span>
            <span class="ml-2 text-sm text-gray-400">(${groupData.count || 0})</span>
        `;

        const contentPanel = document.createElement('div');
        contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
        contentPanel.setAttribute('data-tab-content', kind);

        // Create table header
        const tableHeader = document.createElement('div');
        tableHeader.className = 'grid grid-cols-4 gap-4 px-6 py-3 bg-gray-50 dark:bg-gray-800 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider border-b border-gray-200 dark:border-gray-700';
        tableHeader.innerHTML = `
            <div>NAME</div>
            <div>PROVIDER</div>
            <div>STATUS</div>
            <div class="text-right">ACTIONS</div>
        `;
        contentPanel.appendChild(tableHeader);

        // Create table body
        const tableBody = document.createElement('div');
        tableBody.className = 'divide-y divide-gray-200 dark:divide-gray-700';

        groupData.resources.forEach(resource => {
            const row = document.createElement('div');
            row.className = 'grid grid-cols-4 gap-4 px-6 py-4 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer';
            
            row.innerHTML = `
                <div class="text-sm font-medium text-gray-900 dark:text-white">
                    ${resource.metadata?.name || 'Unnamed'}
                    <div class="text-xs text-gray-500 dark:text-gray-400">${resource.apiVersion || ''}</div>
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                    ${resource.provider || resource.display_provider || 'Unknown'}
                    <div class="text-xs">${resource.providerconfig || ''}</div>
                </div>
                <div>
                    <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                        ${resource._health_status || 'Unknown'}
                    </span>
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400 text-right">
                    <button class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                            onclick="event.stopPropagation(); showYAMLInMonaco(${JSON.stringify(resource)})">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                    </button>
                </div>
                <div class="managed-resource-details col-span-4 bg-gray-50 dark:bg-gray-700 px-6 py-4" style="display: none;">
                    ${renderManagedResourceDetails(resource)}
                </div>
            `;

            // Add click event listener for row
            row.addEventListener('click', function(e) {
                // Don't expand if clicking the YAML button
                if (e.target.closest('button')) return;
                
                // Toggle details
                const details = this.querySelector('.managed-resource-details');
                if (details) {
                    const isExpanded = details.style.display !== 'none';
                    details.style.display = isExpanded ? 'none' : 'block';
                }
            });

            tableBody.appendChild(row);
        });

        contentPanel.appendChild(tableBody);

        tab.addEventListener('click', () => {
            document.querySelectorAll('[data-tab]').forEach(t => {
                t.classList.remove('text-blue-600', 'border-blue-600');
                t.classList.add('text-gray-500', 'border-transparent');
            });
            tab.classList.remove('text-gray-500', 'border-transparent');
            tab.classList.add('text-blue-600', 'border-blue-600');

            document.querySelectorAll('[data-tab-content]').forEach(p => {
                p.classList.add('hidden');
            });
            contentPanel.classList.remove('hidden');
        });

        tabsList.appendChild(tab);
        contentContainer.appendChild(contentPanel);
        
        isFirstTab = false;
    });

    // Update URL params to match filters
    const url = new URL(window.location);
    Object.entries(filters).forEach(([key, value]) => {
        if (value) {
            url.searchParams.set(key, value);
        } else {
            url.searchParams.delete(key);
        }
    });
    window.history.replaceState({}, '', url);

    // Add filter event listeners
    const searchInput = document.getElementById('resource-search');
    const statusFilterSelect = document.getElementById('status-filter');
    const providerConfigFilterSelect = document.getElementById('providerconfig-filter');

    // Helper function to rerender with current filters
    const reapplyFilters = () => {
        if (window.originalResourceData) {
            renderManagedResources(window.originalResourceData);
        }
    };

    if (searchInput) {
        searchInput.addEventListener('input', _.debounce(() => {
            reapplyFilters();
        }, 300));
    }

    if (statusFilterSelect) {
        statusFilterSelect.addEventListener('change', reapplyFilters);
    }

    if (providerConfigFilterSelect) {
        providerConfigFilterSelect.addEventListener('change', reapplyFilters);
    }

    // Set initial filter values from URL if present and not already set
    if (!window.filtersInitialized) {
        const searchParams = new URLSearchParams(window.location.search);
        const hasInitialFilters = searchParams.has('search') || searchParams.has('status') || searchParams.has('providerconfig');
        
        if (hasInitialFilters) {
            // Set filter values
            if (searchInput && searchParams.has('search')) {
                searchInput.value = searchParams.get('search');
            }
            if (statusFilterSelect && searchParams.has('status')) {
                const status = searchParams.get('status');
                if (['Healthy', 'Unhealthy', 'Unknown', ''].includes(status)) {
                    statusFilterSelect.value = status;
                }
            }
            if (providerConfigFilterSelect && searchParams.has('providerconfig')) {
                providerConfigFilterSelect.value = searchParams.get('providerconfig');
            }
        }
        window.filtersInitialized = true;
    }
}

function updateSummaryCounts(data) {
    const elements = {
        total: document.getElementById('total-resources-count'),
        healthy: document.getElementById('healthy-resources-count'),
        unhealthy: document.getElementById('unhealthy-resources-count'),
        unknown: document.getElementById('unknown-resources-count')
    };

    // Handle both API response and filtered data formats
    const summary = data?.health_summary || { healthy: 0, unhealthy: 0, unknown: 0 };
    const total = data?.total_count || 0;

    // Update UI elements if they exist
    if (elements.total) elements.total.textContent = total;
    if (elements.healthy) elements.healthy.textContent = summary.healthy || '0';
    if (elements.unhealthy) elements.unhealthy.textContent = summary.unhealthy || '0';
    if (elements.unknown) elements.unknown.textContent = summary.unknown || '0';

    // Return summary for potential use by caller
    return { ...summary, total };
}

function getHealthStatusClass(status) {
    switch (status) {
        case 'Healthy':
            return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
        case 'Unhealthy':
            return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
        default:
            return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
    }
}

// Function to set status filter and trigger rerender
function setStatusFilter(status) {
    const statusFilter = document.getElementById('status-filter');
    if (statusFilter) {
        statusFilter.value = status;
        if (window.originalResourceData) {
            renderManagedResources(window.originalResourceData);
        }
    }
}

// Export functions
window.renderManagedResources = renderManagedResources;
window.setStatusFilter = setStatusFilter;
