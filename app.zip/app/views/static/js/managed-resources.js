// managed-resources.js - Managed Resources functionality
let filterElements = {
    searchInput: null,
    statusFilterSelect: null,
    providerConfigFilterSelect: null
};

function calculateSummaryCounts(resources) {
    let summary = {
        total: 0,
        healthy: 0,
        unhealthy: 0,
        unknown: 0
    };

    Object.values(resources || {}).forEach(group => {
        group.resources.forEach(resource => {
            summary.total++;
            switch (resource._health_status) {
                case 'Healthy':
                    summary.healthy++;
                    break;
                case 'Unhealthy':
                    summary.unhealthy++;
                    break;
                default:
                    summary.unknown++;
            }
        });
    });

    // Update UI
    const elements = {
        total: document.getElementById('total-resources-count'),
        healthy: document.getElementById('healthy-resources-count'),
        unhealthy: document.getElementById('unhealthy-resources-count'),
        unknown: document.getElementById('unknown-resources-count')
    };

    if (elements.total) elements.total.textContent = summary.total.toString();
    if (elements.healthy) elements.healthy.textContent = summary.healthy.toString();
    if (elements.unhealthy) elements.unhealthy.textContent = summary.unhealthy.toString();
    if (elements.unknown) elements.unknown.textContent = summary.unknown.toString();

    return summary;
}

function renderManagedResourceDetails(resource) {
    const status = resource.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const syncedCondition = conditions.find(c => c.type === 'Synced') || {};

    return `
        <div class="px-4 py-5">
            <div class="space-y-4">
                <div>
                    <h4 class="text-sm font-medium text-gray-900 dark:text-white">Status</h4>
                    <div class="mt-2 space-y-2">
                        <div class="flex items-center">
                            <span class="text-sm text-gray-500 dark:text-gray-400 w-24">Ready:</span>
                            <span class="text-sm ${readyCondition.status === 'True' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                ${readyCondition.status || 'Unknown'}
                            </span>
                        </div>
                        <div class="flex items-center">
                            <span class="text-sm text-gray-500 dark:text-gray-400 w-24">Synced:</span>
                            <span class="text-sm ${syncedCondition.status === 'True' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                ${syncedCondition.status || 'Unknown'}
                            </span>
                        </div>
                    </div>
                </div>
                ${conditions.length > 0 ? `
                    <div>
                        <h4 class="text-sm font-medium text-gray-900 dark:text-white">Conditions</h4>
                        <div class="mt-2 space-y-2">
                            ${conditions.map(condition => `
                                <div class="flex items-start">
                                    <span class="text-sm text-gray-500 dark:text-gray-400 w-24">${condition.type}:</span>
                                    <div class="flex-1">
                                        <span class="text-sm ${condition.status === 'True' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                            ${condition.status}
                                        </span>
                                        ${condition.message ? `
                                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                                ${condition.message}
                                            </p>
                                        ` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function initializeFilterElements() {
    filterElements = {
        searchInput: document.getElementById('resource-search'),
        statusFilterSelect: document.getElementById('status-filter'),
        providerConfigFilterSelect: document.getElementById('providerconfig-filter')
    };
}

function initializeFilters() {
    initializeFilterElements();
    
    const searchParams = new URLSearchParams(window.location.search);
    const searchTerm = searchParams.get('search');
    const statusFilter = searchParams.get('status');
    const providerConfigFilter = searchParams.get('providerconfig');

    if (filterElements.searchInput && searchTerm) {
        filterElements.searchInput.value = searchTerm;
    }
    if (filterElements.statusFilterSelect && statusFilter) {
        filterElements.statusFilterSelect.value = statusFilter;
    }
    if (filterElements.providerConfigFilterSelect && providerConfigFilter) {
        filterElements.providerConfigFilterSelect.value = providerConfigFilter;
    }
}

function setupFilterEventListeners() {
    if (filterElements.searchInput) {
        filterElements.searchInput.addEventListener('input', _.debounce(() => {
            const url = new URL(window.location);
            if (filterElements.searchInput.value) {
                url.searchParams.set('search', filterElements.searchInput.value);
            } else {
                url.searchParams.delete('search');
            }
            window.history.pushState({}, '', url);
            loadTabData('managed-resources');
        }, 300));
    }

    if (filterElements.statusFilterSelect) {
        filterElements.statusFilterSelect.addEventListener('change', () => {
            const url = new URL(window.location);
            if (filterElements.statusFilterSelect.value) {
                url.searchParams.set('status', filterElements.statusFilterSelect.value);
            } else {
                url.searchParams.delete('status');
            }
            window.history.pushState({}, '', url);
            loadTabData('managed-resources');
        });
    }

    if (filterElements.providerConfigFilterSelect) {
        filterElements.providerConfigFilterSelect.addEventListener('change', () => {
            const url = new URL(window.location);
            if (filterElements.providerConfigFilterSelect.value) {
                url.searchParams.set('providerconfig', filterElements.providerConfigFilterSelect.value);
            } else {
                url.searchParams.delete('providerconfig');
            }
            window.history.pushState({}, '', url);
            loadTabData('managed-resources');
        });
    }
}

function renderManagedResources(data) {
    if (!data) {
        console.error('No data provided to renderManagedResources');
        return;
    }

    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'border-b border-gray-200';
    
    const tabsList = document.createElement('nav');
    tabsList.className = 'flex -mb-px';
    tabsContainer.appendChild(tabsList);

    const contentContainer = document.createElement('div');
    contentContainer.className = 'mt-4';

    const container = document.getElementById('managed-resources-list');
    if (!container) return;

    container.innerHTML = '';
    container.appendChild(tabsContainer);
    container.appendChild(contentContainer);

    // Apply filters from URL
    const searchParams = new URLSearchParams(window.location.search);
    const statusFilter = searchParams.get('status');
    const searchTerm = searchParams.get('search')?.toLowerCase();
    const providerConfigFilter = searchParams.get('providerconfig');

    if (statusFilter || searchTerm || providerConfigFilter) {
        const filteredResources = {};
        Object.entries(data.resources || {}).forEach(([kind, group]) => {
            const filteredGroup = {
                ...group,
                resources: group.resources.filter(r => {
                    if (statusFilter && r._health_status !== statusFilter) return false;
                    if (searchTerm) {
                        const searchFields = [
                            r.metadata?.name,
                            r.kind,
                            r.apiVersion,
                            r.provider,
                            r.display_provider,
                            r.providerconfig
                        ].map(field => (field || '').toLowerCase());
                        return searchFields.some(field => field.includes(searchTerm));
                    }
                    if (providerConfigFilter && r.providerconfig !== providerConfigFilter) return false;
                    return true;
                })
            };
            filteredGroup.count = filteredGroup.resources.length;
            if (filteredGroup.resources.length > 0) {
                filteredResources[kind] = filteredGroup;
            }
        });
        data.resources = filteredResources;
    }

    // Calculate and update summary counts
    calculateSummaryCounts(data.resources);

    if (!data.resources || Object.keys(data.resources).length === 0) {
        contentContainer.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        return;
    }

    let isFirstTab = true;
    Object.entries(data.resources).forEach(([kind, groupData]) => {
        const tab = document.createElement('button');
        tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
            isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
        }`;
        tab.setAttribute('data-tab', kind);
        tab.innerHTML = `
            <span>${kind}</span>
            <span class="ml-2 text-sm text-gray-400">(${groupData.count || 0})</span>
        `;

        const contentPanel = document.createElement('div');
        contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
        contentPanel.setAttribute('data-tab-content', kind);

        const resourcesContainer = document.createElement('div');
        resourcesContainer.className = 'divide-y divide-gray-200';

        groupData.resources.forEach(resource => {
            const resourceElement = document.createElement('div');
            resourceElement.className = 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150';
            
            resourceElement.innerHTML = `
                <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <h4 class="text-lg font-medium text-gray-900 dark:text-white">
                                ${resource.metadata?.name || 'Unnamed'}
                                <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${resource.apiVersion || ''}</span>
                            </h4>
                            <div class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                <p>Provider: ${resource.provider || resource.display_provider || 'Unknown'}</p>
                                <p>Provider Config: ${resource.providerconfig || 'Unknown'}</p>
                                <p class="mt-1 text-xs text-gray-400">
                                    Created: ${formatTimeAgo(resource.metadata?.creationTimestamp)}
                                </p>
                            </div>
                        </div>
                        <div class="ml-4 flex items-center">
                            <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                                ${resource._health_status || 'Unknown'}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="managed-resource-details" style="display: none;">
                    ${renderManagedResourceDetails(resource)}
                </div>
            `;

            // Add click event listener for details toggle
            resourceElement.addEventListener('click', function() {
                const details = this.querySelector('.managed-resource-details');
                if (details) {
                    const isExpanded = details.style.display !== 'none';
                    details.style.display = isExpanded ? 'none' : 'block';
                    this.classList.toggle('expanded', !isExpanded);
                }
            });

            resourcesContainer.appendChild(resourceElement);
        });

        contentPanel.appendChild(resourcesContainer);

        tab.addEventListener('click', () => {
            document.querySelectorAll('[data-tab]').forEach(t => {
                t.classList.remove('text-blue-600', 'border-blue-600');
                t.classList.add('text-gray-500', 'border-transparent');
            });
            tab.classList.remove('text-gray-500', 'border-transparent');
            tab.classList.add('text-blue-600', 'border-blue-600');

            document.querySelectorAll('[data-tab-content]').forEach(p => {
                p.classList.add('hidden');
            });
            contentPanel.classList.remove('hidden');
        });

        tabsList.appendChild(tab);
        contentContainer.appendChild(contentPanel);
        
        isFirstTab = false;
    });

    // Initialize filter elements and setup listeners
    initializeFilterElements();
    if (!filterElements.searchInput) {
        // If elements don't exist yet, wait for them to be created
        setTimeout(() => {
            initializeFilterElements();
            setupFilterEventListeners();
        }, 100);
    } else {
        setupFilterEventListeners();
    }
}

function getHealthStatusClass(status) {
    switch (status) {
        case 'Healthy':
            return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
        case 'Unhealthy':
            return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
        default:
            return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
    }
}

// Handle search initialization
function initializeSearch() {
    const searchParams = new URLSearchParams(window.location.search);
    const searchTerm = searchParams.get('search');
    const searchInput = document.getElementById('resource-search');
    
    if (searchInput && searchTerm) {
        searchInput.value = searchTerm;
        // Trigger search immediately
        loadTabData('managed-resources');
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    initializeFilters();
    initializeSearch();
});

// Export functions
window.renderManagedResources = renderManagedResources;
window.initializeFilters = initializeFilters;
window.initializeSearch = initializeSearch;
