// editor.js - YAML viewer functionality
let editor = null;

function createEditor(element, value, isDark) {
    const textArea = document.createElement('textarea');
    textArea.value = value;
    textArea.readOnly = true;
    textArea.style.width = '100%';
    textArea.style.height = '100%';
    textArea.style.fontFamily = 'monospace';
    textArea.style.padding = '8px';
    textArea.style.border = 'none';
    textArea.style.resize = 'none';
    textArea.style.backgroundColor = isDark ? '#1e1e1e' : '#ffffff';
    textArea.style.color = isDark ? '#d4d4d4' : '#000000';
    element.appendChild(textArea);
    
    return {
        dispose: () => textArea.remove(),
        setValue: (value) => textArea.value = value,
        getValue: () => textArea.value
    };
}

function updateEditorTheme(isDark) {
    const textArea = document.querySelector('#yaml-editor textarea');
    if (textArea) {
        textArea.style.backgroundColor = isDark ? '#1e1e1e' : '#ffffff';
        textArea.style.color = isDark ? '#d4d4d4' : '#000000';
    }
}

function showYAMLInMonaco(data) {
    try {
        // Parse data if it's a string
        const parsedData = typeof data === 'string' ? JSON.parse(data) : data;

        // Remove internal fields
        const cleanData = { ...parsedData };
        delete cleanData._health_status;
        delete cleanData.display_provider;

        // Update metadata fields
        const metadataFields = {
            'yaml-resource-name': cleanData.metadata?.name || '',
            'yaml-resource-kind': cleanData.kind || '',
            'yaml-resource-group': (cleanData.apiVersion || '').split('/')[0] || '',
            'yaml-resource-version': (cleanData.apiVersion || '').split('/')[1] || '',
            'yaml-resource-namespace': cleanData.metadata?.namespace || 'default'
        };

        Object.entries(metadataFields).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });

        const yamlContent = jsyaml.dump(cleanData, {
            indent: 2,
            lineWidth: -1,
            noRefs: true,
            sortKeys: false,
            noArrayIndent: false,
            quotingType: '"',
            forceQuotes: false,
            skipInvalid: true
        });
        
        const editorElement = document.getElementById('yaml-editor');
        if (!editorElement) {
            console.error('Editor element not found');
            return;
        }

        // Clear any existing content
        editorElement.innerHTML = '';
        
        // Show modal
        const modal = document.getElementById('yaml-modal');
        if (modal) {
            modal.classList.remove('hidden');
        }
        
        // Create editor if it doesn't exist
        if (!editor) {
            const isDark = document.documentElement.classList.contains('dark');
            editor = createEditor(editorElement, yamlContent, isDark);

            // Set up theme change listener
            document.addEventListener('themechange', (e) => {
                updateEditorTheme(e.detail.theme === 'dark');
            });
        } else {
            editor.setValue(yamlContent);
        }

        // Set up close button
        const closeButtons = document.querySelectorAll('#yaml-close, #yaml-close-btn');
        closeButtons.forEach(button => {
            button.onclick = () => {
                document.getElementById('yaml-modal').classList.add('hidden');
                if (editor) {
                    editor.dispose();
                    editor = null;
                }
            };
        });

        // Set up copy button
        const copyButton = document.getElementById('yaml-copy');
        if (copyButton) {
            copyButton.onclick = () => {
                if (editor) {
                    const content = editor.getValue();
                    navigator.clipboard.writeText(content).then(() => {
                        copyButton.innerHTML = `
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>Copied!</span>
                        `;
                        setTimeout(() => {
                            copyButton.innerHTML = `
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                                </svg>
                                <span>Copy YAML</span>
                            `;
                        }, 2000);
                        showSuccess('YAML copied to clipboard');
                    }).catch(err => {
                        console.error('Failed to copy YAML:', err);
                        showError('Failed to copy YAML');
                    });
                }
            };
        }
    } catch (error) {
        console.error('Error showing YAML:', error);
        console.error('Data received:', data);
        showError('Failed to display YAML');
    }
}

// Cleanup on page unload
window.addEventListener('unload', () => {
    if (editor) {
        editor.dispose();
        editor = null;
    }
});

// Export functions
window.showYAMLInMonaco = showYAMLInMonaco;
