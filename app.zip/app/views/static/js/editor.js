// editor.js
let editor = null;

// Configure Monaco loader
require.config({
    paths: {
        'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs'
    }
});

// Pre-load Monaco when the page loads
window.MonacoEnvironment = {
    getWorkerUrl: function(workerId, label) {
        return `data:text/javascript;charset=utf-8,${encodeURIComponent(`
            self.MonacoEnvironment = {
                baseUrl: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/'
            };
            importScripts('https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/base/worker/workerMain.js');`
        )}`;
    }
};

function updateEditorTheme(isDark) {
    if (editor) {
        monaco.editor.setTheme(isDark ? 'vs-dark' : 'vs');
    }
}

function initializeEditor(content = '', readOnly = false) {
    const editorElement = document.getElementById('yaml-editor');
    if (!editorElement) {
        console.error('Editor element not found');
        return;
    }

    // Clear any existing content
    editorElement.innerHTML = '';
    
    // Load Monaco and create editor
    require(['vs/editor/editor.main'], function() {
        createEditor(editorElement, content, readOnly);
        setupEditorEventListeners();
        // Set initial theme
        updateEditorTheme();
    });
}

function createEditor(element, content = '', readOnly = false) {
    // Always create a fresh editor instance
    editor = monaco.editor.create(element, {
        value: content,
        language: 'yaml',
        theme: document.documentElement.classList.contains('dark') ? 'vs-dark' : 'vs',
        automaticLayout: true,
        minimap: { enabled: false },
        scrollBeyondLastLine: false,
        lineNumbers: 'on',
        renderWhitespace: 'boundary',
        tabSize: 2,
        insertSpaces: true,
        detectIndentation: false,
        trimAutoWhitespace: true,
        readOnly: readOnly,
        domReadOnly: readOnly,
        formatOnPaste: true,
        formatOnType: true,
        wordWrap: 'off'
    });

    // Set editor model formatting options
    const model = editor.getModel();
    if (model) {
        model.updateOptions({
            insertSpaces: true,
            tabSize: 2,
            trimAutoWhitespace: true
        });
    }

    // Configure YAML language options if available
    if (monaco.languages.yaml && monaco.languages.yaml.yamlDefaults) {
        monaco.languages.yaml.yamlDefaults.setDiagnosticsOptions({
            validate: true,
            schemas: [],
            enableSchemaRequest: true,
            format: true
        });
    }
}

function setupEditorEventListeners() {
    const modal = document.getElementById('yaml-modal');
    if (!modal) {
        console.warn('Modal element not found');
        return;
    }

    const saveButton = modal.querySelector('#yaml-save');
    const cancelButton = modal.querySelector('#yaml-cancel');
    const closeButton = modal.querySelector('#yaml-close');

    if (saveButton) {
        saveButton.addEventListener('click', () => {
            if (editor) {
                const yamlContent = editor.getValue();
                saveYamlContent(yamlContent);
            }
            hideEditor();
        });
    }

    if (cancelButton) {
        cancelButton.addEventListener('click', hideEditor);
    }

    if (closeButton) {
        closeButton.addEventListener('click', hideEditor);
    }

    // Listen for theme changes
    document.addEventListener('themechange', (e) => {
        updateEditorTheme(e.detail.theme === 'dark');
    });
}

function showEditor(content = '', readOnly = false) {
    const modal = document.getElementById('yaml-modal');
    if (!modal) return;

    // Hide save button if in read-only mode
    const saveButton = modal.querySelector('#yaml-save');
    if (saveButton) {
        saveButton.style.display = readOnly ? 'none' : 'block';
    }

    modal.classList.remove('hidden');
    initializeEditor(content, readOnly);
}

function hideEditor() {
    const modal = document.getElementById('yaml-modal');
    if (modal) {
        modal.classList.add('hidden');
        // Dispose of the editor when hiding to ensure clean state
        disposeEditor();
    }
}

function disposeEditor() {
    if (editor) {
        editor.dispose();
        editor = null;
    }
}

// Cleanup on page unload
window.addEventListener('unload', disposeEditor);

// Lazy initialization of editor
document.addEventListener('DOMContentLoaded', () => {
    // Editor will be initialized when needed
    setupEditorEventListeners();
});

// Function to show details in Monaco editor
function showDetailsInMonaco(data) {
    try {
        // Handle URL-encoded data
        if (typeof data === 'string') {
            try {
                // First try to decode if URL-encoded
                data = decodeURIComponent(data);
            } catch (e) {
                // If decoding fails, use original string
                console.log('Data was not URL-encoded:', e);
            }
            // Then parse as JSON
            data = JSON.parse(data);
        }
        
        // Use the data object directly if not a string
        let objectData = data;
        
        // Convert the data to YAML with specific formatting
        const yamlContent = jsyaml.dump(objectData, {
            indent: 2,
            lineWidth: -1,
            noRefs: true,
            sortKeys: false, // Don't sort keys to maintain original order
            noArrayIndent: false,
            quotingType: '"',
            forceQuotes: false,
            skipInvalid: true
        });
        
        // Show the editor with the YAML content in read-only mode
        showEditor(yamlContent, true);
    } catch (error) {
        console.error('Error showing details:', error);
        console.error('Data received:', data);
        showError('Failed to display resource details. Please check the console for more information.');
    }
}

// Export functions
window.showDetailsInMonaco = showDetailsInMonaco;
window.showEditor = showEditor;
window.hideEditor = hideEditor;
