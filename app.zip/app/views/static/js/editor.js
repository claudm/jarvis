// editor.js - Monaco editor functionality
let editor = null;

// Initialize Monaco loader
require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' }});
window.MonacoEnvironment = {
    getWorkerUrl: function(workerId, label) {
        return `data:text/javascript;charset=utf-8,${encodeURIComponent(`
            self.MonacoEnvironment = {
                baseUrl: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/'
            };
            importScripts('https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/base/worker/workerMain.js');`
        )}`;
    }
};

// Initialize Monaco editor when needed
require(['vs/editor/editor.main'], function() {
    // Monaco is now loaded and ready to use
    console.log('Monaco editor loaded');
});

function updateEditorTheme(isDark) {
    if (editor) {
        monaco.editor.setTheme(isDark ? 'vs-dark' : 'vs');
    }
}

function showYAMLInMonaco(data) {
    try {
        const yamlContent = jsyaml.dump(data, {
            indent: 2,
            lineWidth: -1,
            noRefs: true,
            sortKeys: false,
            noArrayIndent: false,
            quotingType: '"',
            forceQuotes: false,
            skipInvalid: true
        });
        
        const editorElement = document.getElementById('yaml-editor');
        if (!editorElement) {
            console.error('Editor element not found');
            return;
        }

        // Clear any existing content
        editorElement.innerHTML = '';
        
        // Show modal
        const modal = document.getElementById('yaml-modal');
        if (modal) {
            modal.classList.remove('hidden');
        }
        
        // Create editor if it doesn't exist
        if (!editor) {
            editor = monaco.editor.create(editorElement, {
                value: yamlContent,
                language: 'yaml',
                theme: document.documentElement.classList.contains('dark') ? 'vs-dark' : 'vs',
                automaticLayout: true,
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                lineNumbers: 'on',
                renderWhitespace: 'boundary',
                readOnly: true,
                domReadOnly: true,
                wordWrap: 'on',
                tabSize: 2,
                insertSpaces: true,
                detectIndentation: false,
                trimAutoWhitespace: true,
                formatOnPaste: true,
                formatOnType: true
            });

            // Set editor model formatting options
            const model = editor.getModel();
            if (model) {
                model.updateOptions({
                    insertSpaces: true,
                    tabSize: 2,
                    trimAutoWhitespace: true
                });
            }

            // Configure YAML language options if available
            if (monaco.languages.yaml && monaco.languages.yaml.yamlDefaults) {
                monaco.languages.yaml.yamlDefaults.setDiagnosticsOptions({
                    validate: true,
                    schemas: [],
                    enableSchemaRequest: true,
                    format: true
                });
            }

            // Set up theme change listener
            document.addEventListener('themechange', (e) => {
                updateEditorTheme(e.detail.theme === 'dark');
            });
        } else {
            editor.setValue(yamlContent);
        }

        // Set up close button
        const closeButtons = document.querySelectorAll('#yaml-close, #yaml-close-btn');
        closeButtons.forEach(button => {
            button.onclick = () => {
                modal.classList.add('hidden');
                if (editor) {
                    editor.dispose();
                    editor = null;
                }
            };
        });

        // Set up copy button
        const copyButton = document.getElementById('yaml-copy');
        if (copyButton) {
            copyButton.onclick = () => {
                if (editor) {
                    const content = editor.getValue();
                    navigator.clipboard.writeText(content).then(() => {
                        copyButton.innerHTML = `
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>Copied!</span>
                        `;
                        setTimeout(() => {
                            copyButton.innerHTML = `
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                                </svg>
                                <span>Copy YAML</span>
                            `;
                        }, 2000);
                        showSuccess('YAML copied to clipboard');
                    }).catch(err => {
                        console.error('Failed to copy YAML:', err);
                        showError('Failed to copy YAML');
                    });
                }
            };
        }
    } catch (error) {
        console.error('Error showing YAML:', error);
        console.error('Data received:', data);
        showError('Failed to display YAML');
    }
}

// Cleanup on page unload
window.addEventListener('unload', () => {
    if (editor) {
        editor.dispose();
        editor = null;
    }
});

// Export functions
window.showYAMLInMonaco = showYAMLInMonaco;
