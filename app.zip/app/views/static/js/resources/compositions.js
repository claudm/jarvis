function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderCompositionGraph(composition, containerId) {
    try {
        const graphElement = document.getElementById(containerId);
        if (!graphElement) {
            console.error(`Graph container ${containerId} not found`);
            return null;
        }

        const chart = echarts.init(graphElement);
        const isDarkMode = document.documentElement.classList.contains('dark');
        
        // Prepare nodes and links data
        const nodes = [];
        const links = [];

        // Icons for nodes using path notation
        const icons = {
            claim: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
            composition: 'path://M3 3h18v18H3z M7 7h10v10H7z',
            resource: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
        };

        // Node colors with improved contrast
        const colors = {
            claim: '#6B7CFF',      // Light purple for claims
            composition: '#4ADE80', // Light green for compositions
            resource: '#FBBF24'    // Light orange/yellow for composite resources
        };

        // Get composition status
        const status = composition.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isReady = readyCondition.status === 'True';

        // Add composition node with improved styling
        nodes.push({
            id: composition.metadata?.name,
            name: composition.metadata?.name || 'Unnamed',
            symbol: icons.composition,
            symbolSize: [50, 50],
            category: 0,
            itemStyle: {
                color: colors.composition,
                opacity: isReady ? 1 : 0.7
            },
            label: {
                show: true,
                formatter: '{b}',
                position: 'right',
                distance: 5,
                color: isReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
            },
            tooltip: {
                formatter: () => `
                    ${composition.metadata?.name}
                    Status: ${isReady ? 'Ready' : 'Not Ready'}
                `
            }
        });

        // Add resource nodes
        if (composition.spec?.resources) {
            composition.spec.resources.forEach((resource, index) => {
                const resourceName = resource.name || `Resource ${index + 1}`;
                const resourceKind = resource.base?.kind || 'Unknown Kind';
                const resourceReady = resource.status?.ready || false;
                
                nodes.push({
                    id: resourceName,
                    name: resourceName,
                    symbol: icons.resource,
                    symbolSize: [45, 45],
                    category: 1,
                    itemStyle: {
                        color: colors.resource,
                        opacity: resourceReady ? 1 : 0.7
                    },
                    label: {
                        show: true,
                        formatter: `{b}\n(${resourceKind})`,
                        position: 'right',
                        distance: 5,
                        color: resourceReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
                    },
                    tooltip: {
                        formatter: () => `
                            ${resourceName}
                            Kind: ${resourceKind}
                            Status: ${resourceReady ? 'Ready' : 'Not Ready'}
                        `
                    }
                });

                // Determine relationship type and style accordingly
                const relationshipType = resource.base?.kind?.toLowerCase().includes('bucket') ? 'composite' : 'uses';
                
                links.push({
                    source: composition.metadata?.name,
                    target: resourceName,
                    lineStyle: {
                        color: relationshipType === 'uses' ? '#4ADE80' : '#60A5FA', // Green for uses, Blue for composite
                        width: 2,
                        opacity: 0.8,
                        type: relationshipType === 'uses' ? 'dashed' : 'solid',
                        curveness: 0.4
                    }
                });

                // Add claims relationship if it exists
                if (resource.claims) {
                    links.push({
                        source: resourceName,
                        target: resource.claims,
                        lineStyle: {
                            color: '#A78BFA', // Purple for claims
                            width: 2,
                            opacity: 0.8,
                            type: 'solid',
                            curveness: 0.4
                        }
                    });
                }
            });
        }

        const option = {
            backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
            tooltip: {
                trigger: 'item',
                formatter: (params) => {
                    if (params.dataType === 'node') {
                        return params.data.tooltip?.formatter() || params.name;
                    }
                    return params.name;
                }
            },
            legend: {
                show: true,
                top: '20',
                left: '20',
                orient: 'vertical',
                itemGap: 20,
                itemWidth: 30,
                itemHeight: 16,
                data: [
                    {
                        name: 'Composition',
                        icon: icons.composition,
                        itemStyle: { color: colors.composition }
                    },
                    {
                        name: 'Resource',
                        icon: icons.resource,
                        itemStyle: { color: colors.resource }
                    }
                ],
                textStyle: {
                    color: isDarkMode ? '#e5e7eb' : '#374151'
                }
            },
            animationDurationUpdate: 1500,
            animationEasingUpdate: 'quinticInOut',
            series: [{
                type: 'graph',
                layout: 'force',
                data: nodes,
                links: links,
                edgeSymbol: ['circle', 'arrow'],
                edgeSymbolSize: [4, 10],
                lineStyle: {
                    curveness: 0.4,
                    width: 2,
                    opacity: 0.8
                },
                categories: [
                    { name: 'Composition' },
                    { name: 'Resource' }
                ],
                roam: true,
                force: {
                    repulsion: 1500,
                    edgeLength: 200,
                    gravity: 0.05,
                    friction: 0.3,
                    layoutAnimation: true
                },
                draggable: true,
                emphasis: {
                    focus: 'adjacency',
                    scale: 1.1
                },
                label: {
                    show: true,
                    position: 'right',
                    color: isDarkMode ? '#e5e7eb' : '#374151',
                    formatter: '{b}'
                }
            }]
        };

        chart.setOption(option);
        
        // Handle window resize
        const resizeHandler = () => {
            if (chart) {
                chart.resize();
            }
        };
        window.addEventListener('resize', resizeHandler);

        // Prevent graph clicks from propagating to card
        graphElement.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        return chart;
    } catch (error) {
        console.error('Error rendering graph:', error);
        return null;
    }
}

function renderCompositions(container, compositions) {
    if (!compositions?.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No compositions found</div>';
        return;
    }

    // Store the original data for filtering
    window.originalCompositionsData = structuredClone(compositions);

    // Get current filters
    const filters = {       
        search: document.getElementById('compositions-search')?.value?.toLowerCase() || ''
    };

    // Apply filters
    const filteredData = compositions.filter(comp => {
        // Search filter
        if (filters.search) {
            const searchFields = [
                comp.metadata?.name,
                comp.kind,
                comp.apiVersion,
                ...(comp.providerConfigs || [])
            ].map(field => (field || '').toLowerCase());
            
            if (!searchFields.some(field => field.includes(filters.search))) {
                return false;
            }
        }
        return true;
    });

    // Set up filter handlers
    const searchInput = document.getElementById('compositions-search');
    if (searchInput && !searchInput.hasEventListener) {
        const handleSearch = _.debounce(() => {
            // Update URL params
            const url = new URL(window.location);
            if (searchInput.value) {
                url.searchParams.set('search', searchInput.value);
            } else {
                url.searchParams.delete('search');
            }
            window.history.replaceState({}, '', url);

            // Re-render with current filters
            if (window.originalCompositionsData) {
                renderCompositions(container, window.originalCompositionsData);
            }
        }, 300);

        searchInput.addEventListener('input', handleSearch);
        searchInput.hasEventListener = true;
    }

    const table = document.createElement('table');
    table.className = 'w-full table-fixed';
    table.innerHTML = `
        <thead class="bg-gray-50 dark:bg-gray-800">
            <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Name</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Provider</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Provider Config</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Status</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-1/5">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        </tbody>
    `;

    const tbody = table.querySelector('tbody');
    filteredData.forEach(comp => {
        const name = comp.metadata?.name || '';
        // Extract provider from resources
        const resources = comp.spec?.resources || [];
        const providers = new Set();
        resources.forEach(resource => {
            const apiVersion = resource.base?.apiVersion || '';
            if (apiVersion) {
                const [group] = apiVersion.split('/');
                if (group) {
                    providers.add(group.split('.')[0].toUpperCase());
                }
            }
        });
        const provider = Array.from(providers).join(', ') || '-';
        const providerConfigs = comp.providerConfigs || [];
        const providerConfigDisplay = providerConfigs.length ? providerConfigs.join(', ') : '-';
        const status = comp.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';
        
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer';
        
        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">${name}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">${provider}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">${providerConfigDisplay}</td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center space-x-2">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        isSynced ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200' : 
                        'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isSynced ? 'Synced' : 'Not Synced'}
                    </span>
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        isReady ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200' : 
                        'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isReady ? 'Ready' : 'Not Ready'}
                    </span>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <button 
                    class="text-gray-400 hover:text-gray-500"
                    data-resource='${JSON.stringify(comp).replace(/'/g, "&apos;")}'
                    onclick="event.stopPropagation(); showYAMLInMonaco(JSON.parse(this.dataset.resource))"
                    title="View YAML">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    container.innerHTML = ''; // Clear container before rendering
    container.appendChild(table);
}

// Initialize search from URL params
function initializeFilters() {
    const searchParams = new URLSearchParams(window.location.search);
    const searchInput = document.getElementById('compositions-search');
    
    if (searchInput && searchParams.has('search')) {
        searchInput.value = searchParams.get('search');
    }
}

// Export functions
window.renderCompositions = renderCompositions;
window.initializeFilters = initializeFilters;

// Initialize filters when document is ready
document.addEventListener('DOMContentLoaded', initializeFilters);
