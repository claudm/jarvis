// composite-resources.js
let eventsPollingInterval;
let resourceCache = new Map();
const CACHE_DURATION = 30000; // 30 seconds cache

// Store original data for filtering
window.originalCompositeResourcesData = null;

// Helper function to get cached data or fetch from API
async function getCachedOrFetch(url) {
    const now = Date.now();
    if (resourceCache.has(url)) {
        const { data, timestamp } = resourceCache.get(url);
        if (now - timestamp < CACHE_DURATION) {
            return data;
        }
    }
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch resources');
    const data = await response.json();
    
    resourceCache.set(url, {
        data,
        timestamp: now
    });
    
    return data;
}

// Helper function to format timestamps in a human-readable way
function formatTimeAgo(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
        return `${days}d ago`;
    } else if (hours > 0) {
        return `${hours}h ago`;
    } else if (minutes > 0) {
        return `${minutes}m ago`;
    } else {
        return 'just now';
    }
}

// Helper function to create DOM elements with attributes
function createElement(tag, attributes = {}) {
    const element = document.createElement(tag);
    Object.entries(attributes).forEach(([key, value]) => {
        if (key === 'className') {
            element.className = value;
        } else {
            element.setAttribute(key, value);
        }
    });
    return element;
}

// Helper function to render events in a container
function renderEvents(container, events) {
    if (events.length > 0) {
        events.forEach(event => {
            const eventElement = document.createElement('div');
            eventElement.className = 'flex items-start space-x-3';
            eventElement.innerHTML = `
                <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                    event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                }"></span>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                        ${event.reason}
                        <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.time)}</span>
                    </p>
                    <p class="text-sm text-gray-500">${event.message}</p>
                </div>
            `;
            container.insertBefore(eventElement, container.firstChild);
        });

        // Limit the number of events shown
        while (container.children.length > 10) {
            container.removeChild(container.lastChild);
        }
    }
}

// Helper function to render composite resource graph
function renderCompositeResourceGraph(resource, containerId) {
    const graphContainer = document.getElementById(containerId);
    if (!graphContainer) {
        console.error('Graph container not found');
        return null;
    }

    const chart = echarts.init(graphContainer);
    const isDarkMode = document.documentElement.classList.contains('dark');

    // Get resource status
    const status = resource.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const isReady = readyCondition.status === 'True';

    // Prepare nodes and links data
    const nodes = [];
    const links = [];

    // Icons for nodes
    const icons = {
        claim: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
        composition: 'path://M3 3h18v18H3z M7 7h10v10H7z',
        resource: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
    };

    // Add composite resource node (centered)
    const compositeNode = {
        id: resource.metadata?.name,
        name: resource.metadata?.name,
        symbolSize: [60, 60],
        symbol: icons.resource,
        category: 0,
        x: graphContainer.clientWidth / 2,
        y: graphContainer.clientHeight / 2,
        itemStyle: {
            color: '#FBBF24',
            borderColor: isDarkMode ? '#374151' : '#D1D5DB',
            borderWidth: 2
        },
        label: {
            show: true,
            position: 'right',
            formatter: [
                '{b}',
                `(${resource.kind})`
            ].join('\n'),
            color: isReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
        }
    };
    nodes.push(compositeNode);

    // Add claim if exists
    if (resource.spec?.claimRef) {
        const claimNode = {
            id: 'claim-' + resource.spec.claimRef.name,
            name: resource.spec.claimRef.name,
            symbolSize: [50, 50],
            symbol: icons.claim,
            category: 1,
            itemStyle: {
                color: '#A78BFA',
                borderColor: isDarkMode ? '#374151' : '#D1D5DB',
                borderWidth: 2
            },
            label: {
                show: true,
                position: 'top',
                formatter: [
                    '{b}',
                    '(Claim)'
                ].join('\n'),
                color: isDarkMode ? '#E5E7EB' : '#374151'
            }
        };
        nodes.push(claimNode);
        links.push({
            source: claimNode.id,
            target: compositeNode.id,
            symbolSize: [5, 12],
            lineStyle: {
                color: '#A78BFA',
                width: 2,
                type: 'solid',
                curveness: 0.2
            },
            label: {
                show: true,
                formatter: 'claims'
            }
        });
    }

    // Add composition if exists
    if (resource.spec?.compositionRef) {
        const compositionNode = {
            id: 'composition-' + resource.spec.compositionRef.name,
            name: resource.spec.compositionRef.name,
            symbolSize: [50, 50],
            symbol: icons.composition,
            category: 2,
            itemStyle: {
                color: '#4ADE80',
                borderColor: isDarkMode ? '#374151' : '#D1D5DB',
                borderWidth: 2
            },
            label: {
                show: true,
                position: 'right',
                formatter: [
                    '{b}',
                    '(Composition)'
                ].join('\n'),
                color: isDarkMode ? '#E5E7EB' : '#374151'
            }
        };
        nodes.push(compositionNode);
        links.push({
            source: compositeNode.id,
            target: compositionNode.id,
            symbolSize: [5, 12],
            lineStyle: {
                color: '#4ADE80',
                width: 2,
                type: 'dashed',
                curveness: 0.2
            },
            label: {
                show: true,
                formatter: 'uses'
            }
        });
    }

    // Add managed resources
    if (resource.spec?.resourceRefs) {
        resource.spec.resourceRefs.forEach((ref, index) => {
            const managedNode = {
                id: 'managed-' + ref.name,
                name: ref.name,
                symbolSize: [50, 50],
                symbol: icons.resource,
                category: 3,
                itemStyle: {
                    color: '#60A5FA',
                    borderColor: isDarkMode ? '#374151' : '#D1D5DB',
                    borderWidth: 2
                },
                label: {
                    show: true,
                    position: 'right',
                    formatter: [
                        '{b}',
                        `(${ref.kind})`
                    ].join('\n'),
                    color: isDarkMode ? '#E5E7EB' : '#374151'
                },
                // Add provider info for filtering
                providerconfig: resource.providerconfig,
                kind: ref.kind
            };
            nodes.push(managedNode);
            links.push({
                source: compositeNode.id,
                target: managedNode.id,
                symbolSize: [5, 12],
                lineStyle: {
                    color: '#60A5FA',
                    width: 2,
                    type: 'solid',
                    curveness: 0.2
                },
                label: {
                    show: true,
                    formatter: 'manages'
                }
            });
        });
    }

    const option = {
        backgroundColor: isDarkMode ? '#1F2937' : '#FFFFFF',
        tooltip: {
            show: true,
            trigger: 'item',
            formatter: '{b}'
        },
        legend: {
            show: true,
            top: '20',
            left: '20',
            orient: 'vertical',
            itemGap: 20,
            itemWidth: 30,
            itemHeight: 16,
            data: [
                {
                    name: 'Composite',
                    icon: icons.resource,
                    itemStyle: { color: '#FBBF24' }
                },
                {
                    name: 'Claim',
                    icon: icons.claim,
                    itemStyle: { color: '#A78BFA' }
                },
                {
                    name: 'Composition',
                    icon: icons.composition,
                    itemStyle: { color: '#4ADE80' }
                },
                {
                    name: 'Managed',
                    icon: icons.resource,
                    itemStyle: { color: '#60A5FA' }
                }
            ],
            textStyle: {
                color: isDarkMode ? '#e5e7eb' : '#374151'
            }
        },
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',
        series: [{
            type: 'graph',
            layout: 'force',
            force: {
                repulsion: 2500,
                edgeLength: 300,
                gravity: 0.05,
                layoutAnimation: true
            },
            data: nodes,
            links: links,
            categories: ['Composite', 'Claim', 'Composition', 'Managed'].map(name => ({
                name: name
            })),
            roam: true,
            label: {
                position: 'right',
                formatter: '{b}'
            },
            lineStyle: {
                color: 'source',
                curveness: 0.3
            },
            emphasis: {
                focus: 'adjacency',
                lineStyle: {
                    width: 10
                }
            },
            edgeSymbol: ['circle', 'arrow'],
            edgeSymbolSize: [4, 10]
        }]
    };

    chart.setOption(option);

    // Add click handler for nodes
    chart.on('click', function(params) {
        if (params.dataType === 'node') {
            const data = params.data;
            if (data.category === 3) {  // Managed resources
                // Switch to managed-resources tab with search and providerconfig
                switchTab('managed-resources', {
                    search: data.name,
                    providerconfig: data.providerconfig || ''
                });
            } else if (data.category === 2) {  // Composition
                // Switch to compositions tab
                switchTab('compositions');
            } else if (data.category === 1) {  // Claims
                // Switch to claims tab
                switchTab('claims');
            } else if (data.category === 0) {  // Composite resource
                // Switch to managed-resources tab with search
                switchTab('managed-resources', {
                    search: data.name
                });
            }
        }
    });

    // Prevent clicks on the graph container from bubbling up
    graphContainer.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
    });

    // Handle resize
    window.addEventListener('resize', () => chart.resize());

    return chart;
}

// Poll for changes in resources
async function pollForChanges() {
    try {
        const data = await getCachedOrFetch('/api/composite-resources');
        
        // Update the resources list
        const container = document.getElementById('composite-resources-list');
        if (container) {
            renderCompositeResources(container, data.resources || []);
        }
    } catch (error) {
        console.error('Error polling for changes:', error);
    }
}

function renderCompositeResources(container, resources) {
    if (!resources?.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500 dark:text-gray-400">No composite resources found</div>';
        return;
    }

    // Store the original data for filtering
    window.originalCompositeResourcesData = structuredClone(resources);

    // Get current filters
    const filters = {       
        search: document.getElementById('composite-resources-search')?.value?.toLowerCase() || '',
        status: document.getElementById('composite-resources-status-filter')?.value || ''
    };

    // Apply filters
    const filteredData = resources.filter(resource => {
        // Search filter
        if (filters.search) {
            const searchFields = [
                resource.metadata?.name,
                resource.kind,
                resource.apiVersion
            ].map(field => (field || '').toLowerCase());
            
            if (!searchFields.some(field => field.includes(filters.search))) {
                return false;
            }
        }

        // Status filter
        if (filters.status) {
            const status = resource.status || {};
            const conditions = status.conditions || [];
            const readyCondition = conditions.find(c => c.type === 'Ready') || {};
            const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
            const isReady = readyCondition.status === 'True';
            const isSynced = syncedCondition.status === 'True';

            switch (filters.status) {
                case 'Ready':
                    if (!isReady) return false;
                    break;
                case 'NotReady':
                    if (isReady) return false;
                    break;
                case 'Synced':
                    if (!isSynced) return false;
                    break;
                case 'NotSynced':
                    if (isSynced) return false;
                    break;
            }
        }

        return true;
    });

    // Set up filter handlers
    const searchInput = document.getElementById('composite-resources-search');
    const statusFilter = document.getElementById('composite-resources-status-filter');

    if (searchInput && !searchInput.hasEventListener) {
        const handleSearch = _.debounce(() => {
            // Update URL params
            const url = new URL(window.location);
            if (searchInput.value) {
                url.searchParams.set('search', searchInput.value);
            } else {
                url.searchParams.delete('search');
            }
            window.history.replaceState({}, '', url);

            // Re-render with current filters
            if (window.originalCompositeResourcesData) {
                renderCompositeResources(container, window.originalCompositeResourcesData);
            }
        }, 300);

        searchInput.addEventListener('input', handleSearch);
        searchInput.hasEventListener = true;
    }

    if (statusFilter && !statusFilter.hasEventListener) {
        statusFilter.addEventListener('change', () => {
            // Update URL params
            const url = new URL(window.location);
            if (statusFilter.value) {
                url.searchParams.set('status', statusFilter.value);
            } else {
                url.searchParams.delete('status');
            }
            window.history.replaceState({}, '', url);

            // Re-render with current filters
            if (window.originalCompositeResourcesData) {
                renderCompositeResources(container, window.originalCompositeResourcesData);
            }
        });
        statusFilter.hasEventListener = true;
    }

    // Start polling for changes if not already started
    if (!eventsPollingInterval) {
        eventsPollingInterval = setInterval(pollForChanges, 30000); // Poll every 30 seconds
    }

    container.innerHTML = ''; // Clear container before rendering
    filteredData.forEach(resource => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4'
        });

        // Header content
        const status = resource.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';
        const creationTime = resource.metadata?.creationTimestamp ? 
            formatTimeAgo(resource.metadata.creationTimestamp) : 'Unknown';

        // Create the header section
        const headerHTML = `
            <div class="px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700">
                <div class="flex items-center min-w-0">
                    <div class="min-w-0">
                        <h3 class="text-sm font-medium truncate ${isReady ? 'text-gray-900 dark:text-white' : 'text-red-600 dark:text-red-400'} cursor-pointer hover:underline" onclick="switchTab('managed-resources', { search: '${resource.metadata?.name || ''}', providerconfig: '${resource.providerconfig || ''}' }); event.stopPropagation();">
                            ${resource.metadata?.name || 'Unnamed'}
                        </h3>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                            ${resource.kind || 'Unknown'} • ${resource.apiVersion || ''} • Created: ${creationTime}
                        </p>
                    </div>
                    <div class="flex items-center">
                        <button class="toggle-content-btn p-1 text-gray-400 hover:text-gray-500" title="Toggle Details">
                            <svg class="h-4 w-4 transform transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isSynced ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                    }">
                        ${isSynced ? 'Synced' : 'Not Synced'}
                    </span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isReady ? 'Ready' : 'Not Ready'}
                    </span>
                </div>
            </div>`;

        // Details container section
        const detailsContainerHTML = `
            <div class="graph-content hidden">
                <div class="px-6 py-4">
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Relations Graph</h3>
                        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4" style="height: 800px;">
                            <div id="relations-graph-${resource.metadata?.name}" style="width: 100%; height: 100%;"></div>
                        </div>
                    </div>             
                </div>
            </div>`;

        // Combine sections
        card.innerHTML = headerHTML + detailsContainerHTML;

        // Add event listeners
        const toggleBtn = card.querySelector('.toggle-content-btn');
        const graphContent = card.querySelector('.graph-content');
        const toggleIcon = toggleBtn.querySelector('svg');
        let chart = null;

        toggleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isExpanded = !graphContent.classList.contains('hidden');
            if (!isExpanded) {
                graphContent.classList.remove('hidden');
                toggleIcon.classList.add('rotate-180');
                
                // Initialize graph
                const graphContainer = document.getElementById(`relations-graph-${resource.metadata?.name}`);
                if (graphContainer && !chart) {
                    setTimeout(() => {
                        chart = renderCompositeResourceGraph(resource, `relations-graph-${resource.metadata?.name}`);
                        if (chart) {
                            chart.resize();
                        }
                    }, 100);
                }
            } else {
                graphContent.classList.add('hidden');
                toggleIcon.classList.remove('rotate-180');
                if (chart) {
                    chart.dispose();
                    chart = null;
                }
            }
        });

        container.appendChild(card);

        // Add initial event
        const eventsContainer = document.getElementById(`resource-events-${resource.metadata?.name}`);
        if (eventsContainer) {
            const event = {
                type: 'Normal',
                reason: 'ComposeResources',
                message: 'Successfully composed resources',
                time: new Date(),
                resource: resource
            };
            renderEvents(eventsContainer, [event]);
        }
    });
}

// Initialize search from URL params
function initializeFilters() {
    const searchParams = new URLSearchParams(window.location.search);
    const searchInput = document.getElementById('composite-resources-search');
    const statusFilter = document.getElementById('composite-resources-status-filter');
    
    if (searchInput && searchParams.has('search')) {
        searchInput.value = searchParams.get('search');
    }
    if (statusFilter && searchParams.has('status')) {
        statusFilter.value = searchParams.get('status');
    }
}

// Cleanup when switching tabs
function cleanup() {
    if (eventsPollingInterval) {
        clearInterval(eventsPollingInterval);
        eventsPollingInterval = null;
    }
    clearCache();
}

// Clear cache
function clearCache() {
    resourceCache.clear();
}

// Export functions
window.renderCompositeResources = renderCompositeResources;
window.renderCompositeResourceGraph = renderCompositeResourceGraph;
window.cleanup = cleanup;
window.initializeFilters = initializeFilters;
window.renderEvents = renderEvents;

// Initialize filters when document is ready
document.addEventListener('DOMContentLoaded', initializeFilters);
