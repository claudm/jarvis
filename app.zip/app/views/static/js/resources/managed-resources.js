// managed-resources.js - Managed Resources functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

// Cache DOM elements and event handlers
const domCache = {
    searchInput: null,
    statusFilter: null,
    providerConfigFilter: null,
    container: null,
    tabsContainer: null,
    contentContainer: null
};

// Memoize health status classes
const healthStatusClasses = {
    'Healthy': 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
    'Unhealthy': 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200',
    'Unknown': 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
};

function getHealthStatusClass(status) {
    return healthStatusClasses[status] || healthStatusClasses['Unknown'];
}

// Memoize resource details
const resourceDetailsCache = new Map();

function renderManagedResourceDetails(resource) {
    const cacheKey = `${resource.metadata?.name}-${resource.metadata?.resourceVersion}`;
    if (resourceDetailsCache.has(cacheKey)) {
        return resourceDetailsCache.get(cacheKey);
    }

    const status = resource.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
    
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';
    const healthyTime = healthyCondition.lastTransitionTime ? 
        formatTimeAgo(healthyCondition.lastTransitionTime) : '';

    const details = `
        <div class="space-y-4">
            <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Provider</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.provider || resource.display_provider || 'Unknown'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(resource.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Status</h3>
                <div class="space-y-2">
                    <div class="flex items-center space-x-2">
                        <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                            ${resource._health_status || 'Unknown'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500 dark:text-gray-400">${readyTime}</span>` : ''}
                        ${readyCondition.message ? `<span class="text-sm text-gray-500 dark:text-gray-400">${readyCondition.message}</span>` : ''}
                    </div>
                </div>
            </div>

            ${conditions.length > 0 ? `
                <div>
                    <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Conditions</h3>
                    <div class="space-y-2">
                        ${conditions.map(condition => `
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-2">
                                    <span class="text-sm font-medium text-gray-900 dark:text-white">${condition.type}</span>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                        condition.status === 'True' ? healthStatusClasses['Healthy'] :
                                        condition.status === 'False' ? healthStatusClasses['Unhealthy'] :
                                        healthStatusClasses['Unknown']
                                    }">
                                        ${condition.status}
                                    </span>
                                </div>
                                ${condition.lastTransitionTime ? `
                                    <span class="text-xs text-gray-500 dark:text-gray-400">
                                        ${formatTimeAgo(condition.lastTransitionTime)}
                                    </span>
                                ` : ''}
                            </div>
                            ${condition.message ? `
                                <p class="text-sm text-gray-500 dark:text-gray-400 ml-4">
                                    ${condition.message}
                                </p>
                            ` : ''}
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;

    resourceDetailsCache.set(cacheKey, details);
    return details;
}

// Memoize filtered data
let filteredDataCache = null;
let lastFilters = null;

function filterData(data, filters) {
    const filterKey = JSON.stringify(filters);
    if (filteredDataCache && lastFilters === filterKey) {
        return filteredDataCache;
    }

    const filteredData = {
        resources: {},
        health_summary: { healthy: 0, unhealthy: 0, unknown: 0 },
        total_count: 0
    };

    const resourceGroups = data.resources || {};
    Object.entries(resourceGroups).forEach(([kind, group]) => {
        const filteredResources = (group.resources || []).filter(resource => {
            if (filters.status && resource._health_status?.toLowerCase() !== filters.status.toLowerCase()) {
                return false;
            }

            if (filters.search) {
                const searchFields = [
                    resource.metadata?.name,
                    resource.kind,
                    resource.apiVersion,
                    resource.provider,
                    resource.display_provider,
                    resource.providerconfig
                ].filter(Boolean).map(field => field.toLowerCase());
                
                if (!searchFields.some(field => field.includes(filters.search))) {
                    return false;
                }
            }

            if (filters.providerconfig && resource.providerconfig !== filters.providerconfig) {
                return false;
            }

            const status = (resource._health_status || 'Unknown').toLowerCase();
            filteredData.health_summary[status === 'healthy' ? 'healthy' : 
                                    status === 'unhealthy' ? 'unhealthy' : 
                                    'unknown']++;
            return true;
        });

        if (filteredResources.length > 0) {
            filteredData.resources[kind] = {
                resources: filteredResources,
                count: filteredResources.length
            };
            filteredData.total_count += filteredResources.length;
        }
    });

    filteredDataCache = filteredData;
    lastFilters = filterKey;
    return filteredData;
}

function renderManagedResources(container, data) {
    if (!data) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No managed resources found</div>';
        return;
    }

    // Store original data
    window.originalResourceData = data;

    // Initialize DOM cache
    if (!domCache.container) {
        domCache.container = container;
        domCache.searchInput = document.getElementById('resource-search');
        domCache.statusFilter = document.getElementById('status-filter');
        domCache.providerConfigFilter = document.getElementById('providerconfig-filter');

        // Create static containers
        domCache.tabsContainer = document.createElement('div');
        domCache.tabsContainer.className = 'border-b border-gray-200';
        domCache.tabsList = document.createElement('nav');
        domCache.tabsList.className = 'flex -mb-px';
        domCache.tabsContainer.appendChild(domCache.tabsList);

        domCache.contentContainer = document.createElement('div');
        domCache.contentContainer.className = 'mt-4';

        container.appendChild(domCache.tabsContainer);
        container.appendChild(domCache.contentContainer);

        // Set up event listeners once
        if (domCache.searchInput) {
            domCache.searchInput.addEventListener('input', _.debounce(() => reapplyFilters(), 300));
        }
        if (domCache.statusFilter) {
            domCache.statusFilter.addEventListener('change', reapplyFilters);
        }
        if (domCache.providerConfigFilter) {
            domCache.providerConfigFilter.addEventListener('change', reapplyFilters);
        }
    }

    // Get current filters
    const filters = {
        status: domCache.statusFilter?.value || '',
        search: domCache.searchInput?.value?.toLowerCase() || '',
        providerconfig: domCache.providerConfigFilter?.value || ''
    };

    // Filter data
    const filteredData = filterData(data, filters);

    // Update summary counts
    updateSummaryCounts(filteredData);

    // Clear existing content
    domCache.tabsList.innerHTML = '';
    domCache.contentContainer.innerHTML = '';

    if (!filteredData.resources || Object.keys(filteredData.resources).length === 0) {
        domCache.contentContainer.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        return;
    }

    // Render tabs and content
    let isFirstTab = true;
    const fragment = document.createDocumentFragment();
    Object.entries(filteredData.resources).forEach(([kind, groupData]) => {
        // Create tab
        const tab = document.createElement('button');
        tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
            isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
        }`;
        tab.setAttribute('data-tab', kind);
        tab.innerHTML = `
            <span>${kind}</span>
            <span class="ml-2 text-sm text-gray-400">(${groupData.count || 0})</span>
        `;

        // Create content panel
        const contentPanel = document.createElement('div');
        contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
        contentPanel.setAttribute('data-tab-content', kind);

        // Create table structure
        const table = document.createElement('div');
        table.className = 'divide-y divide-gray-200 dark:divide-gray-700';
        table.innerHTML = `
            <div class="grid grid-cols-4 gap-4 px-6 py-3 bg-gray-50 dark:bg-gray-800 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                <div>NAME</div>
                <div>PROVIDER</div>
                <div>STATUS</div>
                <div class="text-right">ACTIONS</div>
            </div>
        `;

        // Add rows
        const rowsFragment = document.createDocumentFragment();
        groupData.resources.forEach(resource => {
            const row = document.createElement('div');
            row.className = 'resource-row';
            row.innerHTML = `
                <div class="grid grid-cols-4 gap-4 px-6 py-4 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                    <div class="text-sm font-medium text-gray-900 dark:text-white">
                        ${resource.metadata?.name || 'Unnamed'}
                        <div class="text-xs text-gray-500 dark:text-gray-400">${resource.apiVersion || ''}</div>
                    </div>
                    <div class="text-sm text-gray-500 dark:text-gray-400">
                        ${resource.provider || resource.display_provider || 'Unknown'}
                        <div class="text-xs">${resource.providerconfig || ''}</div>
                    </div>
                    <div>
                        <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                            ${resource._health_status || 'Unknown'}
                        </span>
                    </div>
                    <div class="text-sm text-gray-500 dark:text-gray-400 text-right">
                        <button class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1 rounded-full yaml-view-btn"
                                type="button"
                                data-resource='${JSON.stringify(resource).replace(/'/g, "&apos;")}'>
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="managed-resource-details col-span-4 bg-gray-50 dark:bg-gray-700 px-6 py-4" style="display: none;">
                    ${renderManagedResourceDetails(resource)}
                </div>
            `;

            // Add event listeners
            const yamlBtn = row.querySelector('.yaml-view-btn');
            yamlBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                showYAMLInMonaco(JSON.parse(e.currentTarget.dataset.resource));
            });

            row.addEventListener('click', (e) => {
                if (e.target.closest('.yaml-view-btn')) return;
                const details = row.querySelector('.managed-resource-details');
                if (details) {
                    const isExpanded = details.style.display !== 'none';
                    details.style.display = isExpanded ? 'none' : 'block';
                }
            });

            rowsFragment.appendChild(row);
        });

        table.appendChild(rowsFragment);
        contentPanel.appendChild(table);

        // Add tab click handler
        tab.addEventListener('click', () => {
            document.querySelectorAll('[data-tab]').forEach(t => {
                t.className = 'group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 text-gray-500 border-b-2 border-transparent';
            });
            tab.className = 'group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 text-blue-600 border-b-2 border-blue-600';

            document.querySelectorAll('[data-tab-content]').forEach(p => p.classList.add('hidden'));
            contentPanel.classList.remove('hidden');
        });

        domCache.tabsList.appendChild(tab);
        fragment.appendChild(contentPanel);
        isFirstTab = false;
    });

    domCache.contentContainer.appendChild(fragment);

    // Update URL params
    const url = new URL(window.location);
    Object.entries(filters).forEach(([key, value]) => {
        if (value) {
            url.searchParams.set(key, value);
        } else {
            url.searchParams.delete(key);
        }
    });
    window.history.replaceState({}, '', url);
}

function updateSummaryCounts(data) {
    const elements = {
        total: document.getElementById('total-resources-count'),
        healthy: document.getElementById('healthy-resources-count'),
        unhealthy: document.getElementById('unhealthy-resources-count'),
        unknown: document.getElementById('unknown-resources-count')
    };

    const summary = data?.health_summary || { healthy: 0, unhealthy: 0, unknown: 0 };
    const total = data?.total_count || 0;

    if (elements.total) elements.total.textContent = total;
    if (elements.healthy) elements.healthy.textContent = summary.healthy || '0';
    if (elements.unhealthy) elements.unhealthy.textContent = summary.unhealthy || '0';
    if (elements.unknown) elements.unknown.textContent = summary.unknown || '0';

    return { ...summary, total };
}

function reapplyFilters() {
    if (window.originalResourceData) {
        renderManagedResources(domCache.container, window.originalResourceData);
    }
}

function setStatusFilter(status) {
    if (domCache.statusFilter) {
        domCache.statusFilter.value = status;
        domCache.statusFilter.dispatchEvent(new Event('change'));
    }
}

// Export functions
window.renderManagedResources = renderManagedResources;
window.setStatusFilter = setStatusFilter;
