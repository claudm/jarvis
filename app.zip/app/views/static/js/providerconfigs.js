function renderProviderConfigs(listElement, data) {
    const configs = data?.items || [];
    
    if (!configs || configs.length === 0) {
        listElement.innerHTML = '<div class="p-4 text-center text-gray-500">No provider configurations found</div>';
        return;
    }

    const table = document.createElement('table');
    table.className = 'min-w-full divide-y divide-gray-200 dark:divide-gray-700';
    table.innerHTML = `
        <thead class="bg-gray-50 dark:bg-gray-800">
            <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Provider</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        </tbody>
    `;

    const tbody = table.querySelector('tbody');
    configs.forEach(config => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer';
        tr.onclick = () => {
            const providerConfigName = config.metadata.name;
            switchTab('managed-resources', {
                providerconfig: providerConfigName,
                search: providerConfigName
            });
        };

        const resourceData = btoa(JSON.stringify(config));
        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                ${config.metadata.name}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">${config.metadata.name.split('-')[0]}</td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                    Active
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <button 
                    class="text-gray-400 hover:text-gray-500"
                    data-resource="${resourceData}"
                    onclick="event.stopPropagation(); showDetailsInMonaco(JSON.parse(atob(this.dataset.resource)))"
                    title="View YAML">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    listElement.appendChild(table);
}

// Export function
window.renderProviderConfigs = renderProviderConfigs;
