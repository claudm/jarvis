// tabs.js - Tab switching functionality
function switchTab(tabId, params = {}) {
    console.log('Switching to tab:', tabId);
    
    // Clean up previous tab
    const previousTab = document.querySelector('[data-tab].active');
    if (previousTab && previousTab.dataset.tab === 'composite-resources') {
        if (typeof cleanup === 'function') {
            cleanup();
        }
    }
    
    // Update active tab
    document.querySelectorAll('[data-tab]').forEach(tab => {
        const isActive = tab.dataset.tab === tabId;
        tab.classList.toggle('active', isActive);
        tab.classList.toggle('text-blue-600', isActive);
        tab.classList.toggle('bg-blue-50', isActive);
        tab.classList.toggle('text-gray-600', !isActive);
    });

    // Hide all panels first
    document.querySelectorAll('.tab-panel').forEach(panel => {
        panel.classList.add('hidden');
        panel.style.display = 'none';
    });

    // Show the selected panel
    const selectedPanel = document.getElementById(`${tabId}-panel`);
    if (selectedPanel) {
        selectedPanel.classList.remove('hidden');
        selectedPanel.style.display = 'block';

        // For managed resources, ensure the list container exists in the correct location
        if (tabId === 'managed-resources') {
            const listContainer = document.getElementById('managed-resources-list');
            if (!listContainer) {
                // Find the content div where the list should go
                const contentDiv = document.getElementById('managed-resources-content');
                if (contentDiv) {
                    const container = document.createElement('div');
                    container.id = 'managed-resources-list';
                    container.className = 'space-y-4';
                    contentDiv.appendChild(container);
                }
            }
        }
        // For other tabs, ensure their list containers exist
        else if (tabId !== 'overview') {
            const listContainer = document.getElementById(`${tabId}-list`);
            if (!listContainer) {
                const container = document.createElement('div');
                container.id = `${tabId}-list`;
                container.className = 'space-y-4';
                selectedPanel.appendChild(container);
            }
        }
    } else {
        console.debug(`Panel not found for tab: ${tabId}`);
    }

    // Update header text
    const sectionTitle = {
        'overview': 'Overview',
        'compositions': 'Compositions',
        'claims': 'Claims',
        'composite-resources': 'Composite Resources',
        'managed-resources': 'Managed Resources',
        'providers': 'Providers',
        'providerconfigs': 'Provider Configurations',
        'composite-resource-definitions': 'Composite Resource Definitions'
    }[tabId];
    
    const headerElement = document.getElementById('current-section');
    if (headerElement) {
        headerElement.textContent = sectionTitle;
    }

    // Show/hide namespace selector based on tab
    const namespaceContainer = document.getElementById('namespace-container');
    if (namespaceContainer) {
        namespaceContainer.classList.toggle('hidden', tabId !== 'claims');
    }

    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('tab', tabId);
    Object.entries(params).forEach(([key, value]) => {
        if (value) {
            url.searchParams.set(key, value);
        } else {
            url.searchParams.delete(key);
        }
    });
    window.history.pushState({}, '', url);

    // Apply filters from URL
    const searchParams = new URLSearchParams(window.location.search);
    if (searchParams.has('status')) {
        const statusFilter = document.getElementById('status-filter');
        if (statusFilter) {
            statusFilter.value = searchParams.get('status');
        }
    }
    if (searchParams.has('search')) {
        const searchInput = document.getElementById('resource-search');
        if (searchInput) {
            searchInput.value = searchParams.get('search');
        }
    }
    if (searchParams.has('providerconfig')) {
        const providerConfigFilter = document.getElementById('providerconfig-filter');
        if (providerConfigFilter) {
            providerConfigFilter.value = searchParams.get('providerconfig');
        }
    }

    // Load data for the tab
    loadTabData(tabId);
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    // Initialize navigation
    const navLinks = [
        { id: 'overview', text: 'Overview' },
        { id: 'providers', text: 'Providers' },
        { id: 'providerconfigs', text: 'Provider Configs' },
        { id: 'compositions', text: 'Compositions' },
        { id: 'composite-resource-definitions', text: 'XRDs' },
        { id: 'claims', text: 'Claims' },
        { id: 'managed-resources', text: 'Managed Resources' },
        { id: 'composite-resources', text: 'Composite Resources' }
    ];

    const nav = document.createElement('nav');
    nav.className = 'flex space-x-4 mb-4';
    navLinks.forEach(link => {
        const a = document.createElement('a');
        a.href = '#';
        a.dataset.tab = link.id;
        a.className = 'tab-button px-3 py-2 rounded-md text-sm font-medium';
        a.textContent = link.text;
        nav.appendChild(a);
    });

    const content = document.querySelector('#content');
    if (content) {
        content.insertBefore(nav, content.firstChild);
    }

    // Initialize navigation links
    document.querySelectorAll('[data-tab]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = link.dataset.tab;
            
            // Update active state
            document.querySelectorAll('[data-tab]').forEach(el => {
                el.classList.remove('text-blue-600', 'bg-blue-50');
                el.classList.add('text-gray-600', 'hover:bg-gray-50', 'hover:text-gray-900');
            });
            link.classList.remove('text-gray-600', 'hover:bg-gray-50', 'hover:text-gray-900');
            link.classList.add('text-blue-600', 'bg-blue-50');
            
            switchTab(tabId);
        });
    });

    // Load initial tab from URL or default to overview
    const searchParams = new URLSearchParams(window.location.search);
    const initialTab = searchParams.get('tab') || 'overview';
    const params = {
        status: searchParams.get('status'),
        search: searchParams.get('search'),
        providerconfig: searchParams.get('providerconfig')
    };
    switchTab(initialTab, params);

    // Handle browser back/forward
    window.addEventListener('popstate', () => {
        const searchParams = new URLSearchParams(window.location.search);
        const tabId = searchParams.get('tab') || 'overview';
        const params = {
            status: searchParams.get('status'),
            search: searchParams.get('search'),
            providerconfig: searchParams.get('providerconfig')
        };
        switchTab(tabId, params);
    });
});

// Export functions
window.switchTab = switchTab;
