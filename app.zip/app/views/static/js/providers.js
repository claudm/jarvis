// providers.js - Providers functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function showProviderYAML(providerJson) {
    try {
        const provider = typeof providerJson === 'string' ? JSON.parse(providerJson) : providerJson;
        
        // Set metadata fields in modal if they exist
        const metadataFields = {
            'yaml-resource-name': provider.metadata?.name || '',
            'yaml-resource-kind': provider.kind || '',
            'yaml-resource-group': provider.apiVersion?.split('/')[0] || '',
            'yaml-resource-version': provider.apiVersion?.split('/')[1] || '',
            'yaml-resource-namespace': provider.metadata?.namespace || 'default'
        };

        Object.entries(metadataFields).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });
        
        // Format YAML content
        const yamlContent = {
            apiVersion: provider.apiVersion,
            kind: provider.kind,
            metadata: {
                name: provider.metadata?.name,
                namespace: provider.metadata?.namespace,
                creationTimestamp: provider.metadata?.creationTimestamp,
                generation: provider.metadata?.generation,
                resourceVersion: provider.metadata?.resourceVersion,
                uid: provider.metadata?.uid,
                finalizers: provider.metadata?.finalizers || [],
                labels: provider.metadata?.labels || {}
            },
            spec: provider.spec || {},
            status: provider.status || {}
        };
        
        // Show in Monaco editor
        showYAMLInMonaco(yamlContent);
    } catch (error) {
        console.error('Error showing provider YAML:', error);
        showError('Failed to display provider YAML');
    }
}

function renderProviders(container, providers) {
    if (!providers.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-400">No providers found</div>';
        return;
    }

    const table = document.createElement('table');
    table.className = 'min-w-full divide-y divide-gray-200 dark:divide-gray-700';
    table.innerHTML = `
        <thead class="bg-gray-50 dark:bg-gray-800">
            <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Provider</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        </tbody>
    `;

    const tbody = table.querySelector('tbody');
    providers.forEach(provider => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer';
        tr.onclick = () => {
            const providerName = provider.metadata?.name;
            switchTab('managed-resources', {
                provider: providerName,
                search: providerName
            });
        };
        
        const resourceData = JSON.stringify(provider);
        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                ${provider.metadata?.name || 'Unnamed'}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                ${provider.spec?.package || 'Unknown'}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                    Active
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <button 
                    class="text-gray-400 hover:text-gray-500"
                    onclick="event.stopPropagation(); showProviderYAML(this.dataset.provider)"
                    data-provider='${resourceData}'
                    title="View YAML">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    container.innerHTML = ''; // Clear container before rendering
    container.appendChild(table);
}

function renderCRDsList(crds, container) {
    if (!crds || crds.length === 0) {
        container.innerHTML = '<div class="text-sm text-gray-400">No CRDs found for this provider</div>';
        return;
    }

    const crdsList = crds.map(crd => `
        <div class="bg-[#1e2124] p-3">
            <div class="flex items-center justify-between">
                <div>
                    <h4 class="text-sm text-gray-300">${crd.kind}</h4>
                    <p class="text-xs text-gray-400">
                        Group: ${crd.group} | Versions: ${crd.versions.join(', ')}
                    </p>
                </div>
                <span class="text-xs text-gray-400">
                    ${crd.scope}
                </span>
            </div>
            ${crd.description ? `
                <p class="mt-2 text-sm text-gray-400">
                    ${crd.description}
                </p>
            ` : ''}
        </div>
    `).join('');

    container.innerHTML = crdsList;
}

async function loadProviderCRDs(providerName) {
    const container = document.getElementById(`crds-${providerName}`);
    if (!container) return;

    try {
        const [crds, status] = await Promise.all([
            fetchProviderCRDs(providerName),
            fetchProviderCRDsStatus(providerName)
        ]);

        if (status) {
            container.innerHTML = `
                <div class="mb-3">
                    <div class="flex items-center space-x-4">
                        <div class="flex-1">
                            <div class="flex items-center space-x-2">
                                <span class="text-sm text-gray-300">
                                    Total CRDs: ${status.total_crds}
                                </span>
                                <span class="text-sm text-gray-400">|</span>
                                <span class="text-sm text-emerald-500">
                                    Established: ${status.established_crds}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            renderCRDsList(crds, container);
        } else {
            renderCRDsList(crds, container);
        }
    } catch (error) {
        console.error('Error loading provider CRDs:', error);
        container.innerHTML = `
            <div class="text-sm text-red-400">
                Failed to load CRDs: ${error.message}
            </div>
        `;
    }
}

// Export functions
window.renderProviders = renderProviders;
window.loadProviderCRDs = loadProviderCRDs;
window.showProviderYAML = showProviderYAML;
