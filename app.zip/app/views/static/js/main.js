// main.js
document.addEventListener('DOMContentLoaded', () => {
    loadInitialData();
});

// Carrega os dados iniciais (por padrão, carrega o overview)
function loadInitialData() {
    // Encontra a tab ativa ou usa 'overview' como padrão
    const activeTab = document.querySelector('.tab-button.active');
    const tabId = activeTab ? activeTab.dataset.tab : 'overview';
    
    // Carrega os dados para a tab ativa
    loadTabData(tabId);
}
