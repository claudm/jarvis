// sidebar.js - Handle sidebar toggle functionality

document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggle-sidebar');
    const sidebar = document.querySelector('.flex-shrink-0.w-64');
    const mainContent = document.querySelector('.flex-1');
    
    // Add transition classes
    sidebar.classList.add('transition-all', 'duration-300', 'ease-in-out');
    mainContent.classList.add('transition-all', 'duration-300', 'ease-in-out');

    let isOpen = true;
    let sidebarWidth = 0;

    // Use ResizeObserver to track sidebar width changes
    const resizeObserver = new ResizeObserver(entries => {
        for (const entry of entries) {
            sidebarWidth = entry.contentRect.width;
        }
    });
    resizeObserver.observe(sidebar);

    toggleButton.addEventListener('click', () => {
        isOpen = !isOpen;
        
        if (!isOpen) {
            sidebar.style.marginLeft = `-${sidebarWidth}px`;
            toggleButton.innerHTML = `
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h7"/>
                </svg>
            `;
        } else {
            sidebar.style.marginLeft = '0';
            toggleButton.innerHTML = `
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16M9 4l-5 8 5 8"/>
                </svg>
            `;
        }
    });
});
