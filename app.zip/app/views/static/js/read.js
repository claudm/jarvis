// YAML reader functionality
class YAMLReader {
    constructor() {
        this.currentContent = null;
    }

    // Display YAML content in a read-only format
    displayYAML(yamlContent) {
        this.currentContent = yamlContent;
        
        // Create or get container
        let container = document.getElementById('yaml-reader-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'yaml-reader-container';
            container.className = 'yaml-reader';
            document.body.appendChild(container);
        }

        // Create read-only display
        const display = document.createElement('pre');
        display.className = 'yaml-content';
        display.textContent = yamlContent;
        
        // Clear and update container
        container.innerHTML = '';
        container.appendChild(display);
    }

    // Load YAML from string
    loadFromString(yamlString) {
        try {
            // Use jsyaml to parse and validate YAML
            const parsed = jsyaml.load(yamlString);
            // Convert back to string for consistent formatting
            const formatted = jsyaml.dump(parsed, {
                indent: 2,
                lineWidth: -1
            });
            this.displayYAML(formatted);
            return true;
        } catch (error) {
            console.error('Error parsing YAML:', error);
            return false;
        }
    }

    // Load YAML from file
    async loadFromFile(file) {
        try {
            const content = await file.text();
            return this.loadFromString(content);
        } catch (error) {
            console.error('Error reading file:', error);
            return false;
        }
    }

    // Get current content
    getCurrentContent() {
        return this.currentContent;
    }
}

// Create global instance
const yamlReader = new YAMLReader();

// Add styles
const style = document.createElement('style');
style.textContent = `
    .yaml-reader {
        background: #1e1e1e;
        border-radius: 4px;
        padding: 16px;
        margin: 10px;
        max-height: 80vh;
        overflow: auto;
    }

    .yaml-content {
        font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
        font-size: 14px;
        line-height: 1.5;
        color: #d4d4d4;
        white-space: pre;
        margin: 0;
    }
`;
document.head.appendChild(style);

// Export for module usage
export { yamlReader, YAMLReader };
