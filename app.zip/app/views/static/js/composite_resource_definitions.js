// composite_resource_definitions.js - Composite Resource Definition functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderCompositeResourceDefinitionDetails(definition) {
    const status = definition.status || {};
    const conditions = status.conditions || [];
    const establishedCondition = conditions.find(c => c.type === 'Established') || {};
    const offeredCondition = conditions.find(c => c.type === 'Offered') || {};
    
    const establishedTime = establishedCondition.lastTransitionTime ? 
        formatTimeAgo(establishedCondition.lastTransitionTime) : '';

    const schema = definition.spec?.versions?.[0]?.schema?.openAPIV3Schema || {};
    const parameters = schema.properties?.spec?.properties?.parameters || {};

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Group</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.group || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.versions?.[0]?.name || 'v1'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(definition.metadata?.creationTimestamp)}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Delete Policy</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.defaultCompositeDeletePolicy || 'Background'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Update Policy</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.defaultCompositionUpdatePolicy || 'Automatic'}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Names</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Resource Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.names?.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Resource Plural</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.names?.plural || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Claim Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.claimNames?.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Claim Plural</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${definition.spec?.claimNames?.plural || ''}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-4">
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                establishedCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                            }">
                                ${establishedCondition.status === 'True' ? 'Established' : 'Not Established'}
                            </span>
                            ${establishedTime ? `<span class="text-xs text-gray-500">${establishedTime}</span>` : ''}
                        </div>
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                offeredCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                            }">
                                ${offeredCondition.status === 'True' ? 'Offered' : 'Not Offered'}
                            </span>
                        </div>
                    </div>
                    ${establishedCondition.reason ? `
                        <div class="text-sm text-gray-600">
                            <span class="font-medium">Established:</span> ${establishedCondition.reason}
                        </div>
                    ` : ''}
                    ${offeredCondition.reason ? `
                        <div class="text-sm text-gray-600">
                            <span class="font-medium">Offered:</span> ${offeredCondition.reason}
                        </div>
                    ` : ''}
                </div>
            </div>

            ${parameters.properties ? `
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Parameters</h3>
                    <div class="space-y-4">
                        ${Object.entries(parameters.properties).map(([name, prop]) => `
                            <div class="border-l-4 border-blue-500 pl-4">
                                <dt class="text-sm font-medium text-gray-900">${name}</dt>
                                <dd class="mt-1 text-sm text-gray-500">
                                    ${prop.description || 'No description'}
                                    <span class="ml-2 text-xs text-gray-400">(${prop.type})</span>
                                    ${parameters.required?.includes(name) ? 
                                        '<span class="ml-2 text-xs text-red-500">Required</span>' : 
                                        ''}
                                </dd>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            ${status.controllers ? `
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Controllers</h3>
                    <div class="space-y-4">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Composite Resource Type</dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                ${status.controllers.compositeResourceType?.kind || ''} 
                                (${status.controllers.compositeResourceType?.apiVersion || ''})
                            </dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Composite Resource Claim Type</dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                ${status.controllers.compositeResourceClaimType?.kind || ''} 
                                (${status.controllers.compositeResourceClaimType?.apiVersion || ''})
                            </dd>
                        </div>
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function renderCompositeResourceDefinitions(container, data) {
    const definitions = data.items || [];
    if (!definitions.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No Composite Resource Definitions found</div>';
        return;
    }

    definitions.forEach(definition => {
        const card = createCompositeResourceDefinitionCard(definition);
        container.appendChild(card);
    });
}

function createCompositeResourceDefinitionCard(definition) {
    const card = createElement('div', {
        className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
    });

    // Get metadata
    const name = definition.metadata?.name || 'Unknown';
    const kind = definition.spec?.names?.kind || 'Unknown Kind';
    const group = definition.spec?.group || '';
    const version = definition.spec?.versions?.[0]?.name || 'v1';
    const scope = definition.spec?.scope || 'Unknown Scope';
    const claimNames = definition.spec?.claimNames || {};
    const categories = definition.spec?.names?.categories || [];
    const creationTime = definition.metadata?.creationTimestamp ? 
        formatTimeAgo(definition.metadata.creationTimestamp) : 'Unknown';

    // Get status
    const status = definition.status || {};
    const conditions = status.conditions || [];
    const establishedCondition = conditions.find(c => c.type === 'Established') || {};
    const offeredCondition = conditions.find(c => c.type === 'Offered') || {};
    const isEstablished = establishedCondition.status === 'True';
    const isOffered = offeredCondition.status === 'True';

    let isExpanded = false;
    const expandedContent = renderCompositeResourceDefinitionDetails(definition);
    
    // Add click handler to the entire card
    card.addEventListener('click', () => {
        isExpanded = !isExpanded;
        const contentSection = card.querySelector('.composite-resource-definition-details');
        if (isExpanded) {
            contentSection.style.display = 'block';
            card.classList.add('expanded');
        } else {
            contentSection.style.display = 'none';
            card.classList.remove('expanded');
        }
    });

    card.innerHTML = `
        <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700 sm:px-6">
            <div class="flex items-center justify-between">
                <div class="flex-grow">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                        ${kind}
                        <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${group}/${version}</span>
                    </h3>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        Name: ${name} | Created: ${creationTime}
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                            Established
                        </span>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                            Offered
                        </span>
                    </div>
                    <button onclick="event.stopPropagation(); showYAMLInMonaco(${JSON.stringify(definition).replace(/"/g, '&quot;')})" 
                            class="p-1 text-gray-400 hover:text-gray-500"
                            title="View YAML">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        <div class="composite-resource-definition-details" style="display: none;">
            ${expandedContent}
        </div>`;

    return card;
}

// Export functions
window.renderCompositeResourceDefinitions = renderCompositeResourceDefinitions;
