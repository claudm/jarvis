from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required
from models.auth import User, db

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user, remember=True)
            if user.is_admin:
                return redirect(url_for('admin.index'))
            return redirect(url_for('dashboard'))
            
        flash('Invalid username or password')
    
    return render_template('login.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

def init_users():
    """Create default admin and regular users if they don't exist"""
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            email='admin@example.com',
            is_admin=True
        )
        admin.set_password('admin123')
        db.session.add(admin)
    
    if not User.query.filter_by(username='user').first():
        user = User(
            username='user',
            email='user@example.com',
            is_admin=False
        )
        user.set_password('user123')
        db.session.add(user)
    
    db.session.commit()
