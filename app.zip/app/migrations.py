from flask import Flask
from models.auth import db, User
from models.cluster import Cluster
import sqlite3

import os

def migrate():
    # Create instance directory if it doesn't exist
    os.makedirs('instance', exist_ok=True)
    
    # Connect to the database
    conn = sqlite3.connect('instance/app.db')
    cursor = conn.cursor()
    
    # Get existing data if possible
    clusters_data = []
    try:
        cursor.execute('SELECT id, owner_id FROM clusters')
        clusters_data = cursor.fetchall()
    except sqlite3.OperationalError:
        # Table doesn't exist yet, that's fine
        pass
    
    # Drop existing tables if they exist
    cursor.execute('DROP TABLE IF EXISTS user_clusters')
    cursor.execute('DROP TABLE IF EXISTS clusters')
    cursor.execute('DROP TABLE IF EXISTS users')
    
    # Create app context for SQLAlchemy
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/app.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    
    with app.app_context():
        # Create new tables
        db.create_all()
        
        # Create admin user
        admin = User(username='admin', email='admin@example.com', is_admin=True)
        admin.set_password('admin123')
        db.session.add(admin)
        
        # Create regular user
        user = User(username='user', email='user@example.com', is_admin=False)
        user.set_password('user123')
        db.session.add(user)
        
        db.session.commit()
        
        # Restore clusters with authorized users
        for cluster_id, user_id in clusters_data:
            cluster = Cluster.query.get(cluster_id)
            if cluster:
                cluster.authorized_user_ids = [user_id]
                db.session.add(cluster)
        
        db.session.commit()

if __name__ == '__main__':
    migrate()
