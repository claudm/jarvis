from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class CompositionManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def list_compositions(self) -> List[dict]:
        """Lista todas as compositions do Crossplane incluindo formato Upbound"""
        try:
            if not self._ensure_connection():
                return []

            response = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions"
            )
            compositions = response.get("items", [])

            # Process compositions to handle both standard and Upbound formats
            processed_compositions = []
            for comp in compositions:
                processed_comp = self._process_composition(comp)
                if processed_comp:
                    processed_compositions.append(processed_comp)

            return processed_compositions
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Compositions CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing compositions: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing compositions: {e}")
            return []

    def _process_composition(self, composition: dict) -> Optional[dict]:
        """Process composition to handle both standard and Upbound formats"""
        try:
            # Check if it's an Upbound format composition
            metadata = composition.get('metadata', {})
            annotations = metadata.get('annotations', {})
            labels = metadata.get('labels', {})

            is_upbound = (
                'meta.upbound.io/configuration' in annotations or
                'upbound.io/configuration' in labels or
                any(key.startswith('upbound.io/') for key in labels.keys())
            )

            # Get provider config reference from resources
            spec = composition.get('spec', {})
            resources = spec.get('resources', [])
            provider_configs = set()
            
            # Check each resource for provider config
            for resource in resources:
                base = resource.get('base', {})
                provider_config_ref = base.get('spec', {}).get('providerConfigRef', {})
                if provider_config_ref and provider_config_ref.get('name'):
                    try:
                        provider_config = self.custom_api.get_cluster_custom_object(
                            group=base.get('apiVersion', '').split('/')[0],
                            version=base.get('apiVersion', '').split('/')[1],
                            plural="providerconfigs",
                            name=provider_config_ref['name']
                        )
                        provider_configs.add(provider_config_ref['name'])
                    except:
                        provider_configs.add(provider_config_ref['name'])

            # Add provider configs to composition
            if provider_configs:
                composition['providerConfigs'] = list(provider_configs)

            if is_upbound:
                # Add Upbound-specific information
                composition['upbound'] = {
                    'configuration': labels.get('upbound.io/configuration') or annotations.get('meta.upbound.io/configuration'),
                    'version': labels.get('upbound.io/version'),
                    'source': 'upbound-format'
                }

                # Process Upbound-specific fields if they exist
                spec = composition.get('spec', {})
                if 'patchSets' in spec:
                    # Handle Upbound patch sets format
                    patch_sets = spec['patchSets']
                    if isinstance(patch_sets, list):
                        for patch_set in patch_sets:
                            if 'patches' in patch_set:
                                # Convert Upbound patch format to standard if needed
                                patches = patch_set['patches']
                                for patch in patches:
                                    if 'type' not in patch and 'fromFieldPath' in patch:
                                        patch['type'] = 'FromCompositeFieldPath'

            return composition
        except Exception as e:
            logger.error(f"Error processing composition {composition.get('metadata', {}).get('name')}: {e}")
            return None

    def get_composition(self, name: str) -> Optional[dict]:
        """Retorna uma composition específica por nome"""
        try:
            composition = self.get_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=name
            )
            if composition:
                return self._process_composition(composition)
            return None
        except Exception as e:
            logger.error(f"Error getting composition {name}: {e}")
            return None

    def get_xrd(self, name: str) -> Optional[dict]:
        """Retorna um XRD específico por nome"""
        try:
            xrd = self.get_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions",
                name=name
            )
            if xrd:
                # Process XRD to handle Upbound format
                metadata = xrd.get('metadata', {})
                annotations = metadata.get('annotations', {})
                labels = metadata.get('labels', {})

                is_upbound = (
                    'meta.upbound.io/configuration' in annotations or
                    'upbound.io/configuration' in labels
                )

                if is_upbound:
                    xrd['upbound'] = {
                        'configuration': labels.get('upbound.io/configuration') or annotations.get('meta.upbound.io/configuration'),
                        'version': labels.get('upbound.io/version'),
                        'source': 'upbound-format'
                    }

                # Get provider config reference
                provider_config_ref = xrd.get('spec', {}).get('providerConfigRef', {})
                if provider_config_ref and provider_config_ref.get('name'):
                    try:
                        provider_config = self.custom_api.get_cluster_custom_object(
                            group=provider_config_ref.get('apiVersion', '').split('/')[0],
                            version=provider_config_ref.get('apiVersion', '').split('/')[1],
                            plural="providerconfigs",
                            name=provider_config_ref['name']
                        )
                        xrd['providerConfig'] = {
                            'name': provider_config['metadata']['name'],
                            'ready': True
                        }
                    except:
                        xrd['providerConfig'] = {
                            'name': provider_config_ref['name'],
                            'ready': False
                        }

            return xrd
        except Exception as e:
            logger.error(f"Error getting XRD {name}: {e}")
            return None

    def list_composite_resource_definitions(self) -> List[dict]:
        """Lista todas as Composite Resource Definitions"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            response = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions"
            )
            xrds = response.get("items", [])

            # Process XRDs to handle Upbound format
            processed_xrds = []
            for xrd in xrds:
                metadata = xrd.get('metadata', {})
                annotations = metadata.get('annotations', {})
                labels = metadata.get('labels', {})

                is_upbound = (
                    'meta.upbound.io/configuration' in annotations or
                    'upbound.io/configuration' in labels
                )

                if is_upbound:
                    xrd['upbound'] = {
                        'configuration': labels.get('upbound.io/configuration') or annotations.get('meta.upbound.io/configuration'),
                        'version': labels.get('upbound.io/version'),
                        'source': 'upbound-format'
                    }

                # Get provider config reference
                provider_config_ref = xrd.get('spec', {}).get('providerConfigRef', {})
                if provider_config_ref and provider_config_ref.get('name'):
                    try:
                        provider_config = self.custom_api.get_cluster_custom_object(
                            group=provider_config_ref.get('apiVersion', '').split('/')[0],
                            version=provider_config_ref.get('apiVersion', '').split('/')[1],
                            plural="providerconfigs",
                            name=provider_config_ref['name']
                        )
                        xrd['providerConfig'] = {
                            'name': provider_config['metadata']['name'],
                            'ready': True
                        }
                    except:
                        xrd['providerConfig'] = {
                            'name': provider_config_ref['name'],
                            'ready': False
                        }

                processed_xrds.append(xrd)

            return processed_xrds
        except Exception as e:
            logger.error(f"Error listing Composite Resource Definitions: {e}")
            return []
