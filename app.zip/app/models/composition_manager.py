from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager
from .resource_manager import ResourceManager

logger = logging.getLogger(__name__)

class CompositionManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.resource_manager = ResourceManager()
        self.namespace = self.get_current_namespace()

    async def list_compositions(self) -> List[dict]:
        """Lista todas as compositions do Crossplane"""
        try:
            if not await self._ensure_connection():
                return []

            response = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions"
            )
            return response.get("items", [])
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Compositions CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing compositions: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing compositions: {e}")
            return []

    async def get_composition(self, name: str) -> Optional[dict]:
        """Retorna uma composition específica por nome"""
        return await self.resource_manager.get_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=name
        )

    async def get_xrd(self, name: str) -> Optional[dict]:
        """Retorna um XRD específico por nome"""
        return await self.resource_manager.get_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositeresourcedefinitions",
            name=name
        )

    async def list_composite_resource_definitions(self) -> List[dict]:
        """Lista todas as Composite Resource Definitions"""
        try:
            if not await self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            response = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions"
            )
            return response.get("items", [])
        except Exception as e:
            logger.error(f"Error listing Composite Resource Definitions: {e}")
            return []
