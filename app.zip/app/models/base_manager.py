import kubernetes
from kubernetes import client, config
import logging
import time

logger = logging.getLogger(__name__)

class BaseManager:
    def __init__(self):
        self.api_client = None
        self.custom_api = None
        self.core_api = None
        self.apps_api = None
        self.api_version = None
        self.kind = None
        self.plural = None
        self.group = None

    def configure(self, api_server, api_token):
        # Initialize with retry
        max_retries = 5
        retry_delay = 2
        last_error = None

        for attempt in range(max_retries):
            try:
                configuration = kubernetes.client.Configuration()
                configuration.api_key = {"authorization": f"Bearer {api_token}"}
                configuration.host = api_server
                configuration.verify_ssl = False
                configuration.timeout = 60  # Increase the timeout to 60 seconds
                
                client.Configuration.set_default(configuration)
                self.api_client = client.ApiClient()
                self.core_v1_api = client.CoreV1Api(self.api_client)
                self.custom_api = client.CustomObjectsApi(self.api_client)
                self.api_ext = client.ApiextensionsV1Api(self.api_client)
                self._closed = False
                logger.info("Using kubectl API token configuration")
                return
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    logger.warning(f"Attempt {attempt + 1} failed, retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                continue
        
        if last_error:
            logger.error(f"Failed to configure kubernetes client after {max_retries} attempts: {str(last_error)}")
            raise last_error

    def list_resources(self, namespace=None):
        try:
            if namespace:
                response = self.custom_api.list_namespaced_custom_object(
                    group=self.group,
                    version=self.api_version,
                    namespace=namespace,
                    plural=self.plural
                )
            else:
                response = self.custom_api.list_cluster_custom_object(
                    group=self.group,
                    version=self.api_version,
                    plural=self.plural
                )
            return response.get('items', [])
        except Exception as e:
            logger.error(f"Error listing resources: {str(e)}")
            return []

    def get_resource(self, name, namespace=None):
        try:
            if namespace:
                return self.custom_api.get_namespaced_custom_object(
                    group=self.group,
                    version=self.api_version,
                    namespace=namespace,
                    plural=self.plural,
                    name=name
                )
            else:
                return self.custom_api.get_cluster_custom_object(
                    group=self.group,
                    version=self.api_version,
                    plural=self.plural,
                    name=name
                )
        except kubernetes.client.rest.ApiException as e:
            if e.status == 404:
                return None
            raise

    def create_resource(self, body, namespace=None):
        try:
            if namespace:
                return self.custom_api.create_namespaced_custom_object(
                    group=self.group,
                    version=self.api_version,
                    namespace=namespace,
                    plural=self.plural,
                    body=body
                )
            else:
                return self.custom_api.create_cluster_custom_object(
                    group=self.group,
                    version=self.api_version,
                    plural=self.plural,
                    body=body
                )
        except Exception as e:
            logger.error(f"Error creating resource: {str(e)}")
            raise

    def update_resource(self, name, body, namespace=None):
        try:
            if namespace:
                return self.custom_api.replace_namespaced_custom_object(
                    group=self.group,
                    version=self.api_version,
                    namespace=namespace,
                    plural=self.plural,
                    name=name,
                    body=body
                )
            else:
                return self.custom_api.replace_cluster_custom_object(
                    group=self.group,
                    version=self.api_version,
                    plural=self.plural,
                    name=name,
                    body=body
                )
        except Exception as e:
            logger.error(f"Error updating resource: {str(e)}")
            raise

    def delete_resource(self, name, namespace=None):
        try:
            if namespace:
                return self.custom_api.delete_namespaced_custom_object(
                    group=self.group,
                    version=self.api_version,
                    namespace=namespace,
                    plural=self.plural,
                    name=name
                )
            else:
                return self.custom_api.delete_cluster_custom_object(
                    group=self.group,
                    version=self.api_version,
                    plural=self.plural,
                    name=name
                )
        except Exception as e:
            logger.error(f"Error deleting resource: {str(e)}")
            raise

    def list_compositions(self, namespace=None):
        """List all compositions in the cluster or in a specific namespace."""
        try:
            if namespace:
                response = self.custom_api.list_namespaced_custom_object(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    namespace=namespace,
                    plural="compositions"
                )
            else:
                response = self.custom_api.list_cluster_custom_object(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    plural="compositions"
                )
            return response.get('items', [])
        except Exception as e:
            logger.error(f"Error listing compositions: {str(e)}")
            return []

    def get_resource_counts(self):
        """Get counts of various resources."""
        try:
            compositions = self.list_compositions()
            return {
                'compositions': len(compositions),
                # Add other resource counts as needed
            }
        except Exception as e:
            logger.error(f"Error getting resource counts: {str(e)}")
            return {}
