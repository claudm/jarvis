from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class ResourceManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    async def get_crossplane_crds(self) -> List[dict]:
        """Get Crossplane CRDs"""
        try:
            if not await self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            crd_list = await self.api_ext.list_custom_resource_definition()
            
            if not crd_list or not hasattr(crd_list, 'items'):
                logger.warning("No CRDs found in the cluster")
                return []

            crossplane_crds = []
            for crd in crd_list.items:
                if not hasattr(crd, 'spec') or not hasattr(crd.spec, 'group'):
                    continue

                categories = getattr(crd.spec.names, 'categories', []) or []
                is_crossplane = (
                    'crossplane.io' in crd.spec.group or
                    any(cat in ['crossplane', 'managed', 'claim', 'composite']
                        for cat in categories)
                )

                if is_crossplane:
                    crossplane_crds.append({
                        'name': crd.metadata.name,
                        'kind': crd.spec.names.kind,
                        'group': crd.spec.group,
                        'version': crd.spec.versions[0].name if crd.spec.versions else '',
                        'scope': crd.spec.scope,
                        'categories': list(getattr(crd.spec.names, 'categories', []) or [])
                    })

            return crossplane_crds

        except Exception as e:
            logger.error(f"Error getting Crossplane CRDs: {e}")
            return []

    async def get_managed_resources(self) -> List[dict]:
        """Lista todos os recursos gerenciados com status de saúde e descrição"""
        try:
            if not await self._ensure_connection():
                return []

            resources = []
            crds = await self.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'managed' in categories:
                    try:
                        # Check if resource is namespaced
                        try:
                            crd_obj = await self.api_ext.read_custom_resource_definition(f"{crd['name']}")
                            is_namespaced = crd_obj.spec.scope == "Namespaced"
                        except Exception as e:
                            logger.debug(f"Error checking CRD scope: {e}")
                            is_namespaced = False

                        if is_namespaced:
                            logger.debug(f"Listing namespaced resources for {crd['kind']} in namespace {self.namespace}")
                            response = await self.custom_api.list_namespaced_custom_object(
                                group=crd['group'],
                                version=crd['version'],
                                namespace=self.namespace,
                                plural=crd['name'].split('.')[0].lower()
                            )
                        else:
                            logger.debug(f"Listing cluster-scoped resources for {crd['kind']}")
                            response = await self.custom_api.list_cluster_custom_object(
                                group=crd['group'],
                                version=crd['version'],
                                plural=crd['name'].split('.')[0].lower()
                            )
                        for item in response.get("items", []):
                            # Get conditions
                            conditions = item.get('status', {}).get('conditions', [])
                            health_status = 'Unknown'
                            synced_status = 'Unknown'
                            
                            for condition in conditions:
                                condition_type = condition.get('type')
                                if condition_type == 'Ready':
                                    health_status = 'Healthy' if condition.get('status') == 'True' else 'Unhealthy'
                                elif condition_type == 'Synced':
                                    synced_status = 'Synced' if condition.get('status') == 'True' else 'Not Synced'

                            # Extract provider from group dynamically
                            group = crd['group']
                            provider = None
                            display_provider = None  # For UI display
                            
                            # Handle different provider group patterns
                            if group.startswith('provider-'):
                                provider = group.split('.')[0]  # Just take provider-aws part
                                display_provider = provider.replace('provider-', '')
                            elif group.endswith('.crossplane.io'):
                                base = group.replace('.crossplane.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"  # provider-aws for filtering
                                    display_provider = base  # s3.aws for display
                                else:
                                    provider = f"provider-{base}"  # provider-aws for filtering
                                    display_provider = base  # aws for display
                            elif '.' in group:
                                parts = group.split('.')
                                if len(parts) >= 2:
                                    provider = f"provider-{parts[1]}"  # provider-aws for filtering
                                    display_provider = f"{parts[0]}.{parts[1]}"  # s3.aws for display

                            # Get providerconfig reference
                            spec = item.get('spec', {})
                            providerconfig_ref = None
                            if 'providerConfigRef' in spec:
                                providerconfig_ref = spec['providerConfigRef'].get('name')
                            elif 'providerRef' in spec:
                                providerconfig_ref = spec['providerRef'].get('name')

                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }
                            item['_health_status'] = health_status
                            item['_synced_status'] = synced_status
                            item['provider'] = provider  # For filtering (e.g. provider-aws)
                            item['display_provider'] = display_provider or provider  # For UI display (e.g. s3.aws)
                            item['providerconfig'] = providerconfig_ref  # Add providerconfig reference
                            resources.append(item)
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing managed resources for {crd['kind']}: {e}")
                    
            return resources
        except Exception as e:
            logger.error(f"Error listing managed resources: {e}")
            return []

    async def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        """Retorna um recurso específico do Kubernetes"""
        try:
            if not await self._ensure_connection():
                return None

            # Use ServiceAccount namespace if none provided and resource is namespaced
            try:
                crd = await self.api_ext.read_custom_resource_definition(f"{plural}.{group}")
                if crd.spec.scope == "Namespaced":
                    namespace = namespace or self.namespace
            except Exception as e:
                logger.debug(f"Error checking CRD scope: {e}")

            if namespace:
                logger.debug(f"Getting namespaced resource {name} in namespace {namespace}")
                return await self.custom_api.get_namespaced_custom_object(
                    group=group,
                    version=version,
                    namespace=namespace,
                    plural=plural,
                    name=name
                )
            else:
                logger.debug(f"Getting cluster-scoped resource {name}")
                return await self.custom_api.get_cluster_custom_object(
                    group=group,
                    version=version,
                    plural=plural,
                    name=name
                )
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Resource {name} not found")
            else:
                logger.error(f"Error getting resource: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting resource: {e}")
            return None
