from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class ClaimManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def _get_events(self, names: List[str], namespace: str = None) -> Dict[str, List[dict]]:
        """Batch get events for multiple resources"""
        events = {}
        try:
            if not self._ensure_connection():
                return events

            core_v1 = client.CoreV1Api(self.api_client)
            field_selector = 'involvedObject.name in (' + ','.join(names) + ')'
            all_events = core_v1.list_namespaced_event(namespace=namespace, field_selector=field_selector)
            
            # Group events by resource name
            for event in all_events.items:
                name = event.involved_object.name
                if name not in events:
                    events[name] = []
                events[name].append({
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'timestamp': event.last_timestamp.isoformat() if event.last_timestamp else None,
                    'count': event.count
                })
        except Exception as e:
            logger.error(f"Error getting events: {e}")
        return events

    def get_claim_events(self, name: str, namespace: str = None) -> List[dict]:
        """Get events for a specific claim"""
        events = self._get_events([name], namespace)
        return events.get(name, [])

    def _get_provider_configs(self, refs: List[Dict]) -> Dict[str, Dict]:
        """Batch get provider configs"""
        provider_configs = {}
        for ref in refs:
            if not ref or not ref.get('name'):
                continue
            try:
                provider_config = self.custom_api.get_cluster_custom_object(
                    group=ref.get('apiVersion', '').split('/')[0],
                    version=ref.get('apiVersion', '').split('/')[1],
                    plural="providerconfigs",
                    name=ref['name']
                )
                conditions = provider_config.get('status', {}).get('conditions', [])
                ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
                provider_configs[ref['name']] = {
                    'name': provider_config['metadata']['name'],
                    'ready': ready_condition.get('status') == 'True'
                }
            except:
                provider_configs[ref['name']] = {
                    'name': ref['name'],
                    'ready': False
                }
        return provider_configs

    def _get_compositions(self, refs: List[Dict]) -> Dict[str, Dict]:
        """Batch get compositions"""
        compositions = {}
        for ref in refs:
            if not ref or not ref.get('name'):
                continue
            try:
                composition = self.custom_api.get_cluster_custom_object(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    plural="compositions",
                    name=ref['name']
                )
                compositions[ref['name']] = {
                    'name': composition['metadata']['name'],
                    'ready': True,
                    'providerConfigRef': composition.get('spec', {}).get('providerConfigRef', {})
                }
            except:
                compositions[ref['name']] = {
                    'name': ref['name'],
                    'ready': False
                }
        return compositions

    def _get_composite_resources(self, refs: List[Dict]) -> Dict[str, Dict]:
        """Batch get composite resources"""
        resources = {}
        for ref in refs:
            if not ref or not ref.get('name'):
                continue
            try:
                composite = self.custom_api.get_cluster_custom_object(
                    group=ref.get('apiVersion', '').split('/')[0],
                    version=ref.get('apiVersion', '').split('/')[1],
                    plural=ref['kind'].lower() + 's',
                    name=ref['name']
                )
                conditions = composite.get('status', {}).get('conditions', [])
                ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
                resources[ref['name']] = {
                    'name': composite['metadata']['name'],
                    'ready': ready_condition.get('status') == 'True'
                }
            except:
                resources[ref['name']] = {
                    'name': ref['name'],
                    'ready': False
                }
        return resources

    def list_claims(self, namespace: str = None) -> List[dict]:
        """Lista todas as claims em um namespace específico com dados relacionados"""
        try:
            if not self._ensure_connection():
                return []

            # Use ServiceAccount namespace if none provided
            namespace = namespace or self.namespace
            logger.debug(f"Listing claims in namespace {namespace}")

            claims = []
            crds = self.get_crossplane_crds()
            
            # Collect all claims first
            all_claims = []
            provider_config_refs = []
            composition_refs = []
            composite_refs = []
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'claim' in categories:
                    try:
                        response = self.custom_api.list_namespaced_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            namespace=namespace,
                            plural=crd['name'].split('.')[0].lower()
                        )
                        for item in response.get("items", []):
                            all_claims.append(item)
                            # Collect refs for batch lookup
                            provider_ref = item.get('spec', {}).get('providerConfigRef', {})
                            if provider_ref and provider_ref.get('name'):
                                provider_config_refs.append(provider_ref)
                            comp_ref = item.get('spec', {}).get('compositionRef', {})
                            if comp_ref and comp_ref.get('name'):
                                composition_refs.append(comp_ref)
                            res_ref = item.get('spec', {}).get('resourceRef', {})
                            if res_ref and res_ref.get('name'):
                                composite_refs.append(res_ref)
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing claims for {crd['kind']}: {e}")

            # Batch get resources
            provider_configs = self._get_provider_configs(provider_config_refs)
            compositions = self._get_compositions(composition_refs)
            composite_resources = self._get_composite_resources(composite_refs)

            # Process claims with batched data
            for item in all_claims:
                # Add resource type info and check for Upbound format
                metadata = item.get('metadata', {})
                annotations = metadata.get('annotations', {})
                labels = metadata.get('labels', {})

                item['_resource_type'] = {
                    'kind': crd['kind'],
                    'group': crd['group'],
                    'version': crd['version']
                }

                # Add Upbound info if present
                if ('meta.upbound.io/configuration' in annotations or
                    'upbound.io/configuration' in labels or
                    any(key.startswith('upbound.io/') for key in labels.keys())):
                    item['upbound'] = {
                        'configuration': (
                            labels.get('upbound.io/configuration') or 
                            annotations.get('meta.upbound.io/configuration')
                        ),
                        'version': labels.get('upbound.io/version'),
                        'source': 'upbound-format'
                    }

                # Get provider config from cache
                provider_config_ref = item.get('spec', {}).get('providerConfigRef', {})
                if provider_config_ref and provider_config_ref.get('name'):
                    item['providerConfig'] = provider_configs.get(provider_config_ref['name'])

                # Get composition from cache
                composition_ref = item.get('spec', {}).get('compositionRef', {})
                if composition_ref and composition_ref.get('name'):
                    composition = compositions.get(composition_ref['name'])
                    if composition:
                        item['composition'] = {
                            'name': composition['name'],
                            'ready': composition['ready']
                        }

                        # Get provider config from composition if not directly specified
                        if not item.get('providerConfig') and composition['providerConfigRef']:
                            provider_config = provider_configs.get(composition['providerConfigRef']['name'])
                            if provider_config:
                                item['providerConfig'] = {
                                    **provider_config,
                                    'from': 'composition'
                                }

                # Get composite resource from cache
                composite_ref = item.get('spec', {}).get('resourceRef', {})
                if composite_ref and composite_ref.get('name'):
                    composite = composite_resources.get(composite_ref['name'])
                    if composite:
                        item['compositeResource'] = composite

                # Collect names for batch event lookup
                event_names = [item['metadata']['name']]
                if item.get('compositeResource', {}).get('name'):
                    event_names.append(item['compositeResource']['name'])

                # Get events in batch
                events = self._get_events(event_names, namespace)
                
                # Combine and sort events
                all_events = []
                all_events.extend(events.get(item['metadata']['name'], []))
                if item.get('compositeResource', {}).get('name'):
                    all_events.extend(events.get(item['compositeResource']['name'], []))
                
                all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
                item['events'] = all_events[:10]
                claims.append(item)
                    
            return claims
        except Exception as e:
            logger.error(f"Error listing claims: {e}")
            return []

    def get_claim(self, name: str, namespace: str = None) -> Optional[dict]:
        """Get a specific claim by name"""
        try:
            if not self._ensure_connection():
                return None

            # Use ServiceAccount namespace if none provided
            namespace = namespace or self.namespace
            logger.debug(f"Getting claim {name} in namespace {namespace}")

            crds = self.get_crossplane_crds()
            
            # Collect refs for batch lookup
            provider_config_refs = []
            composition_refs = []
            composite_refs = []
            found_claim = None
            found_crd = None

            # Find the claim and collect refs
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'claim' in categories:
                    try:
                        claim = self.custom_api.get_namespaced_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            namespace=namespace,
                            plural=crd['name'].split('.')[0].lower(),
                            name=name
                        )
                        found_claim = claim
                        found_crd = crd

                        # Collect refs for batch lookup
                        provider_ref = claim.get('spec', {}).get('providerConfigRef', {})
                        if provider_ref and provider_ref.get('name'):
                            provider_config_refs.append(provider_ref)
                        comp_ref = claim.get('spec', {}).get('compositionRef', {})
                        if comp_ref and comp_ref.get('name'):
                            composition_refs.append(comp_ref)
                        res_ref = claim.get('spec', {}).get('resourceRef', {})
                        if res_ref and res_ref.get('name'):
                            composite_refs.append(res_ref)
                        break
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error getting claim {name} from {crd['kind']}: {e}")

            if not found_claim:
                return None

            # Batch get resources
            provider_configs = self._get_provider_configs(provider_config_refs)
            compositions = self._get_compositions(composition_refs)
            composite_resources = self._get_composite_resources(composite_refs)

            # Process claim with batched data
            claim = found_claim
            crd = found_crd

            # Add resource type info
            metadata = claim.get('metadata', {})
            annotations = metadata.get('annotations', {})
            labels = metadata.get('labels', {})

            claim['_resource_type'] = {
                'kind': crd['kind'],
                'group': crd['group'],
                'version': crd['version']
            }

            # Add Upbound info if present
            if ('meta.upbound.io/configuration' in annotations or
                'upbound.io/configuration' in labels or
                any(key.startswith('upbound.io/') for key in labels.keys())):
                claim['upbound'] = {
                    'configuration': (
                        labels.get('upbound.io/configuration') or 
                        annotations.get('meta.upbound.io/configuration')
                    ),
                    'version': labels.get('upbound.io/version'),
                    'source': 'upbound-format'
                }

            # Get provider config from cache
            provider_config_ref = claim.get('spec', {}).get('providerConfigRef', {})
            if provider_config_ref and provider_config_ref.get('name'):
                claim['providerConfig'] = provider_configs.get(provider_config_ref['name'])

            # Get composition from cache
            composition_ref = claim.get('spec', {}).get('compositionRef', {})
            if composition_ref and composition_ref.get('name'):
                composition = compositions.get(composition_ref['name'])
                if composition:
                    claim['composition'] = {
                        'name': composition['name'],
                        'ready': composition['ready']
                    }

                    # Get provider config from composition if not directly specified
                    if not claim.get('providerConfig') and composition['providerConfigRef']:
                        provider_config = provider_configs.get(composition['providerConfigRef']['name'])
                        if provider_config:
                            claim['providerConfig'] = {
                                **provider_config,
                                'from': 'composition'
                            }

            # Get composite resource from cache
            composite_ref = claim.get('spec', {}).get('resourceRef', {})
            if composite_ref and composite_ref.get('name'):
                composite = composite_resources.get(composite_ref['name'])
                if composite:
                    claim['compositeResource'] = composite

            # Collect names for batch event lookup
            event_names = [name]
            if claim.get('compositeResource', {}).get('name'):
                event_names.append(claim['compositeResource']['name'])

            # Get events in batch
            events = self._get_events(event_names, namespace)
            
            # Combine and sort events
            all_events = []
            all_events.extend(events.get(name, []))
            if claim.get('compositeResource', {}).get('name'):
                all_events.extend(events.get(claim['compositeResource']['name'], []))
            
            all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
            claim['events'] = all_events[:10]

            return claim
        except Exception as e:
            logger.error(f"Error getting claim: {e}")
            return None
