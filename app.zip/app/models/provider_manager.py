from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class ProviderManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def list_providers(self) -> List[dict]:
        """Lista todos os providers instalados no Crossplane"""
        try:
            if not self._ensure_connection():
                logger.error("Failed to list providers: No connection to Kubernetes cluster")
                return []

            logger.info("Attempting to list providers from Kubernetes API")
            response = self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            providers = response.get("items", [])

            # Process each provider to add Upbound info if present
            for provider in providers:
                metadata = provider.get('metadata', {})
                annotations = metadata.get('annotations', {})
                labels = metadata.get('labels', {})

                if ('meta.upbound.io/configuration' in annotations or
                    'upbound.io/configuration' in labels or
                    any(key.startswith('upbound.io/') for key in labels.keys())):
                    provider['upbound'] = {
                        'configuration': (
                            labels.get('upbound.io/configuration') or 
                            annotations.get('meta.upbound.io/configuration')
                        ),
                        'version': labels.get('upbound.io/version'),
                        'source': 'upbound-format'
                    }

            logger.info(f"Retrieved {len(providers)} providers from Kubernetes API")
            logger.debug(f"Provider response: {response}")
            return providers
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Providers CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing providers: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing providers: {e}")
            return []

    def get_provider_status(self, provider_name: str) -> Optional[dict]:
        """Retorna o status de um provider específico"""
        try:
            if not self._ensure_connection():
                return None

            provider = self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            return provider.get("status", {})
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Provider {provider_name} not found")
            else:
                logger.error(f"Error getting provider status: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider status: {e}")
            return None

    def list_provider_configs(self) -> List[dict]:
        """Lista todas as configurações de providers"""
        try:
            if not self._ensure_connection():
                return []

            configs = []
            # Get all provider CRDs
            all_crds = self.get_crossplane_crds()
            logger.info(f"All CRDs: {all_crds}")
            
            provider_crds = [crd for crd in all_crds 
                           if any(g in crd.get('group', '') for g in ['.crossplane.io', '.upbound.io'])
                           and 'providerconfigs' in crd.get('name', '').lower()]

            logger.info(f"Found {len(provider_crds)} provider config CRDs: {provider_crds}")
            for crd in provider_crds:
                try:
                    is_namespaced = self._get_crd_scope(crd['name'])
                    if is_namespaced:
                        logger.info(f"Listing namespaced provider configs for {crd['kind']} in namespace {self.namespace}")
                        response = self.custom_api.list_namespaced_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            namespace=self.namespace,
                            plural=crd['name'].split('.')[0].lower()
                        )
                    else:
                        logger.info(f"Listing cluster-scoped provider configs for {crd['kind']}")
                        response = self.custom_api.list_cluster_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            plural=crd['name'].split('.')[0].lower()
                        )

                    response_data = response
                    logger.info(f"Raw response for {crd['kind']}: {response_data}")
                    items = response.get('items', [])
                    logger.info(f"Found {len(items)} provider configs for {crd['kind']}: {items}")
                    # Process each config to add Upbound info if present
                    for config in items:
                        metadata = config.get('metadata', {})
                        annotations = metadata.get('annotations', {})
                        labels = metadata.get('labels', {})

                        if ('meta.upbound.io/configuration' in annotations or
                            'upbound.io/configuration' in labels or
                            any(key.startswith('upbound.io/') for key in labels.keys())):
                            config['upbound'] = {
                                'configuration': (
                                    labels.get('upbound.io/configuration') or 
                                    annotations.get('meta.upbound.io/configuration')
                                ),
                                'version': labels.get('upbound.io/version'),
                                'source': 'upbound-format'
                            }
                        configs.append(config)

                except Exception as e:
                    logger.debug(f"Error listing provider configs for {crd['kind']}: {e}")

            return configs
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("ProviderConfigs CRD not found")
            else:
                logger.error(f"Error listing provider configs: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing provider configs: {e}")
            return []

    def get_provider_config(self, name: str) -> Optional[dict]:
        """Retorna uma configuração de provider específica"""
        try:
            if not self._ensure_connection():
                return None

            # Get all provider CRDs
            provider_crds = [crd for crd in self.get_crossplane_crds() 
                           if any(g in crd.get('group', '') for g in ['.crossplane.io', '.upbound.io'])
                           and 'providerconfigs' in crd.get('name', '').lower()]

            for crd in provider_crds:
                try:
                    is_namespaced = self._get_crd_scope(crd['name'])
                    if is_namespaced:
                        logger.debug(f"Getting namespaced provider config {name} for {crd['kind']} in namespace {self.namespace}")
                        config = self.custom_api.get_namespaced_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            namespace=self.namespace,
                            plural=crd['name'].split('.')[0].lower(),
                            name=name
                        )
                    else:
                        logger.debug(f"Getting cluster-scoped provider config {name} for {crd['kind']}")
                        config = self.custom_api.get_cluster_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            plural=crd['name'].split('.')[0].lower(),
                            name=name
                        )

                    # Add Upbound info if present
                    metadata = config.get('metadata', {})
                    annotations = metadata.get('annotations', {})
                    labels = metadata.get('labels', {})

                    if ('meta.upbound.io/configuration' in annotations or
                        'upbound.io/configuration' in labels or
                        any(key.startswith('upbound.io/') for key in labels.keys())):
                        config['upbound'] = {
                            'configuration': (
                                labels.get('upbound.io/configuration') or 
                                annotations.get('meta.upbound.io/configuration')
                            ),
                            'version': labels.get('upbound.io/version'),
                            'source': 'upbound-format'
                        }

                    return config
                except client.ApiException as e:
                    if e.status != 404:
                        logger.warning(f"Error getting provider config {name} from {crd['kind']}: {e}")
                except Exception as e:
                    logger.debug(f"Error getting provider config {name} from {crd['kind']}: {e}")

            return None
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"ProviderConfig {name} not found")
            else:
                logger.error(f"Error getting provider config: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider config: {e}")
            return None

    def list_provider_crds(self, provider_name: str) -> List[dict]:
        """List all CRDs installed by a specific provider"""
        try:
            if not self._ensure_connection():
                return []

            # Get provider details first
            provider = self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            if not provider:
                logger.warning(f"Provider {provider_name} not found")
                return []

            # Get all CRDs
            crds = self.get_crossplane_crds()
            if not crds:
                return []

            # Filter CRDs for this provider
            provider_crds = []
            provider_group = provider.get('spec', {}).get('package', '').split('/')[-1]
            if provider_group.startswith('provider-'):
                provider_group = provider_group[9:]  # Remove "provider-" prefix

            crds = self.get_crossplane_crds()
            for crd in crds:
                if provider_group in crd.get('group', ''):
                    provider_crds.append(crd)

            return provider_crds

        except Exception as e:
            logger.error(f"Error listing provider CRDs: {e}")
            return []

    def get_provider_crds_status(self, provider_name: str) -> Dict:
        """Get status of all CRDs for a provider including installation status"""
        try:
            crds = self.list_provider_crds(provider_name)
            
            status = {
                "total_crds": len(crds),
                "established_crds": 0,
                "crds": crds
            }

            # Check CRD conditions using ApiextensionsV1Api
            api_ext = client.ApiextensionsV1Api(self.api_client)
            for crd in crds:
                crd_name = crd.get("name")
                if crd_name:
                    try:
                        crd_obj = api_ext.read_custom_resource_definition(name=crd_name)
                        if crd_obj.status and crd_obj.status.conditions:
                            for condition in crd_obj.status.conditions:
                                if condition.type == "Established" and condition.status == "True":
                                    status["established_crds"] += 1
                                    break
                    except Exception as e:
                        logger.warning(f"Error checking CRD status for {crd_name}: {e}")

            return status

        except Exception as e:
            logger.error(f"Error getting provider CRDs status: {e}")
            return {
                "total_crds": 0,
                "established_crds": 0,
                "crds": [],
                "error": str(e)
            }
