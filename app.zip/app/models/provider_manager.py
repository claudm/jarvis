from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager
from .resource_manager import ResourceManager

logger = logging.getLogger(__name__)

class ProviderManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.resource_manager = ResourceManager()
        self.namespace = self.get_current_namespace()

    async def list_providers(self) -> List[dict]:
        """Lista todos os providers instalados no Crossplane"""
        try:
            if not await self._ensure_connection():
                logger.error("Failed to list providers: No connection to Kubernetes cluster")
                return []

            logger.info("Attempting to list providers from Kubernetes API")
            response = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            providers = response.get("items", [])
            logger.info(f"Retrieved {len(providers)} providers from Kubernetes API")
            logger.debug(f"Provider response: {response}")
            return providers
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Providers CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing providers: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing providers: {e}")
            return []

    async def get_provider_status(self, provider_name: str) -> Optional[dict]:
        """Retorna o status de um provider específico"""
        try:
            if not await self._ensure_connection():
                return None

            provider = await self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            return provider.get("status", {})
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Provider {provider_name} not found")
            else:
                logger.error(f"Error getting provider status: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider status: {e}")
            return None

    async def list_provider_configs(self) -> List[dict]:
        """Lista todas as configurações de providers"""
        try:
            if not await self._ensure_connection():
                return []

            # Check if providerconfigs are namespaced
            try:
                crd = await self.api_ext.read_custom_resource_definition("providerconfigs.aws.crossplane.io")
                is_namespaced = crd.spec.scope == "Namespaced"
            except Exception as e:
                logger.debug(f"Error checking ProviderConfig scope: {e}")
                is_namespaced = False

            if is_namespaced:
                logger.debug(f"Listing namespaced provider configs in namespace {self.namespace}")
                response = await self.custom_api.list_namespaced_custom_object(
                    group="aws.crossplane.io",
                    version="v1beta1",
                    namespace=self.namespace,
                    plural="providerconfigs"
                )
            else:
                logger.debug("Listing cluster-scoped provider configs")
                response = await self.custom_api.list_cluster_custom_object(
                    group="aws.crossplane.io",
                    version="v1beta1",
                    plural="providerconfigs"
                )
            return response.get("items", [])
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("ProviderConfigs CRD not found")
            else:
                logger.error(f"Error listing provider configs: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing provider configs: {e}")
            return []

    async def get_provider_config(self, name: str) -> Optional[dict]:
        """Retorna uma configuração de provider específica"""
        try:
            if not await self._ensure_connection():
                return None

            # Check if providerconfigs are namespaced
            try:
                crd = await self.api_ext.read_custom_resource_definition("providerconfigs.aws.crossplane.io")
                is_namespaced = crd.spec.scope == "Namespaced"
            except Exception as e:
                logger.debug(f"Error checking ProviderConfig scope: {e}")
                is_namespaced = False

            if is_namespaced:
                logger.debug(f"Getting namespaced provider config {name} in namespace {self.namespace}")
                config = await self.custom_api.get_namespaced_custom_object(
                    group="aws.crossplane.io",
                    version="v1beta1",
                    namespace=self.namespace,
                    plural="providerconfigs",
                    name=name
                )
            else:
                logger.debug(f"Getting cluster-scoped provider config {name}")
                config = await self.custom_api.get_cluster_custom_object(
                    group="aws.crossplane.io",
                    version="v1beta1",
                    plural="providerconfigs",
                    name=name
                )
            return config
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"ProviderConfig {name} not found")
            else:
                logger.error(f"Error getting provider config: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider config: {e}")
            return None

    async def list_provider_crds(self, provider_name: str) -> List[dict]:
        """List all CRDs installed by a specific provider"""
        try:
            if not await self._ensure_connection():
                return []

            # Get provider details first
            provider = await self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            if not provider:
                logger.warning(f"Provider {provider_name} not found")
                return []

            # Get all CRDs
            crds = await self.resource_manager.get_crossplane_crds()
            if not crds:
                return []

            # Filter CRDs for this provider
            provider_crds = []
            provider_group = provider.get('spec', {}).get('package', '').split('/')[-1]
            if provider_group.startswith('provider-'):
                provider_group = provider_group[9:]  # Remove "provider-" prefix

            for crd in crds:
                if provider_group in crd.get('group', ''):
                    provider_crds.append(crd)

            return provider_crds

        except Exception as e:
            logger.error(f"Error listing provider CRDs: {e}")
            return []

    async def get_provider_crds_status(self, provider_name: str) -> Dict:
        """Get status of all CRDs for a provider including installation status"""
        try:
            crds = await self.list_provider_crds(provider_name)
            
            status = {
                "total_crds": len(crds),
                "established_crds": 0,
                "crds": crds
            }

            # Check CRD conditions using ApiextensionsV1Api
            api_ext = client.ApiextensionsV1Api(self.api_client)
            for crd in crds:
                crd_name = crd.get("name")
                if crd_name:
                    try:
                        crd_obj = await api_ext.read_custom_resource_definition(name=crd_name)
                        if crd_obj.status and crd_obj.status.conditions:
                            for condition in crd_obj.status.conditions:
                                if condition.type == "Established" and condition.status == "True":
                                    status["established_crds"] += 1
                                    break
                    except Exception as e:
                        logger.warning(f"Error checking CRD status for {crd_name}: {e}")

            return status

        except Exception as e:
            logger.error(f"Error getting provider CRDs status: {e}")
            return {
                "total_crds": 0,
                "established_crds": 0,
                "crds": [],
                "error": str(e)
            }
