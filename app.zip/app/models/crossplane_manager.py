from models.base_manager import BaseManager
import logging

logger = logging.getLogger(__name__)

class CrossplaneManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.api_version = "v1"
        self.group = "apiextensions.crossplane.io"

    def list_composite_resource_definitions(self):
        """List all composite resource definitions."""
        self.plural = "compositeresourcedefinitions"
        return self.list_resources()

    def list_compositions(self):
        """List all compositions."""
        self.plural = "compositions"
        return self.list_resources()

    def list_provider_configs(self):
        """List all provider configs."""
        self.group = "pkg.crossplane.io"
        self.plural = "providerconfigs"
        resources = self.list_resources()
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resources

    def list_providers(self):
        """List all providers."""
        self.group = "pkg.crossplane.io"
        self.plural = "providers"
        resources = self.list_resources()
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resources

    def get_resource_counts(self):
        """Get counts of various Crossplane resources."""
        try:
            xrds = self.list_composite_resource_definitions()
            compositions = self.list_compositions()
            provider_configs = self.list_provider_configs()
            providers = self.list_providers()

            return {
                'composite_resource_definitions': len(xrds),
                'compositions': len(compositions),
                'provider_configs': len(provider_configs),
                'providers': len(providers)
            }
        except Exception as e:
            logger.error(f"Error getting resource counts: {str(e)}")
            return {
                'composite_resource_definitions': 0,
                'compositions': 0,
                'provider_configs': 0,
                'providers': 0
            }

    def get_composite_resource_definition(self, name):
        """Get a specific composite resource definition."""
        self.plural = "compositeresourcedefinitions"
        return self.get_resource(name)

    def get_composition(self, name):
        """Get a specific composition."""
        self.plural = "compositions"
        return self.get_resource(name)

    def get_provider_config(self, name):
        """Get a specific provider config."""
        self.group = "pkg.crossplane.io"
        self.plural = "providerconfigs"
        resource = self.get_resource(name)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def get_provider(self, name):
        """Get a specific provider."""
        self.group = "pkg.crossplane.io"
        self.plural = "providers"
        resource = self.get_resource(name)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def create_composite_resource_definition(self, body):
        """Create a composite resource definition."""
        self.plural = "compositeresourcedefinitions"
        return self.create_resource(body)

    def create_composition(self, body):
        """Create a composition."""
        self.plural = "compositions"
        return self.create_resource(body)

    def create_provider_config(self, body):
        """Create a provider config."""
        self.group = "pkg.crossplane.io"
        self.plural = "providerconfigs"
        resource = self.create_resource(body)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def create_provider(self, body):
        """Create a provider."""
        self.group = "pkg.crossplane.io"
        self.plural = "providers"
        resource = self.create_resource(body)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def update_composite_resource_definition(self, name, body):
        """Update a composite resource definition."""
        self.plural = "compositeresourcedefinitions"
        return self.update_resource(name, body)

    def update_composition(self, name, body):
        """Update a composition."""
        self.plural = "compositions"
        return self.update_resource(name, body)

    def update_provider_config(self, name, body):
        """Update a provider config."""
        self.group = "pkg.crossplane.io"
        self.plural = "providerconfigs"
        resource = self.update_resource(name, body)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def update_provider(self, name, body):
        """Update a provider."""
        self.group = "pkg.crossplane.io"
        self.plural = "providers"
        resource = self.update_resource(name, body)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def delete_composite_resource_definition(self, name):
        """Delete a composite resource definition."""
        self.plural = "compositeresourcedefinitions"
        return self.delete_resource(name)

    def delete_composition(self, name):
        """Delete a composition."""
        self.plural = "compositions"
        return self.delete_resource(name)

    def delete_provider_config(self, name):
        """Delete a provider config."""
        self.group = "pkg.crossplane.io"
        self.plural = "providerconfigs"
        resource = self.delete_resource(name)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource

    def delete_provider(self, name):
        """Delete a provider."""
        self.group = "pkg.crossplane.io"
        self.plural = "providers"
        resource = self.delete_resource(name)
        self.group = "apiextensions.crossplane.io"  # Reset group
        return resource
