from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager
from .provider_manager import ProviderManager
from .resource_manager import ResourceManager
from .claim_manager import ClaimManager
from .composition_manager import CompositionManager
from .composite_manager import CompositeManager
from .template_manager import TemplateManager

logger = logging.getLogger(__name__)

class CrossplaneManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()
        self.provider_manager = ProviderManager()
        self.resource_manager = ResourceManager()
        self.claim_manager = ClaimManager()
        self.composition_manager = CompositionManager()
        self.composite_manager = CompositeManager()
        self.template_manager = TemplateManager()

    async def get_crossplane_status(self) -> Dict:
        """Get Crossplane health status, version, and pod status"""
        try:
            if not await self._ensure_connection():
                return {
                    "health": "Unknown",
                    "version": "Unknown",
                    "pods": []
                }

            # Get Crossplane deployment
            apps_v1 = client.AppsV1Api(self.api_client)
            core_v1 = client.CoreV1Api(self.api_client)

            deployment = await apps_v1.read_namespaced_deployment(
                name="crossplane",
                namespace="crossplane-system"
            )

            # Check health based on deployment status
            health = "Healthy"
            if deployment.status.available_replicas != deployment.status.replicas:
                health = "Unhealthy"

            # Get version from image tag
            version = "Unknown"
            if deployment.spec.template.spec.containers:
                image = deployment.spec.template.spec.containers[0].image
                if ':' in image:
                    version = image.split(':')[1]

            # Get pods in crossplane-system namespace
            pod_list = await core_v1.list_namespaced_pod(namespace="crossplane-system")
            pods = []
            
            for pod in pod_list.items:
                # Get container statuses
                container_statuses = []
                for container in (pod.status.container_statuses or []):
                    status = "Unknown"
                    if container.ready:
                        status = "Running"
                    elif container.state.waiting:
                        status = container.state.waiting.reason
                    elif container.state.terminated:
                        status = container.state.terminated.reason

                    container_statuses.append({
                        "name": container.name,
                        "status": status,
                        "ready": container.ready,
                        "restarts": container.restart_count
                    })

                pods.append({
                    "name": pod.metadata.name,
                    "status": pod.status.phase,
                    "containers": container_statuses,
                    "age": pod.metadata.creation_timestamp.isoformat() if pod.metadata.creation_timestamp else None
                })

            return {
                "health": health,
                "version": version,
                "pods": pods
            }
        except Exception as e:
            logger.error(f"Error getting Crossplane status: {e}")
            return {
                "health": "Unknown",
                "version": "Unknown",
                "pods": []
            }

    # Delegate methods to specific managers
    async def list_providers(self) -> List[dict]:
        return await self.provider_manager.list_providers()

    async def get_provider_status(self, provider_name: str) -> Optional[dict]:
        return await self.provider_manager.get_provider_status(provider_name)

    async def list_provider_configs(self) -> List[dict]:
        """List all provider configurations"""
        try:
            if not await self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []
                
            # First ensure we can list providers
            providers = await self.list_providers()
            if not providers:
                logger.warning("No providers found")
                return []
                
            # Then get configs
            configs = await self.provider_manager.list_provider_configs()
            logger.info(f"Retrieved {len(configs)} provider configurations")
            return configs
            
        except Exception as e:
            logger.error(f"Error listing provider configurations: {e}")
            return []

    async def get_managed_resources(self) -> List[dict]:
        return await self.resource_manager.get_managed_resources()

    async def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        return await self.resource_manager.get_resource(group, version, plural, name, namespace)

    async def list_claims(self, namespace: str = None) -> List[dict]:
        namespace = namespace or self.namespace
        return await self.claim_manager.list_claims(namespace)

    async def get_claim_events(self, name: str, namespace: str = None) -> List[dict]:
        namespace = namespace or self.namespace
        return await self.claim_manager.get_claim_events(name, namespace)

    async def get_claim(self, name: str, namespace: str = None) -> Optional[dict]:
        namespace = namespace or self.namespace
        return await self.claim_manager.get_claim(name, namespace)

    async def list_compositions(self) -> List[dict]:
        return await self.composition_manager.list_compositions()

    async def get_composition(self, name: str) -> Optional[dict]:
        return await self.composition_manager.get_composition(name)

    async def get_xrd(self, name: str) -> Optional[dict]:
        return await self.composition_manager.get_xrd(name)

    async def list_composite_resource_definitions(self) -> List[dict]:
        return await self.composition_manager.list_composite_resource_definitions()

    async def get_composite_resources(self) -> List[dict]:
        return await self.composite_manager.get_composite_resources()

    async def list_templates(self) -> List[dict]:
        return await self.template_manager.list_templates()

    async def get_template_details(self, name: str) -> Optional[dict]:
        return await self.template_manager.get_template_details(name)

    async def get_provider_config(self, name: str) -> Optional[dict]:
        """Get a specific provider configuration"""
        try:
            if not await self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return None

            return await self.provider_manager.get_provider_config(name)
        except Exception as e:
            logger.error(f"Error getting provider config: {e}")
            return None
