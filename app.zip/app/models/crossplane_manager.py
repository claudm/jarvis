from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from .provider_manager import ProviderManager
from .claim_manager import ClaimManager
from .composition_manager import CompositionManager
from .composite_manager import CompositeManager
from .template_manager import TemplateManager
import threading

logger = logging.getLogger(__name__)

class CrossplaneManager(BaseManager):
    _instance = None
    _lock = threading.Lock()

    @classmethod
    def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = cls()
                    instance.initialize_client()
                    instance.initialize_managers()
                    cls._instance = instance
        elif cls._instance._closed:
            with cls._lock:
                cls._instance.initialize_client()
                cls._instance.initialize_managers()
        return cls._instance

    def __init__(self):
        super().__init__()
        self.namespace = None
        self.provider_manager = None
        self.claim_manager = None
        self.composition_manager = None
        self.composite_manager = None
        self.template_manager = None

    def initialize_managers(self):
        """Initialize all managers after client is ready"""
        self.namespace = self.get_current_namespace()
        self.provider_manager = ProviderManager()
        self.claim_manager = ClaimManager()
        self.composition_manager = CompositionManager()
        self.composite_manager = CompositeManager()
        self.template_manager = TemplateManager()

    def get_crossplane_status(self) -> Dict:
        """Get Crossplane health status, version, and pod status"""
        try:
            if not self._ensure_connection():
                return {
                    "health": "Unknown",
                    "version": "Unknown",
                    "pods": []
                }

            # Get Crossplane deployment
            apps_v1 = client.AppsV1Api(self.api_client)
            core_v1 = client.CoreV1Api(self.api_client)

            deployment = apps_v1.read_namespaced_deployment(
                name="crossplane",
                namespace="crossplane-system"
            )

            # Check health based on deployment status
            health = "Healthy"
            if deployment.status.available_replicas != deployment.status.replicas:
                health = "Unhealthy"

            # Get version from image tag
            version = "Unknown"
            if deployment.spec.template.spec.containers:
                image = deployment.spec.template.spec.containers[0].image
                if ':' in image:
                    version = image.split(':')[1]

            # Get pods in crossplane-system namespace
            pod_list = core_v1.list_namespaced_pod(namespace="crossplane-system")
            pods = []
            
            for pod in pod_list.items:
                # Get container statuses
                container_statuses = []
                for container in (pod.status.container_statuses or []):
                    status = "Unknown"
                    if container.ready:
                        status = "Running"
                    elif container.state.waiting:
                        status = container.state.waiting.reason
                    elif container.state.terminated:
                        status = container.state.terminated.reason

                    container_statuses.append({
                        "name": container.name,
                        "status": status,
                        "ready": container.ready,
                        "restarts": container.restart_count
                    })

                pods.append({
                    "name": pod.metadata.name,
                    "status": pod.status.phase,
                    "containers": container_statuses,
                    "age": pod.metadata.creation_timestamp.isoformat() if pod.metadata.creation_timestamp else None
                })

            return {
                "health": health,
                "version": version,
                "pods": pods
            }
        except Exception as e:
            logger.error(f"Error getting Crossplane status: {e}")
            return {
                "health": "Unknown",
                "version": "Unknown",
                "pods": []
            }

    # Delegate methods to specific managers
    def list_providers(self) -> List[dict]:
        return self.provider_manager.list_providers()

    def get_provider_status(self, provider_name: str) -> Optional[dict]:
        return self.provider_manager.get_provider_status(provider_name)

    def list_provider_configs(self) -> List[dict]:
        """List all provider configurations"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []
                
            # First ensure we can list providers
            providers = self.list_providers()
            if not providers:
                logger.warning("No providers found")
                return []
                
            # Then get configs
            configs = self.provider_manager.list_provider_configs()
            logger.info(f"Retrieved {len(configs)} provider configurations")
            return configs
            
        except Exception as e:
            logger.error(f"Error listing provider configurations: {e}")
            return []

    def get_managed_resources(self) -> List[dict]:
        """Get all managed resources"""
        try:
            if not self._ensure_connection():
                return []

            managed_resources = []
            # Get managed resources from CRDs
            managed_crds = [crd for crd in self.get_crossplane_crds() if 'managed' in (crd.get('categories', []) or [])]
            
            for mcrd in managed_crds:
                try:
                    if self._get_crd_scope(mcrd['name']):
                        response = self.custom_api.list_namespaced_custom_object(
                            group=mcrd['group'],
                            version=mcrd['version'],
                            namespace=self.namespace,
                            plural=mcrd['name'].split('.')[0].lower()
                        )
                    else:
                        response = self.custom_api.list_cluster_custom_object(
                            group=mcrd['group'],
                            version=mcrd['version'],
                            plural=mcrd['name'].split('.')[0].lower()
                        )
                    
                    # Process each resource
                    for item in response.get('items', []):
                        conditions = item.get('status', {}).get('conditions', [])
                        # Get Ready condition for health status
                        ready_condition = next(
                            (c for c in conditions if c.get('type') == 'Ready'),
                            {}
                        )
                        health_status = 'Unknown'
                        if ready_condition:
                            if ready_condition.get('status') == 'True':
                                health_status = 'Healthy'
                            elif ready_condition.get('status') == 'False':
                                health_status = 'Unhealthy'

                        # Get Synced condition for sync status
                        synced_condition = next(
                            (c for c in conditions if c.get('type') == 'Synced'),
                            {}
                        )
                        synced_status = 'Unknown'
                        if synced_condition:
                            if synced_condition.get('status') == 'True':
                                synced_status = 'Synced'
                            elif synced_condition.get('status') == 'False':
                                synced_status = 'Not Synced'

                        # Extract provider info
                        group = mcrd['group']
                        provider = None
                        display_provider = None

                        # Handle both standard Crossplane and Upbound formats
                        if group.startswith('provider-'):
                            provider = group.split('.')[0]
                            display_provider = provider.replace('provider-', '')
                        elif group.endswith('.crossplane.io'):
                            base = group.replace('.crossplane.io', '')
                            if '.' in base:
                                provider = f"provider-{base.split('.')[1]}"
                                display_provider = base
                            else:
                                provider = f"provider-{base}"
                                display_provider = base
                        elif group.endswith('.upbound.io'):
                            base = group.replace('.upbound.io', '')
                            if '.' in base:
                                provider = f"provider-{base.split('.')[1]}"
                                display_provider = base
                            else:
                                provider = f"provider-{base}"
                                display_provider = base
                        elif '.' in group:
                            parts = group.split('.')
                            if len(parts) >= 2:
                                provider = f"provider-{parts[1]}"
                                display_provider = f"{parts[0]}.{parts[1]}"

                        # Get Upbound metadata if present
                        metadata = item.get('metadata', {})
                        annotations = metadata.get('annotations', {})
                        labels = metadata.get('labels', {})
                        upbound_info = None

                        if ('meta.upbound.io/configuration' in annotations or
                            'upbound.io/configuration' in labels or
                            any(key.startswith('upbound.io/') for key in labels.keys())):
                            upbound_info = {
                                'configuration': (
                                    labels.get('upbound.io/configuration') or 
                                    annotations.get('meta.upbound.io/configuration')
                                ),
                                'version': labels.get('upbound.io/version'),
                                'source': 'upbound-format'
                            }

                        item.update({
                            '_resource_type': {
                                'kind': mcrd['kind'],
                                'group': mcrd['group'],
                                'version': mcrd['version']
                            },
                            '_health_status': health_status,
                            '_synced_status': synced_status,
                            'provider': provider,
                            'display_provider': display_provider or provider,
                            'providerconfig': (
                                item.get('spec', {}).get('providerConfigRef', {}).get('name') or
                                item.get('spec', {}).get('providerRef', {}).get('name')
                            )
                        })

                        # Add Upbound info if present
                        if upbound_info:
                            item['upbound'] = upbound_info
                        managed_resources.append(item)
                except Exception as e:
                    logger.debug(f"Error listing managed resources for {mcrd['kind']}: {e}")

            return managed_resources
        except Exception as e:
            logger.error(f"Error getting managed resources: {e}")
            return []

    def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        return super().get_resource(group, version, plural, name, namespace)

    def list_claims(self, namespace: str = None) -> List[dict]:
        namespace = namespace or self.namespace
        return self.claim_manager.list_claims(namespace)

    def get_claim_events(self, name: str, namespace: str = None) -> List[dict]:
        namespace = namespace or self.namespace
        return self.claim_manager.get_claim_events(name, namespace)

    def get_claim(self, name: str, namespace: str = None) -> Optional[dict]:
        namespace = namespace or self.namespace
        return self.claim_manager.get_claim(name, namespace)

    def list_compositions(self) -> List[dict]:
        return self.composition_manager.list_compositions()

    def get_composition(self, name: str) -> Optional[dict]:
        return self.composition_manager.get_composition(name)

    def get_xrd(self, name: str) -> Optional[dict]:
        return self.composition_manager.get_xrd(name)

    def list_composite_resource_definitions(self) -> List[dict]:
        return self.composition_manager.list_composite_resource_definitions()

    def get_composite_resources(self) -> List[dict]:
        return self.composite_manager.get_composite_resources()

    def list_templates(self) -> List[dict]:
        return self.template_manager.list_templates()

    def get_template_details(self, name: str) -> Optional[dict]:
        return self.template_manager.get_template_details(name)

    def get_provider_config(self, name: str) -> Optional[dict]:
        """Get a specific provider configuration"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return None

            return self.provider_manager.get_provider_config(name)
        except Exception as e:
            logger.error(f"Error getting provider config: {e}")
            return None
