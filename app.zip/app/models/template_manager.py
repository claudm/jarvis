from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class TemplateManager(BaseManager):
    def __init__(self):
        super().__init__()

    def list_templates(self) -> List[dict]:
        """Lista todos os templates disponíveis"""
        try:
            if not self._ensure_connection():
                return []

            response = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions"
            )
            templates = response.get("items", [])

            # Add relations for each template
            for template in templates:
                # Get composition using this template
                try:
                    composition_name = template.get('metadata', {}).get('ownerReferences', [{}])[0].get('name')
                    if composition_name:
                        composition = self.custom_api.get_cluster_custom_object(
                            group="apiextensions.crossplane.io",
                            version="v1",
                            plural="compositions",
                            name=composition_name
                        )

                        # Check for Upbound format in composition
                        comp_metadata = composition.get('metadata', {})
                        comp_annotations = comp_metadata.get('annotations', {})
                        comp_labels = comp_metadata.get('labels', {})
                        
                        comp_info = {
                            'name': composition['metadata']['name'],
                            'ready': True
                        }

                        if ('meta.upbound.io/configuration' in comp_annotations or
                            'upbound.io/configuration' in comp_labels or
                            any(key.startswith('upbound.io/') for key in comp_labels.keys())):
                            comp_info['upbound'] = {
                                'configuration': (
                                    comp_labels.get('upbound.io/configuration') or 
                                    comp_annotations.get('meta.upbound.io/configuration')
                                ),
                                'version': comp_labels.get('upbound.io/version'),
                                'source': 'upbound-format'
                            }

                        template['composition'] = comp_info
                except:
                    template['composition'] = None

                # Get composite resources using this template's composition
                try:
                    if template.get('composition', {}).get('name'):
                        # Get composite resources from CRDs
                        composite_resources = []
                        composite_crds = [crd for crd in self.get_crossplane_crds() if 'composite' in (crd.get('categories', []) or [])]
                        for ccrd in composite_crds:
                            try:
                                if self._get_crd_scope(ccrd['name']):
                                    response = self.custom_api.list_namespaced_custom_object(
                                        group=ccrd['group'],
                                        version=ccrd['version'],
                                        namespace=self.namespace,
                                        plural=ccrd['name'].split('.')[0].lower()
                                    )
                                else:
                                    response = self.custom_api.list_cluster_custom_object(
                                        group=ccrd['group'],
                                        version=ccrd['version'],
                                        plural=ccrd['name'].split('.')[0].lower()
                                    )
                                composite_resources.extend(response.get('items', []))
                            except Exception as e:
                                logger.debug(f"Error listing composite resources for {ccrd['kind']}: {e}")
                        related_resources = [
                            {
                                'name': resource['metadata']['name'],
                                'ready': resource.get('_health_status') == 'Healthy'
                            }
                            for resource in composite_resources
                            if resource.get('spec', {}).get('compositionRef', {}).get('name') == template['composition']['name']
                        ]
                        template['compositeResources'] = related_resources
                except:
                    template['compositeResources'] = []

                # Get claims using this template's composition
                try:
                    if template.get('composition', {}).get('name'):
                        # Get claims from CRDs
                        claims = []
                        claim_crds = [crd for crd in self.get_crossplane_crds() if 'claim' in (crd.get('categories', []) or [])]
                        for ccrd in claim_crds:
                            try:
                                response = self.custom_api.list_namespaced_custom_object(
                                    group=ccrd['group'],
                                    version=ccrd['version'],
                                    namespace=self.namespace,
                                    plural=ccrd['name'].split('.')[0].lower()
                                )
                                claims.extend(response.get('items', []))
                            except Exception as e:
                                logger.debug(f"Error listing claims for {ccrd['kind']}: {e}")
                        related_claims = [
                            {
                                'name': claim['metadata']['name'],
                                'ready': claim.get('compositeResource', {}).get('ready', False)
                            }
                            for claim in claims
                            if claim.get('spec', {}).get('compositionRef', {}).get('name') == template['composition']['name']
                        ]
                        template['claims'] = related_claims
                except:
                    template['claims'] = []

            return templates
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Templates CRD not found")
            else:
                logger.error(f"Error listing templates: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing templates: {e}")
            return []

    def get_template_details(self, name: str) -> Optional[dict]:
        """Retorna detalhes de um template específico"""
        try:
            if not self._ensure_connection():
                return None

            template = self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions",
                name=name
            )

            # Check for Upbound format
            metadata = template.get('metadata', {})
            annotations = metadata.get('annotations', {})
            labels = metadata.get('labels', {})

            if ('meta.upbound.io/configuration' in annotations or
                'upbound.io/configuration' in labels or
                any(key.startswith('upbound.io/') for key in labels.keys())):
                template['upbound'] = {
                    'configuration': (
                        labels.get('upbound.io/configuration') or 
                        annotations.get('meta.upbound.io/configuration')
                    ),
                    'version': labels.get('upbound.io/version'),
                    'source': 'upbound-format'
                }

            return template
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Template {name} not found")
            else:
                logger.error(f"Error getting template details: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting template details: {e}")
            return None
