from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class CompositeManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def get_composite_resources(self) -> List[dict]:
        """Lista todos os recursos compostos com status de saúde e descrição"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            resources = []
            crds = self.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'composite' in categories:
                    try:
                        # Check if resource is namespaced
                        try:
                            crd_obj = self.api_ext.read_custom_resource_definition(f"{crd['name']}")
                            is_namespaced = crd_obj.spec.scope == "Namespaced"
                        except Exception as e:
                            logger.debug(f"Error checking CRD scope: {e}")
                            is_namespaced = False

                        if is_namespaced:
                            logger.debug(f"Listing namespaced composite resources for {crd['kind']} in namespace {self.namespace}")
                            response = self.custom_api.list_namespaced_custom_object(
                                group=crd['group'],
                                version=crd['version'],
                                namespace=self.namespace,
                                plural=crd['name'].split('.')[0].lower()
                            )
                        else:
                            logger.debug(f"Listing cluster-scoped composite resources for {crd['kind']}")
                            response = self.custom_api.list_cluster_custom_object(
                                group=crd['group'],
                                version=crd['version'],
                                plural=crd['name'].split('.')[0].lower()
                            )
                        
                        for item in response.get("items", []):
                            # Get conditions
                            conditions = item.get('status', {}).get('conditions', [])
                            health_status = 'Unknown'
                            synced_status = 'Unknown'
                            
                            for condition in conditions:
                                condition_type = condition.get('type')
                                if condition_type == 'Ready':
                                    health_status = 'Healthy' if condition.get('status') == 'True' else 'Unhealthy'
                                elif condition_type == 'Synced':
                                    synced_status = 'Synced' if condition.get('status') == 'True' else 'Not Synced'
                            
                            # Extract provider from group dynamically
                            group = crd['group']
                            provider = None
                            display_provider = None  # For UI display
                            
                            # Handle both standard Crossplane and Upbound formats
                            if group.startswith('provider-'):
                                provider = group.split('.')[0]  # Just take provider-aws part
                                display_provider = provider.replace('provider-', '')
                            elif group.endswith('.crossplane.io'):
                                base = group.replace('.crossplane.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"  # provider-aws for filtering
                                    display_provider = base  # s3.aws for display
                                else:
                                    provider = f"provider-{base}"  # provider-aws for filtering
                                    display_provider = base  # aws for display
                            elif group.endswith('.upbound.io'):
                                base = group.replace('.upbound.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"  # provider-aws for filtering
                                    display_provider = base  # s3.aws for display
                                else:
                                    provider = f"provider-{base}"  # provider-aws for filtering
                                    display_provider = base  # aws for display
                            elif '.' in group:
                                parts = group.split('.')
                                if len(parts) >= 2:
                                    provider = f"provider-{parts[1]}"  # provider-aws for filtering
                                    display_provider = f"{parts[0]}.{parts[1]}"  # s3.aws for display

                            # Get Upbound metadata if present
                            metadata = item.get('metadata', {})
                            annotations = metadata.get('annotations', {})
                            labels = metadata.get('labels', {})
                            upbound_info = None

                            if ('meta.upbound.io/configuration' in annotations or
                                'upbound.io/configuration' in labels or
                                any(key.startswith('upbound.io/') for key in labels.keys())):
                                upbound_info = {
                                    'configuration': (
                                        labels.get('upbound.io/configuration') or 
                                        annotations.get('meta.upbound.io/configuration')
                                    ),
                                    'version': labels.get('upbound.io/version'),
                                    'source': 'upbound-format'
                                }

                            # Add resource metadata
                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }
                            item['_health_status'] = health_status
                            item['_synced_status'] = synced_status
                            item['provider'] = provider  # For filtering (e.g. provider-aws)
                            item['display_provider'] = display_provider or provider  # For UI display (e.g. s3.aws)

                            # Add Upbound info if present
                            if upbound_info:
                                item['upbound'] = upbound_info

                            # Get composition reference
                            composition_ref = item.get('spec', {}).get('compositionRef', {})
                            if composition_ref and composition_ref.get('name'):
                                try:
                                    composition = self.custom_api.get_cluster_custom_object(
                                        group="apiextensions.crossplane.io",
                                        version="v1",
                                        plural="compositions",
                                        name=composition_ref['name']
                                    )
                                    item['composition'] = {
                                        'name': composition['metadata']['name'],
                                        'ready': True
                                    }
                                except:
                                    item['composition'] = {
                                        'name': composition_ref['name'],
                                        'ready': False
                                    }

                            # Get managed resources
                            try:
                                managed_resources = []
                                # Get managed resources from CRDs
                                managed_crds = [crd for crd in self.get_crossplane_crds() if 'managed' in (crd.get('categories', []) or [])]
                                for mcrd in managed_crds:
                                    try:
                                        if self._get_crd_scope(mcrd['name']):
                                            response = self.custom_api.list_namespaced_custom_object(
                                                group=mcrd['group'],
                                                version=mcrd['version'],
                                                namespace=self.namespace,
                                                plural=mcrd['name'].split('.')[0].lower()
                                            )
                                        else:
                                            response = self.custom_api.list_cluster_custom_object(
                                                group=mcrd['group'],
                                                version=mcrd['version'],
                                                plural=mcrd['name'].split('.')[0].lower()
                                            )
                                        managed_resources.extend(response.get('items', []))
                                    except Exception as e:
                                        logger.debug(f"Error listing managed resources for {mcrd['kind']}: {e}")
                                related_resources = []
                                for resource in managed_resources:
                                    owner_refs = resource.get('metadata', {}).get('ownerReferences', [])
                                    if any(ref.get('name') == item['metadata']['name'] for ref in owner_refs):
                                        conditions = resource.get('status', {}).get('conditions', [])
                                        synced_condition = next((c for c in conditions if c['type'] == 'Synced'), {})
                                        related_resources.append({
                                            'name': resource['metadata']['name'],
                                            'kind': resource.get('kind', ''),
                                            'synced': synced_condition.get('status') == 'True',
                                            'apiVersion': resource.get('apiVersion', ''),
                                            'spec': resource.get('spec', {}),
                                            'status': resource.get('status', {})
                                        })
                                item['managedResources'] = related_resources
                            except:
                                item['managedResources'] = []

                            # Get related claims
                            try:
                                claims = []
                                # Get claims from CRDs
                                claim_crds = [crd for crd in self.get_crossplane_crds() if 'claim' in (crd.get('categories', []) or [])]
                                for ccrd in claim_crds:
                                    try:
                                        response = self.custom_api.list_namespaced_custom_object(
                                            group=ccrd['group'],
                                            version=ccrd['version'],
                                            namespace=self.namespace,
                                            plural=ccrd['name'].split('.')[0].lower()
                                        )
                                        claims.extend(response.get('items', []))
                                    except Exception as e:
                                        logger.debug(f"Error listing claims for {ccrd['kind']}: {e}")
                                related_claims = [
                                    {
                                        'name': claim['metadata']['name'],
                                        'ready': claim.get('compositeResource', {}).get('ready', False),
                                        'apiVersion': claim.get('apiVersion', ''),
                                        'kind': claim.get('kind', ''),
                                        'spec': claim.get('spec', {}),
                                        'status': claim.get('status', {})
                                    }
                                    for claim in claims
                                    if claim.get('spec', {}).get('resourceRef', {}).get('name') == item['metadata']['name']
                                ]
                                item['claims'] = related_claims
                            except:
                                item['claims'] = []

                            # Include full resource details
                            resources.append({
                                **item,  # Include all existing fields
                                'spec': item.get('spec', {}),
                                'status': item.get('status', {})
                            })
                            
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing composite resources for {crd['kind']}: {e}")
                    
            return resources
        except Exception as e:
            logger.error(f"Error listing composite resources: {e}")
            return []
