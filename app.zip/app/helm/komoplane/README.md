# Komoplane Helm Chart

A Helm chart for Komoplane - A UI Dashboard for Crossplane

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+

## Installing the Chart

To install the chart with the release name `komoplane`:

```bash
helm repo add komoplane https://charts.komoplane.io
helm install komoplane komoplane/komoplane
```

## Dependencies

This chart has the following dependencies:

- [Crossplane](https://github.com/crossplane/crossplane) (>= 1.14.1)

The Crossplane dependency is automatically installed by default. You can disable it if you already have Crossplane installed:

```bash
helm install komoplane komoplane/komoplane --set crossplane.enabled=false
```

## Configuration

The following table lists the configurable parameters of the Komoplane chart and their default values.

### Global Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `nameOverride` | Override the name of the chart | `""` |
| `fullnameOverride` | Override the full name of the chart | `""` |

### Image Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Image repository | `komoplane` |
| `image.tag` | Image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |

### Service Account Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `serviceAccount.create` | Create service account | `true` |
| `serviceAccount.annotations` | Service account annotations | `{}` |
| `serviceAccount.name` | Service account name | `""` |
| `serviceAccount.automountServiceAccountToken` | Automount API credentials | `true` |

### RBAC Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `rbac.create` | Create RBAC resources | `true` |
| `rbac.rules` | Custom RBAC rules | See values.yaml |

### Service Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |

### Resource Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `resources.limits.cpu` | CPU limit | `500m` |
| `resources.limits.memory` | Memory limit | `512Mi` |
| `resources.requests.cpu` | CPU request | `100m` |
| `resources.requests.memory` | Memory request | `128Mi` |

### Crossplane Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `crossplane.enabled` | Install Crossplane dependency | `true` |
| `crossplane.rbacManager.deploy` | Deploy Crossplane RBAC manager | `true` |
| `crossplane.resourcesCrossplane.limits.cpu` | Crossplane CPU limit | `500m` |
| `crossplane.resourcesCrossplane.limits.memory` | Crossplane memory limit | `512Mi` |
| `crossplane.resourcesCrossplane.requests.cpu` | Crossplane CPU request | `100m` |
| `crossplane.resourcesCrossplane.requests.memory` | Crossplane memory request | `256Mi` |

### Application Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `config.apiMode` | API mode (kubernetes/direct) | `kubernetes` |
| `config.apiEndpoint` | Direct API endpoint | `""` |
| `config.apiKey` | Direct API key | `""` |
| `config.debug` | Enable debug mode | `false` |

## Upgrading

### To 1.0.0

This is the first stable release of the chart. No special upgrade steps are required.

## Uninstalling

To uninstall/delete the `komoplane` deployment:

```bash
helm delete komoplane
```

This will remove all the Kubernetes components associated with the chart and delete the release.