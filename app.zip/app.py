from flask import Flask, redirect, url_for, render_template, request, flash, Blueprint, session
# import flask_login
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_admin import Admin, AdminIndexView, expose
from flask_admin.menu import MenuLink
from werkzeug.security import generate_password_hash
from admin.views import UserView, ClusterView
from models.auth import User
from models.cluster import Cluster
from models.crossplane_manager import CrossplaneManager
from controllers.page_controller import page_bp
from controllers.api_controller import api_bp
from services.background_worker import start_background_worker, _worker
from kubernetes import client
import os

# Create Flask application
app = Flask(__name__, 
           template_folder='views/templates',
           static_folder='views/static',
           static_url_path='/static')

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')

# Initialize extensions
login_manager = LoginManager(app)
login_manager.login_view = 'index'

# Create auth blueprint
auth = Blueprint('auth', __name__, template_folder='templates')

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.get_by_username(request.form['username'])
        if user and user.check_password(request.form['password']):
            login_user(user)
            if user.is_admin:
                return redirect(url_for('admin.index'))
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# User loader
@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

# Routes
@app.route('/', methods=['GET', 'POST'])
def index():
    if not current_user.is_authenticated:
        if request.method == 'POST':
            user = User.get_by_username(request.form['username'])
            if user and user.check_password(request.form['password']):
                login_user(user)
                if user.is_admin:
                    return redirect(url_for('admin.index'))
                return redirect(url_for('dashboard'))
            flash('Invalid username or password')
        return render_template('login.html')
    
    if current_user.is_admin:
        return redirect(url_for('admin.index'))
    
    # Check if cluster is selected
    if 'cluster_id' not in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html', 
                         update_interval=_worker.update_interval,
                         tab=request.args.get('tab', 'overview'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for('admin.index'))
    
    # Get clusters accessible to current user
    clusters = []
    for cluster in Cluster.query():
        if current_user.id in cluster.get_users():
            clusters.append(cluster)
    
    return render_template('dashboard.html', clusters=clusters)

import tempfile
import os

@app.route('/select_cluster', methods=['POST'])
@login_required
def select_cluster():
    cluster_id = request.form.get('cluster_id')
    if not cluster_id:
        flash('No cluster selected')
        return redirect(url_for('dashboard'))
    
    cluster = Cluster.get(cluster_id)
    if not cluster:
        flash('Invalid cluster selection')
        return redirect(url_for('dashboard'))
    
    # Check if user has access to this cluster
    if not current_user.is_admin and current_user.id not in cluster.get_users():
        flash('Access denied to this cluster')
        return redirect(url_for('dashboard'))
    
    try:
        # Initialize CrossplaneManager with cluster credentials
        manager = CrossplaneManager.get_instance()
        
        if cluster.kubeconfig:
            # Create temporary file for kubeconfig
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                f.write(cluster.kubeconfig)
                kubeconfig_path = f.name
            
            try:
                # Initialize with kubeconfig
                manager.initialize_client(kubeconfig=kubeconfig_path)
            finally:
                # Clean up temporary file
                try:
                    os.unlink(kubeconfig_path)
                except:
                    pass
        else:
            # Initialize with endpoint/token
            manager.initialize_client(
                endpoint=cluster.endpoint,
                token=cluster.token
            )
        
        # Store cluster info in session
        session['cluster_id'] = cluster.id
        session['cluster_name'] = cluster.name
        
        # Start background worker after cluster selection
        start_background_worker()
        
        # Render index template with overview tab
        return render_template('index.html', update_interval=_worker.update_interval, tab='overview')
        
    except Exception as e:
        flash(f'Error connecting to cluster: {str(e)}')
        # Clear session if connection fails
        session.pop('cluster_id', None)
        session.pop('cluster_name', None)
        return redirect(url_for('dashboard'))

# Register blueprints

app.register_blueprint(auth, url_prefix='/auth')
app.register_blueprint(page_bp, url_prefix='/')
app.register_blueprint(api_bp, url_prefix='/api')

# Custom Admin Index View
class MyAdminIndexView(AdminIndexView):
    def is_accessible(self):
        print("Checking if user is authenticated and admin...")
        return current_user.is_authenticated and current_user.is_admin

    def inaccessible_callback(self, name, **kwargs):
        print("User is not authenticated or not an admin, redirecting to login...")
        return redirect(url_for('auth.login'))

    @expose('/')
    def index(self):
        print("Rendering admin index page...")
        if not self.is_accessible():
            return self.inaccessible_callback(name='index')
        return self.render('admin/index.html')

# Initialize admin
admin = Admin(app, name='Crossplane Monitor', template_mode='bootstrap4', 
             base_template='admin/master.html', index_view=MyAdminIndexView())
# Initialize admin views with proper endpoints
user_view = UserView(User, name='Users', endpoint='users')
cluster_view = ClusterView(Cluster, name='Clusters', endpoint='clusters')

# Add views to admin
admin.add_view(user_view)
admin.add_view(cluster_view)

# Create tables and admin user
User.create_table()
Cluster.create_table()

# Create admin user if it doesn't exist
if not User.get_by_username('admin'):
    admin = User(
        username='admin',
        is_admin=True
    )
    admin.set_password('admin')
    admin.save()

if __name__ == '__main__':
    app.run(debug=True)
