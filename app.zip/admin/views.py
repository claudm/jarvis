from flask_admin import BaseView, expose
from flask_admin.model import BaseModelView
from flask_login import current_user
from flask import redirect, url_for, request, jsonify, flash
from wtforms import Form, fields, validators
from models.auth import User
from models.cluster import Cluster

class SecureView:
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin

    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.login'))

class DynamoModelView(BaseModelView, SecureView):
    can_view_details = True
    can_delete = True
    page_size = 50
    form_excluded_columns = []
    form_extra_fields = {}

    def get_pk_value(self, model):
        if isinstance(model, dict):
            return model.get('id')
        else:
            return model.id

    def scaffold_list_columns(self):
        return self.column_list

    def scaffold_sortable_columns(self):
        return self.column_list

    def scaffold_form(self):
        class DynamoForm(Form):
            def __init__(self, formdata=None, obj=None, prefix='', **kwargs):
                Form.__init__(self, formdata=formdata, obj=obj, prefix=prefix, **kwargs)

        # For UserView, define fields in the desired order
        if self.model == User:
            DynamoForm.password = fields.PasswordField(
                'Password',
                validators=[validators.Optional()],
                description='Password for authentication (leave empty to keep current password when editing)'
            )
            DynamoForm.username = fields.StringField(
                'Username',
                validators=[validators.DataRequired()],
                description='Unique username for login'
            )
            DynamoForm.is_admin = fields.BooleanField(
                'Administrator',
                description='Grant administrative privileges'
            )
        else:
            # For other views, add fields based on form_columns
            for field_name in self.form_columns:
                if field_name not in (self.form_excluded_columns or []):
                    if field_name == 'is_admin':
                        setattr(DynamoForm, field_name, fields.BooleanField())
                    else:
                        setattr(DynamoForm, field_name, fields.StringField())
            
            # Add extra fields
            for field_name, field in getattr(self, 'form_extra_fields', {}).items():
                setattr(DynamoForm, field_name, field)
        
        return DynamoForm

    def get_list(self, page, sort_field, sort_desc, search, filters, page_size=None):
        if self.model == User:
            items = User.get_table().scan()['Items']
            models = []
            for item in items:
                user_data = {
                    'id': item.get('id'),
                    'username': item.get('username'),
                    'password_hash': item.get('password_hash'),
                    'is_admin': item.get('is_admin', False)
                }
                models.append(self.model(**user_data))
            
            # Sort if sort_field is specified
            if sort_field:
                models.sort(key=lambda x: getattr(x, sort_field, ''), reverse=sort_desc)
        else:
            items = Cluster.get_table().scan()['Items']
            models = []
            for item in items:
                cluster_data = {
                    'id': item.get('id'),
                    'name': item.get('name'),
                    'endpoint': item.get('endpoint'),
                    'token': item.get('token'),
                    'kubeconfig': item.get('kubeconfig'),
                    'user_ids': item.get('user_ids', [])
                }
                models.append(self.model(**cluster_data))
            
            # Sort if sort_field is specified
            if sort_field:
                models.sort(key=lambda x: getattr(x, sort_field, ''), reverse=sort_desc)
        
        return len(models), models

    def get_one(self, id):
        return self.model.get(id)

    def create_model(self, form):
        try:
            model = self.model()
            
            # Populate fields first
            form.populate_obj(model)
            model.save()
            
            # Handle extra fields after save
            if hasattr(form, 'users'):
                user_ids = [int(uid) for uid in (form.users.data if form.users.data else [])]
                if user_ids:
                    model.add_users(user_ids)
            
            return True
        except Exception as ex:
            flash(f'Error creating model: {str(ex)}', 'error')
            return False

    def update_model(self, form, model):
        try:
            # Primeiro, atualize os campos básicos
            form.populate_obj(model)
            
            # Depois, lide com os usuários se o campo existir
            if hasattr(form, 'users'):
                # Converta os IDs do formulário para inteiros, garantindo que não seja None
                form_user_ids = [int(uid) for uid in (form.users.data or [])]
                
                # Atualize diretamente a lista de user_ids
                model.user_ids = form_user_ids
            
            # Salve o modelo com todas as alterações
            model.save()
            return True
        except Exception as ex:
            flash(f'Error updating model: {str(ex)}', 'error')
            return False

    def delete_model(self, model):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You do not have permission to delete this item', 'error')
            return False

        try:
            # Allow deletion of any model (including User) for administrators
            model.delete()
            return True
        except Exception as ex:
            flash(f'Error deleting item: {str(ex)}', 'error')
            return False

    def is_sortable(self, name):
        return True

    @expose('/edit/', methods=('GET', 'POST'))
    def edit_view(self):
        """View for editing records"""
        return_url = url_for('.index_view')
        id = request.args.get('id')
        model = self.get_one(id)
        if model is None:
            flash('Record does not exist.', 'error')
            return redirect(self.get_url('.index_view'))

        form = self.edit_form(obj=model)
        if request.method == 'POST':
            if self.validate_form(form):
                if self.update_model(form, model):
                    flash('Record was successfully saved.', 'success')
                    return redirect(return_url)

        return self.render('admin/model/edit.html',
                          form=form,
                          model=model,
                          return_url=return_url)

class UserView(DynamoModelView):
    column_list = ['username', 'is_admin']
    column_searchable_list = ['username']
    can_delete = True  # Disable deletion functionality
    
    column_labels = {
        'username': 'Username',
        'is_admin': 'Administrator'
    }

    def __init__(self, *args, **kwargs):
        super(UserView, self).__init__(*args, **kwargs)
        self.can_delete = True  # Ensure deletion is disabled

    form_columns = ['password', 'username', 'is_admin']
    form_excluded_columns = ['password_hash']

    form_extra_fields = {
        'password': fields.PasswordField(
            'Password',
            validators=[validators.Optional()],
            description='Password for authentication (leave empty to keep current password when editing)'
        )
    }
    
    form_args = {
        'username': {
            'label': 'Username',
            'validators': [validators.DataRequired()],
            'description': 'Unique username for login'
        },
        'is_admin': {
            'label': 'Administrator',
            'description': 'Grant administrative privileges'
        }
    }

    def validate_form(self, form):
        # Only validate password for create/edit forms
        if hasattr(form, 'password'):
            is_create = not request.args.get('id')
            if is_create and not form.password.data:
                flash('Password is required when creating a new user', 'error')
                return False
        return super().validate_form(form)

    def on_model_change(self, form, model, is_created):
        if form.password.data:
            model.set_password(form.password.data)
        elif is_created:
            # Ensure password is set for new users
            model.set_password(form.password.data)

    model = User

class ClusterView(DynamoModelView):
    can_create = True
    can_edit = True
    can_delete = True
    column_list = ['name', 'endpoint', 'users']
    column_searchable_list = ['name']
    
    column_labels = {
        'name': 'Cluster Name',
        'endpoint': 'API Endpoint',
        'users': 'Users'
    }

    column_formatters = {
        'users': lambda v, c, m, p: ', '.join([User.get(int(user_id)).username for user_id in m.user_ids])
    }

    form_columns = ['name', 'endpoint', 'token', 'kubeconfig', 'users']
    
    form_widget_args = {
        'kubeconfig': {
            'rows': 10,
            'style': 'font-family: monospace;'
        }
    }
    
    form_args = {
        'name': {
            'label': 'Cluster Name',
            'validators': [validators.DataRequired()],
            'description': 'A unique name to identify this cluster'
        },
        'endpoint': {
            'label': 'API Endpoint',
            'description': 'The Kubernetes API endpoint (optional if using kubeconfig)'
        },
        'token': {
            'label': 'API Token',
            'description': 'The authentication token (optional if using kubeconfig)'
        },
        'kubeconfig': {
            'label': 'Kubeconfig',
            'description': 'The kubeconfig file content (optional if using endpoint/token)'
        }
    }

    form_extra_fields = {
        'users': fields.SelectMultipleField(
            'Users',
            coerce=str,
            description='Select users who can access this cluster'
        )
    }

    model = Cluster

    def create_form(self, obj=None):
        form = super().create_form(obj)
        form.users.choices = [(str(u.id), u.username) for u in self.get_users()]
        return form

    def edit_form(self, obj=None):
        form = super().edit_form(obj)
        form.users.choices = [(str(u.id), u.username) for u in self.get_users()]
        if obj:
            form.users.data = [str(u_id) for u_id in obj.get_users()]
        return form

    def get_users(self):
        """Get all users for the user list"""
        table = User.get_table()
        response = table.scan()
        return [User(**item) for item in response['Items']]
