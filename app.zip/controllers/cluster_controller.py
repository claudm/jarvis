from flask import jsonify, session
from flask_login import current_user, login_required
from models.cluster import Cluster

@login_required
def get_clusters():
    """Get available clusters and current cluster"""
    try:
        # Get all clusters since we don't maintain relationships in DynamoDB
        clusters = Cluster.query()
        
        # Get current cluster if one is selected
        current_cluster = None
        if 'cluster_id' in session:
            current_cluster = Cluster.get(session['cluster_id'])
        
        return jsonify({
            'current_cluster': {
                'id': current_cluster.id,
                'name': current_cluster.name
            } if current_cluster else None,
            'available_clusters': [
                {
                    'id': cluster.id,
                    'name': cluster.name
                }
                for cluster in clusters
            ]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
