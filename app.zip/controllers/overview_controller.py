from flask import Blueprint, jsonify, request
from services.background_worker import _worker
import logging

bp = Blueprint('overview', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

@bp.route('/interval', methods=['POST'])
def update_interval():
    """Update the refresh interval"""
    try:
        new_interval = request.json.get('interval')
        if not new_interval or not isinstance(new_interval, int):
            return jsonify({"error": "Invalid interval"}), 400
            
        if new_interval < 3 or new_interval > 3600:
            return jsonify({"error": "Interval must be between 3 and 3600 seconds"}), 400

        # Update the worker's interval
        _worker.update_interval = new_interval
        
        return jsonify({
            "message": "Interval updated successfully",
            "interval": new_interval
        }), 200
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error updating interval: {error_msg}")
        return jsonify({"error": f"Failed to update interval: {error_msg}"}), 500
