from flask import Blueprint, render_template, redirect, url_for, session
from flask_login import login_required
from services.background_worker import _worker

page_bp = Blueprint('page', __name__)

@page_bp.route('/providers')
@login_required
def providers():
    return render_template('providers.html')

@page_bp.route('/compositions')
@login_required
def compositions():
    return render_template('compositions.html')

@page_bp.route('/composite-resource-definitions')
@login_required
def composite_resource_definitions():
    return render_template('composite-resource-definitions.html')

@page_bp.route('/claims')
@login_required
def claims():
    return render_template('claims.html')

@page_bp.route('/managed-resources')
@login_required
def managed_resources():
    return render_template('managed-resources.html')

@page_bp.route('/composite-resources')
@login_required
def composite_resources():
    return render_template('composite-resources.html')

@page_bp.route('/providerconfigs')
@login_required
def provider_configs():
    return render_template('provider-configs.html')
