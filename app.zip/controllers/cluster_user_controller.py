from flask import flash
from models.auth import User
from models.cluster import Cluster

class ClusterUserController:
    @staticmethod
    def get_users_for_cluster(cluster_id):
        """
        Get all users assigned to a cluster
        
        Args:
            cluster_id: ID of the cluster
        Returns:
            List of User objects or None if cluster not found
        """
        cluster = Cluster.get(cluster_id)
        if not cluster:
            return None
        
        # In DynamoDB implementation, we don't have direct relationships
        # We'll need to scan users table to find matches
        return []

    @staticmethod
    def get_all_users():
        """
        Get all users in the system
        
        Returns:
            List of User objects
        """
        table = User.get_table()
        response = table.scan()
        users = []
        for item in response['Items']:
            users.append(User(
                id=item['id'],
                username=item['username'],
                password_hash=item['password_hash'],
                is_admin=item.get('is_admin', False)
            ))
        return sorted(users, key=lambda x: x.username)

    @staticmethod
    def update_cluster_users(cluster_id, user_ids):
        """
        Update the complete list of users for a cluster
        
        Args:
            cluster_id: ID of the cluster
            user_ids: Complete list of user IDs that should be assigned to the cluster
        Returns:
            True if successful, False otherwise
        """
        try:
            cluster = Cluster.get(cluster_id)
            if not cluster:
                flash('Cluster not found', 'error')
                return False

            # In DynamoDB implementation, we don't maintain relationships
            return True

        except Exception as e:
            flash(f'Error updating cluster users: {str(e)}', 'error')
            return False

    @staticmethod
    def clear_cluster_users(cluster_id):
        """
        Remove all users from a cluster
        
        Args:
            cluster_id: ID of the cluster
        Returns:
            True if successful, False otherwise
        """
        try:
            cluster = Cluster.get(cluster_id)
            if not cluster:
                flash('Cluster not found', 'error')
                return False

            # In DynamoDB implementation, we don't maintain relationships
            return True

        except Exception as e:
            flash(f'Error clearing cluster users: {str(e)}', 'error')
            return False
