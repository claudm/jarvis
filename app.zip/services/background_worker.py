import threading
import time
import logging
from models.crossplane_manager import CrossplaneManager
from models.overview import OverviewManager, SystemOverview, SystemHealth, ResourceCounts, HealthSummary

logger = logging.getLogger(__name__)

class BackgroundWorker:
    def __init__(self):
        self._stop_event = threading.Event()
        self._thread = None
        self._update_interval = 60  # Update every 60 seconds
        self._interval_changed = threading.Event()

    @property
    def update_interval(self):
        return self._update_interval

    @update_interval.setter
    def update_interval(self, value):
        self._update_interval = value
        self._interval_changed.set()  # Signal that interval has changed

    def start(self):
        """Start the background worker thread"""
        if self._thread is not None:
            logger.warning("Background worker already running")
            return

        # Initialize data immediately
        self._update_overview_cache()
        
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("Background worker started")

    def stop(self):
        """Stop the background worker thread"""
        if self._thread is None:
            logger.warning("Background worker not running")
            return

        self._stop_event.set()
        self._thread.join()
        self._thread = None
        self._stop_event.clear()
        logger.info("Background worker stopped")

    def _run(self):
        """Main worker loop"""
        while not self._stop_event.is_set():
            try:
                self._update_overview_cache()
            except Exception as e:
                logger.error(f"Error updating overview cache: {e}")

            # Sleep for the update interval, but check stop event and interval changes every second
            for _ in range(self._update_interval):
                if self._stop_event.is_set():
                    break
                if self._interval_changed.is_set():
                    self._interval_changed.clear()
                    break  # Break the sleep loop to apply new interval
                time.sleep(1)

    def _update_overview_cache(self):
        """Update the overview cache"""
        try:
            logger.debug("Updating overview cache")
            manager = CrossplaneManager.get_instance()
            # Update the overview data in the controller
            from controllers import overview_controller
            overview_controller.overview_data = manager.get_system_overview(use_cache=False)
            logger.debug("Overview cache updated successfully")
        except Exception as e:
            logger.error(f"Failed to update overview cache: {e}")

# Global instance
_worker = BackgroundWorker()

def start_background_worker():
    """Start the background worker"""
    _worker.start()

def stop_background_worker():
    """Stop the background worker"""
    _worker.stop()
