$(document).ready(function() {
    // Initialize Select2 for user selection in cluster form
    $('.select2-users').select2({
        theme: 'bootstrap4',
        width: '100%',
        placeholder: 'Select users...',
        allowClear: true
    });

    // Initialize Select2 for cluster selection in user form
    $('.select2-clusters').select2({
        theme: 'bootstrap4',
        width: '100%',
        placeholder: 'Select clusters...',
        allowClear: true
    });
});
