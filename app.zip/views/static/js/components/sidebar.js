// sidebar.js - Handle sidebar toggle functionality

document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggle-sidebar');
    const sidebar = document.querySelector('.flex-shrink-0.w-64');
    const mainContent = document.querySelector('.flex-1');
    
    // Add transition classes
    sidebar.classList.add('transition-all', 'duration-300', 'ease-in-out');
    mainContent.classList.add('transition-all', 'duration-300', 'ease-in-out');

    let isOpen = window.innerWidth > 768;

    function updateSidebarState() {
        const sidebarWidth = window.innerWidth <= 1024 ? '5rem' : '16rem';
        sidebar.style.width = sidebarWidth; // Mantém a largura constante
        
        if (!isOpen) {
            sidebar.style.marginLeft = `-${sidebarWidth}`; // Esconde exatamente a largura atual
            toggleButton.innerHTML = `
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            `;
        } else {
            sidebar.style.marginLeft = '0';
            toggleButton.innerHTML = `
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            `;
        }
    }

    // Initial state
    updateSidebarState();

    // Toggle button click
    toggleButton.addEventListener('click', () => {
        isOpen = !isOpen;
        updateSidebarState();
    });

    // Handle window resize
    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (window.innerWidth <= 768 && isOpen) {
                isOpen = false;
                updateSidebarState();
            }
        }, 250);
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (event) => {
        if (window.innerWidth <= 768 && isOpen && 
            !sidebar.contains(event.target) && 
            !toggleButton.contains(event.target)) {
            isOpen = false;
            updateSidebarState();
        }
    });
});
