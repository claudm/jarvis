// cluster-selector.js - Handle cluster selection dropdown

document.addEventListener('DOMContentLoaded', () => {
    const clusterButton = document.getElementById('cluster-button');
    const clusterDropdown = document.getElementById('cluster-dropdown');
    const clusterList = clusterDropdown?.querySelector('.py-1');

    if (clusterButton && clusterDropdown && clusterList) {
        // Load clusters from API
        async function loadClusters() {
            try {
                const response = await fetch('/api/clusters');
                const data = await response.json();

                // Update button text with current cluster
                const buttonText = clusterButton.querySelector('span');
                if (buttonText) {
                    buttonText.textContent = data.current_cluster?.name || 'Select Cluster';
                }

                // Update dropdown list
                clusterList.innerHTML = '';
                if (data.available_clusters?.length > 0) {
                    data.available_clusters.forEach(cluster => {
                        const form = document.createElement('form');
                        form.action = '/select_cluster';
                        form.method = 'post';
                        form.className = 'block';

                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = 'cluster_id';
                        input.value = cluster.id;

                        const button = document.createElement('button');
                        button.type = 'submit';
                        button.className = `w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600 ${
                            data.current_cluster?.id === cluster.id ? 'bg-gray-100 dark:bg-gray-600' : ''
                        }`;
                        button.textContent = cluster.name;

                        form.appendChild(input);
                        form.appendChild(button);
                        clusterList.appendChild(form);
                    });
                } else {
                    const div = document.createElement('div');
                    div.className = 'px-4 py-2 text-sm text-gray-500 dark:text-gray-400';
                    div.textContent = 'No clusters available';
                    clusterList.appendChild(div);
                }
            } catch (error) {
                console.error('Error loading clusters:', error);
            }
        }

        // Load clusters initially
        loadClusters();

        // Toggle dropdown
        clusterButton.addEventListener('click', (e) => {
            e.stopPropagation();
            clusterDropdown.classList.toggle('hidden');
            if (!clusterDropdown.classList.contains('hidden')) {
                loadClusters(); // Refresh list when opening
            }
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!clusterDropdown.contains(e.target) && !clusterButton.contains(e.target)) {
                clusterDropdown.classList.add('hidden');
            }
        });

        // Close dropdown when pressing escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                clusterDropdown.classList.add('hidden');
            }
        });
    }
});
