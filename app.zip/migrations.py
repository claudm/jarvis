from flask import Flask
from models.auth import User
from models.cluster import Cluster

def init_migrations(app: Flask):
    """Initialize DynamoDB tables"""
    # Create DynamoDB tables if they don't exist
    User.create_table()
    Cluster.create_table()
    
    return None
