from app import app, db
from flask_migrate import Migrate
from flask.cli import FlaskGroup
from models.auth import User
from models.cluster import Cluster

migrate = Migrate(app, db)
cli = FlaskGroup(app)

@cli.command("db_init")
def db_init():
    """Initialize the database."""
    with app.app_context():
        db.create_all()
        print("Database initialized.")

@cli.command("db_migrate")
def db_migrate():
    """Create a database migration."""
    migrate.init_app(app, db)
    with app.app_context():
        migrate.init()
        migrate.migrate()
        print("Migration created.")

@cli.command("db_upgrade")
def db_upgrade():
    """Apply database migrations."""
    migrate.init_app(app, db)
    with app.app_context():
        migrate.upgrade()
        print("Database upgraded.")

if __name__ == '__main__':
    cli()
