from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('overview', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

@bp.route('/overview', methods=['GET'])
def get_overview():
    """Get system overview using the optimized get_system_overview method"""
    try:
        use_cache = request.args.get('use_cache', 'true').lower() == 'true'
        logger.info(f"Fetching system overview data (use_cache={use_cache})")
        
        manager = CrossplaneManager.get_instance()
        overview = manager.get_system_overview(use_cache=use_cache)

        # Transform the data to match the expected format
        results = {
            'crossplane': {
                'health': overview['health'],
                'version': overview['version'],
                'pods': overview['pods']
            },
            'managed_resources': {
                'total_count': overview['counts']['managed_resources'],
                'health_summary': overview['health_summary']
            },
            'claims': {
                'count': overview['counts']['claims']
            },
            'composite_resources': {
                'count': overview['counts']['composite_resources']
            },
            'providers': {
                'count': overview['counts']['providers']
            },
            'provider_configs': {
                'count': overview['counts']['providers']  # Using providers count as proxy
            },
            'compositions': {
                'count': overview['counts']['compositions']
            },
            'composite_resource_definitions': {
                'count': overview['counts']['xrds']
            }
        }

        logger.info("Successfully fetched system overview data")
        return jsonify(results)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting system overview data: {error_msg}")
        return jsonify({"error": f"Failed to get system overview data: {error_msg}"}), 500

@bp.route('/overview/cache', methods=['DELETE'])
def invalidate_overview_cache():
    """Invalidate the overview cache"""
    try:
        manager = CrossplaneManager.get_instance()
        manager.invalidate_overview_cache()
        return jsonify({"message": "Overview cache invalidated successfully"})
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error invalidating overview cache: {error_msg}")
        return jsonify({"error": f"Failed to invalidate overview cache: {error_msg}"}), 500
