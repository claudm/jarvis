from typing import List, Dict, Optional
import logging
import time
from kubernetes import client
from .base_manager import BaseManager, resource_cache, last_cache_update
from .provider_manager import ProviderManager
from .claim_manager import ClaimManager
from .composition_manager import CompositionManager
from .composite_manager import CompositeManager
from .template_manager import TemplateManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

logger = logging.getLogger(__name__)

# Constants for thread pooling
MAX_WORKERS = 10
BATCH_SIZE = 50

class CrossplaneManager(BaseManager):
    _instance = None
    _lock = threading.Lock()
    _thread_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)

    @classmethod
    def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = cls()
                    instance.initialize_client()
                    instance.initialize_managers()
                    cls._instance = instance
        elif cls._instance._closed:
            with cls._lock:
                cls._instance.initialize_client()
                cls._instance.initialize_managers()
        return cls._instance

    def __init__(self):
        super().__init__()
        self.namespace = None
        self.provider_manager = None
        self.claim_manager = None
        self.composition_manager = None
        self.composite_manager = None
        self.template_manager = None

    def initialize_managers(self):
        """Initialize all managers after client is ready"""
        self.namespace = self.get_current_namespace()
        self.provider_manager = ProviderManager()
        self.claim_manager = ClaimManager()
        self.composition_manager = CompositionManager()
        self.composite_manager = CompositeManager()
        self.template_manager = TemplateManager()

    # Shorter TTL for overview cache
    OVERVIEW_CACHE_TTL = 60  # 1 minute

    def _is_overview_cache_valid(self) -> bool:
        """Check if overview cache is valid with shorter TTL"""
        cache_key = 'system_overview'
        if cache_key not in last_cache_update:
            return False
        return (time.time() - last_cache_update[cache_key]) < self.OVERVIEW_CACHE_TTL

    def invalidate_overview_cache(self):
        """Invalidate the overview cache"""
        cache_key = 'system_overview'
        if cache_key in resource_cache:
            del resource_cache[cache_key]
        if cache_key in last_cache_update:
            del last_cache_update[cache_key]

    def get_system_overview(self, use_cache: bool = True) -> dict:
        """Get a lightweight system overview with only essential data using base manager methods.
        Args:
            use_cache: Whether to use cached data if available
        Returns a dict with system health, counts and minimal status info.
        """
        if not self._ensure_connection():
            return {
                "health": "Unavailable",
                "version": "Unknown",
                "pods": [],
                "counts": {
                    "claims": 0,
                    "compositions": 0,
                    "composite_resources": 0,
                    "managed_resources": 0,
                    "providers": 0,
                    "xrds": 0
                },
                "health_summary": {
                    "healthy": 0,
                    "unhealthy": 0,
                    "unknown": 0
                }
            }

        try:
            # Check cache for system overview
            cache_key = 'system_overview'
            if use_cache and self._is_overview_cache_valid() and cache_key in resource_cache:
                # Start background refresh if cache is getting old
                if time.time() - last_cache_update[cache_key] > (self.OVERVIEW_CACHE_TTL * 0.8):
                    self._thread_pool.submit(self.get_system_overview, use_cache=False)
                return resource_cache[cache_key]

            # Get Crossplane deployment status using base manager
            try:
                deployment = self.get_resource(
                    group="apps",
                    version="v1",
                    plural="deployments",
                    name="crossplane",
                    namespace="crossplane-system"
                )
                
                version = "Unknown"
                if deployment and 'spec' in deployment:
                    containers = deployment['spec'].get('template', {}).get('spec', {}).get('containers', [])
                    if containers:
                        image = containers[0].get('image', '')
                        if ':' in image:
                            version = image.split(':')[1]

                health = "Healthy"
                if deployment and 'status' in deployment:
                    if deployment['status'].get('availableReplicas') != deployment['status'].get('replicas'):
                        health = "Unhealthy"
            except Exception as e:
                logger.error(f"Error getting Crossplane deployment: {e}")
                health = "Unavailable"
                version = "Unknown"

            # Get Crossplane pods using core_v1_api
            try:
                pod_list = self.core_v1_api.list_namespaced_pod(namespace="crossplane-system")
                pods = []
                
                for pod in pod_list.items:
                    if pod.status.phase in ['Succeeded', 'Failed']:
                        continue
                        
                    containers = []
                    if pod.status.container_statuses:
                        for container in pod.status.container_statuses:
                            containers.append({
                                "name": container.name,
                                "ready": container.ready,
                                "restarts": container.restart_count,
                                "status": "Running" if container.ready else "Not Ready"
                            })
                    
                    pods.append({
                        "name": pod.metadata.name,
                        "status": pod.status.phase,
                        "containers": containers
                    })
            except Exception as e:
                logger.error(f"Error getting Crossplane pods: {e}")
                pods = []

            # Get Crossplane CRDs using base manager method
            crds = self.get_crossplane_crds()
            
            counts = {
                "claims": 0,
                "compositions": 0,
                "composite_resources": 0,
                "managed_resources": 0,
                "providers": 0,
                "xrds": 0
            }

            health_summary = {"healthy": 0, "unhealthy": 0, "unknown": 0}

            # Count resources by type using CRD categories
            for crd in crds:
                categories = crd.get('categories', [])
                if 'claim' in categories:
                    counts['claims'] += 1
                elif 'composite' in categories:
                    counts['composite_resources'] += 1
                elif 'managed' in categories:
                    # For managed resources also get health status
                    try:
                        resources = self.get_resource(
                            group=crd['group'],
                            version=crd['version'],
                            plural=crd['name'].split('.')[0],
                            name=''  # Empty name to get all resources
                        )
                        if resources and isinstance(resources, dict) and 'items' in resources:
                            for resource in resources['items']:
                                counts['managed_resources'] += 1
                                conditions = resource.get('status', {}).get('conditions', [])
                                ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                                
                                if ready.get('status') == 'True':
                                    health_summary['healthy'] += 1
                                elif ready.get('status') == 'False':
                                    health_summary['unhealthy'] += 1
                                else:
                                    health_summary['unknown'] += 1
                    except Exception as e:
                        logger.error(f"Error checking managed resource health: {e}")

            # Get counts for other resources
            try:
                # Providers
                providers = self.get_resource(
                    group="pkg.crossplane.io",
                    version="v1",
                    plural="providers",
                    name=""
                )
                counts['providers'] = len(providers.get('items', [])) if providers else 0

                # Compositions - use processed compositions count
                compositions = self.composition_manager.list_compositions()
                counts['compositions'] = len(compositions)

                # XRDs
                xrds = self.get_resource(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    plural="compositeresourcedefinitions",
                    name=""
                )
                counts['xrds'] = len(xrds.get('items', [])) if xrds else 0
            except Exception as e:
                logger.error(f"Error getting resource counts: {e}")

            result = {
                "health": health,
                "version": version,
                "pods": pods,
                "counts": counts,
                "health_summary": health_summary
            }

            # Update cache
            resource_cache[cache_key] = result
            last_cache_update[cache_key] = time.time()
            return result

        except Exception as e:
            logger.error(f"Error getting system overview: {e}")
            return {
                "health": "Error",
                "version": "Unknown",
                "pods": [],
                "counts": {k: 0 for k in counts},
                "health_summary": {k: 0 for k in health_summary}
            }

    def get_managed_resources(self) -> List[dict]:
        """Get all managed resources with concurrent processing"""
        try:
            if not self._ensure_connection():
                return []

            managed_resources = []
            crds = self.get_crossplane_crds()
            managed_crds = [crd for crd in crds if 'managed' in (crd.get('categories', []) or [])]

            # Process each CRD
            for crd in managed_crds:
                try:
                    resources = self.get_resource(
                        group=crd['group'],
                        version=crd['version'],
                        plural=crd['name'].split('.')[0],
                        name=''  # Empty name to get all resources
                    )

                    if resources and isinstance(resources, dict) and 'items' in resources:
                        for resource in resources['items']:
                            # Add resource type info
                            resource['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }

                            # Extract provider info
                            group = crd['group']
                            provider = None
                            display_provider = None

                            if group.startswith('provider-'):
                                provider = group.split('.')[0]
                                display_provider = provider.replace('provider-', '')
                            elif group.endswith('.crossplane.io'):
                                base = group.replace('.crossplane.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"
                                    display_provider = base
                                else:
                                    provider = f"provider-{base}"
                                    display_provider = base
                            elif group.endswith('.upbound.io'):
                                base = group.replace('.upbound.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"
                                    display_provider = base
                                else:
                                    provider = f"provider-{base}"
                                    display_provider = base
                            elif '.' in group:
                                parts = group.split('.')
                                if len(parts) >= 2:
                                    provider = f"provider-{parts[1]}"
                                    display_provider = f"{parts[0]}.{parts[1]}"

                            resource['provider'] = provider
                            resource['display_provider'] = display_provider or provider

                            # Add provider config reference
                            resource['providerconfig'] = (
                                resource.get('spec', {}).get('providerConfigRef', {}).get('name') or
                                resource.get('spec', {}).get('providerRef', {}).get('name')
                            )

                            # Add health status
                            conditions = resource.get('status', {}).get('conditions', [])
                            ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                            resource['_health_status'] = (
                                'Healthy' if ready.get('status') == 'True'
                                else 'Unhealthy' if ready.get('status') == 'False'
                                else 'Unknown'
                            )

                            # Process Upbound info
                            metadata = resource.get('metadata', {})
                            annotations = metadata.get('annotations', {})
                            labels = metadata.get('labels', {})

                            if ('meta.upbound.io/configuration' in annotations or
                                'upbound.io/configuration' in labels or
                                any(key.startswith('upbound.io/') for key in labels.keys())):
                                resource['upbound'] = {
                                    'configuration': (
                                        labels.get('upbound.io/configuration') or 
                                        annotations.get('meta.upbound.io/configuration')
                                    ),
                                    'version': labels.get('upbound.io/version'),
                                    'source': 'upbound-format'
                                }

                            managed_resources.append(resource)

                except Exception as e:
                    logger.error(f"Error processing CRD {crd['name']}: {e}")

            return managed_resources

        except Exception as e:
            logger.error(f"Error getting managed resources: {e}")
            return []

    # Delegate methods to specific managers
    def list_providers(self) -> List[dict]:
        return self.provider_manager.list_providers()

    def get_provider_status(self, provider_name: str) -> Optional[dict]:
        return self.provider_manager.get_provider_status(provider_name)

    def list_provider_configs(self) -> List[dict]:
        """List all provider configurations"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []
                
            # First ensure we can list providers
            providers = self.list_providers()
            if not providers:
                logger.warning("No providers found")
                return []
                
            # Then get configs
            configs = self.provider_manager.list_provider_configs()
            logger.info(f"Retrieved {len(configs)} provider configurations")
            return configs
            
        except Exception as e:
            logger.error(f"Error listing provider configurations: {e}")
            return []

    def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        return super().get_resource(group, version, plural, name, namespace)

    def list_claims(self, namespace: str = None) -> List[dict]:
        namespace = namespace or self.namespace
        return self.claim_manager.list_claims(namespace)

    def get_claim_events(self, name: str, namespace: str = None) -> List[dict]:
        namespace = namespace or self.namespace
        return self.claim_manager.get_claim_events(name, namespace)

    def get_claim(self, name: str, namespace: str = None) -> Optional[dict]:
        namespace = namespace or self.namespace
        return self.claim_manager.get_claim(name, namespace)

    def list_compositions(self) -> List[dict]:
        return self.composition_manager.list_compositions()

    def get_composition(self, name: str) -> Optional[dict]:
        return self.composition_manager.get_composition(name)

    def get_xrd(self, name: str) -> Optional[dict]:
        return self.composition_manager.get_xrd(name)

    def list_composite_resource_definitions(self) -> List[dict]:
        return self.composition_manager.list_composite_resource_definitions()

    def get_composite_resources(self) -> List[dict]:
        return self.composite_manager.get_composite_resources()

    def list_templates(self) -> List[dict]:
        return self.template_manager.list_templates()

    def get_template_details(self, name: str) -> Optional[dict]:
        return self.template_manager.get_template_details(name)

    def get_provider_config(self, name: str) -> Optional[dict]:
        """Get a specific provider configuration"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return None

            return self.provider_manager.get_provider_config(name)
        except Exception as e:
            logger.error(f"Error getting provider config: {e}")
            return None
