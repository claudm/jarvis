from kubernetes import client, config
from typing import List, Dict, Optional
import logging
import os
import threading
import time
import urllib3
import warnings

# Disable SSL verification warnings for local development
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Cache for CRD and resource information
crd_scope_cache = {}  # Cache for CRD scope information
crd_list_cache = {}   # Cache for CRD lists
resource_cache = {}   # Cache for resources
cache_ttl = 300      # Cache TTL in seconds (5 minutes)
last_cache_update = {}  # Track last update time for each cache

class BaseManager:
    _instance = None
    _lock = threading.Lock()
    _initialized = False
    _connection_retries = 5
    _retry_delay = 2  # seconds

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self.namespace = None  # Current namespace from ServiceAccount
            self._initialized = True
            self._closed = False

    def _is_cache_valid(self, cache_key: str) -> bool:
        """Check if cache is still valid based on TTL"""
        if cache_key not in last_cache_update:
            return False
        return (time.time() - last_cache_update[cache_key]) < cache_ttl

    def _update_cache(self, cache_key: str, data: any):
        """Update cache with new data and timestamp"""
        if cache_key.startswith('crd_list'):
            crd_list_cache[cache_key] = data
        elif cache_key.startswith('resource'):
            resource_cache[cache_key] = data
        last_cache_update[cache_key] = time.time()

    def _clear_cache(self):
        """Clear all caches"""
        crd_scope_cache.clear()
        crd_list_cache.clear()
        resource_cache.clear()
        last_cache_update.clear()

    def get_crossplane_crds(self) -> List[dict]:
        """Get Crossplane CRDs with caching"""
        try:
            if not self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            cache_key = 'crd_list'
            if self._is_cache_valid(cache_key) and cache_key in crd_list_cache:
                return crd_list_cache[cache_key]

            crd_list = self.api_ext.list_custom_resource_definition()
            
            if not crd_list or not hasattr(crd_list, 'items'):
                logger.warning("No CRDs found in the cluster")
                return []

            crossplane_crds = []
            for crd in crd_list.items:
                if not hasattr(crd, 'spec') or not hasattr(crd.spec, 'group'):
                    continue

                categories = getattr(crd.spec.names, 'categories', []) or []
                annotations = getattr(crd.metadata, 'annotations', {}) or {}
                labels = getattr(crd.metadata, 'labels', {}) or {}

                # Check both standard Crossplane and Upbound format
                is_crossplane = (
                    'crossplane.io' in crd.spec.group or
                    'upbound.io' in crd.spec.group or
                    any(cat in ['crossplane', 'managed', 'claim', 'composite']
                        for cat in categories) or
                    'meta.upbound.io/configuration' in annotations or
                    'upbound.io/configuration' in labels or
                    any(key.startswith('upbound.io/') for key in labels.keys())
                )

                if is_crossplane:
                    crd_info = {
                        'name': crd.metadata.name,
                        'kind': crd.spec.names.kind,
                        'group': crd.spec.group,
                        'version': crd.spec.versions[0].name if crd.spec.versions else '',
                        'scope': crd.spec.scope,
                        'categories': list(categories)
                    }

                    # Add Upbound-specific information if present
                    if ('meta.upbound.io/configuration' in annotations or
                        'upbound.io/configuration' in labels or
                        any(key.startswith('upbound.io/') for key in labels.keys())):
                        crd_info['upbound'] = {
                            'configuration': (
                                labels.get('upbound.io/configuration') or 
                                annotations.get('meta.upbound.io/configuration')
                            ),
                            'version': labels.get('upbound.io/version'),
                            'source': 'upbound-format'
                        }

                    crossplane_crds.append(crd_info)

            self._update_cache(cache_key, crossplane_crds)
            return crossplane_crds

        except Exception as e:
            logger.error(f"Error getting Crossplane CRDs: {e}")
            return []

    def _get_crd_scope(self, crd_name: str) -> bool:
        """Get CRD scope with caching"""
        if crd_name in crd_scope_cache:
            return crd_scope_cache[crd_name]
        
        try:
            crd_obj = self.api_ext.read_custom_resource_definition(crd_name)
            is_namespaced = crd_obj.spec.scope == "Namespaced"
            crd_scope_cache[crd_name] = is_namespaced
            return is_namespaced
        except Exception as e:
            logger.debug(f"Error checking CRD scope: {e}")
            return False

    def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        """Get a specific resource with caching"""
        try:
            if not self._ensure_connection():
                return None

            # Create cache key
            cache_key = f"resource_{group}_{version}_{plural}_{name}"
            if namespace:
                cache_key += f"_{namespace}"

            # Check cache
            if self._is_cache_valid(cache_key) and cache_key in resource_cache:
                return resource_cache[cache_key]

            # Use ServiceAccount namespace if none provided and resource is namespaced
            try:
                crd = self.api_ext.read_custom_resource_definition(f"{plural}.{group}")
                if crd.spec.scope == "Namespaced":
                    namespace = namespace or self.namespace
            except Exception as e:
                logger.debug(f"Error checking CRD scope: {e}")

            result = None
            if namespace:
                logger.debug(f"Getting namespaced resource {name} in namespace {namespace}")
                result = self.custom_api.get_namespaced_custom_object(
                    group=group,
                    version=version,
                    namespace=namespace,
                    plural=plural,
                    name=name
                )
            else:
                logger.debug(f"Getting cluster-scoped resource {name}")
                result = self.custom_api.get_cluster_custom_object(
                    group=group,
                    version=version,
                    plural=plural,
                    name=name
                )

            if result:
                self._update_cache(cache_key, result)
            return result

        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Resource {name} not found")
            else:
                logger.error(f"Error getting resource: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting resource: {e}")
            return None

    def get_current_namespace(self) -> str:
        """Get the current namespace, defaults to 'default'"""
        return self.namespace or 'default'

    @classmethod
    def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    cls._instance.initialize_client()
        elif cls._instance._closed:
            with cls._lock:
                cls._instance.initialize_client()
        return cls._instance

    def close(self):
        """Close all connections and clear caches"""
        try:
            if self.api_client:
                try:
                    self.api_client.close()
                except Exception as e:
                    logger.warning(f"Error closing Kubernetes API client: {e}")
                finally:
                    self.api_client = None
                    self.custom_api = None
                    self.api_ext = None
                    self._closed = True
                    self._clear_cache()  # Clear caches on close
        except Exception as e:
            logger.error(f"Error during connection cleanup: {e}")
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self._closed = True
            self._clear_cache()  # Clear caches on error

    def cleanup(self):
        """Cleanup resources when application shuts down"""
        try:
            self.close()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
        finally:
            BaseManager._instance = None
            self._initialized = False
            self._closed = True
            self._clear_cache()  # Clear caches on cleanup

    def _ensure_connection(self):
        """Ensure connection is active, retry if needed"""
        for attempt in range(self._connection_retries):
            try:
                if not self._closed and self.verify_connection():
                    return True
                self.initialize_client()
                return True
            except Exception as e:
                if attempt == self._connection_retries - 1:
                    logger.error(f"Failed to ensure connection after {self._connection_retries} attempts: {e}")
                    return False
                logger.warning(f"Connection attempt {attempt + 1} failed: {e}")
                time.sleep(self._retry_delay)
        return False

    def initialize_client(self):
        """Initialize Kubernetes client"""
        try:
            self.close()

            configuration = client.Configuration()
            
            # SSL settings
            configuration.verify_ssl = False
            configuration.ssl_ca_cert = None
            configuration.assert_hostname = False
            
            # Connection settings
            configuration.connection_pool_maxsize = 32
            configuration.retries = 5
            configuration.timeout = 60
            
            # Proxy settings
            http_proxy = os.getenv('HTTP_PROXY')
            https_proxy = os.getenv('HTTPS_PROXY')
            proxy_user = os.getenv('PROXY_USER')
            proxy_pass = os.getenv('PROXY_PASS')

            if http_proxy or https_proxy:
                if http_proxy:
                    configuration.proxy = http_proxy
                if https_proxy:
                    configuration.proxy = https_proxy
                if proxy_user and proxy_pass:
                    configuration.proxy_headers = urllib3.make_headers(
                        proxy_basic_auth=f"{proxy_user}:{proxy_pass}"
                    )

            # Try loading in-cluster config first (ServiceAccount)
            try:
                # Check for service account token
               
                # Try standard in-cluster config
                config.load_incluster_config(client_configuration=configuration)
                logger.info("Using standard in-cluster configuration")
            except Exception as e:
                logger.debug(f"Not running in-cluster, trying kubeconfig: {e}")
                if os.path.exists(os.path.expanduser('~/.kube/config')):
                    config.load_kube_config(client_configuration=configuration)
                    logger.info("Using local kubeconfig configuration")
                else:
                    raise Exception("No valid Kubernetes configuration found")

            # Initialize with retry
            max_retries = 5
            retry_delay = 2
            last_error = None

            for attempt in range(max_retries):
                try:
                    self.api_client = client.ApiClient(configuration)
                    self.custom_api = client.CustomObjectsApi(self.api_client)
                    self.api_ext = client.ApiextensionsV1Api(self.api_client)
                    
                    # Test connection
                    self.api_ext.get_api_resources()
                    logger.info("Successfully connected to Kubernetes cluster")
                    self._closed = False
                    return
                except Exception as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        logger.warning(f"Connection attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
                        self.close()
                        time.sleep(retry_delay)
                    else:
                        logger.error(f"Failed to initialize Kubernetes client after {max_retries} attempts: {last_error}")
                        raise last_error

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}")
            raise

    def verify_connection(self) -> bool:
        """Verify connection is active"""
        try:
            if not all([self.api_client, self.custom_api, self.api_ext]):
                return False
            self.api_ext.get_api_resources()
            return True
        except:
            return False
