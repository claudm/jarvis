from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

logger = logging.getLogger(__name__)

# Constants for thread pooling
MAX_WORKERS = 10
BATCH_SIZE = 50

class ProviderManager(BaseManager):
    _thread_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
    _lock = threading.Lock()

    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def _process_upbound_info(self, item: dict) -> dict:
        """Process Upbound-specific information for a resource"""
        metadata = item.get('metadata', {})
        annotations = metadata.get('annotations', {})
        labels = metadata.get('labels', {})

        if ('meta.upbound.io/configuration' in annotations or
            'upbound.io/configuration' in labels or
            any(key.startswith('upbound.io/') for key in labels.keys())):
            item['upbound'] = {
                'configuration': (
                    labels.get('upbound.io/configuration') or 
                    annotations.get('meta.upbound.io/configuration')
                ),
                'version': labels.get('upbound.io/version'),
                'source': 'upbound-format'
            }
        return item

    def list_providers(self) -> List[dict]:
        """List all installed Crossplane providers with concurrent processing"""
        try:
            if not self._ensure_connection():
                logger.error("Failed to list providers: No connection to Kubernetes cluster")
                return []

            logger.info("Attempting to list providers from Kubernetes API")
            response = self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            providers = response.get("items", [])

            # Process providers concurrently
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(self._process_upbound_info, provider) 
                          for provider in providers]
                providers = [future.result() for future in as_completed(futures)]

            logger.info(f"Retrieved {len(providers)} providers from Kubernetes API")
            return providers
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Providers CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing providers: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing providers: {e}")
            return []

    def get_provider_status(self, provider_name: str) -> Optional[dict]:
        """Get status of a specific provider"""
        try:
            if not self._ensure_connection():
                return None

            provider = self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            return provider.get("status", {})
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Provider {provider_name} not found")
            else:
                logger.error(f"Error getting provider status: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider status: {e}")
            return None

    def _fetch_provider_configs(self, crd: dict) -> List[dict]:
        """Fetch provider configs for a single CRD"""
        try:
            is_namespaced = self._get_crd_scope(crd['name'])
            if is_namespaced:
                logger.info(f"Listing namespaced provider configs for {crd['kind']} in namespace {self.namespace}")
                response = self.custom_api.list_namespaced_custom_object(
                    group=crd['group'],
                    version=crd['version'],
                    namespace=self.namespace,
                    plural=crd['name'].split('.')[0].lower()
                )
            else:
                logger.info(f"Listing cluster-scoped provider configs for {crd['kind']}")
                response = self.custom_api.list_cluster_custom_object(
                    group=crd['group'],
                    version=crd['version'],
                    plural=crd['name'].split('.')[0].lower()
                )

            items = response.get('items', [])
            
            # Process items concurrently
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(self._process_upbound_info, config) 
                          for config in items]
                processed_items = [future.result() for future in as_completed(futures)]
            
            return processed_items
        except Exception as e:
            logger.debug(f"Error listing provider configs for {crd['kind']}: {e}")
            return []

    def list_provider_configs(self) -> List[dict]:
        """List all provider configurations with concurrent processing"""
        try:
            if not self._ensure_connection():
                return []

            # Get all provider CRDs
            all_crds = self.get_crossplane_crds()
            provider_crds = [crd for crd in all_crds 
                           if any(g in crd.get('group', '') for g in ['.crossplane.io', '.upbound.io'])
                           and 'providerconfigs' in crd.get('name', '').lower()]

            logger.info(f"Found {len(provider_crds)} provider config CRDs")
            
            # Fetch configs concurrently
            configs = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_crd = {
                    executor.submit(self._fetch_provider_configs, crd): crd
                    for crd in provider_crds
                }
                
                for future in as_completed(future_to_crd):
                    try:
                        configs.extend(future.result())
                    except Exception as e:
                        logger.error(f"Error processing provider configs: {e}")

            return configs
        except Exception as e:
            logger.error(f"Error listing provider configs: {e}")
            return []

    def get_provider_config(self, name: str) -> Optional[dict]:
        """Get a specific provider configuration"""
        try:
            if not self._ensure_connection():
                return None

            provider_crds = [crd for crd in self.get_crossplane_crds() 
                           if any(g in crd.get('group', '') for g in ['.crossplane.io', '.upbound.io'])
                           and 'providerconfigs' in crd.get('name', '').lower()]

            # Try to get config from each CRD concurrently
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = []
                for crd in provider_crds:
                    future = executor.submit(self._get_provider_config_from_crd, crd, name)
                    futures.append(future)
                
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        if result:
                            return result
                    except Exception as e:
                        logger.debug(f"Error getting provider config: {e}")

            return None
        except Exception as e:
            logger.error(f"Error getting provider config: {e}")
            return None

    def _get_provider_config_from_crd(self, crd: dict, name: str) -> Optional[dict]:
        """Get provider config from a specific CRD"""
        try:
            is_namespaced = self._get_crd_scope(crd['name'])
            if is_namespaced:
                config = self.custom_api.get_namespaced_custom_object(
                    group=crd['group'],
                    version=crd['version'],
                    namespace=self.namespace,
                    plural=crd['name'].split('.')[0].lower(),
                    name=name
                )
            else:
                config = self.custom_api.get_cluster_custom_object(
                    group=crd['group'],
                    version=crd['version'],
                    plural=crd['name'].split('.')[0].lower(),
                    name=name
                )

            return self._process_upbound_info(config)
        except client.ApiException as e:
            if e.status != 404:
                logger.warning(f"Error getting provider config {name} from {crd['kind']}: {e}")
            return None
        except Exception as e:
            logger.debug(f"Error getting provider config {name} from {crd['kind']}: {e}")
            return None
