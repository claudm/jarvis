from typing import List, Dict, Optional
import logging
from kubernetes import client
from .base_manager import BaseManager
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

logger = logging.getLogger(__name__)

# Constants for thread pooling
MAX_WORKERS = 10
BATCH_SIZE = 50

class ClaimManager(BaseManager):
    _thread_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
    _lock = threading.Lock()

    def __init__(self):
        super().__init__()
        self.namespace = self.get_current_namespace()

    def _get_events(self, names: List[str], namespace: str = None) -> Dict[str, List[dict]]:
        """Batch get events for multiple resources with concurrent processing"""
        events = {}
        try:
            if not self._ensure_connection():
                return events

            core_v1 = client.CoreV1Api(self.api_client)
            
            # Split names into batches for concurrent processing
            name_batches = [names[i:i + BATCH_SIZE] for i in range(0, len(names), BATCH_SIZE)]
            
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = []
                for batch in name_batches:
                    field_selector = 'involvedObject.name in (' + ','.join(batch) + ')'
                    future = executor.submit(
                        core_v1.list_namespaced_event,
                        namespace=namespace,
                        field_selector=field_selector
                    )
                    futures.append(future)

                # Process results as they complete
                for future in as_completed(futures):
                    try:
                        batch_events = future.result()
                        for event in batch_events.items:
                            name = event.involved_object.name
                            if name not in events:
                                events[name] = []
                            events[name].append({
                                'type': event.type,
                                'reason': event.reason,
                                'message': event.message,
                                'timestamp': event.last_timestamp.isoformat() if event.last_timestamp else None,
                                'count': event.count
                            })
                    except Exception as e:
                        logger.error(f"Error processing events batch: {e}")

        except Exception as e:
            logger.error(f"Error getting events: {e}")
        return events

    def get_claim_events(self, name: str, namespace: str = None) -> List[dict]:
        """Get events for a specific claim"""
        events = self._get_events([name], namespace)
        return events.get(name, [])

    def _fetch_provider_config(self, ref: Dict) -> Optional[Dict]:
        """Fetch a single provider config"""
        try:
            if not ref or not ref.get('name'):
                return None

            provider_config = self.custom_api.get_cluster_custom_object(
                group=ref.get('apiVersion', '').split('/')[0],
                version=ref.get('apiVersion', '').split('/')[1],
                plural="providerconfigs",
                name=ref['name']
            )
            conditions = provider_config.get('status', {}).get('conditions', [])
            ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
            return {
                'name': provider_config['metadata']['name'],
                'ready': ready_condition.get('status') == 'True'
            }
        except Exception as e:
            logger.debug(f"Error fetching provider config {ref.get('name')}: {e}")
            return {
                'name': ref['name'],
                'ready': False
            }

    def _get_provider_configs(self, refs: List[Dict]) -> Dict[str, Dict]:
        """Batch get provider configs with concurrent processing"""
        provider_configs = {}
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {
                executor.submit(self._fetch_provider_config, ref): ref
                for ref in refs if ref and ref.get('name')
            }
            
            for future in as_completed(futures):
                ref = futures[future]
                try:
                    result = future.result()
                    if result:
                        provider_configs[ref['name']] = result
                except Exception as e:
                    logger.error(f"Error processing provider config: {e}")
                    provider_configs[ref['name']] = {
                        'name': ref['name'],
                        'ready': False
                    }
        return provider_configs

    def _fetch_composition(self, ref: Dict) -> Optional[Dict]:
        """Fetch a single composition"""
        try:
            if not ref or not ref.get('name'):
                return None

            composition = self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=ref['name']
            )
            return {
                'name': composition['metadata']['name'],
                'ready': True,
                'providerConfigRef': composition.get('spec', {}).get('providerConfigRef', {})
            }
        except Exception as e:
            logger.debug(f"Error fetching composition {ref.get('name')}: {e}")
            return {
                'name': ref['name'],
                'ready': False
            }

    def _get_compositions(self, refs: List[Dict]) -> Dict[str, Dict]:
        """Batch get compositions with concurrent processing"""
        compositions = {}
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {
                executor.submit(self._fetch_composition, ref): ref
                for ref in refs if ref and ref.get('name')
            }
            
            for future in as_completed(futures):
                ref = futures[future]
                try:
                    result = future.result()
                    if result:
                        compositions[ref['name']] = result
                except Exception as e:
                    logger.error(f"Error processing composition: {e}")
                    compositions[ref['name']] = {
                        'name': ref['name'],
                        'ready': False
                    }
        return compositions

    def _fetch_composite_resource(self, ref: Dict) -> Optional[Dict]:
        """Fetch a single composite resource"""
        try:
            if not ref or not ref.get('name'):
                return None

            composite = self.custom_api.get_cluster_custom_object(
                group=ref.get('apiVersion', '').split('/')[0],
                version=ref.get('apiVersion', '').split('/')[1],
                plural=ref['kind'].lower() + 's',
                name=ref['name']
            )
            conditions = composite.get('status', {}).get('conditions', [])
            ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
            return {
                'name': composite['metadata']['name'],
                'ready': ready_condition.get('status') == 'True'
            }
        except Exception as e:
            logger.debug(f"Error fetching composite resource {ref.get('name')}: {e}")
            return {
                'name': ref['name'],
                'ready': False
            }

    def _get_composite_resources(self, refs: List[Dict]) -> Dict[str, Dict]:
        """Batch get composite resources with concurrent processing"""
        resources = {}
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {
                executor.submit(self._fetch_composite_resource, ref): ref
                for ref in refs if ref and ref.get('name')
            }
            
            for future in as_completed(futures):
                ref = futures[future]
                try:
                    result = future.result()
                    if result:
                        resources[ref['name']] = result
                except Exception as e:
                    logger.error(f"Error processing composite resource: {e}")
                    resources[ref['name']] = {
                        'name': ref['name'],
                        'ready': False
                    }
        return resources

    def _process_claim(self, item: dict, crd: dict, provider_configs: Dict, compositions: Dict, composite_resources: Dict) -> dict:
        """Process a single claim with all related data"""
        try:
            metadata = item.get('metadata', {})
            annotations = metadata.get('annotations', {})
            labels = metadata.get('labels', {})

            item['_resource_type'] = {
                'kind': crd['kind'],
                'group': crd['group'],
                'version': crd['version']
            }

            if ('meta.upbound.io/configuration' in annotations or
                'upbound.io/configuration' in labels or
                any(key.startswith('upbound.io/') for key in labels.keys())):
                item['upbound'] = {
                    'configuration': (
                        labels.get('upbound.io/configuration') or 
                        annotations.get('meta.upbound.io/configuration')
                    ),
                    'version': labels.get('upbound.io/version'),
                    'source': 'upbound-format'
                }

            provider_config_ref = item.get('spec', {}).get('providerConfigRef', {})
            if provider_config_ref and provider_config_ref.get('name'):
                item['providerConfig'] = provider_configs.get(provider_config_ref['name'])

            composition_ref = item.get('spec', {}).get('compositionRef', {})
            if composition_ref and composition_ref.get('name'):
                composition = compositions.get(composition_ref['name'])
                if composition:
                    item['composition'] = {
                        'name': composition['name'],
                        'ready': composition['ready']
                    }

                    if not item.get('providerConfig') and composition['providerConfigRef']:
                        provider_config = provider_configs.get(composition['providerConfigRef']['name'])
                        if provider_config:
                            item['providerConfig'] = {
                                **provider_config,
                                'from': 'composition'
                            }

            composite_ref = item.get('spec', {}).get('resourceRef', {})
            if composite_ref and composite_ref.get('name'):
                composite = composite_resources.get(composite_ref['name'])
                if composite:
                    item['compositeResource'] = composite

            return item
        except Exception as e:
            logger.error(f"Error processing claim: {e}")
            return item

    def _fetch_claims_for_crd(self, crd: dict, namespace: str) -> List[dict]:
        """Fetch claims for a specific CRD"""
        try:
            response = self.custom_api.list_namespaced_custom_object(
                group=crd['group'],
                version=crd['version'],
                namespace=namespace,
                plural=crd['name'].split('.')[0].lower()
            )
            return response.get("items", [])
        except Exception as e:
            logger.debug(f"Error fetching claims for CRD {crd['kind']}: {e}")
            return []

    def list_claims(self, namespace: str = None) -> List[dict]:
        """List all claims in a namespace with concurrent processing"""
        try:
            if not self._ensure_connection():
                return []

            namespace = namespace or self.namespace
            logger.debug(f"Listing claims in namespace {namespace}")

            crds = self.get_crossplane_crds()
            claim_crds = [
                crd for crd in (crds or [])
                if 'claim' in (crd.get('categories', []) or [])
            ]

            # Fetch claims concurrently
            all_claims = []
            provider_config_refs = []
            composition_refs = []
            composite_refs = []

            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                # Fetch claims for each CRD concurrently
                futures = []
                for crd in claim_crds:
                    future = executor.submit(self._fetch_claims_for_crd, crd, namespace)
                    futures.append((future, crd))

                # Process results and collect refs
                for future, crd in futures:
                    try:
                        items = future.result()
                        for item in items:
                            all_claims.append((item, crd))
                            provider_ref = item.get('spec', {}).get('providerConfigRef', {})
                            if provider_ref and provider_ref.get('name'):
                                provider_config_refs.append(provider_ref)
                            comp_ref = item.get('spec', {}).get('compositionRef', {})
                            if comp_ref and comp_ref.get('name'):
                                composition_refs.append(comp_ref)
                            res_ref = item.get('spec', {}).get('resourceRef', {})
                            if res_ref and res_ref.get('name'):
                                composite_refs.append(res_ref)
                    except Exception as e:
                        logger.error(f"Error fetching claims for CRD: {e}")

            # Fetch related resources concurrently
            with ThreadPoolExecutor(max_workers=3) as executor:
                provider_configs_future = executor.submit(self._get_provider_configs, provider_config_refs)
                compositions_future = executor.submit(self._get_compositions, composition_refs)
                composites_future = executor.submit(self._get_composite_resources, composite_refs)

                provider_configs = provider_configs_future.result()
                compositions = compositions_future.result()
                composite_resources = composites_future.result()

            # Process claims concurrently
            processed_claims = []
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [
                    executor.submit(
                        self._process_claim,
                        item,
                        crd,
                        provider_configs,
                        compositions,
                        composite_resources
                    )
                    for item, crd in all_claims
                ]

                for future in as_completed(futures):
                    try:
                        processed_claim = future.result()
                        if processed_claim:
                            processed_claims.append(processed_claim)
                    except Exception as e:
                        logger.error(f"Error processing claim: {e}")

            # Fetch events for all claims concurrently
            event_names = []
            for claim in processed_claims:
                event_names.append(claim['metadata']['name'])
                if claim.get('compositeResource', {}).get('name'):
                    event_names.append(claim['compositeResource']['name'])

            events = self._get_events(event_names, namespace)

            # Add events to claims
            for claim in processed_claims:
                all_events = []
                all_events.extend(events.get(claim['metadata']['name'], []))
                if claim.get('compositeResource', {}).get('name'):
                    all_events.extend(events.get(claim['compositeResource']['name'], []))
                all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
                claim['events'] = all_events[:10]

            return processed_claims
        except Exception as e:
            logger.error(f"Error listing claims: {e}")
            return []

    def get_claim(self, name: str, namespace: str = None) -> Optional[dict]:
        """Get a specific claim by name with concurrent processing"""
        try:
            if not self._ensure_connection():
                return None

            namespace = namespace or self.namespace
            logger.debug(f"Getting claim {name} in namespace {namespace}")

            crds = self.get_crossplane_crds()
            claim_crds = [
                crd for crd in (crds or [])
                if 'claim' in (crd.get('categories', []) or [])
            ]

            # Find claim concurrently
            found_claim = None
            found_crd = None
            provider_config_refs = []
            composition_refs = []
            composite_refs = []

            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = []
                for crd in claim_crds:
                    future = executor.submit(
                        self.custom_api.get_namespaced_custom_object,
                        group=crd['group'],
                        version=crd['version'],
                        namespace=namespace,
                        plural=crd['name'].split('.')[0].lower(),
                        name=name
                    )
                    futures.append((future, crd))

                for future, crd in futures:
                    try:
                        claim = future.result()
                        found_claim = claim
                        found_crd = crd
                        provider_ref = claim.get('spec', {}).get('providerConfigRef', {})
                        if provider_ref and provider_ref.get('name'):
                            provider_config_refs.append(provider_ref)
                        comp_ref = claim.get('spec', {}).get('compositionRef', {})
                        if comp_ref and comp_ref.get('name'):
                            composition_refs.append(comp_ref)
                        res_ref = claim.get('spec', {}).get('resourceRef', {})
                        if res_ref and res_ref.get('name'):
                            composite_refs.append(res_ref)
                        break
                    except Exception:
                        continue

            if not found_claim:
                return None

            # Fetch related resources concurrently
            with ThreadPoolExecutor(max_workers=3) as executor:
                provider_configs_future = executor.submit(self._get_provider_configs, provider_config_refs)
                compositions_future = executor.submit(self._get_compositions, composition_refs)
                composites_future = executor.submit(self._get_composite_resources, composite_refs)

                provider_configs = provider_configs_future.result()
                compositions = compositions_future.result()
                composite_resources = composites_future.result()

            # Process claim
            processed_claim = self._process_claim(
                found_claim,
                found_crd,
                provider_configs,
                compositions,
                composite_resources
            )

            # Get events
            event_names = [name]
            if processed_claim.get('compositeResource', {}).get('name'):
                event_names.append(processed_claim['compositeResource']['name'])

            events = self._get_events(event_names, namespace)
            
            # Add events to claim
            all_events = []
            all_events.extend(events.get(name, []))
            if processed_claim.get('compositeResource', {}).get('name'):
                all_events.extend(events.get(processed_claim['compositeResource']['name'], []))
            all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
            processed_claim['events'] = all_events[:10]

            return processed_claim
        except Exception as e:
            logger.error(f"Error getting claim: {e}")
            return None
