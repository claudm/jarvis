// tabs.js - Tab switching functionality
function showLoading() {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
        loadingScreen.classList.remove('hidden');
    }
}

function hideLoading() {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
        loadingScreen.classList.add('hidden');
    }
}

function switchTab(tabId, params = {}) {
    console.log('Switching to tab:', tabId);
    
    // Clean up previous tab
    const previousTab = document.querySelector('[data-tab].active');
    if (previousTab && previousTab.dataset.tab === 'composite-resources') {
        if (typeof cleanup === 'function') {
            cleanup();
        }
    }
    
    // Update active tab
    document.querySelectorAll('[data-tab]').forEach(tab => {
        const isActive = tab.dataset.tab === tabId;
        tab.classList.toggle('active', isActive);
        tab.classList.toggle('text-blue-600', isActive);
        tab.classList.toggle('bg-blue-50', isActive);
        tab.classList.toggle('text-gray-600', !isActive);
    });

    // Hide all panels first
    document.querySelectorAll('.tab-panel').forEach(panel => {
        panel.classList.add('hidden');
        panel.style.display = 'none';
    });

    // Show the selected panel
    const selectedPanel = document.getElementById(`${tabId}-panel`);
    if (selectedPanel) {
        selectedPanel.classList.remove('hidden');
        selectedPanel.style.display = 'block';

        // For non-overview tabs, ensure their list containers exist
        if (tabId !== 'overview') {
            const listContainer = document.getElementById(`${tabId}-list`);
            if (!listContainer) {
                const container = document.createElement('div');
                container.id = `${tabId}-list`;
                container.className = 'space-y-4';
                selectedPanel.appendChild(container);
            }
        }
    } else {
        console.debug(`Panel not found for tab: ${tabId}`);
    }

    // Update header text immediately
    const headerElement = document.getElementById('current-section');
    if (headerElement) {
        // Get the active tab element to use its text content
        const activeTab = document.querySelector(`[data-tab="${tabId}"]`);
        if (activeTab) {
            // Get text content from the tab-text span
            const tabTextElement = activeTab.querySelector('.tab-text');
            const tabText = tabTextElement ? tabTextElement.textContent.trim() : activeTab.dataset.tab;
            headerElement.textContent = tabText;
            console.log('Updated header to:', tabText);
        } else {
            // Fallback to default title
            const defaultTitle = headerElement.getAttribute('data-default-title');
            headerElement.textContent = defaultTitle;
            console.log('Restored default header:', defaultTitle);
        }
    } else {
        console.warn('Header element not found');
    }

    // Show/hide namespace selector based on tab
    const namespaceContainer = document.getElementById('namespace-container');
    if (namespaceContainer) {
        namespaceContainer.classList.toggle('hidden', tabId !== 'claims');
    }

    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('tab', tabId);
    Object.entries(params).forEach(([key, value]) => {
        if (value) {
            url.searchParams.set(key, value);
        } else {
            url.searchParams.delete(key);
        }
    });
    window.history.pushState({}, '', url);

    // Apply filters from URL
    const searchParams = new URLSearchParams(window.location.search);
    if (searchParams.has('status')) {
        const statusFilter = document.getElementById('status-filter');
        if (statusFilter) {
            statusFilter.value = searchParams.get('status');
        }
    }
    if (searchParams.has('search')) {
        const searchInput = document.getElementById('resource-search');
        if (searchInput) {
            searchInput.value = searchParams.get('search');
        }
    }
    if (searchParams.has('providerconfig')) {
        const providerConfigFilter = document.getElementById('providerconfig-filter');
        if (providerConfigFilter) {
            providerConfigFilter.value = searchParams.get('providerconfig');
        }
    }

    // Load data for the tab
    loadTabData(tabId);
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    // Initialize navigation links
    document.querySelectorAll('[data-tab]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = link.dataset.tab;
            
            // Update active state and switch tab
            switchTab(tabId);
        });
    });

    // Load initial tab from URL or default to overview
    const searchParams = new URLSearchParams(window.location.search);
    const initialTab = searchParams.get('tab') || 'overview';
    
    // Ensure the tab exists before switching
    const tabElement = document.querySelector(`[data-tab="${initialTab}"]`);
    if (tabElement) {
        const params = {
            status: searchParams.get('status'),
            search: searchParams.get('search'),
            providerconfig: searchParams.get('providerconfig')
        };
        console.log('Initial tab switch:', { initialTab, tabElement });
        switchTab(initialTab, params);
    } else {
        console.warn('Initial tab not found:', initialTab);
        // Fall back to overview if the requested tab doesn't exist
        switchTab('overview');
    }

    // Handle browser back/forward
    window.addEventListener('popstate', () => {
        const searchParams = new URLSearchParams(window.location.search);
        const tabId = searchParams.get('tab') || 'overview';
        const params = {
            status: searchParams.get('status'),
            search: searchParams.get('search'),
            providerconfig: searchParams.get('providerconfig')
        };
        switchTab(tabId, params);
    });
});

// Load data for specific tabs
function loadTabData(tabId) {
    // Show loading screen
    showLoading();

    // Skip container check for overview tab since it has a different structure
    if (tabId === 'overview') {
        fetch('/api/overview')
            .then(response => response.json())
            .then(data => {
                if (window.renderOverview) {
                    window.renderOverview(data);
                }
            })
            .catch(error => {
                console.error('Error loading overview:', error);
                const panel = document.getElementById('overview-panel');
                if (panel) {
                    panel.innerHTML = '<div class="p-4 text-center text-red-500">Failed to load overview</div>';
                }
            })
            .finally(() => {
                hideLoading();
            });
        return;
    }

    const container = document.getElementById(`${tabId}-list`);
    if (!container) {
        hideLoading();
        return;
    }

    // Clear container and show loading message
    container.innerHTML = '<div class="p-4 text-center text-gray-500">Loading...</div>';

    switch (tabId) {
        case 'compositions':
            fetch('/api/compositions')
                .then(response => response.json())
                .then(data => {
                    if (window.renderCompositions) {
                        window.renderCompositions(container, data.compositions || []);
                    }
                })
                .catch(error => {
                    console.error('Error loading compositions:', error);
                    container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to load compositions</div>';
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        case 'composite-resource-definitions':
            fetch('/api/composite-resource-definitions')
                .then(response => response.json())
                .then(data => {
                    if (window.renderCompositeResourceDefinitions) {
                        window.renderCompositeResourceDefinitions(container, data);
                    }
                })
                .catch(error => {
                    console.error('Error loading composite resource definitions:', error);
                    container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to load composite resource definitions</div>';
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        case 'composite-resources':
            fetch('/api/composite-resources')
                .then(response => response.json())
                .then(data => {
                    if (window.renderCompositeResources) {
                        window.renderCompositeResources(container, data.resources || []);
                    }
                })
                .catch(error => {
                    console.error('Error loading composite resources:', error);
                    container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to load composite resources</div>';
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        case 'claims':
            fetch('/api/claims')
                .then(response => response.json())
                .then(data => {
                    if (window.renderClaims) {
                        window.renderClaims(container, data.claims || []);
                    }
                })
                .catch(error => {
                    console.error('Error loading claims:', error);
                    container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to load claims</div>';
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        case 'providers':
            fetch('/api/providers')
                .then(response => response.json())
                .then(data => {
                    if (window.renderProviders) {
                        window.renderProviders(container, data.providers || []);
                    }
                })
                .catch(error => {
                    console.error('Error loading providers:', error);
                    container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to load providers</div>';
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        case 'providerconfigs':
            fetch('/api/providerconfigs')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.debug('Provider configs data:', data);
                    if (window.renderProviderConfigs) {
                        window.renderProviderConfigs(container, data);
                    } else {
                        console.error('renderProviderConfigs function not found');
                        container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to render provider configurations</div>';
                    }
                })
                .catch(error => {
                    console.error('Error loading provider configs:', error);
                    container.innerHTML = `<div class="p-4 text-center text-red-500">Failed to load provider configurations: ${error.message}</div>`;
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        case 'managed-resources':
            // Get current filter values
            const statusFilter = document.getElementById('status-filter')?.value;
            const searchInput = document.getElementById('resource-search')?.value;
            const providerConfigFilter = document.getElementById('providerconfig-filter')?.value;
            
            // Build URL with filters
            const url = new URL('/api/managed-resources', window.location.origin);
            if (statusFilter) url.searchParams.set('status', statusFilter);
            if (searchInput) url.searchParams.set('search', searchInput);
            if (providerConfigFilter) url.searchParams.set('providerconfig', providerConfigFilter);
            
            // Load managed resources with filters
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (!data) {
                        throw new Error('No data received from server');
                    }
                    if (window.renderManagedResources) {
                        window.renderManagedResources(container, data);
                    } else {
                        console.error('renderManagedResources function not found');
                        container.innerHTML = '<div class="p-4 text-center text-red-500">Failed to render managed resources</div>';
                    }
                })
                .catch(error => {
                    console.error('Error loading managed resources:', error);
                    container.innerHTML = `<div class="p-4 text-center text-red-500">Failed to load managed resources: ${error.message}</div>`;
                })
                .finally(() => {
                    hideLoading();
                });
            break;
        default:
            hideLoading();
            break;
    }
}

// Export functions
window.switchTab = switchTab;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
