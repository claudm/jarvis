from flask import Blueprint, jsonify, request
from models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('providerconfigs', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

@bp.route('/providerconfigs', methods=['GET'])
def list_provider_configs():
    """List all provider configurations"""
    try:
        logger.info("Attempting to list Provider Configurations from Kubernetes API")
        manager = CrossplaneManager.get_instance()
        
        # First check if we have any providers installed
        providers = manager.list_providers()
        if not providers:
            logger.warning("No providers installed in the cluster")
            return jsonify({
                "items": [],
                "count": 0,
                "message": "No providers installed in the cluster"
            })
            
        # Get provider configurations
        configs = manager.list_provider_configs()
        logger.info(f"Retrieved {len(configs)} Provider Configurations")
        
        # Process configs to extract relevant data
        processed_configs = []
        for config in configs:
            processed_config = {
                'apiVersion': config.get('apiVersion'),
                'kind': config.get('kind'),
                'metadata': {
                    'name': config.get('metadata', {}).get('name'),
                    'creationTimestamp': config.get('metadata', {}).get('creationTimestamp')
                },
                'spec': config.get('spec', {}),
                'status': config.get('status', {})
            }
            processed_configs.append(processed_config)

        return jsonify({
            "items": processed_configs,
            "count": len(processed_configs),
            "message": "No Provider Configurations found" if not processed_configs else None
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing Provider Configurations: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list Provider Configurations"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Provider Configurations resource not found"}), 404
        else:
            return jsonify({"error": f"Failed to list Provider Configurations: {error_msg}"}), 500

@bp.route('/providerconfigs/<name>', methods=['GET'])
def get_provider_config(name):
    """Get a specific provider configuration"""
    try:
        logger.info(f"Attempting to get Provider Configuration: {name}")
        manager = CrossplaneManager.get_instance()
        config = manager.get_provider_config(name)
        if not config:
            logger.warning(f"Provider Configuration not found: {name}")
            return jsonify({"error": f"Provider Configuration '{name}' not found"}), 404
        return jsonify(config)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting Provider Configuration {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get Provider Configuration"}), 403
        else:
            return jsonify({"error": f"Failed to get Provider Configuration: {error_msg}"}), 500
