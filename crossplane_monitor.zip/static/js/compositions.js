import { BaseController } from '/static/js/base.js';
import { utils, api } from '/static/js/main.js';

class CompositionsController extends BaseController {
    constructor() {
        super('compositionsGrid');
        this.setupSearch();
        this.setupFilters();
        this.setupModal();
    }

    setupSearch() {
        const searchInput = document.getElementById('compositionSearch');
        searchInput.addEventListener('input', () => this.filterCompositions());
    }

    setupFilters() {
        const modeFilter = document.getElementById('compositionModeFilter');
        modeFilter.addEventListener('change', () => this.filterCompositions());
    }

    setupModal() {
        this.modal = document.getElementById('compositionModal');
        this.modalContent = document.getElementById('compositionTabContent');
        
        // Setup dos botões de tab
        document.querySelectorAll('.composition-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });
        
        // Setup do botão de fechar
        document.getElementById('closeCompositionModal').addEventListener('click', 
            () => this.modal.classList.add('hidden'));
    }

    async refresh() {
        this.showLoading();
        try {
            this.data = await api.getCompositions();
            this.renderCompositions();
        } catch (error) {
            this.showError('Failed to load compositions');
        }
        this.hideLoading();
    }

    filterCompositions() {
        const searchTerm = document.getElementById('compositionSearch').value.toLowerCase();
        const modeFilter = document.getElementById('compositionModeFilter').value;
        
        const filtered = this.data.filter(composition => {
            const matchesSearch = composition.name.toLowerCase().includes(searchTerm);
            const matchesMode = !modeFilter || composition.mode === modeFilter;
            return matchesSearch && matchesMode;
        });
        
        this.renderCompositions(filtered);
    }

    renderCompositions(compositions = this.data) {
        const html = compositions.map(comp => `
            <div class="bg-white shadow rounded-lg hover:shadow-md transition-shadow duration-200 cursor-pointer"
                 data-composition="${comp.name}">
                <div class="px-4 py-5 sm:p-6">
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="text-lg font-medium text-gray-900">${comp.name}</h3>
                            <p class="mt-1 text-sm text-gray-500">
                                Type: ${comp.type_ref.kind}
                            </p>
                        </div>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            ${comp.mode}
                        </span>
                    </div>
                    
                    <div class="mt-4 flex justify-between items-center">
                        <div class="text-sm text-gray-500">
                            Resources: ${comp.resources.length}
                        </div>
                        <button class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        this.container.innerHTML = html;
        
        // Adiciona event listeners para os cards
        this.container.querySelectorAll('[data-composition]').forEach(card => {
            card.addEventListener('click', () => this.showCompositionDetails(card.dataset.composition));
        });
    }

    async showCompositionDetails(compositionName) {
        try {
            const details = await api.getCompositionDetails(compositionName);
            this.modal.classList.remove('hidden');
            document.getElementById('modalTitle').textContent = compositionName;
            this.showTab('overview', details);
        } catch (error) {
            utils.showError(`Failed to load composition details: ${error.message}`);
        }
    }

    async switchTab(tabName) {
        const compositionName = document.getElementById('modalTitle').textContent;
        const details = await api.getCompositionDetails(compositionName);
        this.showTab(tabName, details);
    }

    showTab(tabName, data) {
        // Atualiza classes ativas dos botões
        document.querySelectorAll('.composition-tab-btn').forEach(btn => {
            btn.classList.toggle('bg-gray-100', btn.dataset.tab === tabName);
        });

        // Renderiza conteúdo baseado na tab
        switch(tabName) {
            case 'overview':
                this.renderOverviewTab(data);
                break;
            case 'resources':
                this.renderResourcesTab(data);
                break;
            case 'patches':
                this.renderPatchesTab(data);
                break;
        }
    }

    renderOverviewTab(data) {
        const html = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-2">Composition Details</h4>
                    <dl class="grid grid-cols-1 gap-2">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Type Reference</dt>
                            <dd class="text-sm text-gray-900">
                                ${data.details.type_ref.kind} (${data.details.type_ref.apiVersion})
                            </dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Mode</dt>
                            <dd class="text-sm text-gray-900">${data.details.mode}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Resources</dt>
                            <dd class="text-sm text-gray-900">${data.details.resources.length} defined</dd>
                        </div>
                    </dl>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-2">Resource Usage</h4>
                    <canvas id="resourceUsageChart" height="200"></canvas>
                </div>
            </div>
            
            <div class="mt-4">
                <h4 class="text-sm font-medium text-gray-500 mb-2">Composite Resources</h4>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Resources</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            ${(data.resources || []).map(resource => `
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        ${resource.name}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        ${utils.createStatusBadge(resource.status)}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        ${resource.resources.length} managed
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        ${utils.formatDate(resource.created_at)}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
        
        // Inicializa gráfico de uso de recursos
        if (data.resources && data.resources.length > 0) {
            this.initializeResourceUsageChart(data.resources);
        }
    }

    initializeResourceUsageChart(resources) {
        const ctx = document.getElementById('resourceUsageChart').getContext('2d');
        const resourceCounts = resources.reduce((acc, resource) => {
            resource.resources.forEach(r => {
                const kind = r.kind;
                acc[kind] = (acc[kind] || 0) + 1;
            });
            return acc;
        }, {});

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(resourceCounts),
                datasets: [{
                    label: 'Resource Count',
                    data: Object.values(resourceCounts),
                    backgroundColor: 'rgba(79, 70, 229, 0.2)',
                    borderColor: 'rgba(79, 70, 229, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }

    renderResourcesTab(data) {
        const resources = data.details.resources;
        const html = `
            <div class="space-y-4">
                ${resources.map((resource, index) => `
                    <div class="bg-gray-50 rounded-lg p-4">
                        <div class="flex justify-between items-start mb-2">
                            <h4 class="text-sm font-medium text-gray-900">
                                Resource ${index + 1}: ${resource.base.kind}
                            </h4>
                            <span class="text-xs text-gray-500">
                                ${resource.base.apiVersion}
                            </span>
                        </div>
                        
                        <div class="mt-2 space-y-2">
                            <div class="text-sm">
                                <span class="font-medium text-gray-500">Base Template:</span>
                                <pre class="mt-1 bg-white p-2 rounded overflow-auto">
                                    ${JSON.stringify(resource.base, null, 2)}
                                </pre>
                            </div>
                            
                            <div class="text-sm">
                                <span class="font-medium text-gray-500">Patches:</span>
                                ${resource.patches.length > 0 ? `
                                    <div class="mt-1 space-y-2">
                                        ${resource.patches.map(patch => `
                                            <div class="bg-white p-2 rounded">
                                                <div class="flex justify-between items-center">
                                                    <span class="font-medium">${patch.type}</span>
                                                    ${patch.patchSetName ? `
                                                        <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                                            PatchSet: ${patch.patchSetName}
                                                        </span>
                                                    ` : ''}
                                                </div>
                                                <pre class="mt-1 text-xs overflow-auto">
                                                    ${JSON.stringify(patch, null, 2)}
                                                </pre>
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : '<div class="text-gray-500">No patches defined</div>'}
                            </div>
                            
                            ${resource.connectionDetails.length > 0 ? `
                                <div class="text-sm">
                                    <span class="font-medium text-gray-500">Connection Details:</span>
                                    <div class="mt-1 bg-white p-2 rounded">
                                        <ul class="list-disc list-inside">
                                            ${resource.connectionDetails.map(detail => `
                                                <li>${detail.name}</li>
                                            `).join('')}
                                        </ul>
                                    </div>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }

    renderPatchesTab(data) {
        const patchSets = data.details.patch_sets || [];
        const patchAnalysis = data.details.patches_analysis || {};
        
        const html = `
            <div class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Patch Statistics</h4>
                        <dl class="grid grid-cols-2 gap-2">
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Total Patches</dt>
                                <dd class="text-2xl font-semibold text-gray-900">
                                    ${patchAnalysis.total_patches || 0}
                                </dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Resources with Patches</dt>
                                <dd class="text-2xl font-semibold text-gray-900">
                                    ${patchAnalysis.resources_with_patches || 0}
                                </dd>
                            </div>
                        </dl>
                    </div>
                    
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Patches by Type</h4>
                        <canvas id="patchesTypeChart" height="200"></canvas>
                    </div>
                </div>

                <div class="space-y-4">
                    <h4 class="text-md font-medium text-gray-900">Patch Sets</h4>
                    ${patchSets.length > 0 ? `
                        ${patchSets.map(patchSet => `
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex justify-between items-start mb-2">
                                    <h5 class="text-sm font-medium text-gray-900">${patchSet.name}</h5>
                                    <span class="text-xs text-gray-500">
                                        ${patchSet.patches.length} patches
                                    </span>
                                </div
                            <div class="space-y-2">
                                    ${patchSet.patches.map(patch => `
                                        <div class="bg-white p-2 rounded">
                                            <div class="flex justify-between items-center">
                                                <span class="font-medium">${patch.type}</span>
                                            </div>
                                            <pre class="mt-1 text-xs overflow-auto">
                                                ${JSON.stringify(patch, null, 2)}
                                            </pre>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                    ` : '<div class="text-gray-500">No patch sets defined</div>'}
                </div>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
        
        // Inicializa gráfico de tipos de patches
        if (patchAnalysis.patches_by_type) {
            this.initializePatchesTypeChart(patchAnalysis.patches_by_type);
        }
    }

    initializePatchesTypeChart(patchesByType) {
        const ctx = document.getElementById('patchesTypeChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(patchesByType),
                datasets: [{
                    data: Object.values(patchesByType),
                    backgroundColor: [
                        'rgba(79, 70, 229, 0.2)',
                        'rgba(16, 185, 129, 0.2)',
                        'rgba(245, 158, 11, 0.2)',
                        'rgba(239, 68, 68, 0.2)',
                        'rgba(107, 114, 128, 0.2)'
                    ],
                    borderColor: [
                        'rgba(79, 70, 229, 1)',
                        'rgba(16, 185, 129, 1)',
                        'rgba(245, 158, 11, 1)',
                        'rgba(239, 68, 68, 1)',
                        'rgba(107, 114, 128, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

// Funções utilitárias específicas para o controlador de Compositions
const compositionUtils = {
    getResourceIcon(kind) {
        const icons = {
            'Database': 'database',
            'Bucket': 'folder',
            'Network': 'globe',
            'Compute': 'server',
            'default': 'box'
        };
        return icons[kind] || icons.default;
    },

    formatPatchType(type) {
        return type.replace(/([A-Z])/g, ' $1').trim();
    },

    summarizeResources(resources) {
        const summary = {};
        resources.forEach(resource => {
            const kind = resource.kind;
            summary[kind] = (summary[kind] || 0) + 1;
        });
        return summary;
    }
};

// Exporta o controlador e utilitários
export { CompositionsController, compositionUtils };