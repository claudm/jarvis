async function showResourceDescribe(service, type, name) {
    const modal = document.getElementById('describeModal');
    const modalContent = document.getElementById('describeModalContent');
    const modalTitle = document.getElementById('describeModalTitle');
    const syncedStatus = document.getElementById('syncedStatus');
    const readyStatus = document.getElementById('readyStatus');
    
    try {
        modalContent.innerHTML = `<div class="flex justify-center items-center py-4"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>`;
        modal.classList.remove('hidden');
        
        const response = await fetch(`/api/providers/resources/describe/${service}/${type}/${name}`);
        const data = await response.json();
        
        if (response.ok) {
            modalTitle.textContent = `${type}: ${name}`;
            
            // Extract status from conditions
            const conditions = data.resource?.status?.conditions || [];
            const syncedCondition = conditions.find(c => c.type === 'Synced');
            const readyCondition = conditions.find(c => c.type === 'Ready');
            
            const isSynced = syncedCondition?.status === 'True';
            const isReady = readyCondition?.status === 'True';

            // Update Synced badge
            syncedStatus.textContent = `Synced: ${syncedCondition?.status || 'Unknown'}`;
            syncedStatus.className = `px-2 py-1 text-xs font-medium rounded-full ${isSynced ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`;
            syncedStatus.classList.remove('hidden');

            // Update Ready badge
            readyStatus.textContent = `Ready: ${readyCondition?.status || 'Unknown'}`;
            readyStatus.className = `px-2 py-1 text-xs font-medium rounded-full ${isReady ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`;
            readyStatus.classList.remove('hidden');

            // Display resource details
            modalContent.innerHTML = `<div class="bg-gray-100 p-3 rounded-lg font-mono text-sm"><pre class="whitespace-pre-wrap overflow-x-auto">${data.describe}</pre></div>`;
        } else {
            throw new Error(data.error || `HTTP error! status: ${response.status}`);
        }
    } catch (error) {
        console.error('Error:', error);
        modalContent.innerHTML = `
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Error Loading Resource Details</strong>
                <p class="text-sm">${error.message}</p>
                <div class="mt-2">
                    <details class="text-sm">
                        <summary class="cursor-pointer">Debug Information</summary>
                        <pre class="mt-2 text-xs">Service: ${service}
Type: ${type}
Name: ${name}</pre>
                    </details>
                </div>
            </div>
        `;
    }
}