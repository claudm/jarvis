import { BaseController } from '/static/js/base.js';
import { utils, api } from '/static/js/main.js';

class ConfigurationsController extends BaseController {
    constructor() {
        super('configurationsGrid');
        this.setupSearch();
        this.setupFilters();
        this.setupModal();
        this.charts = {};
    }

    setupSearch() {
        const searchInput = document.getElementById('configSearch');
        searchInput.addEventListener('input', () => this.filterConfigurations());
    }

    setupFilters() {
        const statusFilter = document.getElementById('configStatusFilter');
        statusFilter.addEventListener('change', () => this.filterConfigurations());
    }

    setupModal() {
        this.modal = document.getElementById('configModal');
        this.modalContent = document.getElementById('configTabContent');
        
        // Setup tab buttons
        document.querySelectorAll('.config-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });
        
        // Setup close button
        document.getElementById('closeConfigModal').addEventListener('click', 
            () => this.hideModal());
    }

    hideModal() {
        this.modal.classList.add('hidden');
        // Clear active charts
        Object.values(this.charts).forEach(chart => chart.destroy());
        this.charts = {};
    }

    async refresh() {
        this.showLoading();
        try {
            this.data = await api.getConfigurations();
            this.renderConfigurations();
        } catch (error) {
            this.showError('Failed to load configurations');
        }
        this.hideLoading();
    }

    filterConfigurations() {
        const searchTerm = document.getElementById('configSearch').value.toLowerCase();
        const statusFilter = document.getElementById('configStatusFilter').value;
        
        const filtered = this.data.filter(config => {
            const matchesSearch = config.name.toLowerCase().includes(searchTerm);
            const matchesStatus = !statusFilter || config.status === statusFilter;
            return matchesSearch && matchesStatus;
        });
        
        this.renderConfigurations(filtered);
    }

    renderConfigurations(configurations = this.data) {
        const html = configurations.map(config => `
            <div class="bg-white shadow rounded-lg hover:shadow-md transition-shadow duration-200 cursor-pointer"
                 data-config="${config.name}">
                <div class="px-4 py-5 sm:p-6">
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="text-lg font-medium text-gray-900">${config.name}</h3>
                            <p class="mt-1 text-sm text-gray-500">
                                Type: ${config.package_type}
                            </p>
                        </div>
                        ${utils.createStatusBadge(config.status)}
                    </div>
                    
                    <div class="mt-4 grid grid-cols-2 gap-4 text-sm text-gray-500">
                        <div>
                            <span class="font-medium">Revision:</span>
                            ${config.revision || 'None'}
                        </div>
                        <div>
                            <span class="font-medium">Policy:</span>
                            ${config.revision_activation_policy}
                        </div>
                    </div>

                    <div class="mt-4 flex justify-between items-center">
                        <div class="text-sm text-gray-500">
                            Created: ${utils.formatDate(config.created_at)}
                        </div>
                        <button class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        this.container.innerHTML = html;
        
        // Add event listeners for cards
        this.container.querySelectorAll('[data-config]').forEach(card => {
            card.addEventListener('click', () => this.showConfigurationDetails(card.dataset.config));
        });
    }

    async showConfigurationDetails(configName) {
        try {
            const details = await api.getConfigurationDetails(configName);
            this.modal.classList.remove('hidden');
            document.getElementById('modalTitle').textContent = configName;
            this.showTab('overview', details);
        } catch (error) {
            utils.showError(`Failed to load configuration details: ${error.message}`);
        }
    }

    async switchTab(tabName) {
        const configName = document.getElementById('modalTitle').textContent;
        const details = await api.getConfigurationDetails(configName);
        this.showTab(tabName, details);
    }

    showTab(tabName, data) {
        // Update active button classes
        document.querySelectorAll('.config-tab-btn').forEach(btn => {
            btn.classList.toggle('bg-gray-100', btn.dataset.tab === tabName);
        });

        // Clear existing charts
        Object.values(this.charts).forEach(chart => chart.destroy());
        this.charts = {};

        // Render content based on selected tab
        switch(tabName) {
            case 'overview':
                this.renderOverviewTab(data);
                break;
            case 'packages':
                this.renderPackagesTab(data);
                break;
            case 'revisions':
                this.renderRevisionsTab(data);
                break;
            case 'events':
                this.renderEventsTab(data);
                break;
            case 'metrics':
                this.renderMetricsTab(data);
                break;
        }
    }

    renderOverviewTab(data) {
        const html = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-2">Configuration Details</h4>
                    <dl class="grid grid-cols-1 gap-2">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Package Type</dt>
                            <dd class="text-sm text-gray-900">${data.status.packageType}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Current Revision</dt>
                            <dd class="text-sm text-gray-900">${data.status.currentRevision}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Revision Policy</dt>
                            <dd class="text-sm text-gray-900">${data.status.revisionActivationPolicy}</dd>
                        </div>
                    </dl>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-2">Status</h4>
                    <dl class="grid grid-cols-1 gap-2">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Health Status</dt>
                            <dd class="text-sm">${utils.createStatusBadge(data.status.status)}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Created</dt>
                            <dd class="text-sm text-gray-900">${utils.formatDate(data.status.created_at)}</dd>
                        </div>
                    </dl>
                </div>
            </div>

            <div class="mt-4">
                <h4 class="text-sm font-medium text-gray-500 mb-2">Dependencies</h4>
                ${this.renderDependenciesSection(data.status.dependencies)}
            </div>

            <div class="mt-4">
                <h4 class="text-sm font-medium text-gray-500 mb-2">Conditions</h4>
                ${this.renderConditionsSection(data.status.conditions)}
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }

    renderDependenciesSection(dependencies) {
        if (!dependencies || dependencies.length === 0) {
            return '<div class="text-sm text-gray-500">No dependencies defined</div>';
        }

        return `
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Provider</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Version</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        ${dependencies.map(dep => `
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    ${dep.type}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    ${dep.provider}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    ${dep.version}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    ${utils.createStatusBadge(dep.status)}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    renderConditionsSection(conditions) {
        if (!conditions || conditions.length === 0) {
            return '<div class="text-sm text-gray-500">No conditions reported</div>';
        }

        return `
            <div class="space-y-2">
                ${conditions.map(condition => `
                    <div class="bg-white p-3 rounded-lg border">
                        <div class="flex justify-between items-center">
                            <span class="font-medium">${condition.type}</span>
                            ${utils.createStatusBadge(condition.status)}
                        </div>
                        ${condition.message ? `
                            <p class="mt-1 text-sm text-gray-500">${condition.message}</p>
                        ` : ''}
                        <p class="mt-1 text-xs text-gray-400">
                            Last updated: ${utils.formatDate(condition.lastTransitionTime)}
                        </p>
                    </div>
                `).join('')}
            </div>
        `;
    }
   

    renderPackagesTab(data) {
        const packages = data.status.packages || { xrds: [], compositions: [] };
        
        const html = `
            <div class="space-y-6">
                <!-- XRDs Section -->
                <div>
                    <h4 class="text-md font-medium text-gray-900 mb-2">Composite Resource Definitions</h4>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Group</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Versions</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                ${packages.xrds.map(xrd => `
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            ${xrd.name}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            ${xrd.group}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            ${xrd.versions.map(v => v.name).join(', ')}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            ${utils.createStatusBadge(xrd.status)}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Compositions Section -->
                <div>
                    <h4 class="text-md font-medium text-gray-900 mb-2">Compositions</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        ${packages.compositions.map(comp => `
                            <div class="bg-white shadow rounded-lg p-4">
                                <div class="flex justify-between items-start">
                                    <h5 class="text-sm font-medium text-gray-900">${comp.name}</h5>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        ${comp.mode}
                                    </span>
                                </div>
                                <div class="mt-2">
                                    <p class="text-sm text-gray-500">
                                        Type: ${comp.type_ref.kind}
                                    </p>
                                    <p class="text-sm text-gray-500">
                                        Resources: ${comp.resources_count}
                                    </p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }

    renderRevisionsTab(data) {
        const revisions = data.status.revisions || [];
        
        const html = `
            <div class="space-y-4">
                <div class="bg-gray-50 rounded-lg p-4">
                    <dl class="grid grid-cols-2 gap-4">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Total Revisions</dt>
                            <dd class="mt-1 text-2xl font-semibold text-gray-900">${revisions.length}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Active Revision</dt>
                            <dd class="mt-1 text-2xl font-semibold text-gray-900">
                                ${data.status.currentRevision || 'None'}
                            </dd>
                        </div>
                    </dl>
                </div>

                <div class="bg-white shadow overflow-hidden sm:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revision</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Desired State</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            ${revisions.map(rev => `
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        ${rev.revision}
                                        ${rev.revision === data.status.currentRevision ? `
                                            <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                Current
                                            </span>
                                        ` : ''}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        ${utils.createStatusBadge(rev.status)}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        ${rev.desired_state}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        ${utils.formatDate(rev.created_at)}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }

    renderEventsTab(data) {
        const events = data.events || [];
        
        const html = `
            <div class="space-y-4">
                ${events.map(event => `
                    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
                        <div class="px-4 py-4 sm:px-6">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    ${utils.createStatusBadge(event.type)}
                                    <p class="ml-2 text-sm font-medium text-gray-900">
                                        ${event.reason}
                                    </p>
                                </div>
                                <div class="text-sm text-gray-500">
                                    ${utils.formatDate(event.last_timestamp)}
                                </div>
                            </div>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500">${event.message}</p>
                            </div>
                            <div class="mt-2 text-xs text-gray-400">
                                <span>Count: ${event.count}</span>
                                <span class="mx-2">|</span>
                                <span>First seen: ${utils.formatDate(event.first_timestamp)}</span>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }

    renderMetricsTab(data) {
        const metrics = data.metrics || {};
        
        const html = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- XRDs Metrics -->
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-4">XRDs</h4>
                    <canvas id="xrdsMetricsChart" height="200"></canvas>
                </div>

                <!-- Compositions Metrics -->
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-4">Compositions</h4>
                    <canvas id="compositionsMetricsChart" height="200"></canvas>
                </div>

                <!-- Revisions Metrics -->
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-4">Revisions</h4>
                    <canvas id="revisionsMetricsChart" height="200"></canvas>
                </div>

                <!-- Overall Stats -->
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="text-sm font-medium text-gray-500 mb-4">Overview</h4>
                    <dl class="grid grid-cols-2 gap-4">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Total XRDs</dt>
                            <dd class="text-2xl font-semibold text-gray-900">${metrics.xrds.total}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Total Compositions</dt>
                            <dd class="text-2xl font-semibold text-gray-900">${metrics.compositions.total}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Total Revisions</dt>
                            <dd class="text-2xl font-semibold text-gray-900">${metrics.revisions.total}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Healthy Revisions</dt>
                            <dd class="text-2xl font-semibold text-gray-900">${metrics.revisions.healthy}</dd>
                        </div>
                    </dl>
                </div>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
        
        // Initialize charts
        this.initializeMetricsCharts(metrics);
    }

    initializeMetricsCharts(metrics) {
        // XRDs Chart
        this.charts.xrds = new Chart(document.getElementById('xrdsMetricsChart').getContext('2d'), {
            type: 'pie',
            data: {
                labels: ['Established', 'Not Established'],
                datasets: [{
                    data: [metrics.xrds.established, metrics.xrds.total - metrics.xrds.established],
                    backgroundColor: ['rgba(16, 185, 129, 0.2)', 'rgba(239, 68, 68, 0.2)'],
                    borderColor: ['rgba(16, 185, 129, 1)', 'rgba(239, 68, 68, 1)'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Compositions Chart
        this.charts.compositions = new Chart(document.getElementById('compositionsMetricsChart').getContext('2d'), {
            type: 'bar',
            data: {
                labels: Object.keys(metrics.compositions.by_mode),
                datasets: [{
                    label: 'Compositions by Mode',
                    data: Object.values(metrics.compositions.by_mode),
                    backgroundColor: 'rgba(79, 70, 229, 0.2)',
                    borderColor: 'rgba(79, 70, 229, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Revisions Chart
        this.charts.revisions = new Chart(document.getElementById('revisionsMetricsChart').getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: Object.keys(metrics.revisions.by_state),
                datasets: [{
                    data: Object.values(metrics.revisions.by_state),
                    backgroundColor: [
                        'rgba(16, 185, 129, 0.2)',
                        'rgba(245, 158, 11, 0.2)',
                        'rgba(239, 68, 68, 0.2)'
                    ],
                    borderColor: [
                        'rgba(16, 185, 129, 1)',
                        'rgba(245, 158, 11, 1)',
                        'rgba(239, 68, 68, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

// Export the controller
export { ConfigurationsController };