# config/settings.py
import os
from datetime import timedelta

class BaseConfig:
    """Configuração base"""
    
    # Flask
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    DEBUG = True
    TESTING = False
    
    # Crossplane
    CROSSPLANE_NAMESPACE = os.getenv('CROSSPLANE_NAMESPACE', 'crossplane-system')
    REFRESH_INTERVAL = int(os.getenv('REFRESH_INTERVAL', '30'))  # segundos
    
    # Kubernetes
    KUBERNETES_CONTEXT = os.getenv('KUBERNETES_CONTEXT', None)
    KUBERNETES_CONFIG_PATH = os.getenv('KUBERNETES_CONFIG_PATH', None)
    IN_CLUSTER = os.getenv('IN_CLUSTER', 'false').lower() == 'true'
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # Cache
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 300  # 5 minutos
    
    # Session
    SESSION_TYPE = 'filesystem'
    PERMANENT_SESSION_LIFETIME = timedelta(days=1)
    
    # API
    API_TITLE = 'Crossplane Monitor API'
    API_VERSION = 'v1'
    API_PREFIX = '/api'
    
    # UI
    TEMPLATES_AUTO_RELOAD = True
    
    # Monitoramento
    MONITOR_PROVIDERS = True
    MONITOR_CONFIGURATIONS = True
    MONITOR_COMPOSITIONS = True
    MONITOR_CLAIMS = True
    
    # Rate Limiting
    RATELIMIT_ENABLED = True
    RATELIMIT_DEFAULT = "200 per minute"
    RATELIMIT_STORAGE_URL = "memory://"

class DevelopmentConfig(BaseConfig):
    """Configuração para desenvolvimento"""
    
    DEBUG = True
    TEMPLATES_AUTO_RELOAD = True
    
    # Cache em desenvolvimento
    CACHE_TYPE = 'simple'
    
    # Logging mais detalhado
    LOG_LEVEL = 'DEBUG'
    
    # Rate Limiting mais permissivo
    RATELIMIT_DEFAULT = "1000 per minute"
    
    # Arquivo de configuração k8s padrão
    KUBERNETES_CONFIG_PATH = os.path.expanduser('~/.kube/config')

class TestingConfig(BaseConfig):
    """Configuração para testes"""
    
    TESTING = True
    DEBUG = True
    
    # Desativa rate limiting em testes
    RATELIMIT_ENABLED = False
    
    # Cache em memória para testes
    CACHE_TYPE = 'simple'
    
    # Banco de dados em memória para testes
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'

class ProductionConfig(BaseConfig):
    """Configuração para produção"""
    
    DEBUG = False
    TESTING = False
    
    # Cache mais robusto para produção
    CACHE_TYPE = 'redis'
    CACHE_REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    # Rate Limiting mais restritivo
    RATELIMIT_DEFAULT = "100 per minute"
    
    # Logs menos verbosos
    LOG_LEVEL = 'INFO'
    
    # Assume que está rodando dentro do cluster
    IN_CLUSTER = True
    
    # Sessão mais segura
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)
    
    def __init__(self):
        # Garante que SECRET_KEY está definida em produção
        if not os.getenv('SECRET_KEY'):
            raise ValueError('SECRET_KEY must be set in production!')

class DockerConfig(ProductionConfig):
    """Configuração para ambiente Docker"""
    
    # Configurações específicas para Docker
    CACHE_REDIS_URL = os.getenv('REDIS_URL', 'redis://redis:6379/0')
    
    # Assume que está rodando em container
    IN_CLUSTER = False
    KUBERNETES_CONFIG_PATH = '/app/config/kubeconfig'

# Mapeia as configurações por ambiente
configs = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'docker': DockerConfig,
    'default': DevelopmentConfig
}

# Função auxiliar para obter a configuração atual
def get_config():
    env = os.getenv('FLASK_ENV', 'default')
    return configs.get(env, configs['default'])