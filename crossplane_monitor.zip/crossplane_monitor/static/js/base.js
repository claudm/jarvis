// Base controller class for state and UI management
export class BaseController {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.isLoading = false;
        this.data = null;
        this.refreshInterval = null;
        this.setupEventListeners();
        this.startAutoRefresh();
    }

    setupEventListeners() {
        // Implementado por subclasses
    }

    startAutoRefresh(interval = 30000) {
        // Clear any existing interval
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        // Start new refresh interval
        this.refreshInterval = setInterval(() => {
            if (!document.hidden) {
                this.refresh();
            }
        }, interval);
    }

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    showLoading() {
        this.isLoading = true;
        // Adiciona spinner de loading
        this.container.innerHTML = `
            <div class="flex justify-center items-center h-40">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
        `;
    }

    hideLoading() {
        this.isLoading = false;
    }

    showError(message) {
        this.container.innerHTML = `
            <div class="flex flex-col items-center justify-center h-40">
                <div class="text-red-500 mb-2">
                    <svg class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div class="text-gray-600">${message}</div>
            </div>
        `;
    }

    async refresh() {
        // Implementado por subclasses
    }
}