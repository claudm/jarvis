import { BaseController } from '/static/js/base.js';
import { utils, api } from '/static/js/main.js';

class ProvidersController extends BaseController {
    constructor() {
        super('providersTableBody');
        this.setupSearch();
        this.setupFilters();
        this.setupModal();
    }

    setupSearch() {
        const searchInput = document.getElementById('providerSearch');
        searchInput.addEventListener('input', () => this.filterProviders());
    }

    setupFilters() {
        const statusFilter = document.getElementById('providerStatusFilter');
        statusFilter.addEventListener('change', () => this.filterProviders());
    }

    setupModal() {
        this.modal = document.getElementById('providerModal');
        this.modalContent = document.getElementById('providerTabContent');
        
        // Setup dos botões de tab
        document.querySelectorAll('.provider-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });
        
        // Setup do botão de fechar
        document.getElementById('closeProviderModal').addEventListener('click', 
            () => this.modal.classList.add('hidden'));
    }

    async refresh() {
        this.showLoading();
        try {
            this.data = await api.getProviders();
            this.renderProviders();
        } catch (error) {
            this.showError('Failed to load providers');
        }
        this.hideLoading();
    }

    filterProviders() {
        const searchTerm = document.getElementById('providerSearch').value.toLowerCase();
        const statusFilter = document.getElementById('providerStatusFilter').value;
        
        const filtered = this.data.filter(provider => {
            const matchesSearch = provider.name.toLowerCase().includes(searchTerm);
            const matchesStatus = !statusFilter || provider.status === statusFilter;
            return matchesSearch && matchesStatus;
        });
        
        this.renderProviders(filtered);
    }

    renderProviders(providers = this.data) {
        const html = providers.map(provider => `
            <tr class="hover:bg-gray-50 cursor-pointer" data-provider="${provider.name}">
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <div class="text-sm font-medium text-gray-900">
                            ${provider.name}
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    ${utils.createStatusBadge(provider.status)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${provider.package}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${provider.revision}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button class="text-indigo-600 hover:text-indigo-900">
                        Details
                    </button>
                </td>
            </tr>
        `).join('');
        
        this.container.innerHTML = html;
        
        // Adiciona event listeners para as linhas
        this.container.querySelectorAll('tr').forEach(row => {
            row.addEventListener('click', () => this.showProviderDetails(row.dataset.provider));
        });
    }

    async showProviderDetails(providerName) {
        try {
            const details = await api.getProviderDetails(providerName);
            this.modal.classList.remove('hidden');
            document.getElementById('modalTitle').textContent = providerName;
            this.showTab('overview', details);
        } catch (error) {
            utils.showError(`Failed to load provider details: ${error.message}`);
        }
    }

    async switchTab(tabName) {
        const providerName = document.getElementById('modalTitle').textContent;
        const details = await api.getProviderDetails(providerName);
        this.showTab(tabName, details);
    }

    showTab(tabName, data) {
        // Update active state for all tab buttons
        document.querySelectorAll('.provider-tab-btn').forEach(btn => {
            if (btn.dataset.tab === tabName) {
                btn.classList.add('bg-gray-100', 'text-gray-900');
                btn.classList.remove('text-gray-500');
            } else {
                btn.classList.remove('bg-gray-100', 'text-gray-900');
                btn.classList.add('text-gray-500');
            }
        });

        // Clear previous content
        this.modalContent.innerHTML = '<div class="flex justify-center py-4"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>';

        // Import the corresponding tab module dynamically
        import(`/static/js/providers/tabs/${tabName}.js`).then(module => {
            // Render new content after a short delay to ensure loading state is visible
            setTimeout(() => {
                const renderFunction = `render${tabName.charAt(0).toUpperCase() + tabName.slice(1)}Tab`;
                if (typeof module[renderFunction] === 'function') {
                    module[renderFunction](this.modalContent, data);
                } else {
                    console.error(`Tab module does not export ${renderFunction} function`);
                    this.modalContent.innerHTML = '<p class="text-red-500 text-center py-4">Error: Tab content not available</p>';
                }
            }, 100);
        }).catch(error => {
            console.error(`Error loading tab module: ${error}`);
            this.modalContent.innerHTML = '<p class="text-red-500 text-center py-4">Error loading tab content</p>';
        });
    }

    renderResourcesTab(data) {
        const resources = data.resources || {};
        if (Object.keys(resources).length === 0) {
            this.modalContent.innerHTML = '<p class="text-gray-500 text-center py-4">No resources found</p>';
            return;
        }

        const html = Object.entries(resources).map(([type, items]) => `
            <div class="mb-6">
                <h4 class="text-sm font-medium text-gray-500 mb-3">${type}</h4>
                <div class="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            ${items.map(resource => `
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        ${resource.name}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        ${utils.createStatusBadge(resource.status)}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        ${utils.formatDate(resource.created_at)}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `).join('');
        
        this.modalContent.innerHTML = html;
    }

    renderRevisionsTab(data) {
        const revisions = data.revisions || [];
        const html = `
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revision</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Desired State</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        ${revisions.map(rev => `
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    ${rev.version}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    ${utils.createStatusBadge(rev.status)}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    ${rev.desiredState}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    ${utils.formatDate(rev.created_at)}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }

    renderConfigTab(data) {
        const config = data.config || {};
        const html = `
            <div class="bg-gray-50 rounded-lg p-4">
                <pre class="text-sm text-gray-900 overflow-auto">
                    ${JSON.stringify(config, null, 2)}
                </pre>
            </div>
        `;
        
        this.modalContent.innerHTML = html;
    }
}


export { ProvidersController };