// API endpoints configuration
export const API_ENDPOINTS = {
    system: {
        status: '/api/system/status',
        events: '/api/system/events'
    },
    providers: {
        list: '/api/providers',
        details: (name) => `/api/providers/${name}`
    },
    compositions: {
        list: '/api/compositions',
        details: (name) => `/api/compositions/${name}`,
        resources: (name) => `/api/compositions/${name}/resources`
    },
    configurations: {
        list: '/api/configurations',
        details: (name) => `/api/configurations/${name}`,
        packages: (name) => `/api/configurations/${name}/packages`
    }
};

// Utility functions
export const utils = {
    formatDate: (dateString) => {
        const date = new Date(dateString);
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(date);
    },

    getStatusColor: (status) => {
        const colors = {
            healthy: 'green',
            ready: 'green',
            unhealthy: 'red',
            degraded: 'red',
            unknown: 'gray',
            syncing: 'blue'
        };
        return colors[status.toLowerCase()] || 'gray';
    },

    createStatusBadge: (status) => {
        const color = utils.getStatusColor(status);
        return `
            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${color}-100 text-${color}-800">
                ${status}
            </span>
        `;
    },

    showError: (message) => {
        // Implementar notificação de erro
        console.error(message);
    }
};

// API functions
export const api = {
    async fetch(endpoint, options = {}) {
        try {
            const response = await fetch(endpoint, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            utils.showError(`Failed to fetch data: ${error.message}`);
            throw error;
        }
    },

    async getSystemStatus() {
        return await this.fetch(API_ENDPOINTS.system.status);
    },

    async getSystemEvents() {
        return await this.fetch(API_ENDPOINTS.system.events);
    },

    async getProviders() {
        return await this.fetch(API_ENDPOINTS.providers.list);
    },

    async getProviderDetails(name) {
        return await this.fetch(API_ENDPOINTS.providers.details(name));
    },

    async getCompositions() {
        return await this.fetch(API_ENDPOINTS.compositions.list);
    },

    async getCompositionDetails(name) {
        return await this.fetch(API_ENDPOINTS.compositions.details(name));
    },

    async getConfigurations() {
        return await this.fetch(API_ENDPOINTS.configurations.list);
    },

    async getConfigurationDetails(name) {
        return await this.fetch(API_ENDPOINTS.configurations.details(name));
    }
};

import { BaseController } from './base.js';

// Controlador do Overview
class OverviewController extends BaseController {
    constructor() {
        super('systemStatus');
        this.setupCharts();
        this.refresh();
    }

    setupCharts() {
        // Configuração dos gráficos
        this.charts = {
            providers: new Chart(document.getElementById('providersChart').getContext('2d'), {
                type: 'doughnut',
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            }),
            compositions: new Chart(document.getElementById('compositionsChart').getContext('2d'), {
                type: 'doughnut',
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            }),
            configurations: new Chart(document.getElementById('configurationsChart').getContext('2d'), {
                type: 'doughnut',
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            })
        };
    }

    async refresh() {
        this.showLoading();
        try {
            const status = await api.getSystemStatus();
            const events = await api.getSystemEvents();
            await this.updateUI(status, events);
        } catch (error) {
            this.showError('Failed to load system overview');
        }
        this.hideLoading();
    }

    async updateUI(status, events) {
        // Atualiza status cards
        this.updateStatusCards(status);
        // Atualiza eventos recentes
        this.updateRecentEvents(events);
        // Atualiza gráficos
        this.updateCharts(status);
    }

    updateStatusCards(status) {
        const statusHtml = `
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                ${this.createStatusCard('Control Plane', status.status.healthy ? 'healthy' : 'unhealthy')}
                ${this.createStatusCard('Providers', `${status.providers} Active`)}
                ${this.createStatusCard('Compositions', `${status.compositions} Active`)}
                ${this.createStatusCard('Configurations', `${status.configurations} Active`)}
            </div>
        `;
        document.getElementById('systemStatus').innerHTML = statusHtml;
    }

    createStatusCard(title, status) {
        const statusColor = utils.getStatusColor(status);
        return `
            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="px-4 py-5 sm:p-6">
                    <dt class="text-sm font-medium text-gray-500 truncate">
                        ${title}
                    </dt>
                    <dd class="mt-1 text-3xl font-semibold text-${statusColor}-600">
                        ${status}
                    </dd>
                </div>
            </div>
        `;
    }

    updateRecentEvents(events) {
        const eventsTable = document.getElementById('recentEvents');
        const eventsHtml = events.map(event => `
            <tr>
                <td class="px-6 py-4 whitespace-nowrap">
                    ${utils.createStatusBadge(event.type)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    ${event.involved_object.kind}/${event.involved_object.name}
                </td>
                <td class="px-6 py-4">
                    ${event.message}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${utils.formatDate(event.last_timestamp)}
                </td>
            </tr>
        `).join('');
        
        eventsTable.querySelector('tbody').innerHTML = eventsHtml;
    }

    updateCharts(status) {
        // Atualiza gráficos com dados do status
        const chartData = {
            providers: {
                labels: ['Healthy', 'Unhealthy', 'Unknown'],
                data: [
                    status.providers_healthy,
                    status.providers_unhealthy,
                    status.providers_unknown
                ]
            },
            compositions: {
                labels: ['Active', 'Inactive'],
                data: [
                    status.compositions_active,
                    status.compositions_inactive
                ]
            },
            configurations: {
                labels: ['Healthy', 'Unhealthy'],
                data: [
                    status.configurations_healthy,
                    status.configurations_unhealthy
                ]
            }
        };

        Object.keys(this.charts).forEach(key => {
            this.charts[key].data = {
                labels: chartData[key].labels,
                datasets: [{
                    data: chartData[key].data,
                    backgroundColor: [
                        '#10B981', // green
                        '#EF4444', // red
                        '#6B7280'  // gray
                    ]
                }]
            };
            this.charts[key].update();
        });
    }
}

// Inicialização
// Import controllers
import { ProvidersController } from './providers.js';
import { CompositionsController } from './compositions.js';
import { ConfigurationsController } from './configurations.js';

document.addEventListener('DOMContentLoaded', () => {
    // Inicializa controlador baseado na página atual
    const page = document.body.dataset.page;
    let controller;

    switch (page) {
        case 'overview':
            controller = new OverviewController();
            break;
        case 'providers':
            controller = new ProvidersController();
            controller.refresh();
            break;
        case 'compositions':
            controller = new CompositionsController();
            controller.refresh();
            break;
        case 'configurations':
            controller = new ConfigurationsController();
            controller.refresh();
            break;
    }

    // Setup do botão de refresh global
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn && controller) {
        refreshBtn.addEventListener('click', () => controller.refresh());
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (controller) {
            controller.stopAutoRefresh();
        }
    });
});