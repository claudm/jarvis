// /static/js/providers/ui.js
export class ProviderUI {
    setupSearch(callback) {
        const searchInput = document.getElementById('providerSearch');
        searchInput.addEventListener('input', callback);
    }

    setupFilters(callback) {
        const statusFilter = document.getElementById('providerStatusFilter');
        statusFilter.addEventListener('change', callback);
    }

    getFilters() {
        return {
            searchTerm: document.getElementById('providerSearch').value.toLowerCase(),
            status: document.getElementById('providerStatusFilter').value
        };
    }
}