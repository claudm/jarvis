// /static/js/providers/modal.js
import { renderOverviewTab } from './tabs/overview.js';
import { renderResourcesTab } from './tabs/resources.js';
import { renderRevisionsTab } from './tabs/revisions.js';
import { renderConfigTab } from './tabs/config.js';

export class ProviderModal {
    setup() {
        this.modal = document.getElementById('providerModal');
        this.modalContent = document.getElementById('providerTabContent');
        
        this.setupTabs();
        this.setupCloseButton();
    }

    setupResourceModal() {
        this.modal = document.getElementById('describeModal');
        this.modalContent = document.getElementById('describeModalContent');
        this.modalTitle = document.getElementById('describeModalTitle');
    }

    setupTabs() {
        document.querySelectorAll('.provider-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });
    }

    setupCloseButton() {
        document.getElementById('closeProviderModal').addEventListener('click', 
            () => this.modal.classList.add('hidden'));
    }

    async show(details) {
        this.modal.classList.remove('hidden');
        document.getElementById('modalTitle').textContent = details.name;
        await this.showTab('overview', details);
    }

    async showTab(tabName, data) {
        this.updateTabButtons(tabName);
        this.modalContent.innerHTML = this.getLoadingHTML();

        setTimeout(() => {
            switch(tabName) {
                case 'overview':
                    renderOverviewTab(this.modalContent, data);
                    break;
                case 'resources':
                    renderResourcesTab(this.modalContent, data);
                    break;
                case 'revisions':
                    renderRevisionsTab(this.modalContent, data);
                    break;
                case 'config':
                    renderConfigTab(this.modalContent, data);
                    break;
            }
        }, 100);
    }

    updateTabButtons(activeTab) {
        document.querySelectorAll('.provider-tab-btn').forEach(btn => {
            if (btn.dataset.tab === activeTab) {
                btn.classList.add('bg-gray-100', 'text-gray-900');
                btn.classList.remove('text-gray-500');
            } else {
                btn.classList.remove('bg-gray-100', 'text-gray-900');
                btn.classList.add('text-gray-500');
            }
        });
    }

    getLoadingHTML() {
        return `
            <div class="flex justify-center py-4">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
        `;
    }

    async showResource(type, name, response) {
        if (!this.modal || !this.modalContent || !this.modalTitle) {
            throw new Error('Modal elements not found');
        }

        this.modalTitle.textContent = `Resource: ${type}/${name}`;
        this.modalContent.innerHTML = `
            <div class="bg-gray-100 p-3 rounded-lg font-mono text-sm">
                <pre class="whitespace-pre-wrap overflow-x-auto">${response.describe || 'No details available'}</pre>
            </div>
        `;
        this.modal.classList.remove('hidden');
    }

    showResourceError(error, service, type, name) {
        if (!this.modal || !this.modalContent || !this.modalTitle) {
            return;
        }

        this.modalTitle.textContent = 'Error Loading Resource Details';
        this.modalContent.innerHTML = `
            <div class="bg-red-50 border border-red-200 p-4 rounded">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-red-800">Error Loading Resource Details</h3>
                        <div class="mt-2 text-sm text-red-700">
                            ${error.message}
                        </div>
                        <div class="mt-2">
                            <details class="text-sm text-red-700">
                                <summary class="cursor-pointer">Debug Information</summary>
                                <pre class="mt-2 text-xs">Service: ${service}
Type: ${type}
Name: ${name}</pre>
                            </details>
                        </div>
                    </div>
                </div>
            </div>
        `;
        this.modal.classList.remove('hidden');
    }
}