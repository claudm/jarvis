// /static/js/providers/tabs/resources.js
import { utils } from '../../utils.js';

export function renderResourcesTab(container, data) {
    const resources = data.resources || {};
    
    if (Object.keys(resources).length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">No resources found</p>';
        return;
    }

    const html = Object.entries(resources).map(([type, items]) => {
        const resourceItems = Array.isArray(items) ? items : [];
        
        return `
        <div class="mb-6">
            <h4 class="text-sm font-medium text-gray-500 mb-3">${type}</h4>
            <div class="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        ${renderResourceRows(resourceItems, type, data.name)}
                    </tbody>
                </table>
            </div>
        </div>
        `;
    }).join('');
    
    container.innerHTML = html;
}

function renderResourceRows(items, type, providerName) {
    if (items.length === 0) {
        return `
            <tr>
                <td colspan="4" class="px-6 py-4 text-center text-gray-500">
                    No resources found for ${type}
                </td>
            </tr>
        `;
    }

    return items.map(resource => `
        <tr class="hover:bg-gray-50">
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                ${resource.name}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                ${utils.createStatusBadge(resource.status)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                ${utils.formatDate(resource.created_at)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button onclick="event.stopPropagation(); window.currentController.showResourceDescribe('provider-${providerName.split('-')[1]}', '${resource.kind}', '${resource.name}');"
                        class="text-indigo-600 hover:text-indigo-900">
                    View Details
                </button>
            </td>
        </tr>
    `).join('');
}