// /static/js/providers/tabs/overview.js
import { utils } from '../../utils.js';

export function renderOverviewTab(container, data) {
    container.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="bg-gray-50 rounded-lg p-4">
                <h4 class="text-sm font-medium text-gray-500 mb-2">Details</h4>
                <dl class="grid grid-cols-1 gap-2">
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Name</dt>
                        <dd class="text-sm text-gray-900">${data.name}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Package</dt>
                        <dd class="text-sm text-gray-900">${data.package}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Current Revision</dt>
                        <dd class="text-sm text-gray-900">${data.revision}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Provider Type</dt>
                        <dd class="text-sm text-gray-900">${data.provider_type}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Created</dt>
                        <dd class="text-sm text-gray-900">${utils.formatDate(data.created_at)}</dd>
                    </div>
                </dl>
            </div>
            
            <div class="bg-gray-50 rounded-lg p-4">
                <h4 class="text-sm font-medium text-gray-500 mb-2">Status</h4>
                <dl class="grid grid-cols-1 gap-2">
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Health Status</dt>
                        <dd class="text-sm">${utils.createStatusBadge(data.status)}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">Resources</dt>
                        <dd class="text-sm text-gray-900">${Object.keys(data.resources || {}).length} types</dd>
                    </div>
                </dl>
            </div>
        </div>
    `;
}