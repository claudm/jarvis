// /static/js/providers/tabs/config.js
export function renderConfigTab(container, data = {}) {
    const config = data.config || {};
    container.innerHTML = `
        <div class="bg-gray-50 rounded-lg p-4">
            <pre class="text-sm text-gray-900 overflow-auto">
                ${JSON.stringify(config, null, 2)}
            </pre>
        </div>
    `;
}