// /static/js/providers/table.js
import { utils } from '../utils.js';

export class ProviderTable {
    constructor(container) {
        this.container = container;
    }

    render(providers = []) {
        if (providers.length === 0) {
            this.container.innerHTML = this.getEmptyHTML();
            return;
        }

        this.container.innerHTML = providers.map(provider => 
            this.getProviderRowHTML(provider)
        ).join('');
        
        this.attachEventListeners();
    }

    renderError(error) {
        this.container.innerHTML = `
            <tr>
                <td colspan="5" class="px-6 py-4 text-center">
                    <div class="text-red-500 mb-2">Failed to load providers: ${error.message}</div>
                    <div class="text-sm text-gray-500">Please try refreshing the page</div>
                </td>
            </tr>
        `;
    }

    getEmptyHTML() {
        return `
            <tr>
                <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                    No providers found
                </td>
            </tr>
        `;
    }

    getProviderRowHTML(provider) {
        const status = utils.getProviderStatus(provider);
        return `
            <tr class="hover:bg-gray-50 cursor-pointer" data-provider="${provider.metadata.name}">
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <div class="text-sm font-medium text-gray-900">
                            ${provider.metadata.name}
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    ${utils.createStatusBadge(status)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${provider.spec?.package || 'N/A'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${provider.status?.currentRevision || 'N/A'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button class="text-indigo-600 hover:text-indigo-900">
                        Details
                    </button>
                </td>
            </tr>
        `;
    }

    attachEventListeners() {
        this.container.querySelectorAll('tr').forEach(row => {
            row.addEventListener('click', () => {
                if (window.currentController) {
                    window.currentController.showProviderDetails(row.dataset.provider);
                }
            });
        });
    }
}