# routes/main.py
from flask import Blueprint, render_template
from kubernetes import client, config
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
import logging

logger = logging.getLogger(__name__)
main_bp = Blueprint('main', __name__)

# Initialize Kubernetes clients
try:
    config.load_kube_config()
except:
    config.load_incluster_config()

custom_api = client.CustomObjectsApi()
core_api = client.CoreV1Api()
apps_api = client.AppsV1Api()

# Initialize services
crossplane_service = CrossplaneService()
provider_service = ProviderService(custom_api)
composition_service = CompositionService(custom_api)
config_service = ConfigurationService(custom_api)

@main_bp.route('/')
@main_bp.route('/index')
def index():
    """Dashboard/Overview page"""
    try:
        status = crossplane_service.get_summary()
        return render_template('index.html', 
                             title='Dashboard',
                             status=status)
    except Exception as e:
        logger.error(f"Error loading dashboard: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/providers')
def providers():
    """Providers page"""
    try:
        providers_list = provider_service.get_providers()
        return render_template('providers.html', 
                             title='Providers',
                             providers=providers_list)
    except Exception as e:
        logger.error(f"Error loading providers: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/providers/<name>')
def provider_details(name):
    """Provider details page"""
    try:
        logger.info(f"Loading details for provider {name}")
        # Get provider
        provider = provider_service.get_provider_details(name)
        if provider is None:
            logger.warning(f"Provider {name} not found")
            return render_template('provider_resources.html',
                                 title=f'Provider: {name}',
                                 provider=None)
        
        logger.info(f"Found provider {name} with {len(provider.get('resources', {}))} resources")
        return render_template('provider_resources.html',
                             title=f'Provider: {name}',
                             provider=provider)
    except Exception as e:
        logger.error(f"Error loading provider details: {e}", exc_info=True)
        return render_template('error.html',
                             title='Error',
                             error=str(e))

@main_bp.route('/compositions')
def compositions():
    """Compositions page"""
    try:
        compositions_list = composition_service.get_compositions()
        return render_template('compositions.html', 
                             title='Compositions',
                             compositions=compositions_list)
    except Exception as e:
        logger.error(f"Error loading compositions: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/compositions/<name>/resources')
def composition_resources(name):
    """Composition resources page"""
    try:
        composition = composition_service.get_composition_details(name)
        if composition is None:
            raise ValueError(f"Composition {name} not found")
            
        return render_template('composition_resources.html',
                             title=f'Composition: {name}',
                             composition=composition)
    except Exception as e:
        logger.error(f"Error loading composition resources: {e}")
        return render_template('error.html',
                             title='Error',
                             error=str(e))
    
@main_bp.route('/compositions/<name>')
def composition_details(name):
    """Composition details page"""
    try:
        composition = composition_service.get_composition_details(name)
        if composition is None:
            raise ValueError(f"Composition {name} not found")
            
        return render_template('composition_details.html',
                             title=f'Composition: {name}',
                             composition=composition)
    except Exception as e:
        logger.error(f"Error loading composition details: {e}")
        return render_template('error.html',
                             title='Error',
                             error=str(e))

@main_bp.route('/configurations')
def configurations():
    """Configurations page"""
    try:
        configs_list = config_service.get_configurations()
        return render_template('configurations.html', 
                             title='Configurations',
                             configurations=configs_list)
    except Exception as e:
        logger.error(f"Error loading configurations: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/configurations/<name>')
def configuration_details(name):
    """Configuration details page"""
    try:
        config = config_service.get_configuration_details(name)
        if config is None:
            raise ValueError(f"Configuration {name} not found")
            
        return render_template('configuration_details.html',
                             title=f'Configuration: {name}',
                             configuration=config)
    except Exception as e:
        logger.error(f"Error loading configuration details: {e}")
        return render_template('error.html',
                             title='Error',
                             error=str(e))

@main_bp.route('/configurations/<name>/resources')
def configuration_resources(name):
    """Configuration resources page"""
    try:
        logger.info(f"Loading resources for configuration {name}")
        # Get configuration
        configuration = config_service.get_configuration_details(name)
        if configuration is None:
            logger.warning(f"Configuration {name} not found")
            return render_template('configuration_resources.html',
                                 title=f'Configuration: {name}',
                                 configuration=None)
        
        logger.info(f"Found configuration {name} with {len(configuration.get('resources', {}))} resources")
        return render_template('configuration_resources.html',
                             title=f'Configuration: {name}',
                             configuration=configuration)
    except Exception as e:
        logger.error(f"Error loading configuration resources: {e}", exc_info=True)
        return render_template('error.html',
                             title='Error',
                             error=str(e))
    
@main_bp.route('/health')
def health():
    """System health page"""
    try:
        health_status = crossplane_service.get_health_status()
        return render_template('health.html', 
                             title='System Health',
                             status=health_status)
    except Exception as e:
        logger.error(f"Error loading health status: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))