# routes/main.py
from flask import Blueprint, render_template
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
import logging
from services.k8s_api_auth import init_kubernetes_client

logger = logging.getLogger(__name__)
main_bp = Blueprint('main', __name__)

# Initialize Kubernetes clients
client = init_kubernetes_client()
custom_api = client.CustomObjectsApi()
core_api = client.CoreV1Api()
apps_api = client.AppsV1Api()

# Initialize services
crossplane_service = CrossplaneService()
provider_service = ProviderService(custom_api)
composition_service = CompositionService(custom_api)
config_service = ConfigurationService(custom_api)

@main_bp.route('/')
@main_bp.route('/index')
def index():
    """Dashboard/Overview page"""
    try:
        status = crossplane_service.get_summary()
        return render_template('index.html', 
                             title='Dashboard',
                             status=status)
    except Exception as e:
        logger.error(f"Error loading dashboard: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/providers')
def providers():
    """Providers page"""
    try:
        providers_list = provider_service.get_providers()
        return render_template('providers.html', 
                             title='Providers',
                             providers=providers_list)
    except Exception as e:
        logger.error(f"Error loading providers: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/providers/<provider_name>/resources')
def provider_resources(provider_name):
    """Provider resources page"""
    try:
        # Get all CRDs for this provider
        crds = custom_api.list_custom_resource_definition()
        resources_by_service = {}
        provider_base = provider_name.replace('provider-', '')
        
        # Get resources for each CRD
        for crd in crds.items:
            if provider_base in crd.spec.group:
                try:
                    resources = custom_api.list_cluster_custom_object(
                        group=crd.spec.group,
                        version=crd.spec.versions[0].name,
                        plural=crd.spec.names.plural
                    )
                    
                    if resources.get('items'):
                        service = crd.spec.group.split('.')[0]  # e.g., s3, rds, etc.
                        
                        if service not in resources_by_service:
                            resources_by_service[service] = []
                        
                        for r in resources.get('items', []):
                            conditions = r.get('status', {}).get('conditions', [])
                            ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                            synced = next((c for c in conditions if c.get('type') == 'Synced'), {})
                            
                            resource_data = {
                                'name': r['metadata']['name'],
                                'kind': crd.spec.names.kind,
                                'status': {
                                    'ready': ready.get('status', 'Unknown'),
                                    'synced': synced.get('status', 'Unknown')
                                },
                                'spec': r.get('spec', {}),
                                'status_details': r.get('status', {}),
                                'created_at': r['metadata']['creationTimestamp']
                            }
                            resources_by_service[service].append(resource_data)
                            
                except Exception as e:
                    logger.error(f"Error getting resources for {crd.spec.names.kind}: {e}")
                    continue
        
        return render_template('provider_resources.html',
                             title=f'Resources: {provider_name}',
                             provider_name=provider_name,
                             resources=resources_by_service)
                             
    except Exception as e:
        logger.error(f"Error loading provider resources: {e}")
        return render_template('error.html',
                             title='Error',
                             error=str(e))

@main_bp.route('/compositions')
def compositions():
    """Compositions page"""
    try:
        compositions_list = composition_service.get_compositions()
        return render_template('compositions.html', 
                             title='Compositions',
                             compositions=compositions_list)
    except Exception as e:
        logger.error(f"Error loading compositions: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/compositions/<name>/resources')
def composition_resources(name):
    """Composition resources page"""
    try:
        composition = composition_service.get_composition_details(name)
        if composition is None:
            raise ValueError(f"Composition {name} not found")
            
        return render_template('resource_details.html',
                             title=f'Composition Resources: {name}',
                             name=name,
                             resource_type='composition',
                             composition=composition)
    except Exception as e:
        logger.error(f"Error loading composition resources: {e}")
        return render_template('error.html',
                             title='Error',
                             error=str(e))

@main_bp.route('/configurations')
def configurations():
    """Configurations page"""
    try:
        configs_list = config_service.get_configurations()
        return render_template('configurations.html', 
                             title='Configurations',
                             configurations=configs_list)
    except Exception as e:
        logger.error(f"Error loading configurations: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

@main_bp.route('/configurations/<name>/resources')
def configuration_resources(name):
    """Configuration resources page"""
    try:
        logger.info(f"Loading resources for configuration {name}")
        # Get configuration
        configuration = config_service.get_configuration_details(name)
        if configuration is None:
            logger.warning(f"Configuration {name} not found")
            return render_template('resource_details.html',
                                title=f'Configuration Resources: {name}',
                                name=name,
                                resource_type='configuration',
                                configuration=None)
        
        logger.info(f"Found configuration {name} with {len(configuration.get('resources', {}))} resources")
        return render_template('resource_details.html',
                             title=f'Configuration Resources: {name}',
                             name=name,
                             resource_type='configuration',
                             configuration=configuration)
    except Exception as e:
        logger.error(f"Error loading configuration resources: {e}", exc_info=True)
        return render_template('error.html',
                             title='Error',
                             error=str(e))


@main_bp.route('/compositions/<name>')
def composition_details(name):
    """Composition details page"""
    try:
        # Get composition details
        composition = custom_api.get_cluster_custom_object(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=name
        )

        # Get type ref to find related resources
        type_ref = composition.get('spec', {}).get('compositeTypeRef', {})
        composition_resources = []

        if type_ref:
            try:
                # Get all composite resources
                composites = custom_api.list_cluster_custom_object(
                    group=type_ref['group'],
                    version=type_ref.get('version', 'v1alpha1'),
                    plural=f"x{type_ref['kind'].lower()}s"
                )

                # Process each composite that uses this composition
                for cr in composites.get('items', []):
                    if name == cr.get('spec', {}).get('compositionRef', {}).get('name'):
                        conditions = cr.get('status', {}).get('conditions', [])
                        ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                        synced = next((c for c in conditions if c.get('type') == 'Synced'), {})

                        resource_info = {
                            'name': cr['metadata']['name'],
                            'kind': cr['kind'],
                            'group': cr['apiVersion'].split('/')[0],
                            'status': 'Ready' if ready.get('status') == 'True' else 'Not Ready',
                            'synced': synced.get('status', 'Unknown')
                        }
                        composition_resources.append(resource_info)

            except Exception as e:
                logger.error(f"Error getting composition resources: {e}")

        # Process composition status
        conditions = composition.get('status', {}).get('conditions', [])
        composition_status = {
            'ready': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Ready'), 'Unknown'),
            'synced': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Synced'), 'Unknown')
        }

        composition_data = {
            'name': composition['metadata']['name'],
            'type_ref': type_ref,
            'mode': composition['spec'].get('mode', 'Pipeline'),
            'status': composition_status,
            'resources': composition_resources,
            'created_at': composition['metadata']['creationTimestamp']
        }

        return render_template('composition_details.html',
                             composition=composition_data)

    except Exception as e:
        logger.error(f"Error getting composition details: {e}", exc_info=True)
        return render_template('error.html',
                             title='Error',
                             error=str(e))

@main_bp.route('/health')
def health():
    """System health page"""
    try:
        health_status = crossplane_service.get_health_status()
        return render_template('health.html', 
                             title='System Health',
                             status=health_status)
    except Exception as e:
        logger.error(f"Error loading health status: {e}")
        return render_template('error.html', 
                             title='Error',
                             error=str(e))

# Error handlers
@main_bp.errorhandler(404)
def not_found_error(error):
    return render_template('error.html',
                         title='Not Found',
                         error='The requested page was not found'), 404

@main_bp.errorhandler(500)
def internal_error(error):
    return render_template('error.html',
                         title='Internal Error',
                         error='An internal server error occurred'), 500