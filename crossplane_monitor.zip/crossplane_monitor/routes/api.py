from flask import Blueprint, jsonify, request
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
from kubernetes import client, config
import logging
import yaml 

logger = logging.getLogger(__name__)
api = Blueprint('api', __name__)

# Initialize services
try:
    config.load_kube_config()
except:
    config.load_incluster_config()

custom_api = client.CustomObjectsApi()
crossplane = CrossplaneService()
provider_svc = ProviderService(custom_api)
composition_svc = CompositionService(custom_api)
config_svc = ConfigurationService(custom_api)

def get_resource_group(service: str, custom_api) -> str:
    """Get Crossplane API group for AWS services using CRDs"""
    crds = custom_api.list_custom_resource_definition()
    
    for crd in crds.items:
        group = crd.spec.group
        if group.startswith(f"{service}.aws.crossplane.io"):
            return group
            
    raise ValueError(f"No CRD found for AWS service: {service}")

@api.route('/system/status')
def get_system_status():
    try:
        status = crossplane.get_summary()
        return jsonify(status)
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/system/events')
def get_system_events():
    try:
        events = crossplane.get_system_events()
        return jsonify(events)
    except Exception as e:
        logger.error(f"Error getting system events: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers')
def get_providers():
    try:
        providers = provider_svc.get_providers()
        logger.debug(f"Found {len(providers)} providers")
        logger.debug(f"Provider data: {providers}")
        return jsonify(providers)
    except Exception as e:
        logger.error(f"Error listing providers: {e}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@api.route('/providers/<name>')
def get_provider_details(name):
    try:
        details = provider_svc.get_provider_details(name)
        if not details:
            return jsonify({'error': 'Provider not found'}), 404
        return jsonify(details)
    except Exception as e:
        logger.error(f"Error getting provider details: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers/resources/describe/<service>/<type>/<name>')
def get_resource_describe(service, type, name):
    try:
        logger.debug(f"Starting resource describe for {service}/{type}/{name}")
        
        # Get group dynamically from CRDs
        group = get_resource_group(service, custom_api)
            
        api_extensions = client.ApiextensionsV1Api()
        
        # List all CRDs and find the matching one
        all_crds = api_extensions.list_custom_resource_definition()
        
        matching_crd = None
        for crd in all_crds.items:
            logger.debug(f"Checking CRD: {crd.spec.names.kind} in group {crd.spec.group}")
            if (crd.spec.group == group and 
                crd.spec.names.kind.lower() == type.lower()):
                matching_crd = crd
                break

        if not matching_crd:
            return jsonify({'error': f"No CRD found for {type} in {group}"}), 404

        api_version = next((v.name for v in matching_crd.spec.versions if v.served), 'v1alpha1')
        resource_plural = matching_crd.spec.names.plural

        logger.debug(f"Found CRD: group={group}, version={api_version}, plural={resource_plural}")

        resource = custom_api.get_cluster_custom_object(
            group=group,
            version=api_version,
            plural=resource_plural,
            name=name
        )

        if not resource:
            return jsonify({'error': f"Resource {name} not found"}), 404

        conditions = resource.get('status', {}).get('conditions', [])
        conditions_str = ""
        ready_status = "Unknown"
        synced_status = "Unknown"
        last_synced = "-"

        for condition in conditions:
            condition_type = condition.get('type', '')
            condition_status = condition.get('status', 'Unknown')
            last_transition = condition.get('lastTransitionTime', '-')
            reason = condition.get('reason', '-')
            message = condition.get('message', '-')
            
            if condition_type == 'Synced':
                synced_status = condition_status
                if condition_status == 'True':
                    last_synced = last_transition
            elif condition_type == 'Ready':
                ready_status = condition_status

            conditions_str += f"""  {condition_type}:
    Status:               {condition_status}
    Last Transition Time: {last_transition}
    Reason:              {reason}
    Message:             {message}\n"""

        describe = f"""Name:         {resource['metadata']['name']}
API Version:  {resource['apiVersion']}
Kind:         {resource['kind']}
Metadata:
  Creation Timestamp:  {resource['metadata']['creationTimestamp']}
  Generation:         {resource['metadata'].get('generation', '-')}
  Resource Version:   {resource['metadata'].get('resourceVersion', '-')}
  UID:               {resource['metadata'].get('uid', '-')}

Status:
  Synced:      {synced_status}
  Ready:       {ready_status}
  Last Synced: {last_synced}
  
  Conditions:
{conditions_str}

Spec:
  Provider Config Ref:
    Name:  {resource['spec'].get('providerConfigRef', {}).get('name', '-')}
    
  For Provider:
    {yaml.dump(resource['spec'].get('forProvider', {}), default_flow_style=False, indent=4).replace('\n', '\n    ')}

At Provider:
    {yaml.dump(resource.get('status', {}).get('atProvider', {}), default_flow_style=False, indent=4).replace('\n', '\n    ')}"""

        return jsonify({
            'describe': describe,
            'resource': resource
        })
            
    except Exception as e:
        error_message = str(e)
        logger.error(f"Error getting resource describe: {error_message}", exc_info=True)
        return jsonify({
            'error': f"Failed to describe resource: {error_message}",
            'details': {
                'service': service,
                'type': type,
                'name': name,
                'group': group if 'group' in locals() else 'unknown',
                'error': error_message,
                'crd': matching_crd.to_dict() if 'matching_crd' in locals() and matching_crd else None
            }
        }), 500

@api.route('/compositions')
def get_compositions():
    try:
        compositions = composition_svc.get_compositions()
        return jsonify(compositions)
    except Exception as e:
        logger.error(f"Error listing compositions: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/compositions/<name>')
def get_composition_details(name):
    try:
        details = composition_svc.get_composition_details(name)
        if details is None:
            return jsonify({'error': 'Composition not found'}), 404
        return jsonify(details)
    except Exception as e:
        logger.error(f"Error getting composition details: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations')
def get_configurations():
    try:
        configurations = config_svc.get_configurations()
        return jsonify(configurations)
    except Exception as e:
        logger.error(f"Error listing configurations: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations/<name>')
def get_configuration_details(name):
    try:
        details = config_svc.get_configuration_details(name)
        if not details:
            return jsonify({'error': 'Configuration not found'}), 404
        return jsonify(details)
    except Exception as e:
        logger.error(f"Error getting configuration details: {e}")
        return jsonify({'error': str(e)}), 500

# Error handlers
@api.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@api.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500