from flask import Blueprint, render_template, redirect, url_for, flash, jsonify
from kubernetes.client.rest import ApiException
from services.k8s_api_auth import init_kubernetes_client
import logging
import yaml 

logger = logging.getLogger(__name__)
api = Blueprint('api', __name__)

# Initialize Kubernetes clients
client = init_kubernetes_client()
custom_api = client.CustomObjectsApi()
extensions_api = client.ApiextensionsV1Api()

@api.route('/providers/aws-resources')
def get_aws_resources():
    try:
        # Get AWS CRDs
        crds = extensions_api.list_custom_resource_definition()
        aws_resources = {}
        
        # Find AWS-related CRDs
        for crd in crds.items:
            if 'aws.crossplane.io' in crd.spec.group:
                kind = crd.spec.names.kind
                version = crd.spec.versions[0].name
                group = crd.spec.group
                
                try:
                    # Get resources for this CRD
                    resources = custom_api.list_cluster_custom_object(
                        group=group,
                        version=version,
                        plural=crd.spec.names.plural
                    )
                    
                    if resources.get('items'):
                        # Get AWS service name (e.g., s3, eks, etc)
                        service = group.split('.')[0]
                        
                        if service not in aws_resources:
                            aws_resources[service] = {}
                        
                        if kind not in aws_resources[service]:
                            aws_resources[service][kind] = []
                        
                        # Process each resource
                        for r in resources.get('items', []):
                            conditions = r.get('status', {}).get('conditions', [])
                            ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                            synced = next((c for c in conditions if c.get('type') == 'Synced'), {})
                            
                            resource_data = {
                                'name': r['metadata']['name'],
                                'kind': kind,
                                'status': {
                                    'ready': ready.get('status', 'Unknown'),
                                    'synced': synced.get('status', 'Unknown'),
                                    'ready_message': ready.get('message', ''),
                                    'synced_message': synced.get('message', '')
                                },
                                'spec': r.get('spec', {}),
                                'status_details': r.get('status', {}),
                                'created_at': r['metadata']['creationTimestamp']
                            }
                            aws_resources[service][kind].append(resource_data)
                            
                except Exception as e:
                    logger.error(f"Error getting resources for {kind}: {e}")
                    continue

        return jsonify(aws_resources)
                             
    except Exception as e:
        logger.error(f"Error getting AWS resources: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers/<provider_name>')
def provider_detail(provider_name):
    try:
        # Get provider details
        provider = custom_api.get_cluster_custom_object(
            group="pkg.crossplane.io",
            version="v1",
            plural="providers",
            name=provider_name
        )
        
        # Get CRDs for this provider
        crds = extensions_api.list_custom_resource_definition()
        provider_crds = []
        provider_crs = []
        
        # Look for CRDs belonging to this provider
        provider_group_prefix = provider_name.replace('provider-', '')
        for crd in crds.items:
            if crd.spec.group.startswith(f"{provider_group_prefix}."):
                # Add CRD info
                crd_info = {
                    'name': crd.metadata.name,
                    'group': crd.spec.group,
                    'kind': crd.spec.names.kind,
                    'plural': crd.spec.names.plural,
                    'version': crd.spec.versions[0].name if crd.spec.versions else 'unknown'
                }
                provider_crds.append(crd_info)
                
                # Get CRs for this CRD
                try:
                    crs = custom_api.list_cluster_custom_object(
                        group=crd.spec.group,
                        version=crd.spec.versions[0].name,
                        plural=crd.spec.names.plural
                    )
                    
                    for cr in crs.get('items', []):
                        cr_info = {
                            'name': cr['metadata']['name'],
                            'kind': crd.spec.names.kind,
                            'group': crd.spec.group,
                            'status': 'Ready' if any(c.get('type') == 'Ready' and c.get('status') == 'True' 
                                                for c in cr.get('status', {}).get('conditions', [])) else 'Not Ready'
                        }
                        provider_crs.append(cr_info)
                except Exception as e:
                    logger.warning(f"Error getting CRs for {crd.metadata.name}: {e}")
                    continue
        
        # Process provider status
        conditions = {}
        for condition in provider.get('status', {}).get('conditions', []):
            conditions[condition.get('type')] = condition.get('status')
        
        # Prepare provider data
        provider_data = {
            'name': provider['metadata']['name'],
            'package': provider['spec']['package'],
            'version': provider['spec']['package'].split(':')[-1],
            'status_healthy': conditions.get('Healthy', 'Unknown'),
            'status_installed': conditions.get('Installed', 'Unknown'),
            'currentRevision': provider['status'].get('currentRevision', ''),
            'crds': provider_crds,
            'crs': provider_crs,
            'raw_status': provider.get('status', {})
        }
        
        return render_template('provider_detail.html', provider=provider_data)
        
    except Exception as e:
        logger.error(f"Error getting provider details: {e}", exc_info=True)
        flash(f"Error getting provider details: {str(e)}", "error")
        return redirect(url_for('api.providers'))

@api.route('/providers/resources/<provider_name>')
def get_provider_resources(provider_name):
    try:
        # Get provider details
        provider = custom_api.get_cluster_custom_object(
            group="pkg.crossplane.io",
            version="v1",
            plural="providers",
            name=provider_name
        )
        
        # Get CRDs for this provider
        crds = extensions_api.list_custom_resource_definition()
        resources_by_type = {}
        
        # Extract provider base name (e.g., aws from provider-aws)
        provider_base = provider_name.replace('provider-', '')
        
        # Get all CRDs and resources for this provider
        for crd in crds.items:
            if provider_base in crd.spec.group:
                kind = crd.spec.names.kind
                version = crd.spec.versions[0].name
                group = crd.spec.group
                
                try:
                    # Get resources for this CRD
                    resources = custom_api.list_cluster_custom_object(
                        group=group,
                        version=version,
                        plural=crd.spec.names.plural
                    )
                    
                    if resources.get('items'):
                        # Extract service name from group (e.g., s3 from s3.aws.crossplane.io)
                        service = group.split('.')[0]
                        
                        if service not in resources_by_type:
                            resources_by_type[service] = {}
                            
                        if kind not in resources_by_type[service]:
                            resources_by_type[service][kind] = []
                        
                        # Process each resource
                        for r in resources.get('items', []):
                            conditions = r.get('status', {}).get('conditions', [])
                            ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                            synced = next((c for c in conditions if c.get('type') == 'Synced'), {})
                            
                            resource_data = {
                                'name': r['metadata']['name'],
                                'kind': kind,
                                'group': group,
                                'version': version,
                                'status': {
                                    'ready': ready.get('status', 'Unknown'),
                                    'synced': synced.get('status', 'Unknown'),
                                    'ready_message': ready.get('message', ''),
                                    'synced_message': synced.get('message', ''),
                                    'conditions': conditions
                                },
                                'spec': r.get('spec', {}),
                                'created_at': r['metadata']['creationTimestamp']
                            }
                            resources_by_type[service][kind].append(resource_data)
                            
                except Exception as e:
                    logger.error(f"Error getting resources for {kind}: {e}")
                    continue

        # Process provider status
        conditions = provider.get('status', {}).get('conditions', [])
        provider_status = {
            'healthy': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Healthy'), 'Unknown'),
            'installed': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Installed'), 'Unknown')
        }
        
        provider_data = {
            'name': provider['metadata']['name'],
            'package': provider['spec']['package'],
            'version': provider['spec']['package'].split(':')[-1],
            'revision': provider['status'].get('currentRevision', ''),
            'status': provider_status,
            'created_at': provider['metadata']['creationTimestamp'],
            'resources': resources_by_type
        }
        
        return jsonify(provider_data)
                             
    except Exception as e:
        logger.error(f"Error getting provider resources: {e}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@api.route('/providers/resources/describe/<service>/<type>/<name>')
def get_resource_describe(service: str, type: str, name: str):
    try:
        logger.debug(f"Starting resource describe for {service}/{type}/{name}")
        crds = extensions_api.list_custom_resource_definition()
        
        # Find matching CRD
        matching_crd = None
        for crd in crds.items:
            if (service in crd.spec.group and 
                crd.spec.names.kind.lower() == type.lower()):
                matching_crd = crd
                break

        if not matching_crd:
            return jsonify({'error': f"No CRD found for {type} in {service}"}), 404

        group = matching_crd.spec.group
        version = matching_crd.spec.versions[0].name
        plural = matching_crd.spec.names.plural

        # Get resource
        resource = custom_api.get_cluster_custom_object(
            group=group,
            version=version,
            plural=plural,
            name=name
        )

        if not resource:
            return jsonify({'error': f"Resource {name} not found"}), 404

        # Format conditions for display
        conditions = resource.get('status', {}).get('conditions', [])
        conditions_formatted = "\n".join([
            f"{c['type']}:\n"
            f"  Status: {c['status']}\n"
            f"  Last Transition: {c['lastTransitionTime']}\n"
            f"  Message: {c.get('message', 'N/A')}\n"
            for c in conditions
        ])

        # Format description
        description = f"""Name:         {resource['metadata']['name']}
API Version:  {resource['apiVersion']}
Kind:         {resource['kind']}
Metadata:
  Created:    {resource['metadata']['creationTimestamp']}
  UID:        {resource['metadata']['uid']}

Status:
  Conditions:
{conditions_formatted}

Spec:
{yaml.dump(resource['spec'], default_flow_style=False, indent=2)}

Status Details:
{yaml.dump(resource.get('status', {}), default_flow_style=False, indent=2)}
"""

        return jsonify({
            'describe': description,
            'resource': resource
        })
            
    except Exception as e:
        error_message = str(e)
        logger.error(f"Error getting resource describe: {error_message}", exc_info=True)
        return jsonify({
            'error': f"Failed to describe resource: {error_message}"
        }), 500

@api.route('/configurations/resources/<config_name>')
def get_configuration_resources(config_name):
    try:
        # Get configuration details
        config = custom_api.get_cluster_custom_object(
            group="pkg.crossplane.io",
            version="v1",
            plural="configurations",
            name=config_name
        )

        # Get all CRDs associated with this configuration
        crds = extensions_api.list_custom_resource_definition()
        resources_by_type = {}

        # Look for CRDs with the configuration label
        for crd in crds.items:
            labels = crd.metadata.labels or {}
            if any(label.startswith("pkg.crossplane.io/configuration") for label in labels) and \
               config_name in str(labels):
                try:
                    group = crd.spec.group
                    kind = crd.spec.names.kind
                    version = crd.spec.versions[0].name
                    plural = crd.spec.names.plural

                    # Get resources for this CRD
                    resources = custom_api.list_cluster_custom_object(
                        group=group,
                        version=version,
                        plural=plural
                    )

                    if resources.get('items'):
                        if kind not in resources_by_type:
                            resources_by_type[kind] = []

                        for r in resources.get('items', []):
                            conditions = r.get('status', {}).get('conditions', [])
                            ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                            synced = next((c for c in conditions if c.get('type') == 'Synced'), {})

                            resource_data = {
                                'name': r['metadata']['name'],
                                'kind': kind,
                                'status': {
                                    'ready': ready.get('status', 'Unknown'),
                                    'synced': synced.get('status', 'Unknown'),
                                    'ready_message': ready.get('message', ''),
                                    'synced_message': synced.get('message', '')
                                },
                                'spec': yaml.dump(r.get('spec', {}), default_flow_style=False),
                                'status_details': yaml.dump(r.get('status', {}), default_flow_style=False),
                                'created_at': r['metadata']['creationTimestamp']
                            }
                            resources_by_type[kind].append(resource_data)

                except Exception as e:
                    logger.error(f"Error getting resources for {kind}: {e}")
                    continue

        return jsonify({
            'name': config_name,
            'resources': resources_by_type
        })

    except Exception as e:
        logger.error(f"Error getting configuration resources: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/compositions/resources/<composition_name>')
def get_composition_resources(composition_name):
    try:
        # Get composition details
        composition = custom_api.get_cluster_custom_object(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=composition_name
        )

        # Get the composite type reference
        type_ref = composition.get('spec', {}).get('compositeTypeRef', {})
        resources_list = []

        if type_ref:
            try:
                # Get composite resources
                composites = custom_api.list_cluster_custom_object(
                    group=type_ref['group'],
                    version=type_ref.get('version', 'v1alpha1'),
                    plural=f"x{type_ref['kind'].lower()}s"
                )

                for composite in composites.get('items', []):
                    # Check if this composite uses our composition
                    if composition_name == composite.get('spec', {}).get('compositionRef', {}).get('name'):
                        comp_conditions = composite.get('status', {}).get('conditions', [])
                        comp_ready = next((c for c in comp_conditions if c.get('type') == 'Ready'), {})
                        comp_synced = next((c for c in comp_conditions if c.get('type') == 'Synced'), {})

                        composite_data = {
                            'name': composite['metadata']['name'],
                            'kind': composite['kind'],
                            'status': {
                                'ready': comp_ready.get('status', 'Unknown'),
                                'synced': comp_synced.get('status', 'Unknown'),
                                'ready_message': comp_ready.get('message', ''),
                                'synced_message': comp_synced.get('message', '')
                            },
                            'spec': yaml.dump(composite.get('spec', {}), default_flow_style=False),
                            'status_details': yaml.dump(composite.get('status', {}), default_flow_style=False),
                            'created_at': composite['metadata']['creationTimestamp'],
                            'managed_resources': []
                        }

                        # Get managed resources
                        for ref in composite.get('status', {}).get('resources', []):
                            try:
                                resource = custom_api.get_cluster_custom_object(
                                    group=ref['resource']['group'],
                                    version=ref['resource']['version'],
                                    plural=ref['resource']['plural'],
                                    name=ref['name']
                                )

                                conditions = resource.get('status', {}).get('conditions', [])
                                ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                                synced = next((c for c in conditions if c.get('type') == 'Synced'), {})

                                resource_data = {
                                    'name': ref['name'],
                                    'kind': ref['kind'],
                                    'status': {
                                        'ready': ready.get('status', 'Unknown'),
                                        'synced': synced.get('status', 'Unknown'),
                                        'ready_message': ready.get('message', ''),
                                        'synced_message': synced.get('message', '')
                                    },
                                    'spec': yaml.dump(resource.get('spec', {}), default_flow_style=False),
                                    'status_details': yaml.dump(resource.get('status', {}), default_flow_style=False),
                                    'created_at': resource['metadata']['creationTimestamp']
                                }
                                composite_data['managed_resources'].append(resource_data)

                            except Exception as e:
                                logger.warning(f"Error getting managed resource {ref['name']}: {e}")
                                continue

                        resources_list.append(composite_data)

            except Exception as e:
                logger.error(f"Error getting composite resources: {e}")

        return jsonify({
            'name': composition_name,
            'resources': resources_list
        })

    except Exception as e:
        logger.error(f"Error getting composition resources: {e}")
        return jsonify({'error': str(e)}), 500


@api.route('/compositions/<name>')
def composition_details(name):
    """Composition details page"""
    try:
        # Get composition details
        composition = custom_api.get_cluster_custom_object(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=name
        )

        # Get type ref to find related resources
        type_ref = composition.get('spec', {}).get('compositeTypeRef', {})
        composition_resources = []

        if type_ref:
            try:
                # Get all composite resources
                composites = custom_api.list_cluster_custom_object(
                    group=type_ref['group'],
                    version=type_ref.get('version', 'v1alpha1'),
                    plural=f"x{type_ref['kind'].lower()}s"
                )

                # Process each composite that uses this composition
                for cr in composites.get('items', []):
                    if name == cr.get('spec', {}).get('compositionRef', {}).get('name'):
                        conditions = cr.get('status', {}).get('conditions', [])
                        ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                        synced = next((c for c in conditions if c.get('type') == 'Synced'), {})

                        resource_info = {
                            'name': cr['metadata']['name'],
                            'kind': cr['kind'],
                            'group': cr['apiVersion'].split('/')[0],
                            'status': 'Ready' if ready.get('status') == 'True' else 'Not Ready',
                            'synced': synced.get('status', 'Unknown')
                        }
                        composition_resources.append(resource_info)

            except Exception as e:
                logger.error(f"Error getting composition resources: {e}")

        # Process composition status
        conditions = composition.get('status', {}).get('conditions', [])
        composition_status = {
            'ready': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Ready'), 'Unknown'),
            'synced': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Synced'), 'Unknown')
        }

        composition_data = {
            'name': composition['metadata']['name'],
            'type_ref': type_ref,
            'mode': composition['spec'].get('mode', 'Pipeline'),
            'status': composition_status,
            'resources': composition_resources,
            'created_at': composition['metadata']['creationTimestamp']
        }

        return render_template('composition_details.html',
                             composition=composition_data)

    except Exception as e:
        logger.error(f"Error getting composition details: {e}", exc_info=True)
        return render_template('error.html',
                             title='Error',
                             error=str(e))

# Error handlers
@api.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@api.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500