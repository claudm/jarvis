# routes/api.py

from flask import Blueprint, jsonify, request
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
from kubernetes import client, config
import logging
import yaml 
import traceback

logger = logging.getLogger(__name__)
api = Blueprint('api', __name__)

# Inicializa serviços
try:
    logger.info("Attempting to load kubeconfig from default location")
    config.load_kube_config()
    logger.info("Successfully loaded kubeconfig")
except Exception as e:
    logger.error(f"Failed to load kubeconfig: {str(e)}")
    try:
        logger.info("Attempting to load in-cluster config")
        config.load_incluster_config()
        logger.info("Successfully loaded in-cluster config")
    except Exception as e:
        logger.error(f"Failed to load in-cluster config: {str(e)}")
        raise Exception("Failed to initialize Kubernetes configuration. Please ensure kubeconfig is properly set up.")

try:
    custom_api = client.CustomObjectsApi()
    api_client = client.ApiextensionsV1Api()
    crossplane = CrossplaneService()
    provider_svc = ProviderService(custom_api)
    composition_svc = CompositionService(custom_api)
    config_svc = ConfigurationService(custom_api)
    logger.info("Successfully initialized all Kubernetes clients and services")
except Exception as e:
    logger.error(f"Failed to initialize Kubernetes clients: {str(e)}")
    raise

@api.route('/system/status')
def get_system_status():
    """Obtém status geral do sistema Crossplane"""
    try:
        status = crossplane.get_summary()  # Changed from get_control_plane_status()
        return jsonify(status)
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/system/events')
def get_system_events():
    """Obtém eventos do sistema"""
    try:
        events = crossplane.get_system_events()
        return jsonify(events)
    except Exception as e:
        logger.error(f"Error getting system events: {e}")
        return jsonify({'error': str(e)}), 500

# Rotas de Providers
@api.route('/providers')
def get_providers():
    """Lista todos os providers"""
    try:
        providers = provider_svc.get_providers()
        # Ensure we return in the expected format with 'items' array
        return jsonify({
            'apiVersion': 'pkg.crossplane.io/v1',
            'kind': 'ProviderList',
            'items': providers
        })
    except Exception as e:
        logger.error(f"Error listing providers: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers/<name>')
def get_provider_details(name):
    """Obtém detalhes de um provider específico"""
    try:
        details = provider_svc.get_provider_details(name)
        if details is None:
            return jsonify({'error': 'Provider not found'}), 404
        return jsonify(details)
    except Exception as e:
        logger.error(f"Error getting provider details: {e}")
        return jsonify({'error': str(e)}), 500
@api.route('/providers/resources/describe/<service>/<type>/<name>')
def get_resource_describe(service, type, name):
    try:
        logger.debug(f"Starting resource describe for {service}/{type}/{name}")
        
        # Map AWS services
        if service == 'ec2':
            group = 'ec2.aws.crossplane.io'
            
        api_extensions = client.ApiextensionsV1Api()
        
        # List all CRDs and find the matching one
        all_crds = api_extensions.list_custom_resource_definition()
        
        matching_crd = None
        for crd in all_crds.items:
            logger.debug(f"Checking CRD: {crd.spec.names.kind} in group {crd.spec.group}")
            if (crd.spec.group == group and 
                crd.spec.names.kind.lower() == type.lower()):
                matching_crd = crd
                break

        if not matching_crd:
            return jsonify({'error': f"No CRD found for {type} in {group}"}), 404

        # Get API version and plural from matched CRD
        api_version = next((v.name for v in matching_crd.spec.versions if v.served), 'v1alpha1')
        resource_plural = matching_crd.spec.names.plural

        logger.debug(f"Found CRD: group={group}, version={api_version}, plural={resource_plural}")

        # Get the actual resource
        resource = custom_api.get_cluster_custom_object(
            group=group,
            version=api_version,
            plural=resource_plural,
            name=name
        )

        if not resource:
            return jsonify({'error': f"Resource {name} not found"}), 404

        # Format describe output 
        conditions_str = ""
        for condition in resource.get('status', {}).get('conditions', []):
            conditions_str += f"""  {condition.get('type', '')}:
    Status:               {condition.get('status', '')}
    Last Transition Time: {condition.get('lastTransitionTime', '')}
    Reason:              {condition.get('reason', '')}
    Message:             {condition.get('message', '')}\n"""

        describe = f"""Name:         {resource['metadata']['name']}
API Version:  {resource['apiVersion']}
Kind:         {resource['kind']}
Metadata:
  Creation Timestamp:  {resource['metadata']['creationTimestamp']}
  Generation:         {resource['metadata'].get('generation', '-')}
  Resource Version:   {resource['metadata'].get('resourceVersion', '-')}
  UID:               {resource['metadata'].get('uid', '-')}

Spec:
  Provider Config Ref:
    Name:  {resource['spec'].get('providerConfigRef', {}).get('name', '-')}
  For Provider:
    {yaml.dump(resource['spec'].get('forProvider', {}), default_flow_style=False, indent=4).replace('\n', '\n    ')}

Status:
  Conditions:
{conditions_str}
  At Provider:
    {yaml.dump(resource.get('status', {}).get('atProvider', {}), default_flow_style=False, indent=4).replace('\n', '\n    ')}"""

        return jsonify({
            'describe': describe,
            'resource': resource
        })
            
    except Exception as e:
        error_message = str(e)
        logger.error(f"Error getting resource describe: {error_message}", exc_info=True)
        return jsonify({
            'error': f"Failed to describe resource: {error_message}",
            'details': {
                'service': service,
                'type': type,
                'name': name,
                'group': group if 'group' in locals() else 'unknown',
                'error': error_message,
                'crd': matching_crd.to_dict() if 'matching_crd' in locals() and matching_crd else None
            }
        }), 500
        
# Rotas de Compositions
@api.route('/compositions')
def get_compositions():
    """Lista todas as compositions"""
    try:
        compositions = composition_svc.get_compositions()
        return jsonify(compositions)
    except Exception as e:
        logger.error(f"Error listing compositions: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/compositions/<name>')
def get_composition_details(name):
    """Obtém detalhes de uma composition específica"""
    try:
        details = composition_svc.get_composition_details(name)
        if details is None:
            return jsonify({'error': 'Composition not found'}), 404
        return jsonify(details)
    except Exception as e:
        logger.error(f"Error getting composition details: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/compositions/describe/<name>')
def get_composition_describe(name):
    """Get detailed describe information about a specific composition"""
    try:
        logger.info(f"Getting describe for composition {name}")

        # Busca a composition
        try:
            composition = custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=name
            )
            logger.info(f"Found composition: {name}")
        except client.exceptions.ApiException as e:
            if e.status == 404:
                logger.warning(f"Composition {name} not found")
                return jsonify({
                    'error': f"Composition '{name}' not found",
                    'details': 'The specified composition does not exist'
                }), 404
            else:
                raise

        # Formatar recursos
        resources_str = ""
        for idx, resource in enumerate(composition.get('spec', {}).get('resources', []), 1):
            resources_str += f"""
Resource {idx}:
  Base:
    API Version: {resource.get('base', {}).get('apiVersion', '-')}
    Kind:        {resource.get('base', {}).get('kind', '-')}
    Spec:
      {yaml.dump(resource.get('base', {}).get('spec', {}), default_flow_style=False, indent=6)}
  
  Patches:
"""
            for patch in resource.get('patches', []):
                resources_str += f"""    - Type: {patch.get('type', '-')}
      From: {patch.get('fromFieldPath', '-')}
      To: {patch.get('toFieldPath', '-')}
      Transforms: {patch.get('transforms', [])}
"""

        # Format describe output
        describe = f"""Name:         {composition['metadata']['name']}
Namespace:    {composition['metadata'].get('namespace', 'default')}
API Version:  {composition['apiVersion']}
Kind:         {composition['kind']}

Metadata:
  Creation Timestamp:  {composition['metadata']['creationTimestamp']}
  Generation:         {composition['metadata'].get('generation', '-')}
  Resource Version:   {composition['metadata'].get('resourceVersion', '-')}
  UID:               {composition['metadata'].get('uid', '-')}

Spec:
  Composite Type Ref:
    API Version:  {composition['spec'].get('compositeTypeRef', {}).get('apiVersion', '-')}
    Kind:         {composition['spec'].get('compositeTypeRef', {}).get('kind', '-')}
  
  Mode: {composition['spec'].get('mode', 'Pipeline')}

  Resources:{resources_str}

Status:
  Conditions:
    {yaml.dump(composition.get('status', {}).get('conditions', []), default_flow_style=False, indent=4)}"""

        logger.info(f"Successfully generated describe for composition {name}")
        return jsonify({
            'describe': describe,
            'resource': composition
        })

    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting composition describe: {error_msg}", exc_info=True)
        return jsonify({
            'error': 'Failed to describe composition',
            'details': error_msg,
            'trace': traceback.format_exc()
        }), 500

@api.route('/compositions/resources/describe/<service>/<type>/<name>')
def get_composition_resource_describe(service, type, name):
    """Get detailed describe information about a specific composition resource"""
    try:
        logger.info(f"Getting describe for composition resource {service}/{type}/{name}")

        # Construir o grupo API
        resource_group = f"{service}.crossplane.io"
        
        # Busca o CRD primeiro
        try:
            crd_name = f"{type.lower()}.{service}.crossplane.io"
            logger.info(f"Looking for CRD: {crd_name}")
            
            crd = api_client.read_custom_resource_definition(
                name=crd_name
            )
            api_version = next((v.name for v in crd.spec.versions if v.served), 'v1alpha1')
            logger.info(f"Found API version from CRD: {api_version}")
            
        except client.exceptions.ApiException as e:
            if e.status == 404:
                logger.warning(f"CRD {crd_name} not found, using default version")
                api_version = 'v1alpha1'
            else:
                raise

        # Formatar o plural do recurso
        resource_plural = type.lower()
        if not resource_plural.endswith('s'):
            resource_plural += 's'

        logger.info(f"Looking up resource: group={resource_group}, version={api_version}, plural={resource_plural}, name={name}")

        # Buscar o recurso
        try:
            resource = custom_api.get_cluster_custom_object(
                group=resource_group,
                version=api_version,
                plural=resource_plural,
                name=name
            )
            logger.info(f"Found resource {name}")
            
        except client.exceptions.ApiException as e:
            if e.status == 404:
                logger.warning(f"Resource {name} not found")
                return jsonify({
                    'error': f"Resource '{name}' not found",
                    'details': 'The specified resource does not exist',
                    'group': resource_group,
                    'version': api_version,
                    'plural': resource_plural
                }), 404
            else:
                raise

        # Formatar as condições
        conditions = resource.get('status', {}).get('conditions', [])
        conditions_str = ""
        for condition in conditions:
            conditions_str += f"""  {condition.get('type', '')}:
    Status:               {condition.get('status', '')}
    Last Transition Time: {condition.get('lastTransitionTime', '')}
    Reason:              {condition.get('reason', '')}
    Message:             {condition.get('message', '')}\n"""

        # Format resource details
        describe = f"""Name:         {resource['metadata']['name']}
API Version:  {resource['apiVersion']}
Kind:         {resource['kind']}
Metadata:
  Creation Timestamp:  {resource['metadata']['creationTimestamp']}
  Generation:         {resource['metadata'].get('generation', '-')}
  Resource Version:   {resource['metadata'].get('resourceVersion', '-')}
  UID:               {resource['metadata'].get('uid', '-')}

Spec:
  Composition Ref:
    Name:  {resource['spec'].get('compositionRef', {}).get('name', '-')}
  Composition Update Policy: {resource['spec'].get('compositionUpdatePolicy', '-')}
  Composition Revision Ref:
    Name:  {resource['spec'].get('compositionRevisionRef', {}).get('name', '-')}

Status:
  Conditions:
{conditions_str}
  Composed Resources:
    {yaml.dump(resource.get('status', {}).get('resources', []), default_flow_style=False, indent=4).replace('\n', '\n    ')}"""

        return jsonify({
            'describe': describe,
            'resource': resource
        })
            
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting resource describe: {error_msg}", exc_info=True)
        return jsonify({
            'error': 'Failed to describe resource',
            'details': error_msg,
            'debug_info': {
                'service': service,
                'type': type,
                'name': name,
                'group': resource_group,
                'api_version': api_version,
                'resource_plural': resource_plural
            },
            'trace': traceback.format_exc()
        }), 500


@api.route('/configurations/<name>')
def get_configuration_details(name):
    """Obtém detalhes de uma configuration"""
    try:
        config = config_service.get_configuration_details(name)
        if config is None:
            return jsonify({'error': 'Configuration not found'}), 404
        return jsonify(config)
    except Exception as e:
        logger.error(f"Error getting configuration details: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations/<name>/resources')
def get_configuration_resources(name):
    """Obtém recursos de uma configuration"""
    try:
        config = config_service.get_configuration_details(name)
        if config is None:
            return jsonify({'error': 'Configuration not found'}), 404
        return jsonify(config.get('resources', {}))
    except Exception as e:
        logger.error(f"Error getting configuration resources: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations/<name>/packages')
def get_configuration_packages(name):
    """Obtém pacotes de uma configuration"""
    try:
        packages = config_service.get_configuration_packages(name)
        return jsonify(packages)
    except Exception as e:
        logger.error(f"Error getting configuration packages: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations/<name>/revisions')
def get_configuration_revisions(name):
    """Obtém revisões de uma configuration"""
    try:
        revisions = config_service.get_configuration_revisions(name)
        return jsonify(revisions)
    except Exception as e:
        logger.error(f"Error getting configuration revisions: {e}")
        return jsonify({'error': str(e)}), 500

# Handler para erros 404
@api.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

# Handler para erros 500
@api.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    return jsonify({'error': 'Internal server error'}), 500

# Handlers de erro
@api.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

