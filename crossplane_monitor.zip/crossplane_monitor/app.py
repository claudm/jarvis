# app.py
from flask import Flask
from routes.main import main_bp
from routes.api import api
from config.settings import get_config
import logging
import os
from datetime import datetime

def create_app():
    app = Flask(__name__)
    
    # Configuração baseada no ambiente
    config = get_config()
    app.config.from_object(config)
    
    # Set higher timeout and add CORS headers
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
    app.config['PERMANENT_SESSION_LIFETIME'] = 3600
    
    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        return response

    # Enhanced logging configuration
    logging.basicConfig(
        level=logging.DEBUG,  # Force debug level for troubleshooting
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)

    # Configure Flask logger
    app.logger.setLevel(logging.DEBUG)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    app.logger.addHandler(console_handler)

    # Filtro para formatação de data/hora
    @app.template_filter('datetime')
    def format_datetime(value):
        """Formata timestamp para data/hora legível"""
        if not value:
            return ''
        try:
            if isinstance(value, str):
                dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                return dt.strftime('%Y-%m-%d %H:%M:%S')
            return value
        except Exception:
            return value

    # Register blueprints with error handling
    try:
        app.register_blueprint(main_bp)  # Main routes
        app.register_blueprint(api, url_prefix='/api')  # API endpoints
              
       
    except Exception as e:
        logger.error(f"Failed to initialize application components: {e}")
        raise

    # Startup logging
    logger.info(f"Application started in {os.getenv('FLASK_ENV', 'development')} mode")
    logger.info(f"Debug mode: {app.config['DEBUG']}")
 

    return app

def main():
    app = create_app()
    
    app.run(
        host='0.0.0.0',
        port=int(os.getenv('PORT', 8000)),
        debug=app.config['DEBUG']
    )

if __name__ == '__main__':
    main()