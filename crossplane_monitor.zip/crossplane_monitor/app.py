# app.py
from flask import Flask
from routes.main import main_bp
from routes.api import api
from config.settings import get_config
import logging
import os
from datetime import datetime

def create_app():
    app = Flask(__name__)
    
    # Configuração baseada no ambiente
    config = get_config()
    app.config.from_object(config)
    
    # Set higher timeout and add CORS headers
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
    app.config['PERMANENT_SESSION_LIFETIME'] = 3600
    
    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        return response

    # Enhanced logging configuration
    logging.basicConfig(
        level=logging.DEBUG,  # Force debug level for troubleshooting
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)

    # Configure Flask logger
    app.logger.setLevel(logging.DEBUG)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    app.logger.addHandler(console_handler)

    # Initialize Kubernetes configuration
    try:
        import os
        from kubernetes import config
        
        # Try to load from specified config path first
        kubeconfig_path = app.config.get('KUBERNETES_CONFIG_PATH')
        if kubeconfig_path:
            if os.path.exists(kubeconfig_path):
                logger.info(f"Loading kubeconfig from {kubeconfig_path}")
                config.load_kube_config(config_file=kubeconfig_path)
            else:
                logger.warning(f"Specified kubeconfig path {kubeconfig_path} not found")
                raise FileNotFoundError(f"Kubeconfig not found at {kubeconfig_path}")
        
        # Try default locations
        elif app.config.get('IN_CLUSTER', False):
            logger.info("Attempting to use in-cluster configuration")
            config.load_incluster_config()
        else:
            default_kubeconfig = os.path.expanduser('~/.kube/config')
            if os.path.exists(default_kubeconfig):
                logger.info(f"Loading default kubeconfig from {default_kubeconfig}")
                config.load_kube_config(config_file=default_kubeconfig)
            else:
                logger.error("No valid kubeconfig found")
                raise FileNotFoundError("No valid kubeconfig found")
                
        logger.info("Successfully initialized Kubernetes configuration")
    except Exception as e:
        logger.error(f"Failed to initialize Kubernetes configuration: {e}")
        app.config['KUBERNETES_AVAILABLE'] = False
    else:
        app.config['KUBERNETES_AVAILABLE'] = True

    # Filtro para formatação de data/hora
    @app.template_filter('datetime')
    def format_datetime(value):
        """Formata timestamp para data/hora legível"""
        if not value:
            return ''
        try:
            if isinstance(value, str):
                dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                return dt.strftime('%Y-%m-%d %H:%M:%S')
            return value
        except Exception:
            return value

    # Register blueprints with error handling
    try:
        app.register_blueprint(main_bp)  # Main routes
        app.register_blueprint(api, url_prefix='/api')  # API endpoints
        
        # Only start Crossplane monitoring if Kubernetes is available
        if app.config['KUBERNETES_AVAILABLE']:
            from routes.main import crossplane_service
            crossplane_service.start()
            logger.info("Crossplane monitoring service started")
        else:
            logger.warning("Crossplane monitoring disabled - Kubernetes not available")

    except Exception as e:
        logger.error(f"Failed to initialize application components: {e}")
        raise

    # Startup logging
    logger.info(f"Application started in {os.getenv('FLASK_ENV', 'development')} mode")
    logger.info(f"Debug mode: {app.config['DEBUG']}")
    logger.info(f"Kubernetes available: {app.config.get('KUBERNETES_AVAILABLE', False)}")

    return app

def main():
    app = create_app()
    app.run(
        host='0.0.0.0',
        port=int(os.getenv('PORT', 8000)),
        debug=app.config['DEBUG']
    )

if __name__ == '__main__':
    main()