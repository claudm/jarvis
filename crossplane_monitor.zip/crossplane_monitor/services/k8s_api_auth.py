from kubernetes import client, config
import os
import logging
import urllib3
from urllib.parse import urlparse

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logger = logging.getLogger(__name__)

def init_kubernetes_client():
    """Initialize Kubernetes client using kubeconfig file"""
    try:
        # Load kubeconfig
        config.load_kube_config()
        
        # Configure client
        configuration = client.Configuration.get_default_copy()
        configuration.verify_ssl = False
        
        # Create API client
        client.Configuration.set_default(configuration)
        api_client = client.ApiClient(configuration)
        
        # Test connection
        v1 = client.CoreV1Api(api_client)
        try:
            v1.list_namespace(limit=1)
            logger.info("Successfully connected to Kubernetes cluster")
        except Exception as e:
            logger.warning(f"Could not list namespaces: {e}")

        return client

    except Exception as e:
        logger.error(f"Failed to initialize Kubernetes client: {e}")
        raise