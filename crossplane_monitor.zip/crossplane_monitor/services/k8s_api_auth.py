from kubernetes_asyncio import client, config
import logging
import urllib3
from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)
logger = logging.getLogger(__name__)

async def init_kubernetes_client():
    """Initialize async Kubernetes client using kubeconfig file"""
    try:
        # Load kubeconfig asynchronously
        await config.load_kube_config()
        
        # Configure client
        configuration = client.Configuration.get_default_copy()
        configuration.verify_ssl = False
        
        # Set default configuration
        client.Configuration.set_default(configuration)
        
        # Create API client
        api_client = client.ApiClient(configuration)
        
        # Test connection
        v1 = client.CoreV1Api(api_client)
        try:
            await v1.list_namespace(limit=1)
            logger.info("Successfully connected to Kubernetes cluster")
        except Exception as e:
            logger.warning(f"Could not list namespaces: {e}")

        return api_client

    except Exception as e:
        logger.error(f"Failed to initialize Kubernetes client: {e}")
        raise