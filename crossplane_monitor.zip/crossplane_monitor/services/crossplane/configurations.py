# services/crossplane/configurations.py
from kubernetes import client
from typing import Dict, List, Any, Optional
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class ConfigurationService:
    def __init__(self, custom_api: client.CustomObjectsApi):
        self.custom_api = custom_api
        self.api_extensions = client.ApiextensionsV1Api()

    def get_configurations(self) -> List[Dict[str, Any]]:
        """
        Obtém todas as configurations.
        """
        try:
            configurations = self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="configurations"
            )
            
            return [{
                'name': c['metadata']['name'],
                'status': self._get_configuration_status(c),
                'package_type': c.get('spec', {}).get('packageType', ''),
                'revision': c.get('status', {}).get('currentRevision', ''),
                'dependencies': c.get('spec', {}).get('dependencies', []),
                'conditions': c.get('status', {}).get('conditions', []),
                'labels': c['metadata'].get('labels', {}),
                'created_at': c['metadata']['creationTimestamp']
            } for c in configurations.get('items', [])]

        except Exception as e:
            logger.error(f"Error fetching configurations: {e}")
            return []

    def get_configuration_revisions(self, config_name: str) -> List[Dict[str, Any]]:
        """
        Obtém todas as revisões de uma configuration.
        
        Args:
            config_name: Nome da configuration
        """
        try:
            revisions = self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="configurationrevisions"
            )
            
            return [{
                'name': rev['metadata']['name'],
                'version': rev.get('spec', {}).get('revision'),
                'desiredState': rev.get('spec', {}).get('desiredState'),
                'status': self._get_revision_status(rev),
                'configuration': rev.get('spec', {}).get('configurationName'),
                'created_at': rev['metadata']['creationTimestamp']
            } for rev in revisions.get('items', [])
                if config_name in rev.get('spec', {}).get('configurationName', '')]

        except Exception as e:
            logger.error(f"Error fetching configuration revisions: {e}")
            return []

    def _sanitize_resource_data(self, data, max_depth=3, current_depth=0):
        """
        Sanitiza dados do recurso para evitar recursão profunda
        """
        if current_depth >= max_depth:
            return "MAX_DEPTH_REACHED"
        
        if isinstance(data, dict):
            return {k: self._sanitize_resource_data(v, max_depth, current_depth + 1) 
                   for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize_resource_data(item, max_depth, current_depth + 1) 
                   for item in data]
        return data

    def get_managed_resources(self, config_name: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Obtém recursos gerenciados pela configuration de forma otimizada
        """
        try:
            resources_by_type = {}

            # Lista CRDs associados à configuration
            crds = self.api_extensions.list_custom_resource_definition()
            relevant_crds = []
            
            # Filtra CRDs relevantes
            for crd in crds.items:
                labels = crd.metadata.labels or {}
                # Verifica se o CRD está associado à configuration
                if any(label.startswith("pkg.crossplane.io/configuration") for label in labels) and \
                config_name in str(labels):
                    relevant_crds.append(crd)
                    logger.info(f"Found relevant CRD: {crd.metadata.name} for config {config_name}")

            # Se não encontrou CRDs, tenta buscar por XRDs
            if not relevant_crds:
                logger.info(f"No direct CRDs found, looking for XRDs for config {config_name}")
                # Busca XRDs associadas à configuration
                selector = f"pkg.crossplane.io/configuration={config_name}"
                xrds = self.custom_api.list_cluster_custom_object(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    plural="compositeresourcedefinitions",
                    label_selector=selector
                )
                
                # Para cada XRD, busca seus recursos
                for xrd in xrds.get('items', []):
                    try:
                        group = xrd['spec']['group']
                        kind = xrd['spec']['names']['kind']
                        version = xrd['spec']['versions'][0]['name']
                        plural = xrd['spec']['names']['plural']
                        service = group.split('.')[0]

                        logger.info(f"Looking for resources of type {kind} in group {group}")
                        
                        # Busca recursos deste tipo
                        resources = self.custom_api.list_cluster_custom_object(
                            group=group,
                            version=version,
                            plural=plural
                        )

                        if resources.get('items'):
                            if service not in resources_by_type:
                                resources_by_type[service] = {}
                                
                            resources_by_type[service][kind] = [
                                {
                                    'name': r['metadata']['name'],
                                    'kind': kind,
                                    'service': service,
                                    'status': self._get_resource_status(r),
                                    'created_at': r['metadata']['creationTimestamp'],
                                    'spec': self._sanitize_resource_data({
                                        'compositionRef': r.get('spec', {}).get('compositionRef', {}),
                                        'compositionUpdatePolicy': r.get('spec', {}).get('compositionUpdatePolicy', ''),
                                        'compositionRevisionRef': r.get('spec', {}).get('compositionRevisionRef', {})
                                    })
                                }
                                for r in resources.get('items', [])
                            ]
                    except Exception as e:
                        logger.warning(f"Error processing XRD {xrd.get('metadata', {}).get('name', 'unknown')}: {e}")
                        continue

            # Processa os CRDs encontrados diretamente
            for crd in relevant_crds:
                try:
                    kind = crd.spec.names.kind
                    group = crd.spec.group
                    version = crd.spec.versions[0].name
                    plural = crd.spec.names.plural
                    service = group.split('.')[0]

                    logger.info(f"Looking for resources of type {kind} in group {group}")
                    
                    # Busca recursos deste tipo
                    resources = self.custom_api.list_cluster_custom_object(
                        group=group,
                        version=version,
                        plural=plural
                    )

                    if resources.get('items'):
                        if service not in resources_by_type:
                            resources_by_type[service] = {}
                            
                        resources_by_type[service][kind] = [
                            {
                                'name': r['metadata']['name'],
                                'kind': kind,
                                'service': service,
                                'status': self._get_resource_status(r),
                                'created_at': r['metadata']['creationTimestamp'],
                                'spec': self._sanitize_resource_data({
                                    'compositionRef': r.get('spec', {}).get('compositionRef', {}),
                                    'compositionUpdatePolicy': r.get('spec', {}).get('compositionUpdatePolicy', ''),
                                    'compositionRevisionRef': r.get('spec', {}).get('compositionRevisionRef', {})
                                })
                            }
                            for r in resources.get('items', [])
                        ]
                except Exception as e:
                    logger.warning(f"Error processing CRD {crd.metadata.name}: {e}")
                    continue

            logger.info(f"Found resources in {len(resources_by_type)} services for config {config_name}")
            return resources_by_type

        except Exception as e:
            logger.error(f"Error getting managed resources for configuration {config_name}: {e}")
            return {}
    def get_configuration_details(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Obtém detalhes completos de uma configuration específica

        Args:
            name: Nome da configuration
            
        Returns:
            Dict com todos os detalhes da configuration ou None se não encontrada
        """
        try:
            # Get basic configuration info from list
            configurations = self.get_configurations()
            configuration = next((c for c in configurations if c['name'] == name), None)
            
            if not configuration:
                logger.warning(f"Configuration {name} not found")
                return None
                
            # Get additional details
            revisions = self.get_configuration_revisions(name)
            packages = self.get_configuration_packages(name)
            resources = self.get_managed_resources(name)
            
            # Create complete configuration details
            configuration.update({
                'revisions': revisions,
                'packages': packages,
                'resources': resources
            })
            
            logger.info(f"Got details for configuration {name}")
            return configuration

        except Exception as e:
            logger.error(f"Error getting configuration details: {e}")
            return None

    def _get_configuration_status(self, config: Dict[str, Any]) -> str:
        """Determina o status de uma configuration"""
        conditions = config.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
            elif condition['type'] == 'Ready':
                return 'ready' if condition['status'] == 'True' else 'not_ready'
        return 'unknown'

    def _get_revision_status(self, revision: Dict[str, Any]) -> str:
        """Determina o status de uma revisão"""
        conditions = revision.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
        return 'unknown'

    def _get_resource_status(self, resource: Dict[str, Any]) -> str:
        """Determina o status de um recurso gerenciado"""
        conditions = resource.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Ready':
                return 'ready' if condition['status'] == 'True' else 'not_ready'
        return 'unknown'

    def get_configuration_packages(self, name: str) -> Dict[str, List[Dict[str, Any]]]:
        """Obtém pacotes associados a uma configuration"""
        try:
            selector = f"pkg.crossplane.io/configuration={name}"
            
            # Get XRDs
            xrds = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions",
                label_selector=selector
            )

            # Get Compositions 
            compositions = self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                label_selector=selector
            )

            return {
                'xrds': [{
                    'name': xrd['metadata']['name'],
                    'group': xrd['spec']['group'],
                    'kind': xrd['spec']['names']['kind'],
                    'versions': xrd['spec'].get('versions', []),
                    'status': self._get_xrd_status(xrd)
                } for xrd in xrds.get('items', [])],

                'compositions': [{
                    'name': comp['metadata']['name'],
                    'typeRef': comp.get('spec', {}).get('compositeTypeRef', {}),
                    'mode': comp.get('spec', {}).get('mode', 'Pipeline'),
                    'resources_count': len(comp.get('spec', {}).get('resources', []))
                } for comp in compositions.get('items', [])]
            }

        except Exception as e:
            logger.error(f"Error getting configuration packages: {e}")
            return {'xrds': [], 'compositions': []}

    def _get_xrd_status(self, xrd: Dict[str, Any]) -> str:
        """Determina o status de uma XRD"""
        conditions = xrd.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Established':
                return 'established' if condition['status'] == 'True' else 'not_established'
        return 'unknown'