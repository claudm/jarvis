from kubernetes import client
from typing import Dict, List, Any, Optional
import logging

logger = logging.getLogger(__name__)

class ProviderService:
    def __init__(self, custom_api: client.CustomObjectsApi):
        self.custom_api = custom_api
        self.api_extensions = client.ApiextensionsV1Api()

    def get_providers(self) -> List[Dict[str, Any]]:
        """Obtém todos os providers instalados"""
        try:
            providers = self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            
            return [{
                'name': p['metadata']['name'],
                'status': self._get_provider_status(p),
                'package': p['spec'].get('package', ''),
                'revision': p.get('status', {}).get('currentRevision', ''),
                'provider_type': 'upbound' if 'upbound.io' in p['spec'].get('package', '') else 'crossplane',
                'created_at': p['metadata']['creationTimestamp']
            } for p in providers.get('items', [])]

        except Exception as e:
            logger.error(f"Error fetching providers: {e}")
            return []

    def get_provider_details(self, name: str) -> Optional[Dict[str, Any]]:
        """Obtém detalhes completos de um provider específico"""
        try:
            # Get basic provider info
            providers = self.get_providers()
            provider = next((p for p in providers if p['name'] == name), None)
            
            if not provider:
                return None
                
            # Get additional details
            revisions = self.get_provider_revisions(name)
            config = self.get_provider_config(name)
            resources = self.get_managed_resources(name)
            
            # Create complete provider details
            provider.update({
                'revisions': revisions,
                'config': config,
                'resources': resources
            })
            
            logger.info(f"Got details for provider {name}")
            return provider

        except Exception as e:
            logger.error(f"Error getting provider details: {e}")
            return None

    def get_provider_revisions(self, provider_name: str) -> List[Dict[str, Any]]:
        """Obtém todas as revisões de um provider"""
        try:
            revisions = self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providerrevisions"
            )
            
            return [{
                'name': rev['metadata']['name'],
                'version': rev.get('spec', {}).get('revision'),
                'image': rev.get('spec', {}).get('image'),
                'desiredState': rev.get('spec', {}).get('desiredState'),
                'status': self._get_revision_status(rev),
                'provider': rev.get('spec', {}).get('providerName'),
                'created_at': rev['metadata']['creationTimestamp']
            } for rev in revisions.get('items', [])
                if rev.get('spec', {}).get('providerName') == provider_name]

        except Exception as e:
            logger.error(f"Error fetching provider revisions: {e}")
            return []

    def get_provider_config(self, provider_name: str) -> Optional[Dict[str, Any]]:
        """Obtém configuração de um provider específico"""
        try:
            provider_configs = {
                'provider-aws': {
                    'group': 'aws.crossplane.io',
                    'version': 'v1beta1',
                    'plural': 'providerconfigs'
                },
                'provider-azure': {
                    'group': 'azure.crossplane.io',
                    'version': 'v1beta1',
                    'plural': 'providerconfigs'
                },
                'provider-gcp': {
                    'group': 'gcp.crossplane.io',
                    'version': 'v1beta1',
                    'plural': 'providerconfigs'
                }
            }

            if provider_name in provider_configs:
                config = provider_configs[provider_name]
                try:
                    configs = self.custom_api.list_cluster_custom_object(
                        group=config['group'],
                        version=config['version'],
                        plural=config['plural']
                    )
                    
                    if configs.get('items'):
                        config_item = configs['items'][0]
                        return {
                            'name': config_item['metadata']['name'],
                            'kind': config_item['kind'],
                            'spec': config_item.get('spec', {}),
                            'status': config_item.get('status', {}),
                            'created_at': config_item['metadata']['creationTimestamp']
                        }
                except Exception as e:
                    logger.warning(f"Error getting provider config: {e}")
            
            # Try to discover CRD if not a known provider
            crds = self.api_extensions.list_custom_resource_definition(
                label_selector=f"pkg.crossplane.io/provider={provider_name}"
            )

            for crd in crds.items:
                if 'providerconfig' in crd.spec.names.kind.lower():
                    try:
                        configs = self.custom_api.list_cluster_custom_object(
                            group=crd.spec.group,
                            version=crd.spec.versions[0].name,
                            plural=crd.spec.names.plural
                        )
                        
                        if configs.get('items'):
                            config_item = configs['items'][0]
                            return {
                                'name': config_item['metadata']['name'],
                                'kind': config_item['kind'],
                                'spec': config_item.get('spec', {}),
                                'status': config_item.get('status', {}),
                                'created_at': config_item['metadata']['creationTimestamp']
                            }
                    except Exception as e:
                        logger.warning(f"Error getting provider config: {e}")
                        continue

            return None

        except Exception as e:
            logger.error(f"Error getting provider config: {e}")
            return None

    def get_managed_resources(self, provider_name: str) -> Dict[str, List[Dict[str, Any]]]:
        """Obtém recursos gerenciados por um provider"""
        try:
            resources_by_type = {}

            crds = [
                crd for crd in self.api_extensions.list_custom_resource_definition().items
                if f'.{provider_name.split("-")[1]}.crossplane.io' in crd.spec.group and 
                'providerconfig' not in crd.spec.names.kind.lower()
            ]

            for crd in crds:
                try:
                    service = crd.spec.group.split('.')[0]
                    kind = crd.spec.names.kind
                    version = crd.spec.versions[0].name
                    
                    resources = self.custom_api.list_cluster_custom_object(
                        group=crd.spec.group,
                        version=version,
                        plural=crd.spec.names.plural
                    )

                    if resources.get('items'):
                        if service not in resources_by_type:
                            resources_by_type[service] = {}
                            
                        resources_by_type[service][kind] = [
                            {
                                'name': r['metadata']['name'],
                                'kind': kind,
                                'service': service,
                                'status': self._get_resource_status(r),
                                'created_at': r['metadata']['creationTimestamp'],
                                'spec': {
                                    'providerConfigRef': r.get('spec', {}).get('providerConfigRef', {}),
                                    'forProvider': r.get('spec', {}).get('forProvider', {})
                                }
                            }
                            for r in resources.get('items', [])
                        ]
                except Exception as e:
                    logger.warning(f"Error processing CRD {crd.metadata.name}: {e}")
                    continue

            return resources_by_type

        except Exception as e:
            logger.error(f"Error getting managed resources: {e}")
            return {}

    def _get_provider_status(self, provider: Dict[str, Any]) -> str:
        """Determina o status de um provider"""
        conditions = provider.get('status', {}).get('conditions', [])
        
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
            
        return 'unknown'

    def _get_revision_status(self, revision: Dict[str, Any]) -> str:
        """Determina o status de uma revisão"""
        conditions = revision.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
        return 'unknown'

    def _get_resource_status(self, resource: Dict[str, Any]) -> str:
        """Determina o status de um recurso gerenciado"""
        conditions = resource.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Ready':
                return 'ready' if condition['status'] == 'True' else 'not_ready'
        return 'unknown'

    def _sanitize_resource_data(self, data, max_depth=3, current_depth=0):
        """Sanitiza dados do recurso para evitar recursão profunda"""
        if current_depth >= max_depth:
            return "MAX_DEPTH_REACHED"
        
        if isinstance(data, dict):
            return {
                k: self._sanitize_resource_data(v, max_depth, current_depth + 1)
                for k, v in data.items()
            }
        elif isinstance(data, list):
            return [
                self._sanitize_resource_data(item, max_depth, current_depth + 1)
                for item in data
            ]
        return data