from kubernetes import client
from typing import Dict, List, Any, Optional
import logging
import asyncio
from datetime import datetime
from .base_service import BaseService
from ..k8s_api_auth import init_kubernetes_client

logger = logging.getLogger(__name__)

class ProviderService(BaseService):
    def __init__(self, custom_api: client.CustomObjectsApi = None, namespace: str = "crossplane-system"):
        super().__init__(custom_api, namespace)
        self.api_extensions = None
        self.core_api = None
        self.apps_api = None

    async def _async_init(self):
        """Initialize Kubernetes clients"""
        try:
            api_client = await init_kubernetes_client()
            
            # Initialize API clients if not provided
            if self.custom_api is None:
                self.custom_api = client.CustomObjectsApi(api_client)
            if self.api_extensions is None:
                self.api_extensions = client.ApiextensionsV1Api(api_client)
            if self.core_api is None:
                self.core_api = client.CoreV1Api(api_client)
            if self.apps_api is None:
                self.apps_api = client.AppsV1Api(api_client)

            # Test connection
            try:
                await self.core_api.list_namespace(limit=1)
                logger.info("Successfully connected to Kubernetes cluster")
            except Exception as e:
                logger.warning(f"Could not list namespaces: {e}")

        except Exception as e:
            logger.error(f"Error initializing Kubernetes clients: {e}")
            raise
    
    # Utility methods
    def _get_provider_status(self, provider: Dict[str, Any]) -> str:
        """Determina o status de um provider"""
        conditions = provider.get('status', {}).get('conditions', [])
        
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
            
        return 'unknown'

    def _get_revision_status(self, revision: Dict[str, Any]) -> str:
        """Determina o status de uma revisão"""
        conditions = revision.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
        return 'unknown'

    def _get_resource_status(self, resource: Dict[str, Any]) -> str:
        """Determina o status de um recurso gerenciado"""
        conditions = resource.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Ready':
                return condition['status']
        return 'Unknown'

    def _sanitize_resource_data(self, data: Any, max_depth: int = 3, current_depth: int = 0) -> Any:
        """Sanitiza dados do recurso para evitar recursão profunda"""
        if current_depth >= max_depth:
            return "MAX_DEPTH_REACHED"
        
        if isinstance(data, dict):
            return {k: self._sanitize_resource_data(v, max_depth, current_depth + 1) 
                   for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize_resource_data(item, max_depth, current_depth + 1) 
                   for item in data]
        return data

    async def _fetch_crd_resources(self, group: str, version: str, plural: str, service: str, kind: str) -> Optional[Dict]:

        """Busca recursos para uma CRD específica"""
        try:
            result = await self.custom_api.list_cluster_custom_object(
                group=group,
                version=version,
                plural=plural
            )
            
            if not result.get('items'):
                return None
                
            resources = [
                {
                    'name': r['metadata']['name'],
                    'kind': kind,
                    'service': service,
                    'status': self._get_resource_status(r),
                    'created_at': r['metadata']['creationTimestamp'],
                    'spec': self._sanitize_resource_data(r.get('spec', {})),
                    'status_details': self._sanitize_resource_data(r.get('status', {}))
                }
                for r in result.get('items', [])
            ]
            
            return {
                'service': service,
                'kind': kind,
                'resources': resources
            }
            
        except Exception as e:
            logger.error(f"Error fetching resources for {group}/{version}/{plural}: {e}")
            return None

    async def get_providers(self) -> List[Dict[str, Any]]:
        """Obtém todos os providers instalados"""
        try:
            # Make sure clients are initialized
            if not self.custom_api:
                await self._async_init()

            providers = []
            
            # Busca providers regulares do Crossplane
            try:
                response = await self.custom_api.list_cluster_custom_object(
                    group="pkg.crossplane.io",
                    version="v1",
                    plural="providers"
                )
                
                for p in response.get('items', []):
                    metadata = p.get('metadata', {})
                    spec = p.get('spec', {})
                    status = p.get('status', {})
                    
                    provider = {
                        'name': metadata.get('name'),
                        'status': self._get_provider_status(p),
                        'package': spec.get('package', ''),
                        'revision': status.get('currentRevision', ''),
                        'provider_type': 'upbound' if 'upbound.io' in spec.get('package', '') else 'crossplane',
                        'created_at': metadata.get('creationTimestamp'),
                        'namespace': metadata.get('namespace', self.namespace),
                        'labels': metadata.get('labels', {}),
                        'conditions': status.get('conditions', [])
                    }
                    logger.debug(f"Found provider: {provider['name']} (type: {provider['provider_type']})")
                    providers.append(provider)

            except Exception as e:
                logger.warning(f"Error fetching regular providers: {e}")

            # Tenta buscar providers via CRDs se nenhum provider foi encontrado
            if not providers:
                try:
                    crds = await self.api_extensions.list_custom_resource_definition()
                    provider_crds = [
                        crd for crd in crds.items
                        if any(label.startswith('pkg.crossplane.io/provider') 
                              for label in (crd.metadata.labels or {}).keys())
                    ]
                    
                    for crd in provider_crds:
                        name = crd.metadata.name.split('.')[0]
                        if name not in [p['name'] for p in providers]:
                            provider = {
                                'name': name,
                                'status': 'discovered',
                                'package': crd.spec.group,
                                'provider_type': 'discovered',
                                'created_at': crd.metadata.creation_timestamp,
                                'namespace': self.namespace,
                                'labels': crd.metadata.labels or {}
                            }
                            logger.debug(f"Discovered provider via CRD: {provider['name']}")
                            providers.append(provider)
                
                except Exception as e:
                    logger.warning(f"Error discovering providers via CRDs: {e}")

            if not providers:
                logger.warning(f"No providers found in namespace {self.namespace}")
            else:
                logger.info(f"Found {len(providers)} providers in namespace {self.namespace}")

            return providers

        except Exception as e:
            logger.error(f"Error fetching providers: {e}")
            return []

    async def get_provider_details(self, name: str) -> Optional[Dict[str, Any]]:
        """Obtém detalhes completos de um provider específico"""
        try:
            logger.info(f"Fetching details for provider: {name}")
            
            # Make sure clients are initialized
            if not self.custom_api:
                await self._async_init()
            
            # Normaliza o nome do provider
            if not name.startswith('provider-') and not name.startswith('upbound'):
                normalized_name = f'provider-{name}'
            else:
                normalized_name = name
            
            logger.debug(f"Using normalized name: {normalized_name}")
            
            # Tenta buscar o provider diretamente primeiro
            provider = None
            try:
                provider_obj = await self.custom_api.get_cluster_custom_object(
                    group="pkg.crossplane.io",
                    version="v1",
                    plural="providers",
                    name=normalized_name
                )
                logger.debug(f"Found provider directly: {normalized_name}")
                
                provider = {
                    'name': normalized_name,
                    'status': self._get_provider_status(provider_obj),
                    'package': provider_obj.get('spec', {}).get('package', ''),
                    'revision': provider_obj.get('status', {}).get('currentRevision', ''),
                    'provider_type': 'upbound' if 'upbound.io' in provider_obj.get('spec', {}).get('package', '') else 'crossplane',
                    'created_at': provider_obj['metadata']['creationTimestamp'],
                    'namespace': provider_obj['metadata'].get('namespace', self.namespace),
                    'labels': provider_obj['metadata'].get('labels', {}),
                    'conditions': provider_obj.get('status', {}).get('conditions', [])
                }
            except Exception as e:
                logger.warning(f"Could not find provider directly, trying fallback methods: {e}")
                
                # Tenta buscar na lista de providers
                providers = await self.get_providers()
                provider = next((p for p in providers if p['name'] in [name, normalized_name]), None)
            
            if not provider:
                logger.error(f"Provider not found: {name}")
                return None
            
            # Busca detalhes adicionais em paralelo
            logger.debug(f"Fetching additional details for provider: {provider['name']}")
            try:
                revisions, resources = await asyncio.gather(
                    self.get_provider_revisions(provider['name']),
                    self.get_managed_resources(provider['name']),
                    return_exceptions=True
                )
                
                # Trata erros individuais
                provider.update({
                    'revisions': [] if isinstance(revisions, Exception) else revisions,
                    'resources': {} if isinstance(resources, Exception) else resources
                })
                
                logger.info(f"Successfully fetched details for provider {name}")
                return provider
                
            except Exception as e:
                logger.error(f"Error fetching additional details: {e}")
                # Retorna o provider com informações básicas mesmo se falhar ao buscar detalhes
                return provider

        except Exception as e:
            logger.error(f"Error getting provider details: {e}")
            return None
    
    async def get_provider_revisions(self, provider_name: str) -> List[Dict[str, Any]]:
        """Obtém todas as revisões de um provider"""
        try:
            # Make sure clients are initialized
            if not self.custom_api:
                await self._async_init()

            revisions = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providerrevisions"
            )
            
            return [{
                'name': rev['metadata']['name'],
                'version': rev.get('spec', {}).get('revision'),
                'image': rev.get('spec', {}).get('image'),
                'desiredState': rev.get('spec', {}).get('desiredState'),
                'status': self._get_revision_status(rev),
                'provider': rev.get('spec', {}).get('providerName'),
                'created_at': rev['metadata']['creationTimestamp']
            } for rev in revisions.get('items', [])
                if rev.get('spec', {}).get('providerName') == provider_name]

        except Exception as e:
            logger.error(f"Error fetching provider revisions: {e}")
            return []

    async def get_managed_resources(self, provider_name: str) -> Dict[str, List[Dict[str, Any]]]:
        """Obtém recursos gerenciados por um provider de forma mais abrangente"""
        try:
            # Make sure clients are initialized
            if not self.custom_api:
                await self._async_init()

            resources_by_type = {}
            provider_group = None
            
            # Primeiro determina o grupo do provider
            base_name = provider_name.replace('provider-', '')
            if 'upbound' in provider_name:
                # Trata providers Upbound
                parts = provider_name.split('-')
                if len(parts) >= 2:
                    provider_group = f'upbound.io/{parts[1]}'
            else:
                # Tenta inferir o grupo do nome
                provider_group = f'{base_name}.crossplane.io'

            logger.info(f"Discovering resources for provider {provider_name} (group: {provider_group})")

            # Busca CRDs
            try:
                crd_list = await self.api_extensions.list_custom_resource_definition()
                
                # Filtra CRDs relevantes usando múltiplos critérios
                relevant_crds = []
                for crd in crd_list.items:
                    crd_group = crd.spec.group
                    
                    # Verifica várias condições para identificar CRDs do provider
                    is_relevant = (
                        # Verifica se pertence ao grupo do provider
                        (provider_group and crd_group == provider_group) or
                        # Ou se tem o label do provider
                        (crd.metadata.labels and 
                         any(label.startswith(f"pkg.crossplane.io/provider") 
                             for label in crd.metadata.labels)) or
                        # Ou se o grupo contém o nome do provider
                        (base_name in crd_group) or
                        # Exclui CRDs específicas que não são recursos gerenciados
                        (not crd.spec.names.kind.lower().endswith('providerconfig') and
                         not crd.spec.names.kind.lower().endswith('providerrevision'))
                    )
                    
                    if is_relevant:
                        relevant_crds.append(crd)
                        logger.debug(f"Found relevant CRD: {crd.metadata.name}")

                # Processa CRDs em paralelo
                tasks = []
                for crd in relevant_crds:
                    service = crd.spec.group.split('.')[0]
                    if 'upbound.io' in crd.spec.group:
                        service = crd.spec.group.split('/')[-1]
                        
                    kind = crd.spec.names.kind
                    version = crd.spec.versions[0].name
                    plural = crd.spec.names.plural
                    
                    tasks.append(
                        self._fetch_crd_resources(
                            group=crd.spec.group,
                            version=version,
                            plural=plural,
                            service=service,
                            kind=kind
                        )
                    )

                if tasks:
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    
                    # Processa resultados
                    for result in results:
                        if isinstance(result, Exception):
                            logger.error(f"Error fetching resources: {result}")
                            continue
                            
                        if result:
                            service = result['service']
                            kind = result['kind']
                            resources = result['resources']
                            
                            if service not in resources_by_type:
                                resources_by_type[service] = {}
                            if resources:  # Só adiciona se houver recursos
                                resources_by_type[service][kind] = resources
                
                if not resources_by_type:
                    logger.warning(f"No resources found for provider {provider_name}")
                else:
                    total_resources = sum(len(resources) 
                                       for service in resources_by_type.values() 
                                       for resources in service.values())
                    logger.info(f"Found {total_resources} resources for provider {provider_name}")

                return resources_by_type

            except Exception as e:
                logger.error(f"Error listing CRDs: {e}")
                return {}

        except Exception as e:
            logger.error(f"Error getting managed resources: {e}")
            return {}