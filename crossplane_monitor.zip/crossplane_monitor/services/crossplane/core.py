import threading
import logging
import time
import os
from typing import Dict, List, Any, Optional
from datetime import datetime
from kubernetes import client, config, watch

from .providers import ProviderService
from .compositions import CompositionService
from .configurations import ConfigurationService

logger = logging.getLogger(__name__)

class CrossplaneService:
    def __init__(self, 
                 namespace: str = "crossplane-system",
                 refresh_interval: int = 30,
                 kubernetes_config: Optional[str] = None,
                 in_cluster: bool = False):
        self.namespace = namespace
        self.refresh_interval = refresh_interval
        self.running = False
        self._setup_kubernetes(kubernetes_config, in_cluster)
        self.resources = {}
        self.watchers = {}
        self._lock = threading.Lock()
        
        self.provider_service = ProviderService(self.custom_api)
        self.composition_service = CompositionService(self.custom_api)
        self.configuration_service = ConfigurationService(self.custom_api)

    def _setup_kubernetes(self, kubernetes_config: Optional[str], in_cluster: bool):
        try:
            # Get proxy settings from environment variables
            http_proxy = os.environ.get('HTTP_PROXY') or os.environ.get('http_proxy')
            https_proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
            no_proxy = os.environ.get('NO_PROXY') or os.environ.get('no_proxy')

            if in_cluster:
                config.load_incluster_config()
                logger.info("Using in-cluster configuration")
            else:
                if kubernetes_config:
                    config.load_kube_config(config_file=kubernetes_config)
                else:
                    config.load_kube_config()

            # Configure proxy settings if they exist
            if http_proxy or https_proxy:
                configuration = client.Configuration.get_default_copy()
                if https_proxy:
                    configuration.proxy = https_proxy
                    logger.info(f"Using HTTPS proxy: {https_proxy}")
                elif http_proxy:
                    configuration.proxy = http_proxy
                    logger.info(f"Using HTTP proxy: {http_proxy}")
                
                if no_proxy:
                    configuration.no_proxy = no_proxy
                    logger.info(f"Using NO_PROXY: {no_proxy}")
                
                client.Configuration.set_default(configuration)

            self.k8s_client = client.ApiClient()
            self.custom_api = client.CustomObjectsApi(self.k8s_client)
            self.core_api = client.CoreV1Api(self.k8s_client)
            self.apps_api = client.AppsV1Api(self.k8s_client)
        except Exception as e:
            logger.error(f"Failed to setup Kubernetes client: {e}")
            raise

    def get_summary(self) -> Dict[str, Any]:
        """Obtém um resumo atualizado dos recursos monitorados"""
        try:
            logger.debug("Starting get_summary()")
            health_status = self.get_health_status()
            
            # Get providers
            providers = self.provider_service.get_providers()
            logger.debug(f"Found {len(providers)} providers")
            healthy_providers = sum(1 for p in providers if p['status'] == 'healthy')
            unhealthy_providers = sum(1 for p in providers if p['status'] == 'unhealthy')
            unknown_providers = len(providers) - healthy_providers - unhealthy_providers

            # Get compositions
            compositions = self.composition_service.get_compositions()
            logger.debug(f"Found {len(compositions)} compositions")
            active_compositions = sum(1 for c in compositions if c['status'] == 'established')
            inactive_compositions = len(compositions) - active_compositions

            # Get configurations
            configurations = self.configuration_service.get_configurations()
            logger.debug(f"Found {len(configurations)} configurations")
            healthy_configurations = sum(1 for c in configurations if c['status'] == 'healthy')
            unhealthy_configurations = len(configurations) - healthy_configurations

            # Get recent events
            events = self.get_system_events()[:10]
            logger.debug(f"Found {len(events)} events")

            summary = {
                'providers': len(providers),
                'healthy_providers': healthy_providers,
                'unhealthy_providers': unhealthy_providers,
                'unknown_providers': unknown_providers,
                
                'compositions': len(compositions),
                'active_compositions': active_compositions,
                'inactive_compositions': inactive_compositions,
                
                'configurations': len(configurations),
                'healthy_configurations': healthy_configurations,
                'unhealthy_configurations': unhealthy_configurations,
                
                'health': health_status.get('healthy', False),
                'events': events
            }

            logger.debug("Returning summary data")
            return summary

        except Exception as e:
            logger.error(f"Error getting summary: {e}")
            return {
                'providers': 0,
                'healthy_providers': 0,
                'unhealthy_providers': 0,
                'unknown_providers': 0,
                'compositions': 0,
                'active_compositions': 0,
                'inactive_compositions': 0,
                'configurations': 0,
                'healthy_configurations': 0,
                'unhealthy_configurations': 0,
                'health': False,
                'events': [],
            }

    def start(self):
        """Inicia o monitoramento dos recursos Crossplane"""
        if self.running:
            logger.warning("Service is already running")
            return

        self.running = True
        logger.info("Starting Crossplane monitoring service")

        self._start_watcher('providers', 
                         group="pkg.crossplane.io",
                         version="v1",
                         plural="providers",
                         upbound_group="registry.upbound.io")
        
        self._start_watcher('configurations',
                          group="pkg.crossplane.io",
                          version="v1",
                          plural="configurations",
                          upbound_group="registry.upbound.io")
        
        self._start_watcher('compositions',
                          group="apiextensions.crossplane.io",
                          version="v1",
                          plural="compositions",
                          upbound_group="apiextensions.upbound.io")

        self._start_health_check()

    def _start_watcher(self, resource_type: str, group: str, version: str, plural: str, upbound_group: Optional[str] = None):
        def watch_resource():
            w = watch.Watch()
            while self.running:
                try:
                    for event in w.stream(
                        self.custom_api.list_cluster_custom_object,
                        group=group,
                        version=version,
                        plural=plural
                    ):
                        if not self.running:
                            break
                        self._handle_event(resource_type, event)

                    if upbound_group:
                        for event in w.stream(
                            self.custom_api.list_cluster_custom_object,
                            group=upbound_group,
                            version=version,
                            plural=plural
                        ):
                            if not self.running:
                                break
                            self._handle_event(f"upbound_{resource_type}", event)

                except Exception as e:
                    logger.error(f"Error watching {resource_type}: {e}")
                    time.sleep(5)

        thread = threading.Thread(target=watch_resource)
        thread.daemon = True
        thread.start()
        self.watchers[resource_type] = thread
        logger.info(f"Started watcher for {resource_type}")

    def _handle_event(self, resource_type: str, event: Dict[str, Any]):
        try:
            event_type = event['type']
            resource = event['object']
            name = resource['metadata']['name']
            
            with self._lock:
                if resource_type not in self.resources:
                    self.resources[resource_type] = {}

                if event_type in ['ADDED', 'MODIFIED']:
                    processed = self._process_resource(resource)
                    self.resources[resource_type][name] = processed
                elif event_type == 'DELETED':
                    self.resources[resource_type].pop(name, None)

            logger.debug(f"Handled {event_type} event for {resource_type}/{name}")
        except Exception as e:
            logger.error(f"Error handling event: {e}")

    def _process_resource(self, resource: Dict[str, Any]) -> Dict[str, Any]:
        return {
            'name': resource['metadata']['name'],
            'kind': resource['kind'],
            'apiVersion': resource['apiVersion'],
            'metadata': resource['metadata'],
            'spec': resource.get('spec', {}),
            'status': resource.get('status', {}),
            'last_updated': datetime.utcnow().isoformat()
        }

    def _start_health_check(self):
        def check_health():
            while self.running:
                try:
                    self._update_health_status()
                except Exception as e:
                    logger.error(f"Error in health check: {e}")
                time.sleep(self.refresh_interval)

        thread = threading.Thread(target=check_health)
        thread.daemon = True
        thread.start()
        logger.info("Started health check thread")

    def _update_health_status(self):
        try:
            pods = self.core_api.list_namespaced_pod(
                namespace=self.namespace,
                label_selector='app=crossplane'
            )
            
            deployments = self.apps_api.list_namespaced_deployment(
                namespace=self.namespace,
                label_selector='app=crossplane'
            )

            pods_healthy = all(
                pod.status.phase == 'Running' 
                for pod in pods.items
            )

            deployments_healthy = all(
                dep.status.ready_replicas == dep.status.replicas
                for dep in deployments.items
                if dep.status.replicas > 0
            )

            status = {
                'healthy': pods_healthy and deployments_healthy,
                'pods': {
                    pod.metadata.name: {
                        'phase': pod.status.phase,
                        'conditions': [
                            {
                                'type': c.type,
                                'status': c.status,
                                'message': c.message
                            }
                            for c in (pod.status.conditions or [])
                        ]
                    }
                    for pod in pods.items
                },
                'deployments': {
                    dep.metadata.name: {
                        'ready': dep.status.ready_replicas == dep.status.replicas,
                        'replicas': dep.status.replicas,
                        'available': dep.status.available_replicas
                    }
                    for dep in deployments.items
                },
                'timestamp': datetime.utcnow().isoformat()
            }

            with self._lock:
                self.resources['health'] = status

            logger.debug("Health status updated")
        except Exception as e:
            logger.error(f"Error updating health status: {e}")

    def get_health_status(self) -> Dict[str, Any]:
        with self._lock:
            return self.resources.get('health', {})

    def get_system_events(self) -> List[Dict[str, Any]]:
        try:
            events = self.core_api.list_event_for_all_namespaces(
                field_selector=f'involvedObject.name=crossplane,involvedObject.namespace={self.namespace}'
            )

            crossplane_events = self.core_api.list_namespaced_event(
                namespace=self.namespace
            )

            provider_events = self.core_api.list_event_for_all_namespaces(
                field_selector='involvedObject.kind=Provider'
            )

            all_events = []
            
            for event in crossplane_events.items:
                all_events.append({
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'involved_object': {
                        'kind': event.involved_object.kind,
                        'name': event.involved_object.name,
                        'namespace': event.involved_object.namespace
                    },
                    'count': event.count,
                    'first_timestamp': event.first_timestamp,
                    'last_timestamp': event.last_timestamp
                })

            for event in provider_events.items:
                all_events.append({
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'involved_object': {
                        'kind': event.involved_object.kind,
                        'name': event.involved_object.name,
                        'namespace': event.involved_object.namespace
                    },
                    'count': event.count,
                    'first_timestamp': event.first_timestamp,
                    'last_timestamp': event.last_timestamp
                })

            seen = set()
            unique_events = []
            for event in all_events:
                event_key = f"{event['involved_object']['kind']}-{event['involved_object']['name']}-{event['message']}"
                if event_key not in seen:
                    seen.add(event_key)
                    unique_events.append(event)

            unique_events.sort(
                key=lambda x: x['last_timestamp'] if x['last_timestamp'] else '',
                reverse=True
            )

            logger.debug(f"Retrieved {len(unique_events)} system events")
            return unique_events

        except Exception as e:
            logger.error(f"Error getting system events: {e}", exc_info=True)
            return []

    def stop(self):
        logger.info("Stopping Crossplane monitoring service")
        self.running = False
        
        for watcher in self.watchers.values():
            watcher.join(timeout=5)
            
        logger.info("Crossplane monitoring service stopped")