# services/crossplane/core.py
import logging
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
from kubernetes_asyncio import client
from ..k8s_api_auth import get_kubernetes_client
from .base_service import BaseService

logger = logging.getLogger(__name__)

class CrossplaneService(BaseService):
    def __init__(self, namespace: str = "crossplane-system"):
        super().__init__(namespace)
        self.k8s_client = get_kubernetes_client()
        self.custom_api = None
        self.core_api = None
        self.apps_api = None

    async def _async_init(self):
        """Initialize async components"""
        try:
            # Initialize API clients
            self.custom_api = await self.k8s_client.custom_api
            self.core_api = await self.k8s_client.core_api
            self.apps_api = await self.k8s_client.apps_api
            
            await self._setup_kubernetes()
            logger.info("Crossplane service initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Crossplane service: {e}")
            raise

    async def _setup_kubernetes(self):
        """Initialize Kubernetes specific components"""
        try:
            # Test connection
            await self.core_api.list_namespaced_pod(self.namespace, limit=1)
            logger.info("Successfully connected to Kubernetes cluster")
        except Exception as e:
            logger.error(f"Failed to connect to Kubernetes cluster: {e}")
            raise

    async def get_summary(self) -> Dict[str, Any]:
        """Get system summary"""
        try:
            logger.debug("Starting get_summary()")
            health_status = await self.get_health_status()
            
            # Get providers
            providers = await self.get_providers()
            logger.debug(f"Found {len(providers)} providers")
            healthy_providers = sum(1 for p in providers if p['status'] == 'healthy')
            unhealthy_providers = sum(1 for p in providers if p['status'] == 'unhealthy')
            unknown_providers = len(providers) - healthy_providers - unhealthy_providers

            # Get compositions
            compositions = await self.get_compositions()
            logger.debug(f"Found {len(compositions)} compositions")
            active_compositions = sum(1 for c in compositions if c['status'] == 'established')
            inactive_compositions = len(compositions) - active_compositions

            # Get configurations
            configurations = await self.get_configurations()
            logger.debug(f"Found {len(configurations)} configurations")
            healthy_configurations = sum(1 for c in configurations if c['status'] == 'healthy')
            unhealthy_configurations = len(configurations) - healthy_configurations

            # Get recent events
            events = (await self.get_system_events())[:10]
            logger.debug(f"Found {len(events)} events")

            summary = {
                'providers': len(providers),
                'healthy_providers': healthy_providers,
                'unhealthy_providers': unhealthy_providers,
                'unknown_providers': unknown_providers,
                
                'compositions': len(compositions),
                'active_compositions': active_compositions,
                'inactive_compositions': inactive_compositions,
                
                'configurations': len(configurations),
                'healthy_configurations': healthy_configurations,
                'unhealthy_configurations': unhealthy_configurations,
                
                'health': health_status.get('healthy', False),
                'events': events
            }

            logger.debug("Returning summary data")
            return summary

        except Exception as e:
            logger.error(f"Error getting summary: {e}")
            return {
                'providers': 0,
                'healthy_providers': 0,
                'unhealthy_providers': 0,
                'unknown_providers': 0,
                'compositions': 0,
                'active_compositions': 0,
                'inactive_compositions': 0,
                'configurations': 0,
                'healthy_configurations': 0,
                'unhealthy_configurations': 0,
                'health': False,
                'events': [],
            }

    async def get_providers(self) -> List[Dict[str, Any]]:
        """Get list of providers"""
        try:
            providers = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            return providers.get('items', [])
        except Exception as e:
            logger.error(f"Error getting providers: {e}")
            return []

    async def get_compositions(self) -> List[Dict[str, Any]]:
        """Get list of compositions"""
        try:
            compositions = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions"
            )
            return compositions.get('items', [])
        except Exception as e:
            logger.error(f"Error getting compositions: {e}")
            return []

    async def get_configurations(self) -> List[Dict[str, Any]]:
        """Get list of configurations"""
        try:
            configs = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="configurations"
            )
            return configs.get('items', [])
        except Exception as e:
            logger.error(f"Error getting configurations: {e}")
            return []

    async def get_health_status(self) -> Dict[str, Any]:
        """Get health status of Crossplane system"""
        try:
            deployment_list, pods = await asyncio.gather(
                self.apps_api.list_namespaced_deployment(
                    namespace=self.namespace,
                    label_selector='app=crossplane'
                ),
                self.core_api.list_namespaced_pod(
                    namespace=self.namespace,
                    label_selector='app=crossplane'
                )
            )

            pods_healthy = all(
                pod.status.phase == 'Running'
                for pod in pods.items
            )

            deployments_healthy = all(
                dep.status.ready_replicas == dep.status.replicas
                for dep in deployment_list.items
                if dep.status.replicas > 0
            )

            return {
                'healthy': pods_healthy and deployments_healthy,
                'pods': {
                    pod.metadata.name: {
                        'phase': pod.status.phase,
                        'conditions': [
                            {
                                'type': c.type,
                                'status': c.status,
                                'message': c.message
                            }
                            for c in (pod.status.conditions or [])
                        ]
                    }
                    for pod in pods.items
                },
                'deployments': {
                    dep.metadata.name: {
                        'ready': dep.status.ready_replicas == dep.status.replicas,
                        'replicas': dep.status.replicas,
                        'available': dep.status.available_replicas
                    }
                    for dep in deployment_list.items
                },
                'timestamp': datetime.utcnow().isoformat()
            }
        except Exception as e:
            logger.error(f"Error getting health status: {e}")
            return {
                'healthy': False,
                'pods': {},
                'deployments': {},
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }

    async def get_system_events(self) -> List[Dict[str, Any]]:
        """Get system events"""
        try:
            events = await self.core_api.list_namespaced_event(
                namespace=self.namespace
            )
            return [
                {
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'involved_object': {
                        'kind': event.involved_object.kind,
                        'name': event.involved_object.name,
                        'namespace': event.involved_object.namespace
                    },
                    'count': event.count,
                    'first_timestamp': event.first_timestamp,
                    'last_timestamp': event.last_timestamp
                }
                for event in events.items
            ]
        except Exception as e:
            logger.error(f"Error getting system events: {e}")
            return []
