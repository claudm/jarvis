import logging
import asyncio
import os
from typing import Dict, List, Any, Optional
from datetime import datetime
from kubernetes_asyncio import watch, client, config
from .providers import ProviderService
from .compositions import CompositionService
from .configurations import ConfigurationService
from ..k8s_api_auth import init_kubernetes_client
from .base_service import BaseService, async_watch_stream

logger = logging.getLogger(__name__)

class CrossplaneService(BaseService):
    def __init__(self, 
                 namespace: str = "crossplane-system",
                 refresh_interval: int = 30,
                 kubernetes_config: Optional[str] = None,
                 in_cluster: bool = False):
        self.namespace = namespace
        self.refresh_interval = refresh_interval
        self.running = False
        self.resources = {}
        self.watchers = {}
        self._tasks = set()
        self._setup()

    async def _async_init(self):
        """Initialize Kubernetes clients and services"""
        try:
            # Carrega a configuração do Kubernetes
            
            
            # Inicializa os clientes
            self.custom_api = client.CustomObjectsApi()
            self.core_api = client.CoreV1Api()
            self.apps_api = client.AppsV1Api()
            self.apiextensions_api = client.ApiextensionsV1Api()
            
            # Inicializa os serviços
            self.provider_service = ProviderService(self.custom_api)
            self.composition_service = CompositionService(self.custom_api)
            self.configuration_service = ConfigurationService(self.custom_api)
            
            # Inicializa os outros componentes
            await self._setup_kubernetes()
            logger.info("Kubernetes clients and services initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes clients: {e}")
            raise

    def _setup(self):
        """Initialize basic service configuration"""
        logger.info(f"Initialized {self.__class__.__name__}")

    async def _setup_kubernetes(self):
        """Initialize Kubernetes specific components"""
        try:
            # Test connection
            await self.core_api.list_namespaced_pod(self.namespace, limit=1)
            logger.info("Successfully connected to Kubernetes cluster")
        except Exception as e:
            logger.error(f"Failed to connect to Kubernetes cluster: {e}")
            raise

    async def get_summary(self) -> Dict[str, Any]:
        """Get system summary"""
        try:
            logger.debug("Starting get_summary()")
            health_status = await self.get_health_status()
            
            # Get providers
            providers = await self.provider_service.get_providers()
            logger.debug(f"Found {len(providers)} providers")
            healthy_providers = sum(1 for p in providers if p['status'] == 'healthy')
            unhealthy_providers = sum(1 for p in providers if p['status'] == 'unhealthy')
            unknown_providers = len(providers) - healthy_providers - unhealthy_providers

            # Get compositions
            compositions = await self.composition_service.get_compositions()
            logger.debug(f"Found {len(compositions)} compositions")
            active_compositions = sum(1 for c in compositions if c['status'] == 'established')
            inactive_compositions = len(compositions) - active_compositions

            # Get configurations
            configurations = await self.configuration_service.get_configurations()
            logger.debug(f"Found {len(configurations)} configurations")
            healthy_configurations = sum(1 for c in configurations if c['status'] == 'healthy')
            unhealthy_configurations = len(configurations) - healthy_configurations

            # Get recent events
            events = (await self.get_system_events())[:10]
            logger.debug(f"Found {len(events)} events")

            summary = {
                'providers': len(providers),
                'healthy_providers': healthy_providers,
                'unhealthy_providers': unhealthy_providers,
                'unknown_providers': unknown_providers,
                
                'compositions': len(compositions),
                'active_compositions': active_compositions,
                'inactive_compositions': inactive_compositions,
                
                'configurations': len(configurations),
                'healthy_configurations': healthy_configurations,
                'unhealthy_configurations': unhealthy_configurations,
                
                'health': health_status.get('healthy', False),
                'events': events
            }

            logger.debug("Returning summary data")
            return summary

        except Exception as e:
            logger.error(f"Error getting summary: {e}")
            return {
                'providers': 0,
                'healthy_providers': 0,
                'unhealthy_providers': 0,
                'unknown_providers': 0,
                'compositions': 0,
                'active_compositions': 0,
                'inactive_compositions': 0,
                'configurations': 0,
                'healthy_configurations': 0,
                'unhealthy_configurations': 0,
                'health': False,
                'events': [],
            }

    async def get_health_status(self) -> Dict[str, Any]:
        """Get health status"""
        try:
            # Use asyncio.gather to make concurrent API calls
            deployment_list, pods = await asyncio.gather(
                self.apps_api.list_namespaced_deployment(
                    namespace=self.namespace,
                    label_selector='app=crossplane'
                ),
                self.core_api.list_namespaced_pod(
                    namespace=self.namespace,
                    label_selector='app=crossplane'
                )
            )
            
            # Process results
            pods_healthy = all(
                pod.status.phase == 'Running' 
                for pod in pods.items
            )

            deployments_healthy = all(
                dep.status.ready_replicas == dep.status.replicas
                for dep in deployment_list.items
                if dep.status.replicas > 0
            )

            return {
                'healthy': pods_healthy and deployments_healthy,
                'pods': {
                    pod.metadata.name: {
                        'phase': pod.status.phase,
                        'conditions': [
                            {
                                'type': c.type,
                                'status': c.status,
                                'message': c.message
                            }
                            for c in (pod.status.conditions or [])
                        ]
                    }
                    for pod in pods.items
                },
                'deployments': {
                    dep.metadata.name: {
                        'ready': dep.status.ready_replicas == dep.status.replicas,
                        'replicas': dep.status.replicas,
                        'available': dep.status.available_replicas
                    }
                    for dep in deployment_list.items
                },
                'timestamp': datetime.utcnow().isoformat()
            }

        except Exception as e:
            logger.error(f"Error getting health status: {e}")
            return {
                'healthy': False,
                'pods': {},
                'deployments': {},
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }

    async def get_system_events(self) -> List[Dict[str, Any]]:
        """Get system events"""
        try:
            # Get events
            events = await self.core_api.list_namespaced_event(
                namespace=self.namespace,
                field_selector=f'involvedObject.name=crossplane'
            )
            
            # Process events
            processed_events = []
            for event in events.items:
                processed_events.append({
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'involved_object': {
                        'kind': event.involved_object.kind,
                        'name': event.involved_object.name,
                        'namespace': event.involved_object.namespace
                    },
                    'count': event.count,
                    'first_timestamp': event.first_timestamp,
                    'last_timestamp': event.last_timestamp
                })
            
            # Sort by timestamp
            processed_events.sort(
                key=lambda x: x['last_timestamp'] if x['last_timestamp'] else '',
                reverse=True
            )
            
            return processed_events

        except Exception as e:
            logger.error(f"Error getting system events: {e}")
            return []

    async def get_managed_resources(self) -> List[Dict[str, Any]]:
        """Get all managed resources across API groups"""
        try:
            logger.debug("Starting get_managed_resources()")
            
            # Get all CRDs
            crds = await self.apiextensions_api.list_custom_resource_definition()
            managed_resources = []
            
            # Filter for Crossplane managed CRDs
            for crd in crds.items:
                group = crd.spec.group
                if '.crossplane.io' in group or '.upbound.io' in group:
                    version = crd.spec.versions[0].name
                    plural = crd.spec.names.plural
                    
                    # List resources of this type
                    items = await self.list_resources(
                        group=group,
                        version=version,
                        plural=plural
                    )
                    
                    # Add group/version/kind information to each resource
                    for item in items:
                        conditions = item.get('status', {}).get('conditions', [])
                        ready_condition = next((c for c in conditions if c.get('type') == 'Ready'), {})
                        synced_condition = next((c for c in conditions if c.get('type') == 'Synced'), {})
                        
                        # Extract VPC ID and CIDR if present
                        spec = item.get('spec', {})
                        vpc_id = None
                        cidr = None
                        
                        if 'forProvider' in spec:
                            provider_spec = spec['forProvider']
                            if 'vpcId' in provider_spec:
                                vpc_id = provider_spec['vpcId']
                            if 'cidrBlock' in provider_spec:
                                cidr = provider_spec['cidrBlock']
                        
                        # Get external ID if present
                        external_name = item.get('status', {}).get('atProvider', {}).get('id')
                        
                        item_with_info = {
                            'apiVersion': f"{group}/{version}",
                            'kind': crd.spec.names.kind,
                            'name': item.get('metadata', {}).get('name', ''),
                            'ready': ready_condition.get('status', 'Unknown'),
                            'synced': synced_condition.get('status', 'Unknown'),
                            'id': external_name,
                            'vpc': vpc_id,
                            'cidr': cidr,
                            'age': item.get('metadata', {}).get('creationTimestamp'),
                            'status': item.get('status', {}),
                            'spec': spec
                        }
                        managed_resources.append(item_with_info)
            
            # Sort resources by kind
            managed_resources.sort(key=lambda x: x['kind'])
            
            logger.debug(f"Found {len(managed_resources)} managed resources")
            return managed_resources
            
        except Exception as e:
            logger.error(f"Error getting managed resources: {e}")
            return []

    async def stop(self):
        """Stop the service"""
        logger.info("Stopping Crossplane service...")
        self.running = False
        
        # Cancel tasks
        for task in self._tasks:
            if not task.done():
                task.cancel()
        
        # Wait for tasks to complete
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        
        logger.info("Crossplane service stopped")
