from typing import Dict, List, Any, Optional, AsyncGenerator
import logging
import asyncio
from datetime import datetime
from kubernetes_asyncio import client, watch
logger = logging.getLogger(__name__)

async def async_watch_stream(watch_func, *args, **kwargs) -> AsyncGenerator[Dict[str, Any], None]:
    """Wrapper to make kubernetes watch async"""
    w = watch.Watch()
    try:
        async for event in w.stream(watch_func, *args, **kwargs):
            yield event
            await asyncio.sleep(0)  # Allow other coroutines to run
    finally:
        w.stop()

class BaseService:
    """Base service class with async support"""
    
    def __init__(self, custom_api: client.CustomObjectsApi, namespace: str = "crossplane-system"):
        self.custom_api = custom_api
        self.namespace = namespace
        self._tasks = set()
        self._setup()

    async def _async_init(self):
        """Async initialization if needed"""
        pass

    def _setup(self):
        """Initialize service"""
        logger.info(f"Initialized {self.__class__.__name__}")

    async def _create_task(self, 
                         coro: Any,
                         name: str = None) -> asyncio.Task:
        """Helper to create and track an async task"""
        task = asyncio.create_task(coro, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    async def stop(self):
        """Stop the service and cancel any running tasks"""
        for task in self._tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        logger.info(f"Stopped {self.__class__.__name__}")

    def get_stats(self) -> Dict[str, Any]:
        """Get service statistics"""
        return {
            'service': self.__class__.__name__,
            'active_tasks': len(self._tasks),
            'timestamp': datetime.utcnow().isoformat()
        }

    async def list_resources(self, 
                           group: str,
                           version: str,
                           plural: str,
                           **kwargs) -> List[Dict[str, Any]]:
        """List Kubernetes resources with retry logic"""
        try:
            result = await self.custom_api.list_cluster_custom_object(
                group=group,
                version=version,
                plural=plural,
                **kwargs
            )
            return result.get('items', [])
        except Exception as e:
            logger.error(f"Error listing resources {group}/{version}/{plural}: {e}")
            return []

    async def get_resource(self,
                         group: str,
                         version: str,
                         plural: str,
                         name: str,
                         **kwargs) -> Optional[Dict[str, Any]]:
        """Get a specific Kubernetes resource"""
        try:
            return await self.custom_api.get_cluster_custom_object(
                group=group,
                version=version,
                plural=plural,
                name=name,
                **kwargs
            )
        except Exception as e:
            logger.error(f"Error getting resource {group}/{version}/{plural}/{name}: {e}")
            return None