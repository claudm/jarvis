# services/crossplane/compositions.py
from typing import Dict, List, Any, Optional
import logging
import asyncio
from datetime import datetime
from kubernetes_asyncio import client
from .base_service import BaseService
from ..k8s_api_auth import get_kubernetes_client

logger = logging.getLogger(__name__)

class CompositionService(BaseService):
    def __init__(self, custom_api):
        super().__init__(custom_api)
        self.api_extensions = None

    async def _async_init(self):
        """Initialize async components"""
        try:
            k8s_client = get_kubernetes_client()
            self.api_extensions = await k8s_client.extensions_api
            logger.info("Successfully initialized Kubernetes clients in CompositionService")
        except Exception as e:
            logger.error(f"Error initializing Kubernetes clients in CompositionService: {e}")
            raise

    async def get_compositions(self) -> List[Dict[str, Any]]:
        """
        Obtém todas as compositions.
        """
        try:
            compositions = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions"
            )
            
            return [{
                'name': c['metadata']['name'],
                'status': self._get_composition_status(c),
                'kind': c.get('spec', {}).get('compositeTypeRef', {}).get('kind', ''),
                'group': c.get('spec', {}).get('compositeTypeRef', {}).get('group', ''),
                'mode': c.get('spec', {}).get('mode', 'Pipeline'),
                'resources_count': len(c.get('spec', {}).get('resources', [])),
                'created_at': c['metadata']['creationTimestamp']
            } for c in compositions.get('items', [])]

        except Exception as e:
            logger.error(f"Error fetching compositions: {e}")
            return []

    async def get_composition_resources(self, composition_name: str) -> List[Dict[str, Any]]:
        """
        Obtém recursos associados a uma composition
        
        Args:
            composition_name: Nome da composition
        """
        try:
            # Get composition
            composition = await self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=composition_name
            )
            
            if not composition:
                return []

            # Get the composite type reference
            type_ref = composition.get('spec', {}).get('compositeTypeRef', {})
            if not type_ref:
                return []

            resources = []
            
            # Get all composite resources
            try:
                composites = await self.custom_api.list_cluster_custom_object(
                    group=type_ref['group'],
                    version=type_ref.get('version', 'v1alpha1'),
                    plural=f"x{type_ref['kind'].lower()}s"
                )

                for composite in composites.get('items', []):
                    if composition_name == composite.get('spec', {}).get('compositionRef', {}).get('name'):
                        # Create tasks for each managed resource
                        resource_tasks = []
                        for ref in composite.get('status', {}).get('resources', []):
                            resource_tasks.append(self.custom_api.get_cluster_custom_object(
                                group=ref['resource']['group'],
                                version=ref['resource']['version'],
                                plural=ref['resource']['plural'],
                                name=ref['name']
                            ))
                        
                        # Wait for all resource tasks to complete
                        managed_resources = []
                        if resource_tasks:
                            results = await asyncio.gather(*resource_tasks, return_exceptions=True)
                            
                            # Process results
                            for ref, result in zip(composite.get('status', {}).get('resources', []), results):
                                if isinstance(result, Exception):
                                    logger.warning(f"Error getting managed resource {ref['name']}: {result}")
                                    continue
                                
                                managed_resources.append({
                                    'name': ref['name'],
                                    'kind': ref['kind'],
                                    'status': self._get_resource_status(result),
                                    'synced': result.get('status', {}).get('synced', False),
                                    'created_at': result['metadata']['creationTimestamp']
                                })
                        
                        resources.append({
                            'name': composite['metadata']['name'],
                            'kind': composite['kind'],
                            'status': self._get_resource_status(composite),
                            'created_at': composite['metadata']['creationTimestamp'],
                            'resources': managed_resources
                        })

            except Exception as e:
                logger.warning(f"Error fetching composite resources: {e}")

            return resources

        except Exception as e:
            logger.error(f"Error getting composition resources: {e}")
            return []

    async def get_composition_details(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Obtém detalhes completos de uma composition

        Args:
            name: Nome da composition
        """
        try:
            composition = await self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=name
            )
            
            if not composition:
                return None

            # Get associated resources
            resources = await self.get_composition_resources(name)
            
            # Process composition details
            details = {
                'name': composition['metadata']['name'],
                'type_ref': composition.get('spec', {}).get('compositeTypeRef', {}),
                'mode': composition.get('spec', {}).get('mode', 'Pipeline'),
                'resources': composition.get('spec', {}).get('resources', []),
                'patches': composition.get('spec', {}).get('patches', []),
                'status': self._get_composition_status(composition),
                'created_at': composition['metadata']['creationTimestamp']
            }

            # Add patch analysis
            patch_analysis = self._analyze_patches(details['resources'], composition.get('spec', {}).get('patchSets', []))
            
            return {
                'details': details,
                'resources': resources,
                'analysis': {
                    'patches': patch_analysis,
                    'resources': {
                        'total': len(resources),
                        'by_status': self._count_resources_by_status(resources),
                        'by_type': self._count_resources_by_type(resources)
                    }
                }
            }

        except Exception as e:
            logger.error(f"Error getting composition details: {e}")
            return None

    def _get_composition_status(self, composition: Dict[str, Any]) -> str:
        """Determina o status de uma composition"""
        conditions = composition.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Ready':
                return 'ready' if condition['status'] == 'True' else 'not_ready'
        return 'unknown'

    def _get_resource_status(self, resource: Dict[str, Any]) -> str:
        """Determina o status de um recurso"""
        conditions = resource.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Ready':
                return 'ready' if condition['status'] == 'True' else 'not_ready'
        return 'unknown'

    def _analyze_patches(self, resources: List[Dict[str, Any]], patch_sets: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analisa detalhes das patches em uma composition"""
        analysis = {
            'total_patches': 0,
            'patches_by_type': {},
            'resources_with_patches': 0
        }

        # Analisa patches por recurso
        for resource in resources:
            patches = resource.get('patches', [])
            if patches:
                analysis['resources_with_patches'] += 1
                analysis['total_patches'] += len(patches)

                for patch in patches:
                    patch_type = patch.get('type', 'FromCompositeFieldPath')
                    analysis['patches_by_type'][patch_type] = analysis['patches_by_type'].get(patch_type, 0) + 1

        # Analisa patch sets
        if patch_sets:
            analysis['patch_sets'] = {
                'total': len(patch_sets),
                'patches': sum(len(ps.get('patches', [])) for ps in patch_sets)
            }

        return analysis

    def _count_resources_by_status(self, resources: List[Dict[str, Any]]) -> Dict[str, int]:
        """Conta recursos por status"""
        counts = {}
        for resource in resources:
            status = resource.get('status', 'unknown')
            counts[status] = counts.get(status, 0) + 1
        return counts

    def _count_resources_by_type(self, resources: List[Dict[str, Any]]) -> Dict[str, int]:
        """Conta recursos por tipo"""
        counts = {}
        for resource in resources:
            for managed in resource.get('resources', []):
                kind = managed.get('kind', 'unknown')
                counts[kind] = counts.get(kind, 0) + 1
        return counts

    def _sanitize_resource_data(self, data: Any, max_depth: int = 3, current_depth: int = 0) -> Any:
        """Sanitiza dados do recurso para evitar recursão profunda"""
        if current_depth >= max_depth:
            return "MAX_DEPTH_REACHED"
        
        if isinstance(data, dict):
            return {k: self._sanitize_resource_data(v, max_depth, current_depth + 1) 
                   for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize_resource_data(item, max_depth, current_depth + 1) 
                   for item in data]
        return data
