import threading
import queue
import logging
import concurrent.futures
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@dataclass(order=True)
class Task:
    """Represents a task to be executed by the thread pool"""
    id: str = field(compare=False)
    func: Callable = field(compare=False)
    priority: int = field(default=0)
    args: tuple = field(default_factory=tuple, compare=False)
    kwargs: dict = field(default_factory=dict, compare=False)
    timeout: int = field(default=30, compare=False)
    retries: int = field(default=3, compare=False)
    retry_delay: int = field(default=5, compare=False)
    created_at: datetime = field(default_factory=datetime.now, compare=False)

@dataclass
class TaskResult:
    """Represents the result of a task execution"""
    task_id: str
    success: bool
    result: Any = None
    error: Optional[str] = None
    processing_time: float = 0
    attempts: int = 0
    completed_at: datetime = field(default_factory=datetime.now)

class ThreadManager:
    """Thread manager for handling concurrent operations"""
    
    def __init__(
        self,
        max_workers: int = 10,
        task_queue_size: int = 1000,
        result_queue_size: int = 1000,
        default_timeout: int = 30,
        cleanup_interval: int = 3600,
        result_ttl: int = 3600
    ):
        self.max_workers = max_workers
        self.default_timeout = default_timeout
        self.cleanup_interval = cleanup_interval
        self.result_ttl = result_ttl
        
        # Initialize queues
        self.task_queue = queue.PriorityQueue(maxsize=task_queue_size)
        self.result_queue = queue.Queue(maxsize=result_queue_size)
        
        # Initialize thread pool
        self.executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix='worker'
        )
        
        # Initialize storage
        self.tasks: Dict[str, Task] = {}
        self.results: Dict[str, TaskResult] = {}
        
        # Initialize state
        self.running = False
        self.stats = {
            'tasks_processed': 0,
            'tasks_failed': 0,
            'tasks_succeeded': 0,
            'avg_processing_time': 0.0,
            'task_queue_size': 0,
            'result_queue_size': 0
        }
        
        # Initialize locks
        self._lock = threading.Lock()
        self._stats_lock = threading.Lock()
        
        # Initialize threads
        self._worker_threads: List[threading.Thread] = []
        self._result_thread: Optional[threading.Thread] = None
        self._monitor_thread: Optional[threading.Thread] = None
        self._cleanup_thread: Optional[threading.Thread] = None

    def start(self):
        """Start the thread manager"""
        if self.running:
            logger.warning("Thread manager is already running")
            return

        self.running = True
        logger.info(f"Starting thread manager with {self.max_workers} workers")
        
        # Start worker threads
        for i in range(self.max_workers):
            thread = threading.Thread(
                target=self._worker_loop,
                name=f'worker-{i}',
                daemon=True
            )
            thread.start()
            self._worker_threads.append(thread)

        # Start result processor thread
        self._result_thread = threading.Thread(
            target=self._process_results,
            name='result-processor',
            daemon=True
        )
        self._result_thread.start()

        # Start monitoring thread
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name='monitor',
            daemon=True
        )
        self._monitor_thread.start()

        # Start cleanup thread
        self._cleanup_thread = threading.Thread(
            target=self._cleanup_loop,
            name='cleanup',
            daemon=True
        )
        self._cleanup_thread.start()

    def stop(self):
        """Stop the thread manager"""
        if not self.running:
            return

        logger.info("Stopping thread manager...")
        self.running = False
        
        # Wait for threads to finish
        for thread in self._worker_threads:
            thread.join(timeout=5)
        
        if self._result_thread:
            self._result_thread.join(timeout=5)
            
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)
            
        if self._cleanup_thread:
            self._cleanup_thread.join(timeout=5)
        
        # Clear queues
        self._clear_queues()
        
        # Shutdown executor
        self.executor.shutdown(wait=True)
        logger.info("Thread manager stopped")

    def submit_task(self, task: Task) -> str:
        """Submit a task for execution"""
        if not self.running:
            raise RuntimeError("Thread manager is not running")

        with self._lock:
            self.tasks[task.id] = task
            self.task_queue.put(task)
            
            with self._stats_lock:
                self.stats['task_queue_size'] = self.task_queue.qsize()

        return task.id

    def get_result(self, task_id: str, timeout: Optional[int] = None) -> Optional[Any]:
        """Get the result of a task"""
        if task_id not in self.tasks:
            raise KeyError(f"Task {task_id} not found")

        timeout = timeout or self.default_timeout
        start_time = datetime.now()

        while (datetime.now() - start_time).total_seconds() < timeout:
            if task_id in self.results:
                result = self.results[task_id]
                if not result.success:
                    raise RuntimeError(f"Task failed: {result.error}")
                return result.result
            threading.Event().wait(0.1)

        raise TimeoutError(f"Timeout waiting for task {task_id}")

    def _worker_loop(self):
        """Main worker loop"""
        while self.running:
            try:
                task = self.task_queue.get(timeout=1)
                start_time = datetime.now()
                attempts = 0
                last_error = None

                while attempts <= task.retries and self.running:
                    try:
                        attempts += 1
                        result = task.func(*task.args, **(task.kwargs or {}))
                        processing_time = (datetime.now() - start_time).total_seconds()
                        
                        self.result_queue.put(TaskResult(
                            task_id=task.id,
                            success=True,
                            result=result,
                            processing_time=processing_time,
                            attempts=attempts
                        ))
                        break
                    except Exception as e:
                        last_error = str(e)
                        if attempts <= task.retries:
                            logger.warning(
                                f"Task {task.id} failed attempt {attempts}/{task.retries}: {e}")
                            threading.Event().wait(task.retry_delay)
                        else:
                            logger.error(f"Task {task.id} failed all retries: {e}")
                            self.result_queue.put(TaskResult(
                                task_id=task.id,
                                success=False,
                                error=last_error,
                                processing_time=(datetime.now() - start_time).total_seconds(),
                                attempts=attempts
                            ))
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error in worker loop: {e}")

    def _process_results(self):
        """Process completed tasks"""
        while self.running:
            try:
                result = self.result_queue.get(timeout=1)
                if result is None:
                    continue

                with self._lock:
                    self.results[result.task_id] = result
                
                with self._stats_lock:
                    self.stats['tasks_processed'] += 1
                    if result.success:
                        self.stats['tasks_succeeded'] += 1
                    else:
                        self.stats['tasks_failed'] += 1
                    
                    # Update average processing time
                    current_avg = self.stats['avg_processing_time']
                    n = self.stats['tasks_processed']
                    new_time = result.processing_time
                    self.stats['avg_processing_time'] = (current_avg * (n - 1) + new_time) / n
                    
                    self.stats['result_queue_size'] = self.result_queue.qsize()

            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error processing results: {e}")

    def _monitor_loop(self):
        """Monitor thread performance and health"""
        while self.running:
            try:
                with self._stats_lock:
                    stats = self.get_stats()
                    
                logger.debug(
                    f"Thread manager stats: "
                    f"Tasks processed: {stats['tasks_processed']}, "
                    f"Success rate: {stats['success_rate']:.1f}%, "
                    f"Avg time: {stats['avg_processing_time']:.2f}s, "
                    f"Queue sizes: {stats['queue_sizes']}"
                )

            except Exception as e:
                logger.error(f"Error in monitor loop: {e}")
            finally:
                threading.Event().wait(60)

    def _cleanup_loop(self):
        """Cleanup old results periodically"""
        while self.running:
            try:
                self._cleanup_old_results()
                threading.Event().wait(self.cleanup_interval)
            except Exception as e:
                logger.error(f"Error in cleanup loop: {e}")

    def _cleanup_old_results(self):
        """Clean up old results based on TTL"""
        current_time = datetime.now()
        with self._lock:
            for task_id in list(self.results.keys()):
                result = self.results[task_id]
                age = (current_time - result.completed_at).total_seconds()
                if age > self.result_ttl:
                    del self.results[task_id]
                    if task_id in self.tasks:
                        del self.tasks[task_id]

    def _clear_queues(self):
        """Clear task and result queues"""
        while not self.task_queue.empty():
            try:
                self.task_queue.get_nowait()
            except queue.Empty:
                break

        while not self.result_queue.empty():
            try:
                self.result_queue.get_nowait()
            except queue.Empty:
                break

    def get_stats(self) -> Dict[str, Any]:
        """Get detailed statistics about the thread manager"""
        with self._stats_lock:
            total_tasks = self.stats['tasks_processed']
            success_rate = 0
            if total_tasks > 0:
                success_rate = (self.stats['tasks_succeeded'] / total_tasks) * 100
                
            return {
                'tasks_processed': total_tasks,
                'tasks_succeeded': self.stats['tasks_succeeded'],
                'tasks_failed': self.stats['tasks_failed'],
                'success_rate': success_rate,
                'avg_processing_time': self.stats['avg_processing_time'],
                'queue_sizes': {
                    'task_queue': self.stats['task_queue_size'],
                    'result_queue': self.stats['result_queue_size']
                },
                'active_tasks': len(self.tasks),
                'completed_results': len(self.results),
                'worker_threads': self.max_workers,
                'timestamp': datetime.now().isoformat()
            }

    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """Get detailed status for a specific task"""
        if task_id not in self.tasks:
            raise KeyError(f"Task {task_id} not found")
            
        task = self.tasks[task_id]
        result = self.results.get(task_id)
        
        status = {
            'task_id': task_id,
            'status': 'completed' if result else 'pending',
            'created_at': task.created_at.isoformat(),
            'priority': task.priority,
            'retries': task.retries
        }
        
        if result:
            status.update({
                'success': result.success,
                'processing_time': result.processing_time,
                'attempts': result.attempts,
                'completed_at': result.completed_at.isoformat(),
                'error': result.error if not result.success else None
            })
            
        return status