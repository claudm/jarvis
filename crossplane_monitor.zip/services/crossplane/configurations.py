# services/crossplane/configurations.py
from typing import Dict, List, Any, Optional
import logging
import asyncio
from datetime import datetime
from kubernetes_asyncio import client
from .base_service import BaseService
from ..k8s_api_auth import get_kubernetes_client

logger = logging.getLogger(__name__)

class ConfigurationService(BaseService):
    def __init__(self, custom_api):
        super().__init__(custom_api)
        self.api_extensions = None

    async def _async_init(self):
        """Initialize async components"""
        try:
            k8s_client = get_kubernetes_client()
            self.api_extensions = await k8s_client.extensions_api
            logger.info("Successfully initialized Kubernetes clients in ConfigurationService")
        except Exception as e:
            logger.error(f"Error initializing Kubernetes clients in ConfigurationService: {e}")
            raise

    async def get_configurations(self) -> List[Dict[str, Any]]:
        """
        Obtém todas as configurations com status detalhado.
        """
        try:
            configurations = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="configurations"
            )
            
            configs = []
            for c in configurations.get('items', []):
                status = self._get_configuration_status(c)
                config = {
                    'name': c['metadata']['name'],
                    'status': status['state'],
                    'status_message': status['message'],
                    'status_reason': status['reason'],
                    'status_last_transition': status['last_transition'],
                    'package': c.get('spec', {}).get('package', ''),
                    'package_type': c.get('spec', {}).get('packageType', ''),
                    'revision': c.get('status', {}).get('currentRevision', ''),
                    'dependencies': c.get('spec', {}).get('dependencies', []),
                    'labels': c['metadata'].get('labels', {}),
                    'created_at': c['metadata']['creationTimestamp']
                }
                configs.append(config)
                
                # Log installation failures
                if status['state'] == 'installation_failed':
                    logger.error(f"Configuration {config['name']} installation failed: {status['message']}")
            
            return configs

        except Exception as e:
            logger.error(f"Error fetching configurations: {e}")
            return []

    async def get_configuration_revisions(self, config_name: str) -> List[Dict[str, Any]]:
        """
        Obtém todas as revisões de uma configuration.
        
        Args:
            config_name: Nome da configuration
        """
        try:
            revisions = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="configurationrevisions"
            )
            
            return [{
                'name': rev['metadata']['name'],
                'version': rev.get('spec', {}).get('revision'),
                'desiredState': rev.get('spec', {}).get('desiredState'),
                'status': self._get_revision_status(rev),
                'configuration': rev.get('spec', {}).get('configurationName'),
                'created_at': rev['metadata']['creationTimestamp']
            } for rev in revisions.get('items', [])
                if config_name in rev.get('spec', {}).get('configurationName', '')]

        except Exception as e:
            logger.error(f"Error fetching configuration revisions: {e}")
            return []

    def _sanitize_resource_data(self, data, max_depth=3, current_depth=0):
        """
        Sanitiza dados do recurso para evitar recursão profunda
        """
        if current_depth >= max_depth:
            return "MAX_DEPTH_REACHED"
        
        if isinstance(data, dict):
            return {k: self._sanitize_resource_data(v, max_depth, current_depth + 1) 
                   for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize_resource_data(item, max_depth, current_depth + 1) 
                   for item in data]
        return data

    async def get_managed_resources(self, config_name: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Obtém recursos gerenciados pela configuration de forma otimizada
        """
        try:
            resources_by_type = {}

            try:
                # Get CRDs associated with configuration
                crds = await self.api_extensions.list_custom_resource_definition()
                relevant_crds = []
                
                # Filter relevant CRDs
                for crd in crds.items:
                    labels = crd.metadata.labels or {}
                    if any(label.startswith("pkg.crossplane.io/configuration") for label in labels) and \
                    config_name in str(labels):
                        relevant_crds.append(crd)
                        logger.info(f"Found relevant CRD: {crd.metadata.name} for config {config_name}")

                # If no CRDs found, try XRDs
                if not relevant_crds:
                    logger.info(f"No direct CRDs found, looking for XRDs for config {config_name}")
                    selector = f"pkg.crossplane.io/configuration={config_name}"
                    xrds = await self.custom_api.list_cluster_custom_object(
                        group="apiextensions.crossplane.io",
                        version="v1",
                        plural="compositeresourcedefinitions",
                        label_selector=selector
                    )
                    
                    # Process XRDs concurrently
                    xrd_tasks = []
                    for xrd in xrds.get('items', []):
                        group = xrd['spec']['group']
                        kind = xrd['spec']['names']['kind']
                        version = xrd['spec']['versions'][0]['name']
                        plural = xrd['spec']['names']['plural']
                        
                        xrd_tasks.append((
                            self.custom_api.list_cluster_custom_object(
                                group=group,
                                version=version,
                                plural=plural
                            ),
                            {
                                'group': group,
                                'kind': kind,
                                'service': group.split('.')[0]
                            }
                        ))
                    
                    # Wait for all XRD resources
                    if xrd_tasks:
                        results = await asyncio.gather(*[task[0] for task in xrd_tasks], return_exceptions=True)
                        
                        # Process results
                        for (result, info), task in zip(zip(results, xrd_tasks), xrd_tasks):
                            if isinstance(result, Exception):
                                logger.warning(f"Error processing XRD resources for {info['kind']}: {result}")
                                continue
                                
                            if result.get('items'):
                                service = info['service']
                                if service not in resources_by_type:
                                    resources_by_type[service] = {}
                                    
                                resources_by_type[service][info['kind']] = [
                                    {
                                        'name': r['metadata']['name'],
                                        'kind': info['kind'],
                                        'service': service,
                                        'status': self._get_resource_status(r),
                                        'created_at': r['metadata']['creationTimestamp'],
                                        'spec': self._sanitize_resource_data({
                                            'compositionRef': r.get('spec', {}).get('compositionRef', {}),
                                            'compositionUpdatePolicy': r.get('spec', {}).get('compositionUpdatePolicy', ''),
                                            'compositionRevisionRef': r.get('spec', {}).get('compositionRevisionRef', {})
                                        })
                                    }
                                    for r in result.get('items', [])
                                ]

                # Process CRDs concurrently
                crd_tasks = []
                for crd in relevant_crds:
                    kind = crd.spec.names.kind
                    group = crd.spec.group
                    version = crd.spec.versions[0].name
                    plural = crd.spec.names.plural
                    
                    crd_tasks.append((
                        self.custom_api.list_cluster_custom_object(
                            group=group,
                            version=version,
                            plural=plural
                        ),
                        {
                            'group': group,
                            'kind': kind,
                            'service': group.split('.')[0]
                        }
                    ))
                
                # Wait for all CRD resources
                if crd_tasks:
                    results = await asyncio.gather(*[task[0] for task in crd_tasks], return_exceptions=True)
                    
                    # Process results
                    for (result, info), task in zip(zip(results, crd_tasks), crd_tasks):
                        if isinstance(result, Exception):
                            logger.warning(f"Error processing CRD resources for {info['kind']}: {result}")
                            continue
                            
                        if result.get('items'):
                            service = info['service']
                            if service not in resources_by_type:
                                resources_by_type[service] = {}
                                
                            resources_by_type[service][info['kind']] = [
                                {
                                    'name': r['metadata']['name'],
                                    'kind': info['kind'],
                                    'service': service,
                                    'status': self._get_resource_status(r),
                                    'created_at': r['metadata']['creationTimestamp'],
                                    'spec': self._sanitize_resource_data({
                                        'compositionRef': r.get('spec', {}).get('compositionRef', {}),
                                        'compositionUpdatePolicy': r.get('spec', {}).get('compositionUpdatePolicy', ''),
                                        'compositionRevisionRef': r.get('spec', {}).get('compositionRevisionRef', {})
                                    })
                                }
                                for r in result.get('items', [])
                            ]

                logger.info(f"Found resources in {len(resources_by_type)} services for config {config_name}")
                return resources_by_type
            except Exception as e:
                logger.error(f"Error in get_managed_resources: {e}")
                return {}

        except Exception as e:
            logger.error(f"Error getting managed resources for configuration {config_name}: {e}")
            return {}
    async def get_configuration_details(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Obtém detalhes completos de uma configuration específica

        Args:
            name: Nome da configuration
            
        Returns:
            Dict com todos os detalhes da configuration ou None se não encontrada
        """
        try:
            # Get basic configuration info from list
            configurations = await self.get_configurations()
            configuration = next((c for c in configurations if c['name'] == name), None)
            
            if not configuration:
                logger.warning(f"Configuration {name} not found")
                return None
                
            # Get additional details concurrently
            revisions, packages, resources = await asyncio.gather(
                self.get_configuration_revisions(name),
                self.get_configuration_packages(name),
                self.get_managed_resources(name)
            )
            
            # Create complete configuration details
            configuration.update({
                'revisions': revisions,
                'packages': packages,
                'resources': resources
            })
            
            logger.info(f"Got details for configuration {name}")
            return configuration

        except Exception as e:
            logger.error(f"Error getting configuration details: {e}")
            return None

    def _get_configuration_status(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Determina o status detalhado de uma configuration"""
        status = {
            'state': 'unknown',
            'message': '',
            'reason': '',
            'last_transition': None
        }
        
        conditions = config.get('status', {}).get('conditions', [])
        for condition in conditions:
            # Check installation status first
            if condition['type'] == 'Installed':
                status['state'] = 'installed' if condition['status'] == 'True' else 'installation_failed'
                status['message'] = condition.get('message', '')
                status['reason'] = condition.get('reason', '')
                status['last_transition'] = condition.get('lastTransitionTime', '')
                if condition['status'] != 'True':
                    return status
                    
            # Then check health
            elif condition['type'] == 'Healthy':
                if status['state'] == 'installed':
                    status['state'] = 'healthy' if condition['status'] == 'True' else 'unhealthy'
                status['message'] = condition.get('message', '')
                status['reason'] = condition.get('reason', '')
                status['last_transition'] = condition.get('lastTransitionTime', '')
                
            # Finally check readiness
            elif condition['type'] == 'Ready' and status['state'] not in ['installation_failed', 'unhealthy']:
                status['state'] = 'ready' if condition['status'] == 'True' else 'not_ready'
                status['message'] = condition.get('message', '')
                status['reason'] = condition.get('reason', '')
                status['last_transition'] = condition.get('lastTransitionTime', '')
        
        return status

    def _get_revision_status(self, revision: Dict[str, Any]) -> str:
        """Determina o status de uma revisão"""
        conditions = revision.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Healthy':
                return 'healthy' if condition['status'] == 'True' else 'unhealthy'
        return 'unknown'

    def _get_resource_status(self, resource: Dict[str, Any]) -> str:
        """Determina o status de um recurso gerenciado"""
        conditions = resource.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Ready':
                return 'ready' if condition['status'] == 'True' else 'not_ready'
        return 'unknown'

    async def get_configuration_packages(self, name: str) -> Dict[str, List[Dict[str, Any]]]:
        """Obtém pacotes associados a uma configuration"""
        try:
            selector = f"pkg.crossplane.io/configuration={name}"
            
            # Get XRDs and Compositions concurrently
            xrds, compositions = await asyncio.gather(
                self.custom_api.list_cluster_custom_object(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    plural="compositeresourcedefinitions",
                    label_selector=selector
                ),
                self.custom_api.list_cluster_custom_object(
                    group="apiextensions.crossplane.io",
                    version="v1",
                    plural="compositions",
                    label_selector=selector
                )
            )
            
            return {
                'xrds': [{
                    'name': xrd['metadata']['name'],
                    'group': xrd['spec']['group'],
                    'kind': xrd['spec']['names']['kind'],
                    'versions': xrd['spec'].get('versions', []),
                    'status': self._get_xrd_status(xrd)
                } for xrd in xrds.get('items', [])],

                'compositions': [{
                    'name': comp['metadata']['name'],
                    'typeRef': comp.get('spec', {}).get('compositeTypeRef', {}),
                    'mode': comp.get('spec', {}).get('mode', 'Pipeline'),
                    'resources_count': len(comp.get('spec', {}).get('resources', []))
                } for comp in compositions.get('items', [])]
            }

        except Exception as e:
            logger.error(f"Error getting configuration packages: {e}")
            return {'xrds': [], 'compositions': []}

    def _get_xrd_status(self, xrd: Dict[str, Any]) -> str:
        """Determina o status de uma XRD"""
        conditions = xrd.get('status', {}).get('conditions', [])
        for condition in conditions:
            if condition['type'] == 'Established':
                return 'established' if condition['status'] == 'True' else 'not_established'
        return 'unknown'
