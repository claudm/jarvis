from kubernetes_asyncio import client
from typing import Dict, List, Any, Optional
import logging
import asyncio
from datetime import datetime
from .base_service import BaseService
from ..k8s_api_auth import init_kubernetes_client

logger = logging.getLogger(__name__)

class ProviderService(BaseService):
    def __init__(self, custom_api: client.CustomObjectsApi = None, namespace: str = "crossplane-system"):
        super().__init__(custom_api, namespace)
        self.api_extensions = None
        self.core_api = None
        self.apps_api = None

    async def _async_init(self):
        """Initialize Kubernetes clients"""
        try:
            api_client = await init_kubernetes_client()
            
            if self.custom_api is None:
                self.custom_api = client.CustomObjectsApi(api_client)
            if self.api_extensions is None:
                self.api_extensions = client.ApiextensionsV1Api(api_client)
            if self.core_api is None:
                self.core_api = client.CoreV1Api(api_client)
            if self.apps_api is None:
                self.apps_api = client.AppsV1Api(api_client)

            logger.info("Successfully initialized Kubernetes clients")

        except Exception as e:
            logger.error(f"Error initializing Kubernetes clients: {e}")
            raise

    async def get_providers(self) -> List[Dict[str, Any]]:
        """Get list of installed providers"""
        try:
            logger.info("Fetching installed providers")
            
            providers = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            
            processed_providers = []
            for provider in providers.get('items', []):
                try:
                    metadata = provider.get('metadata', {})
                    spec = provider.get('spec', {})
                    status = provider.get('status', {})
                    
                    conditions = status.get('conditions', [])
                    ready_condition = next((c for c in conditions if c['type'] == 'Healthy'), 
                                        {'status': 'Unknown'})
                    synced_condition = next((c for c in conditions if c['type'] == 'Synced'),
                                         {'status': 'Unknown'})
                    
                    processed_provider = {
                        'name': metadata.get('name'),
                        'namespace': metadata.get('namespace', self.namespace),
                        'package': spec.get('package', ''),
                        'provider_type': 'upbound' if 'upbound.io' in spec.get('package', '') else 'crossplane',
                        'status': {
                            'ready': ready_condition.get('status'),
                            'synced': synced_condition.get('status')
                        },
                        'conditions': conditions,
                        'revision': status.get('currentRevision', ''),
                        'created_at': metadata.get('creationTimestamp')
                    }
                    processed_providers.append(processed_provider)
                    
                except Exception as e:
                    logger.error(f"Error processing provider {metadata.get('name')}: {e}")
                    continue
            
            logger.info(f"Found {len(processed_providers)} providers")
            return processed_providers
            
        except Exception as e:
            logger.error(f"Error getting providers: {e}")
            return []

    async def get_managed_resources(self) -> Dict[str, Any]:
        """Get all managed resources from providers"""
        try:
            logger.info("Fetching managed resources")

            resources = {}
            stats = {'total': 0, 'ready': 0, 'not_ready': 0}

            crds = await self.api_extensions.list_custom_resource_definition()

            for crd in crds.items:
                group = crd.spec.group
                version = crd.spec.versions[0].name
                plural = crd.spec.names.plural
                kind = crd.spec.names.kind

                # Fetch resources of this kind
                response = await self.custom_api.list_cluster_custom_object(
                    group=group,
                    version=version,
                    plural=plural
                )

                if 'items' in response:
                    resources[kind] = response['items']
                    stats['total'] += len(response['items'])

                    for item in response['items']:
                        ready_condition = next(
                            (c for c in item.get('status', {}).get('conditions', []) if c['type'] == 'Ready'), {}
                        )
                        if ready_condition.get('status') == 'True':
                            stats['ready'] += 1
                        else:
                            stats['not_ready'] += 1

            logger.debug(f"Managed Resources: {resources}")
            return {'providers': resources, 'stats': stats}
        except Exception as e:
            logger.error(f"Error getting managed resources: {e}")
            return {'providers': {}, 'stats': {'total': 0}}

    async def get_provider_details(self, name: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific provider"""
        try:
            provider = await self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=name
            )
            
            if not provider:
                logger.warning(f"Provider {name} not found")
                return None
                
            managed = await self.get_managed_resources()
            provider_resources = managed['providers'].get(
                name.replace('provider-', ''), []
            )
            
            metadata = provider.get('metadata', {})
            spec = provider.get('spec', {})
            status = provider.get('status', {})
            
            return {
                'name': metadata.get('name'),
                'namespace': metadata.get('namespace', self.namespace),
                'package': spec.get('package', ''),
                'provider_type': 'upbound' if 'upbound.io' in spec.get('package', '') else 'crossplane',
                'status': {
                    'ready': next((c['status'] for c in status.get('conditions', []) if c['type'] == 'Healthy'), 'Unknown'),
                    'synced': next((c['status'] for c in status.get('conditions', []) if c['type'] == 'Synced'), 'Unknown')
                },
                'conditions': status.get('conditions', []),
                'revision': status.get('currentRevision', ''),
                'created_at': metadata.get('creationTimestamp'),
                'resources': provider_resources
            }
            
        except Exception as e:
            logger.error(f"Error getting provider details for {name}: {e}")
            return None

    async def get_provider_revisions(self, provider_name: str) -> List[Dict[str, Any]]:
        """Get revision history for a provider"""
        try:
            revisions = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providerrevisions"
            )
            
            provider_revisions = []
            for revision in revisions.get('items', []):
                if revision.get('spec', {}).get('providerName') == provider_name:
                    metadata = revision['metadata']
                    spec = revision.get('spec', {})
                    status = revision.get('status', {})
                    
                    provider_revisions.append({
                        'name': metadata['name'],
                        'version': spec.get('revision'),
                        'image': spec.get('image'),
                        'desiredState': spec.get('desiredState'),
                        'status': next((c['status'] for c in status.get('conditions', []) 
                                     if c['type'] == 'Healthy'), 'Unknown'),
                        'created_at': metadata['creationTimestamp']
                    })
                    
            return sorted(
                provider_revisions,
                key=lambda x: x['created_at'],
                reverse=True
            )
            
        except Exception as e:
            logger.error(f"Error getting provider revisions: {e}")
            return []