from kubernetes_asyncio import client
from typing import Dict, List, Any, Optional
import logging
import asyncio
from datetime import datetime
from .base_service import BaseService
from ..k8s_api_auth import init_kubernetes_client

logger = logging.getLogger(__name__)

class ProviderService(BaseService):
   def __init__(self, custom_api=None, namespace: str = "crossplane-system"):
       super().__init__(namespace)
       self.custom_api = custom_api
       self.api_extensions = None
       self.core_api = None
       self.apps_api = None

   async def _async_init(self):
       # Call parent's _async_init first
       await super()._async_init()
       
       # Initialize additional API clients if needed
       if self.api_extensions is None:
           api_client, _, core_api, apps_api, extensions_api = await init_kubernetes_client()
           self.api_extensions = extensions_api
           self.core_api = core_api
           self.apps_api = apps_api
           logger.info("Successfully initialized additional Kubernetes clients")

   async def get_providers(self) -> List[Dict[str, Any]]:
       try:
           # Ensure initialization
           await self._async_init()
           
           logger.info("Fetching installed providers")
           providers = await self.custom_api.list_cluster_custom_object(
               group="pkg.crossplane.io",
               version="v1",
               plural="providers"
           )
           
           processed_providers = []
           for provider in providers.get('items', []):
               try:
                   metadata = provider.get('metadata', {})
                   spec = provider.get('spec', {})
                   status = provider.get('status', {})
                   
                   conditions = status.get('conditions', [])
                   ready_condition = next((c for c in conditions if c['type'] == 'Healthy'), 
                                       {'status': 'Unknown'})
                   synced_condition = next((c for c in conditions if c['type'] == 'Synced'),
                                        {'status': 'Unknown'})
                   
                   processed_provider = {
                       'name': metadata.get('name'),
                       'namespace': metadata.get('namespace', self.namespace),
                       'package': spec.get('package', ''),
                       'provider_type': 'upbound' if 'upbound.io' in spec.get('package', '') else 'crossplane',
                       'status': {
                           'ready': ready_condition.get('status'),
                           'synced': synced_condition.get('status')
                       },
                       'conditions': conditions,
                       'revision': status.get('currentRevision', ''),
                       'created_at': metadata.get('creationTimestamp')
                   }
                   processed_providers.append(processed_provider)
                   
               except Exception as e:
                   logger.error(f"Error processing provider {metadata.get('name')}: {e}")
                   continue
           
           return processed_providers
           
       except Exception as e:
           logger.error(f"Error getting providers: {e}")
           return []

   async def get_provider_details(self, name: str) -> Optional[Dict[str, Any]]:
       try:
           # Ensure initialization
           await self._async_init()
           
           provider = await self.custom_api.get_cluster_custom_object(
               group="pkg.crossplane.io",
               version="v1",
               plural="providers",
               name=name
           )
           
           if not provider:
               logger.warning(f"Provider {name} not found")
               return None
               
           managed = await self.get_managed_resources(name)
           
           metadata = provider.get('metadata', {})
           spec = provider.get('spec', {})
           status = provider.get('status', {})
           
           return {
               'name': metadata.get('name'),
               'namespace': metadata.get('namespace', self.namespace),
               'package': spec.get('package', ''),
               'provider_type': 'upbound' if 'upbound.io' in spec.get('package', '') else 'crossplane',
               'status': {
                   'ready': next((c['status'] for c in status.get('conditions', []) if c['type'] == 'Healthy'), 'Unknown'),
                   'synced': next((c['status'] for c in status.get('conditions', []) if c['type'] == 'Synced'), 'Unknown')
               },
               'conditions': status.get('conditions', []),
               'revision': status.get('currentRevision', ''),
               'created_at': metadata.get('creationTimestamp'),
               'resources': managed.get('resources', [])
           }
           
       except Exception as e:
           logger.error(f"Error getting provider details for {name}: {e}")
           return None

   async def get_managed_resources(self, provider_name: str = None) -> Dict[str, Any]:
       try:
           # Ensure initialization
           await self._async_init()
           
           logger.info("Fetching managed resources")
           resources_by_provider = {}
           stats = {'total': 0, 'ready': 0, 'not_ready': 0}

           crds = await self.api_extensions.list_custom_resource_definition()
           
           # Get all provider CRDs by checking if they have a provider prefix in their group
           provider_crds = [
               crd for crd in crds.items
               if (
                   # Get the first part of the group (e.g., 'aws' from 'aws.crossplane.io')
                   crd.spec.group.split('.')[0] in [p['name'].replace('provider-', '') for p in await self.get_providers()]
                   # Exclude providerconfig CRDs as they are not managed resources
                   and 'providerconfig' not in crd.spec.names.kind.lower()
               )
           ]

           if provider_name:
               provider_crds = [crd for crd in provider_crds if provider_name.replace('provider-', '') in crd.spec.group]

           for crd in provider_crds:
               try:
                   provider_name = crd.spec.group.split('.')[0]
                   
                   if provider_name not in resources_by_provider:
                       resources_by_provider[provider_name] = []

                   resources = await self.custom_api.list_cluster_custom_object(
                       group=crd.spec.group,
                       version=crd.spec.versions[0].name,
                       plural=crd.spec.names.plural
                   )

                   for resource in resources.get('items', []):
                       try:
                           conditions = resource.get('status', {}).get('conditions', [])
                           ready = next((c for c in conditions if c['type'] == 'Ready'), {})
                           synced = next((c for c in conditions if c['type'] == 'Synced'), {})

                           processed_resource = {
                               'name': resource['metadata']['name'],
                               'kind': crd.spec.names.kind,
                               'group': crd.spec.group,
                               'status': {
                                   'ready': ready.get('status', 'Unknown'),
                                   'synced': synced.get('status', 'Unknown')
                               },
                               'created_at': resource['metadata']['creationTimestamp']
                           }

                           resources_by_provider[provider_name].append(processed_resource)
                           
                           stats['total'] += 1
                           if ready.get('status') == 'True':
                               stats['ready'] += 1
                           else:
                               stats['not_ready'] += 1

                       except Exception as e:
                           logger.error(f"Error processing resource {resource.get('metadata', {}).get('name')}: {e}")
                           continue

               except Exception as e:
                   logger.error(f"Error processing CRD {crd.metadata.name}: {e}")
                   continue

           return {
               'providers': resources_by_provider,
               'stats': stats
           }

       except Exception as e:
           logger.error(f"Error getting managed resources: {e}")
           return {'providers': {}, 'stats': {'total': 0, 'ready': 0, 'not_ready': 0}}

   async def get_provider_revisions(self, provider_name: str) -> List[Dict[str, Any]]:
       try:
           # Ensure initialization
           await self._async_init()
           
           revisions = await self.custom_api.list_cluster_custom_object(
               group="pkg.crossplane.io",
               version="v1",
               plural="providerrevisions"
           )
           
           provider_revisions = []
           for revision in revisions.get('items', []):
               if revision.get('spec', {}).get('providerName') == provider_name:
                   metadata = revision['metadata']
                   spec = revision.get('spec', {})
                   status = revision.get('status', {})
                   
                   provider_revisions.append({
                       'name': metadata['name'],
                       'version': spec.get('revision'),
                       'image': spec.get('image'),
                       'desiredState': spec.get('desiredState'),
                       'status': next((c['status'] for c in status.get('conditions', []) 
                                    if c['type'] == 'Healthy'), 'Unknown'),
                       'created_at': metadata['creationTimestamp']
                   })
                   
           return sorted(
               provider_revisions,
               key=lambda x: x['created_at'],
               reverse=True
           )
           
       except Exception as e:
           logger.error(f"Error getting provider revisions: {e}")
           return []
