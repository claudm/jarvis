from kubernetes_asyncio import client, config
import logging
import os
import urllib3
from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)
logger = logging.getLogger(__name__)

async def init_kubernetes_client():
    """Initialize async Kubernetes client using configuration settings"""
    try:
        from config.settings import get_config
        app_config = get_config()
        
        # Configure proxy settings if present
        http_proxy = os.getenv('HTTP_PROXY')
        https_proxy = os.getenv('HTTPS_PROXY')
        proxy_user = os.getenv('PROXY_USER')
        proxy_pass = os.getenv('PROXY_PASS')

        if app_config.IN_CLUSTER:
            # In-cluster configuration
            logger.info("Using in-cluster configuration")
            await config.load_incluster_config()
        else:
            # Out-of-cluster configuration
            if app_config.KUBERNETES_CONFIG_PATH:
                logger.info(f"Loading kubeconfig from: {app_config.KUBERNETES_CONFIG_PATH}")
                await config.load_kube_config(
                    config_file=app_config.KUBERNETES_CONFIG_PATH,
                    context=app_config.KUBERNETES_CONTEXT
                )
            else:
                logger.info("Loading default kubeconfig")
                await config.load_kube_config(context=app_config.KUBERNETES_CONTEXT)

        # Get the current configuration
        configuration = client.Configuration.get_default_copy()
        configuration.verify_ssl = False
        configuration.timeout = 60

        # Configure proxy if needed
        if http_proxy:
            configuration.proxy = http_proxy
        if https_proxy:
            configuration.proxy = https_proxy
        if proxy_user and proxy_pass:
            configuration.proxy_headers = urllib3.make_headers(proxy_basic_auth=f"{proxy_user}:{proxy_pass}")

        client.Configuration.set_default(configuration)
        
        # Initialize API clients
        api_client = client.ApiClient()
        custom_api = client.CustomObjectsApi(api_client)
        core_api = client.CoreV1Api(api_client)
        apps_api = client.AppsV1Api(api_client)
        extensions_api = client.ApiextensionsV1Api(api_client)

        # Test connection
        try:
            await core_api.list_namespace(limit=1)
            logger.info("Successfully connected to cluster")
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            raise

        return (api_client, custom_api, core_api, apps_api, extensions_api)

    except Exception as e:
        logger.error(f"Failed to initialize Kubernetes client: {e}")
        raise
