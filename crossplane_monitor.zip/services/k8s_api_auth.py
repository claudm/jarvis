from kubernetes_asyncio import client, config as k8s_config
import logging
import os
import urllib3
from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)
logger = logging.getLogger(__name__)

class KubernetesClient:
    _instance = None
    _initialized = False
    _api_client = None
    _custom_api = None
    _core_api = None
    _apps_api = None
    _extensions_api = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    async def _init(self):
        """Initialize the Kubernetes client if not already initialized"""
        if self._initialized:
            return

        try:
            # Get application configuration
            from config.settings import get_config
            app_config = get_config()
            
            logger.info(f"Initializing Kubernetes client (env: {os.getenv('FLASK_ENV', 'development')}, in_cluster: {app_config.IN_CLUSTER})")

            if app_config.IN_CLUSTER:
                # Use in-cluster config (service account)
                logger.info("Using in-cluster configuration")
                await k8s_config.load_incluster_config()
            else:
                # Try environment variables first
                k8s_host = os.environ.get('KUBERNETES_HOST')
                k8s_token = os.environ.get('KUBERNETES_TOKEN')

                if k8s_host and k8s_token:
                    # Use explicit host/token configuration
                    logger.info("Using host/token configuration")
                    k8s_configuration = client.Configuration()
                    k8s_configuration.host = k8s_host
                    k8s_configuration.api_key = {"authorization": k8s_token}
                    k8s_configuration.verify_ssl = False
                    k8s_configuration.debug = True
                    self._api_client = client.ApiClient(k8s_configuration)
                else:
                    # Use kubeconfig file
                    kubeconfig = app_config.KUBERNETES_CONFIG_PATH or os.path.expanduser('~/.kube/config')
                    context = app_config.KUBERNETES_CONTEXT
                    logger.info(f"Using kubeconfig: {kubeconfig} with context: {context}")
                    await k8s_config.load_kube_config(
                        config_file=kubeconfig,
                        context=context
                    )
            
            # Create API client if not already created
            if not self._api_client:
                self._api_client = client.ApiClient()

            # Create API instances
            self._custom_api = client.CustomObjectsApi(self._api_client)
            self._core_api = client.CoreV1Api(self._api_client)
            self._apps_api = client.AppsV1Api(self._api_client)
            self._extensions_api = client.ApiextensionsV1Api(self._api_client)

            self._initialized = True
            logger.info("Kubernetes client successfully initialized")

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}", exc_info=True)
            self._initialized = False
            raise

    @property
    def initialized(self):
        return self._initialized

    @property
    async def api_client(self):
        if not self._initialized:
            await self._init()
        return self._api_client

    @property
    async def custom_api(self):
        if not self._initialized:
            await self._init()
        return self._custom_api

    @property
    async def core_api(self):
        if not self._initialized:
            await self._init()
        return self._core_api

    @property
    async def apps_api(self):
        if not self._initialized:
            await self._init()
        return self._apps_api

    @property
    async def extensions_api(self):
        if not self._initialized:
            await self._init()
        return self._extensions_api

    async def get_all_clients(self):
        if not self._initialized:
            await self._init()
        return (
            self._api_client,
            self._custom_api,
            self._core_api,
            self._apps_api,
            self._extensions_api
        )

    async def close(self):
        """Close the API client connection"""
        if self._api_client:
            await self._api_client.close()
            self._initialized = False
            logger.info("Kubernetes client connection closed")

# Global instance
_kubernetes_client = None

def get_kubernetes_client():
    """Get or create Kubernetes client singleton instance"""
    global _kubernetes_client
    if _kubernetes_client is None:
        _kubernetes_client = KubernetesClient()
    return _kubernetes_client
