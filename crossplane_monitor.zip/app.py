# app.py
from quart import Quart, g
from routes.main import main_bp
from routes.api import api
from config.settings import get_config
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
import logging
import os
from datetime import datetime
import asyncio
from services.k8s_api_auth import init_kubernetes_client

logging.basicConfig(
   level=logging.DEBUG,
   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def format_datetime(value):
   if not value:
       return ''
   try:
       if isinstance(value, str):
           dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
           return dt.strftime('%Y-%m-%d %H:%M:%S')
       return value
   except Exception:
       return value

async def create_app():
   app = Quart(__name__)
   
   app_config = get_config()
   app.config.from_object(app_config)
   
   @app.template_filter('datetime')
   def datetime_filter(value):
       return format_datetime(value)
   
   app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
   app.config['PERMANENT_SESSION_LIFETIME'] = 3600

   app.logger.setLevel(logging.DEBUG)
   console_handler = logging.StreamHandler()
   console_handler.setLevel(logging.DEBUG)
   formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
   console_handler.setFormatter(formatter)
   app.logger.addHandler(console_handler)
   
   @app.after_request
   async def after_request(response):
       response.headers.add('Access-Control-Allow-Origin', '*')
       response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
       response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
       return response

   @app.before_serving
   async def startup():
       logger.info("Initializing services...")
       try:
           # Initialize Kubernetes client
           k8s_client = await init_kubernetes_client()
           api_client, custom_api, core_api, apps_api, extensions_api = k8s_client
           
           app.custom_api = custom_api
           app.extensions_api = extensions_api
           app.core_api = core_api
           app.apps_api = apps_api
           
           app.crossplane = CrossplaneService(namespace="crossplane-system")
           app.provider_svc = ProviderService(custom_api)
           app.composition_svc = CompositionService(custom_api)
           app.config_svc = ConfigurationService(custom_api)
           
           await app.crossplane._async_init()
           await app.provider_svc._async_init()
           await app.composition_svc._async_init()
           await app.config_svc._async_init()
           
           logger.info("Services initialized successfully")
           
       except Exception as e:
           logger.error(f"Failed to initialize services: {e}", exc_info=True)
           raise

   @app.after_serving
   async def shutdown():
       logger.info("Cleaning up services...")
       try:
           # Stop all services
           if hasattr(app, 'crossplane'):
               await app.crossplane.stop()
           if hasattr(app, 'provider_svc'):
               await app.provider_svc.stop()
           if hasattr(app, 'composition_svc'):
               await app.composition_svc.stop()
           if hasattr(app, 'config_svc'):
               await app.config_svc.stop()
           
           # Close Kubernetes client
           if hasattr(app, 'k8s_client'):
               await app.k8s_client.close()
               
           logger.info("Services cleaned up successfully")
           
       except Exception as e:
           logger.error(f"Error during cleanup: {e}")

   try:
       app.register_blueprint(main_bp)
       app.register_blueprint(api, url_prefix='/api')
       logger.info("Blueprints registered successfully")
   except Exception as e:
       logger.error(f"Failed to initialize application components: {e}")
       raise

   logger.info(f"Application started in {os.getenv('FLASK_ENV', 'development')} mode")
   logger.info(f"Debug mode: {app.config['DEBUG']}")

   return app

async def main():
   app = await create_app()
   
   try:
       await app.run_task(
           host='0.0.0.0',
           port=int(os.getenv('PORT', 8000)),
           debug=app.config['DEBUG']
       )
   except Exception as e:
       logger.error(f"Error running application: {e}")
       async with app.app_context():
           for func in app.after_serving_funcs:
               await func()
       raise

if __name__ == '__main__':
   asyncio.run(main())
