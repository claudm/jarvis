from quart import Blueprint, render_template, redirect, url_for, flash, jsonify, request
from kubernetes.client.rest import ApiException
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
from services.k8s_api_auth import init_kubernetes_client
import logging
import yaml 
import asyncio
from datetime import datetime

def format_datetime(value):
    """Format datetime to readable string"""
    if not value:
        return ''
    try:
        if isinstance(value, str):
            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        return value
    except Exception:
        return value



logger = logging.getLogger(__name__)

from quart import current_app

# Initialize Blueprint
api = Blueprint('api', __name__)

@api.context_processor
def utility_processor():
    """Add utility functions to template context"""
    return dict(
        format_datetime=format_datetime
    )
    


@api.route('/system/status')
async def get_system_status():
    try:
        status = await current_app.ctx.crossplane.get_summary()
        return jsonify(status)
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/system/events')
async def get_system_events():
    try:
        events = await current_app.crossplane.get_system_events()
        return jsonify(events)
    except Exception as e:
        logger.error(f"Error getting system events: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers')
async def providers():
    try:
        providers = await current_app.provider_svc.get_providers()
        return await render_template('providers.html', providers=providers)
    except Exception as e:
        logger.error(f"Error getting providers: {e}", exc_info=True)
        flash(f"Error getting providers: {str(e)}", "error")
        return redirect(url_for('index'))

@api.route('/providers/<provider_name>')
async def provider_detail(provider_name):
    try:
        provider = await current_app.provider_svc.get_provider_details(provider_name)
        if not provider:
            flash(f"Provider {provider_name} not found", "error")
            return redirect(url_for('api.providers'))
            
        return await render_template('provider_detail.html', provider=provider)
        
    except Exception as e:
        logger.error(f"Error getting provider details: {e}", exc_info=True)
        flash(f"Error getting provider details: {str(e)}", "error")
        return redirect(url_for('api.providers'))



@api.route('/providers/resources', methods=['GET'])
@api.route('/providers/resources/', methods=['GET'])
@api.route('/providers/resources/<provider_name>', methods=['GET'])
async def get_provider_resources(provider_name=None):
    """Get provider resources"""
    try:
        if provider_name is None:
            # Get all providers first
            providers = await current_app.provider_svc.get_providers()
            
            # Get resources for each provider concurrently
            tasks = []
            for provider in providers:
                provider_name = provider.get('name')
                if provider_name:
                    tasks.append(asyncio.create_task(current_app.provider_svc.get_provider_details(provider_name)))
            
            provider_details = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Combine results
            result = {}
            for provider in provider_details:
                if isinstance(provider, Exception):
                    logger.error(f"Error getting provider details: {provider}")
                    continue
                if provider and isinstance(provider, dict):
                    name = provider.get('name')
                    if name:
                        result[name] = {
                            'package': provider.get('package', ''),
                            'version': provider.get('version', ''),
                            'revision': provider.get('revision', ''),
                            'resources': provider.get('resources', {})
                        }
            
            return jsonify(result)
        else:
            logger.info(f"Fetching resources for provider {provider_name}")
            
            provider = await current_app.provider_svc.get_provider_details(provider_name)
            if not provider:
                return jsonify({'error': f'Provider {provider_name} not found'}), 404
                
            return jsonify({
                'provider': {
                    'name': provider_name,
                    'package': provider.get('package', ''),
                    'version': provider.get('version', ''),
                    'revision': provider.get('revision', '')
                },
                'resources': provider.get('resources', {})
            })
                             
    except Exception as e:
        logger.error(f"Error getting provider resources: {e}")
        return jsonify({'error': str(e)}), 500

async def process_composition(comp):
    try:
        metadata = comp.get('metadata', {})
        spec = comp.get('spec', {})
        type_ref = spec.get('compositeTypeRef', {})
        
        conditions = comp.get('status', {}).get('conditions', [])
        ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
        
        return {
            'name': metadata.get('name', 'Unknown'),
            'created_at': metadata.get('creationTimestamp', ''),
            'kind': type_ref.get('kind', ''),
            'group': type_ref.get('group', ''),
            'mode': spec.get('mode', 'Pipeline'),
            'status': ready.get('status', 'Unknown'),
            'resources_count': len(spec.get('resources', []))
        }
    except Exception as e:
        logger.error(f"Error processing composition: {e}")
        return None

@api.route('/compositions')
async def get_compositions():
    try:
        # Get compositions async
        compositions = await current_app.custom_api.list_cluster_custom_object(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions"
        )
        
        # Process compositions concurrently using asyncio.gather
        tasks = [process_composition(comp) for comp in compositions.get('items', [])]
        processed_compositions = await asyncio.gather(*tasks)
        
        # Filter out None results
        processed_compositions = [comp for comp in processed_compositions if comp is not None]
        
        return jsonify(processed_compositions)
    except Exception as e:
        logger.error(f"Error getting compositions: {e}")
        return jsonify({'error': str(e)}), 500

async def process_composite_resource(cr):
    try:
        conditions = cr.get('status', {}).get('conditions', [])
        ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
        synced = next((c for c in conditions if c.get('type') == 'Synced'), {})
        
        # Get managed resources concurrently
        tasks = [get_managed_resource(ref) for ref in cr.get('status', {}).get('resources', [])]
        managed_resources = await asyncio.gather(*tasks)
        
        # Filter out None results
        managed_resources = [r for r in managed_resources if r is not None]
        
        return {
            'name': cr['metadata']['name'],
            'kind': cr['kind'],
            'status': {
                'ready': ready.get('status', 'Unknown'),
                'synced': synced.get('status', 'Unknown'),
                'ready_message': ready.get('message', ''),
                'synced_message': synced.get('message', '')
            },
            'spec': yaml.dump(cr.get('spec', {}), default_flow_style=False),
            'status_details': yaml.dump(cr.get('status', {}), default_flow_style=False),
            'created_at': cr['metadata']['creationTimestamp'],
            'managed_resources': managed_resources
        }
    except Exception as e:
        logger.error(f"Error processing composite resource: {e}")
        return None

@api.route('/compositions/<name>')
async def get_composition_details(name):
    try:
        # Get composition and composites concurrently
        composition = await current_app.custom_api.get_cluster_custom_object(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=name
        )
        
        type_ref = composition.get('spec', {}).get('compositeTypeRef', {})
        if not type_ref:
            return jsonify({'error': 'No type reference found'}), 404

        composites = await current_app.custom_api.list_cluster_custom_object(
            group=type_ref['group'],
            version=type_ref.get('version', 'v1alpha1'),
            plural=f"x{type_ref['kind'].lower()}s"
        )

        # Process matching resources concurrently
        matching_composites = [
            composite for composite in composites.get('items', [])
            if name == composite.get('spec', {}).get('compositionRef', {}).get('name')
        ]
        
        tasks = [process_composite_resource(composite) for composite in matching_composites]
        resources = await asyncio.gather(*tasks)
        
        # Filter out None results
        resources = [r for r in resources if r is not None]

        composition_data = {
            'name': composition['metadata']['name'],
            'type_ref': type_ref,
            'mode': composition['spec'].get('mode', 'Pipeline'),
            'resources': resources,
            'created_at': composition['metadata']['creationTimestamp']
        }

        return jsonify(composition_data)
    except Exception as e:
        logger.error(f"Error getting composition details: {e}")
        return jsonify({'error': str(e)}), 500

async def process_configuration(config):
    try:
        conditions = config.get('status', {}).get('conditions', [])
        status = {
            'ready': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Ready'), 'Unknown'),
            'healthy': next((c.get('status', 'Unknown') for c in conditions if c.get('type') == 'Healthy'), 'Unknown'),
            'conditions': conditions
        }
        
        return {
            'name': config['metadata']['name'],
            'package_type': config['spec'].get('packageType', ''),
            'status': status,
            'created_at': config['metadata']['creationTimestamp']
        }
    except Exception as e:
        logger.error(f"Error processing configuration: {e}")
        return None

@api.route('/configurations')
async def get_configurations():
    try:
        # Get configurations async
        configs = await current_app.custom_api.list_cluster_custom_object(
            group="pkg.crossplane.io",
            version="v1",
            plural="configurations"
        )
        
        # Process configurations concurrently
        tasks = [process_configuration(config) for config in configs.get('items', [])]
        processed_configs = await asyncio.gather(*tasks)
        
        # Filter out None results
        processed_configs = [config for config in processed_configs if config is not None]
        
        return jsonify(processed_configs)
    except Exception as e:
        logger.error(f"Error getting configurations: {e}")
        return jsonify({'error': str(e)}), 500

async def process_crd_resources(crd):
    try:
        kind = crd.spec.names.kind
        version = crd.spec.versions[0].name
        group = crd.spec.group
        
        # Get resources for this CRD
        resources = await current_app.custom_api.list_cluster_custom_object(
            group=group,
            version=version,
            plural=crd.spec.names.plural
        )
        
        if resources.get('items'):
            service = group.split('.')[0]
            processed_resources = []
            
            for r in resources.get('items', []):
                conditions = r.get('status', {}).get('conditions', [])
                ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
                synced = next((c for c in conditions if c.get('type') == 'Synced'), {})
                
                resource_data = {
                    'name': r['metadata']['name'],
                    'kind': kind,
                    'group': group,
                    'version': version,
                    'status': {
                        'ready': ready.get('status', 'Unknown'),
                        'synced': synced.get('status', 'Unknown'),
                        'ready_message': ready.get('message', ''),
                        'synced_message': synced.get('message', '')
                    },
                    'spec': yaml.dump(r.get('spec', {}), default_flow_style=False),
                    'status_details': yaml.dump(r.get('status', {}), default_flow_style=False),
                    'created_at': r['metadata']['creationTimestamp']
                }
                processed_resources.append(resource_data)
            
            return service, kind, processed_resources
    except Exception as e:
        logger.error(f"Error processing CRD {crd.metadata.name}: {e}")
        return None

@api.route('/configurations')
async def configurations():
    """Get configurations page"""
    try:
        configs = await config_svc.get_configurations()
        return await render_template('configurations.html', configurations=configs)
    except Exception as e:
        logger.error(f"Error getting configurations: {e}", exc_info=True)
        flash(f"Error getting configurations: {str(e)}", "error")
        return redirect(url_for('index'))

@api.route('/configurations/<name>')
async def get_configuration_details(name):
    """Get configuration details"""
    try:
        config = await config_svc.get_configuration_details(name)
        if not config:
            return jsonify({'error': f'Configuration {name} not found'}), 404
        return jsonify(config)
    except Exception as e:
        logger.error(f"Error getting configuration details: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations/<name>/retry', methods=['POST'])
async def retry_configuration(name):
    """Retry configuration installation"""
    try:
        # Get current configuration
        config = await config_svc.get_configuration_details(name)
        if not config:
            return jsonify({'error': f'Configuration {name} not found'}), 404
            
        # Check if configuration is in failed state
        if config['status'] != 'installation_failed':
            return jsonify({'error': 'Configuration is not in failed state'}), 400
            
        # Delete the configuration to trigger a fresh installation
        await current_app.custom_api.delete_cluster_custom_object(
            group="pkg.crossplane.io",
            version="v1",
            plural="configurations",
            name=name
        )
        
        # Wait a moment for deletion to complete
        await asyncio.sleep(2)
        
        # Recreate the configuration with the same spec
        await current_app.custom_api.create_cluster_custom_object(
            group="pkg.crossplane.io",
            version="v1",
            plural="configurations",
            body={
                "apiVersion": "pkg.crossplane.io/v1",
                "kind": "Configuration",
                "metadata": {
                    "name": name
                },
                "spec": {
                    "package": config['package'],
                    "packagePullPolicy": "Always",  # Force pull new package
                    "revisionActivationPolicy": "Automatic",
                    "revisionHistoryLimit": 1
                }
            }
        )
        
        return jsonify({'message': f'Configuration {name} retry initiated'}), 200
    except Exception as e:
        logger.error(f"Error retrying configuration installation: {e}")
        return jsonify({'error': str(e)}), 500

async def process_provider(p):
    try:
        metadata = p.get('metadata', {})
        spec = p.get('spec', {})
        status = p.get('status', {})
        
        status_dict = {}
        for condition in status.get('conditions', []):
            if isinstance(condition, dict):
                status_dict[condition.get('type', '')] = condition.get('status', 'Unknown')
        
        return {
            'name': metadata.get('name', 'Unknown'),
            'created_at': metadata.get('creationTimestamp', ''),
            'package': spec.get('package', ''),
            'version': spec.get('package', '').split(':')[-1] if spec.get('package') else '',
            'revision': status.get('currentRevision', ''),
            'status': {
                'healthy': status_dict.get('Healthy', 'Unknown'),
                'installed': status_dict.get('Installed', 'Unknown')
            },
            'kind': p.get('kind', 'Unknown'),
            'group': p.get('apiVersion', '').split('/')[0],
            'is_upbound': 'upbound.io' in spec.get('package', '')
        }
    except Exception as e:
        logger.error(f"Error processing provider: {e}")
        return None

async def process_crd(crd):
    try:
        return {
            'name': crd.metadata.name,
            'group': crd.spec.group,
            'kind': crd.spec.names.kind,
            'plural': crd.spec.names.plural,
            'version': crd.spec.versions[0].name if crd.spec.versions else 'unknown'
        }
    except Exception as e:
        logger.error(f"Error processing CRD: {e}")
        return None



async def get_managed_resource(ref):
    try:
        resource = await current_app.custom_api.get_cluster_custom_object(
            group=ref['resource']['group'],
            version=ref['resource']['version'],
            plural=ref['resource']['plural'],
            name=ref['name']
        )
        
        conditions = resource.get('status', {}).get('conditions', [])
        ready = next((c for c in conditions if c.get('type') == 'Ready'), {})
        synced = next((c for c in conditions if c.get('type') == 'Synced'), {})
        
        return {
            'name': ref['name'],
            'kind': ref['kind'],
            'status': {
                'ready': ready.get('status', 'Unknown'),
                'synced': synced.get('status', 'Unknown'),
                'ready_message': ready.get('message', ''),
                'synced_message': synced.get('message', '')
            },
            'spec': yaml.dump(resource.get('spec', {}), default_flow_style=False),
            'status_details': yaml.dump(resource.get('status', {}), default_flow_style=False),
            'created_at': resource['metadata']['creationTimestamp']
        }
    except Exception as e:
        logger.error(f"Error getting managed resource: {e}")
        return None

async def get_custom_resources(group, version, plural, kind):
    try:
        resources = await current_app.custom_api.list_cluster_custom_object(
            group=group,
            version=version,
            plural=plural
        )
        
        return [{
            'name': r['metadata']['name'],
            'kind': kind,
            'group': group,
            'status': 'Ready' if any(c.get('type') == 'Ready' and c.get('status') == 'True' 
                                   for c in r.get('status', {}).get('conditions', [])) else 'Not Ready'
        } for r in resources.get('items', [])]
    except Exception as e:
        logger.error(f"Error getting custom resources: {e}")
        return None

@api.errorhandler(404)
async def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@api.errorhandler(500)
async def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500