# api.py
from quart import Blueprint, jsonify, request
from kubernetes.client.rest import ApiException
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
from services.k8s_api_auth import get_kubernetes_client
import logging
import yaml 
import asyncio
from datetime import datetime

def format_datetime(value):
    """Format datetime to readable string"""
    if not value:
        return ''
    try:
        if isinstance(value, str):
            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        return value
    except Exception:
        return value

logger = logging.getLogger(__name__)

# Initialize Blueprint
api = Blueprint('api', __name__)

@api.context_processor
def utility_processor():
    """Add utility functions to template context"""
    return dict(format_datetime=format_datetime)

@api.route('/system/status')
async def get_system_status():
    try:
        k8s_client =   get_kubernetes_client()
        crossplane = CrossplaneService(namespace="crossplane-system")
        await crossplane._async_init()
        status = await crossplane.get_summary()
        return jsonify(status)
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers')
async def get_providers():
    try:
        k8s_client = await get_kubernetes_client()
        provider_svc = ProviderService(namespace="crossplane-system")
        await provider_svc._async_init()
        providers = await provider_svc.get_providers()
        return jsonify(providers)
    except Exception as e:
        logger.error(f"Error getting providers: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers/<provider_name>')
async def get_provider_details(provider_name):
    try:
        k8s_client =   get_kubernetes_client()
        provider_svc = ProviderService(namespace="crossplane-system")
        await provider_svc._async_init()
        provider = await provider_svc.get_provider_details(provider_name)
        if not provider:
            return jsonify({'error': f'Provider {provider_name} not found'}), 404
        return jsonify(provider)
    except Exception as e:
        logger.error(f"Error getting provider details: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/providers/resources', methods=['GET'])
@api.route('/providers/resources/<provider_name>', methods=['GET'])
async def get_provider_resources(provider_name=None):
    try:
        k8s_client = await get_kubernetes_client()
        provider_svc = ProviderService(namespace="crossplane-system")
        await provider_svc._async_init()
        
        resources = await provider_svc.get_managed_resources(provider_name)
        return jsonify(resources)
    except Exception as e:
        logger.error(f"Error getting provider resources: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/compositions')
async def get_compositions():
    try:
        k8s_client =   get_kubernetes_client()
        composition_svc = CompositionService(k8s_client.custom_api)
        await composition_svc._async_init()
        compositions = await composition_svc.get_compositions()
        return jsonify(compositions)
    except Exception as e:
        logger.error(f"Error getting compositions: {e}")
        return jsonify({'error': str(e)}), 500

@api.route('/configurations')
async def get_configurations():
    try:
        k8s_client =   get_kubernetes_client()
        config_svc = ConfigurationService(k8s_client.custom_api)
        await config_svc._async_init()
        configs = await config_svc.get_configurations()
        return jsonify(configs)
    except Exception as e:
        logger.error(f"Error getting configurations: {e}")
        return jsonify({'error': str(e)}), 500

# Error handlers
@api.errorhandler(404)
async def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@api.errorhandler(500)
async def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500