# main.py
from quart import Blueprint, render_template
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
import logging
from services.k8s_api_auth import get_kubernetes_client
import asyncio
from datetime import datetime

def format_datetime(value):
    """Format datetime to readable string"""
    if not value:
        return ''
    try:
        if isinstance(value, str):
            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        return value
    except Exception:
        return value

logger = logging.getLogger(__name__)
main_bp = Blueprint('main', __name__)

@main_bp.context_processor
def utility_processor():
    """Add utility functions to template context"""
    return dict(
        format_datetime=format_datetime
    )

@main_bp.route('/')
@main_bp.route('/index')
async def index():
    """Dashboard/Overview page"""
    try:
        # Get initialized services
        k8s_client = get_kubernetes_client()
        crossplane = CrossplaneService(namespace="crossplane-system")
        provider_svc = ProviderService(namespace="crossplane-system")
        composition_svc = CompositionService(k8s_client.custom_api)
        config_svc = ConfigurationService(k8s_client.custom_api)

        # Initialize async components
        await crossplane._async_init()
        await provider_svc._async_init()
        await composition_svc._async_init()
        await config_svc._async_init()

        # Get status and all data concurrently
        status, events, providers, compositions, configs = await asyncio.gather(
            crossplane.get_summary(),
            crossplane.get_system_events(),
            provider_svc.get_providers(),
            composition_svc.get_compositions(),
            config_svc.get_configurations()
        )
        
        # Combine results
        status['events'] = events
        status['provider_list'] = providers
        status['composition_list'] = compositions
        status['configuration_list'] = configs
        
        return await render_template('index.html', 
                                  title='Dashboard',
                                  status=status)
    except Exception as e:
        logger.error(f"Error loading dashboard: {e}")
        return await render_template('error.html', 
                                  title='Error',
                                  error=str(e))

@main_bp.route('/providers')
async def providers():
    """Providers page"""
    try:
        k8s_client = get_kubernetes_client()
        provider_svc = ProviderService(namespace="crossplane-system")
        await provider_svc._async_init()
        
        providers_list = await provider_svc.get_providers()
        managed = await provider_svc.get_managed_resources()
        
        # Combine provider data with their resources, grouped by kind
        for provider in providers_list:
            provider_name = provider['name'].replace('provider-', '')
            resources = managed.get('providers', {}).get(provider_name, [])
            
            # Group resources by kind
            resources_by_kind = {}
            for resource in resources:
                kind = resource['kind']
                if kind not in resources_by_kind:
                    resources_by_kind[kind] = []
                resources_by_kind[kind].append(resource)
            
            provider['resources'] = resources_by_kind
        
        return await render_template('providers.html', 
                                  title='Providers',
                                  providers=providers_list,
                                  stats=managed.get('stats', {}))
    except Exception as e:
        logger.error(f"Error loading providers: {e}")
        return await render_template('error.html', 
                                  title='Error',
                                  error=str(e))

@main_bp.route('/providers/<provider_name>')
async def provider_details(provider_name):
    """Provider details page"""
    try:
        k8s_client = get_kubernetes_client()
        provider_svc = ProviderService(namespace="crossplane-system")
        await provider_svc._async_init()
        
        provider = await provider_svc.get_provider_details(provider_name)
        if not provider:
            logger.warning(f"Provider {provider_name} not found")
            return await render_template('error.html',
                                      title='Provider Not Found',
                                      error=f'Provider {provider_name} not found')
        
        return await render_template('provider_details.html',
                                  title=f'Provider: {provider_name}',
                                  provider=provider)
    except Exception as e:
        logger.error(f"Error loading provider details: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/compositions')
async def compositions():
    """Compositions page"""
    try:
        k8s_client = get_kubernetes_client()
        composition_svc = CompositionService(k8s_client.custom_api)
        await composition_svc._async_init()
        
        compositions_list = await composition_svc.get_compositions()
        return await render_template('compositions.html',
                                  title='Compositions',
                                  compositions=compositions_list)
    except Exception as e:
        logger.error(f"Error loading compositions: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/compositions/<name>')
async def composition_details(name):
    """Composition details page"""
    try:
        k8s_client = get_kubernetes_client()
        composition_svc = CompositionService(k8s_client.custom_api)
        await composition_svc._async_init()
        
        composition = await composition_svc.get_composition_details(name)
        if not composition:
            return await render_template('error.html',
                                      title='Composition Not Found',
                                      error=f'Composition {name} not found')
        
        return await render_template('composition_details.html',
                                  title=f'Composition: {name}',
                                  composition=composition)
    except Exception as e:
        logger.error(f"Error loading composition details: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/configurations')
async def configurations():
    """Configurations page"""
    try:
        k8s_client = get_kubernetes_client()
        config_svc = ConfigurationService(k8s_client.custom_api)
        await config_svc._async_init()
        
        configs_list = await config_svc.get_configurations()
        return await render_template('configurations.html',
                                  title='Configurations',
                                  configurations=configs_list)
    except Exception as e:
        logger.error(f"Error loading configurations: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/configurations/<name>')
async def configuration_details(name):
    """Configuration details page"""
    try:
        k8s_client = get_kubernetes_client()
        config_svc = ConfigurationService(k8s_client.custom_api)
        await config_svc._async_init()
        
        config = await config_svc.get_configuration_details(name)
        if not config:
            return await render_template('error.html',
                                      title='Configuration Not Found',
                                      error=f'Configuration {name} not found')
        
        return await render_template('configuration_details.html',
                                  title=f'Configuration: {name}',
                                  configuration=config)
    except Exception as e:
        logger.error(f"Error loading configuration details: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/health')
async def health():
    """Health check page"""
    try:
        k8s_client = get_kubernetes_client()
        crossplane = CrossplaneService(namespace="crossplane-system")
        await crossplane._async_init()
        
        health_status = await crossplane.get_health_status()
        return await render_template('health.html',
                                  title='System Health',
                                  status=health_status)
    except Exception as e:
        logger.error(f"Error checking health: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.errorhandler(404)
async def not_found_error(error):
    return await render_template('error.html',
                              title='Not Found',
                              error='The requested page was not found'), 404

@main_bp.errorhandler(500)
async def internal_error(error):
    return await render_template('error.html',
                              title='Internal Error',
                              error='An internal server error occurred'), 500
