from quart import Blueprint, render_template, g
from services.crossplane.core import CrossplaneService
from services.crossplane.providers import ProviderService
from services.crossplane.compositions import CompositionService
from services.crossplane.configurations import ConfigurationService
import logging
from kubernetes_asyncio import client, config
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)
main_bp = Blueprint('main', __name__)

def format_datetime(value):
    """Format datetime to readable string"""
    if not value:
        return ''
    try:
        if isinstance(value, str):
            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        return value
    except Exception:
        return value

@main_bp.context_processor
def utility_processor():
    """Add utility functions to template context"""
    return dict(
        format_datetime=format_datetime
    )

async def init_services():
    """Initialize all services"""
    if not hasattr(g, 'services_initialized'):
        try:
            # Load Kubernetes config
            await config.load_kube_config()
            
            # Create API client
            api_client = client.ApiClient()
            
            # Create API instances
            g.custom_api = client.CustomObjectsApi(api_client)
            g.core_api = client.CoreV1Api(api_client)
            g.apps_api = client.AppsV1Api(api_client)
            g.extensions_api = client.ApiextensionsV1Api(api_client)
            
            # Initialize services
            g.crossplane = CrossplaneService(namespace="crossplane-system")
            g.provider_svc = ProviderService(g.custom_api)
            g.composition_svc = CompositionService(g.custom_api)
            g.config_svc = ConfigurationService(g.custom_api)
            
            # Initialize async components
            await g.crossplane._async_init()
            await g.provider_svc._async_init()
            await g.composition_svc._async_init()
            await g.config_svc._async_init()
            
            g.services_initialized = True
            logger.info("Services initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize services: {e}", exc_info=True)
            raise

@main_bp.before_request
async def before_request():
    """Initialize services before each request"""
    await init_services()

@main_bp.route('/')
@main_bp.route('/index')
async def index():
    """Dashboard/Overview page"""
    try:
        # Get system status and other data concurrently
        status, events, providers, compositions, configs = await asyncio.gather(
            g.crossplane.get_summary(),
            g.crossplane.get_system_events(),
            g.provider_svc.get_providers(),
            g.composition_svc.get_compositions(),
            g.config_svc.get_configurations()
        )
        
        # Combine results
        status.update({
            'events': events,
            'provider_list': providers,
            'composition_list': compositions,
            'configuration_list': configs
        })
        
        return await render_template('index.html', 
                                  title='Dashboard',
                                  status=status)
    except Exception as e:
        logger.error(f"Error loading dashboard: {e}")
        return await render_template('error.html', 
                                  title='Error',
                                  error=str(e))

@main_bp.route('/providers')
async def providers():
    """Providers page"""
    try:
        # Obtenha os dados dos provedores
        providers_list = await g.provider_svc.get_providers()
        managed = await g.provider_svc.get_managed_resources()

        # Combine recursos com provedores
        for provider in providers_list:
            provider_name = provider['name']  # Nome original do provedor
            provider['resources'] = managed.get('providers', {}).get(provider_name, [])

        # Estatísticas
        stats = managed.get('stats', {})

        # Log para depuração
        logger.debug(f"Providers List: {providers_list}")
        logger.debug(f"Stats: {stats}")

        # Renderize o template e passe as variáveis necessárias
        return await render_template(
            'providers.html',
            title='Providers',
            providers=providers_list,
            stats=stats
        )
    except Exception as e:
        logger.error(f"Error loading providers: {e}")
        return await render_template('error.html', title='Error', error=str(e))

@main_bp.route('/providers/<provider_name>')
async def provider_details(provider_name):
    """Provider details page"""
    try:
        # Fetch provider details and revisions
        provider = await g.provider_svc.get_provider_details(provider_name)
        if not provider:
            logger.warning(f"Provider {provider_name} not found")
            return await render_template(
                'error.html',
                title='Provider Not Found',
                error=f'Provider {provider_name} not found'
            )

        revisions = await g.provider_svc.get_provider_revisions(provider_name)
        provider['revisions'] = revisions

        return await render_template(
            'provider_details.html',
            title=f'Provider: {provider_name}',
            provider=provider
        )
    except Exception as e:
        logger.error(f"Error loading provider details: {e}")
        return await render_template('error.html', title='Error', error=str(e))

@main_bp.route('/compositions')
async def compositions():
    """Compositions page"""
    try:
        compositions_list = await g.composition_svc.get_compositions()
        
        return await render_template('compositions.html',
                                  title='Compositions',
                                  compositions=compositions_list)
                                  
    except Exception as e:
        logger.error(f"Error loading compositions: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/compositions/<name>')
async def composition_details(name):
    """Composition details page"""
    try:
        composition = await g.composition_svc.get_composition_details(name)
        
        if not composition:
            logger.warning(f"Composition {name} not found")
            return await render_template('error.html',
                                      title='Composition Not Found',
                                      error=f'Composition {name} not found')
        
        return await render_template('composition_details.html',
                                  title=f'Composition: {name}',
                                  composition=composition)
                                  
    except Exception as e:
        logger.error(f"Error loading composition details: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/configurations')
async def configurations():
    """Configurations page"""
    try:
        configs_list = await g.config_svc.get_configurations()
        
        return await render_template('configurations.html',
                                  title='Configurations',
                                  configurations=configs_list)
                                  
    except Exception as e:
        logger.error(f"Error loading configurations: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/configurations/<name>')
async def configuration_details(name):
    """Configuration details page"""
    try:
        config = await g.config_svc.get_configuration_details(name)
        
        if not config:
            logger.warning(f"Configuration {name} not found")
            return await render_template('error.html',
                                      title='Configuration Not Found',
                                      error=f'Configuration {name} not found')
        
        return await render_template('configuration_details.html',
                                  title=f'Configuration: {name}',
                                  configuration=config)
                                  
    except Exception as e:
        logger.error(f"Error loading configuration details: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

@main_bp.route('/health')
async def health():
    """Health check endpoint"""
    try:
        health_status = await g.crossplane.get_health_status()
        return await render_template('health.html',
                                  title='System Health',
                                  status=health_status)
                                  
    except Exception as e:
        logger.error(f"Error checking health: {e}")
        return await render_template('error.html',
                                  title='Error',
                                  error=str(e))

# API routes for resource operations
@main_bp.route('/api/providers/resources/describe/<group>/<kind>/<name>')
async def describe_provider_resource(group: str, kind: str, name: str):
    """Get detailed description of a provider resource"""
    try:
        # Get resource details
        resource = await g.custom_api.get_cluster_custom_object(
            group=group,
            version='v1alpha1',  # Usually v1alpha1 for provider resources
            plural=f"{kind.lower()}s",
            name=name
        )
        
        return {'describe': resource}
        
    except Exception as e:
        logger.error(f"Error describing resource: {e}")
        return {'error': str(e)}, 500

@main_bp.errorhandler(404)
async def not_found_error(error):
    return await render_template('error.html',
                              title='Not Found',
                              error='The requested page was not found'), 404

@main_bp.errorhandler(500)
async def internal_error(error):
    return await render_template('error.html',
                              title='Internal Error',
                              error='An internal server error occurred'), 500