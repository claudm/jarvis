// Wait for DOM content to be loaded before initializing theme
document.addEventListener('DOMContentLoaded', () => {
    // Theme management
    class ThemeManager {
    constructor() {
        this.html = document.documentElement;
        this.themeToggleBtn = document.getElementById('theme-toggle');
        this.lightIcon = document.getElementById('light-icon');
        this.darkIcon = document.getElementById('dark-icon');
        
        this.initialize();
    }

    initialize() {
        // Check for saved theme preference, otherwise use system preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            this.setTheme(savedTheme);
        } else {
            const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            this.setTheme(systemPrefersDark ? 'dark' : 'light');
        }

        // Setup event listeners
        this.setupEventListeners();
        
        // Update icons initial state
        this.updateIcons();
    }

    setTheme(theme) {
        this.html.classList.remove('light', 'dark');
        this.html.classList.add(theme);
        localStorage.setItem('theme', theme);
        this.updateIcons();

        // Dispatch theme change event
        const event = new CustomEvent('themechange', { detail: { theme } });
        document.dispatchEvent(event);
    }

    toggleTheme() {
        const newTheme = this.html.classList.contains('dark') ? 'light' : 'dark';
        this.setTheme(newTheme);
    }

    updateIcons() {
        const isDark = this.html.classList.contains('dark');
        this.lightIcon.classList.toggle('hidden', !isDark);
        this.darkIcon.classList.toggle('hidden', isDark);
    }

    setupEventListeners() {
        // Theme toggle button click
        if (this.themeToggleBtn) {
            this.themeToggleBtn.addEventListener('click', () => this.toggleTheme());
        }

        // Listen for system theme changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (!localStorage.getItem('theme')) {
                this.setTheme(e.matches ? 'dark' : 'light');
            }
        });
    }
}

    // Initialize theme manager
    window.themeManager = new ThemeManager();
});
