from flask import Blueprint, jsonify, request
from app.models.crossplane_manager import CrossplaneManager
from app.services.background_worker import operation_queue, operation_results, operation_lock
import time
import logging

bp = Blueprint('xrd', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)
manager = CrossplaneManager()

async def ensure_manager_initialized():
    """Ensure the Kubernetes client is initialized"""
    if not await manager.verify_connection():
        await manager.initialize_client()

@bp.route('/xrds', methods=['GET'])
async def list_xrds():
    """List all XRDs (Composite Resource Definitions)"""
    try:
        await ensure_manager_initialized()
        logger.info("Attempting to list XRDs from Kubernetes API")
        crds = await manager.get_crossplane_crds()
        
        # Filter only XRDs (Composite Resource Definitions)
        xrds = [
            crd for crd in crds
            if any(cat in ['composite', 'definition.crossplane.io'] 
                  for cat in crd.get('categories', []))
        ]
        
        # Transform CRDs into the format expected by the frontend
        transformed_xrds = []
        for xrd in xrds:
            transformed = {
                'metadata': {
                    'name': xrd.get('name'),
                    'creationTimestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ')
                },
                'spec': {
                    'group': xrd.get('group'),
                    'versions': [{'name': xrd.get('version')}] if xrd.get('version') else [],
                    'names': {
                        'kind': xrd.get('kind'),
                        'categories': xrd.get('categories', [])
                    },
                    'scope': xrd.get('scope')
                }
            }
            transformed_xrds.append(transformed)
            
        logger.info(f"Retrieved {len(transformed_xrds)} XRDs")
        return jsonify({
            'xrds': transformed_xrds,
            'count': len(transformed_xrds),
            'message': 'No XRDs found' if not transformed_xrds else None
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing XRDs: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list XRDs"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "XRDs resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list XRDs: {error_msg}"}), 500

@bp.route('/xrds/<name>', methods=['GET'])
async def get_xrd(name):
    """Get a specific XRD by name"""
    try:
        await ensure_manager_initialized()
        logger.info(f"Attempting to get XRD: {name}")
        xrd = await manager.get_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositeresourcedefinitions",
            name=name
        )
        if not xrd:
            logger.warning(f"XRD not found: {name}")
            return jsonify({"error": f"XRD '{name}' not found"}), 404
        return jsonify(xrd)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting XRD {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get XRD"}), 403
        else:
            return jsonify({"error": f"Failed to get XRD: {error_msg}"}), 500

@bp.route('/xrds', methods=['POST'])
async def create_xrd():
    """Create a new XRD"""
    try:
        await ensure_manager_initialized()
        xrd_data = request.json
        
        if not xrd_data:
            return jsonify({"error": "No XRD data provided"}), 400

        # Validate required fields
        if not isinstance(xrd_data, dict):
            return jsonify({"error": "Invalid XRD format: must be a JSON object"}), 400

        metadata = xrd_data.get("metadata", {})
        if not isinstance(metadata, dict):
            return jsonify({"error": "Invalid metadata format: must be a JSON object"}), 400

        name = metadata.get("name")
        if not name:
            return jsonify({"error": "XRD name is required in metadata"}), 400

        try:
            result = await manager.create_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions",
                body=xrd_data
            )

            if result:
                logger.info(f"Successfully created XRD: {name}")
                return jsonify({
                    'message': 'XRD created successfully',
                    'xrd': result
                }), 201
            return jsonify({"error": "Failed to create XRD: No response from API"}), 500

        except Exception as e:
            error_msg = str(e)
            if "already exists" in error_msg.lower():
                return jsonify({"error": f"XRD '{name}' already exists"}), 409
            elif "forbidden" in error_msg.lower():
                return jsonify({"error": "Permission denied to create XRD"}), 403
            elif "invalid" in error_msg.lower():
                return jsonify({"error": f"Invalid XRD format: {error_msg}"}), 400
            else:
                return jsonify({"error": f"Failed to create XRD: {error_msg}"}), 500

    except Exception as e:
        logger.error(f"Unexpected error creating XRD: {str(e)}")
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

@bp.route('/xrds/<name>', methods=['PUT'])
async def update_xrd(name):
    """Update an existing XRD"""
    try:
        await ensure_manager_initialized()
        xrd_data = request.json
        
        if not xrd_data:
            return jsonify({"error": "No XRD data provided"}), 400

        # Validate required fields
        if not isinstance(xrd_data, dict):
            return jsonify({"error": "Invalid XRD format: must be a JSON object"}), 400

        metadata = xrd_data.get("metadata", {})
        if not isinstance(metadata, dict):
            return jsonify({"error": "Invalid metadata format: must be a JSON object"}), 400

        if metadata.get("name") != name:
            return jsonify({"error": "XRD name in URL must match name in metadata"}), 400

        try:
            result = await manager.update_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositeresourcedefinitions",
                name=name,
                body=xrd_data
            )

            if result:
                logger.info(f"Successfully updated XRD: {name}")
                return jsonify({
                    'message': 'XRD updated successfully',
                    'xrd': result
                })
            return jsonify({"error": "Failed to update XRD: No response from API"}), 500

        except Exception as e:
            error_msg = str(e)
            if "not found" in error_msg.lower():
                return jsonify({"error": f"XRD '{name}' not found"}), 404
            elif "forbidden" in error_msg.lower():
                return jsonify({"error": "Permission denied to update XRD"}), 403
            elif "invalid" in error_msg.lower():
                return jsonify({"error": f"Invalid XRD format: {error_msg}"}), 400
            else:
                return jsonify({"error": f"Failed to update XRD: {error_msg}"}), 500

    except Exception as e:
        logger.error(f"Unexpected error updating XRD: {str(e)}")
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

@bp.route('/xrds/<name>', methods=['DELETE'])
async def delete_xrd(name):
    """Delete an XRD"""
    try:
        await ensure_manager_initialized()
        logger.info(f"Attempting to delete XRD: {name}")
        result = await manager.delete_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositeresourcedefinitions",
            name=name
        )
        if result:
            logger.info(f"Successfully deleted XRD: {name}")
            return jsonify({"message": f"XRD '{name}' deleted successfully"})
        return jsonify({"error": "Failed to delete XRD: No response from API"}), 500
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error deleting XRD {name}: {error_msg}")
        if "not found" in error_msg.lower():
            return jsonify({"error": f"XRD '{name}' not found"}), 404
        elif "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to delete XRD"}), 403
        else:
            return jsonify({"error": f"Failed to delete XRD: {error_msg}"}), 500
