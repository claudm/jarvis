# app/controllers/__init__.py
from . import composition_controller
from . import claim_controller
from . import resource_controller
from . import xrd_controller
from . import page_controller
