from flask import Blueprint, jsonify, request
from app.models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('composite_resource_definition', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)
manager = CrossplaneManager()

async def ensure_manager_initialized():
    """Ensure the Kubernetes client is initialized"""
    if not await manager.verify_connection():
        await manager.initialize_client()

@bp.route('/composite-resource-definitions', methods=['GET'])
async def list_composite_resource_definitions():
    """List all Composite Resource Definitions"""
    try:
        await ensure_manager_initialized()
        logger.info("Attempting to list Composite Resource Definitions from Kubernetes API")
        # Get full XRD objects directly from the API
        response = await manager.custom_api.list_cluster_custom_object(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositeresourcedefinitions"
        )
        
        logger.info(f"Retrieved {len(response.get('items', []))} Composite Resource Definitions")
        return jsonify(response)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing XRDs: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list Composite Resource Definitions"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Composite Resource Definitions resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list Composite Resource Definitions: {error_msg}"}), 500

@bp.route('/composite-resource-definitions/<name>', methods=['GET'])
async def get_composite_resource_definition(name):
    """Get a specific Composite Resource Definition by name"""
    try:
        await ensure_manager_initialized()
        logger.info(f"Attempting to get Composite Resource Definition: {name}")
        xrd = await manager.get_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositeresourcedefinitions",
            name=name
        )
        if not xrd:
            logger.warning(f"Composite Resource Definition not found: {name}")
            return jsonify({"error": f"Composite Resource Definition '{name}' not found"}), 404
        return jsonify(xrd)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting Composite Resource Definition {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get Composite Resource Definition"}), 403
        else:
            return jsonify({"error": f"Failed to get Composite Resource Definition: {error_msg}"}), 500
