# app/controllers/page_controller.py
from flask import Blueprint, render_template, redirect, url_for, jsonify
from app.models.crossplane_manager import CrossplaneManager
from functools import wraps
import asyncio

bp = Blueprint('pages', __name__)
manager = CrossplaneManager()

def async_route(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop.run_until_complete(f(*args, **kwargs))
    return wrapper

@bp.route('/api/overview')
@async_route
async def api_overview():
    # Get Crossplane status
    crossplane_status = await manager.get_crossplane_status()

    # Gather data from all resources
    providers = await manager.list_providers()
    compositions = await manager.list_compositions()
    xrds = await manager.get_crossplane_crds()
    claims = await manager.list_claims()
    composite_resources = await manager.get_composite_resources()
    managed_resources = await manager.get_managed_resources()

    # Filter XRDs to only include composite ones
    filtered_xrds = [x for x in xrds if 'composite' in (x.get('categories', []) or [])]

    # Calculate managed resources summary
    managed_resources_summary = {
        "total_count": 0,
        "health_summary": {"healthy": 0, "unhealthy": 0, "unknown": 0}
    }
    
    for resource in managed_resources:
        managed_resources_summary["total_count"] += 1
        health_status = resource.get('_health_status', 'unknown').lower()
        managed_resources_summary["health_summary"][health_status] = managed_resources_summary["health_summary"].get(health_status, 0) + 1

    # Return comprehensive overview
    return jsonify({
        "status": "success",
        "data": {
            "crossplane": crossplane_status,
            "providers": {
                "count": len(providers),
                "items": providers
            },
            "compositions": {
                "count": len(compositions),
                "items": compositions
            },
            "xrds": {
                "count": len(filtered_xrds),
                "items": filtered_xrds
            },
            "claims": {
                "count": len(claims),
                "items": claims
            },
            "composite_resources": {
                "count": len(composite_resources),
                "items": composite_resources
            },
            "managed_resources": managed_resources_summary
        }
    })

@bp.route('/api/providers')
@async_route
async def api_providers():
    providers = await manager.list_providers()
    return jsonify({
        "count": len(providers),
        "providers": providers
    })

@bp.route('/api/compositions')
@async_route
async def api_compositions():
    compositions = await manager.list_compositions()
    return jsonify({
        "count": len(compositions),
        "compositions": compositions
    })

@bp.route('/api/xrds')
@async_route
async def api_xrds():
    xrds = await manager.get_crossplane_crds()
    filtered_xrds = [x for x in xrds if 'composite' in (x.get('categories', []) or [])]
    return jsonify({
        "count": len(filtered_xrds),
        "xrds": filtered_xrds
    })

@bp.route('/api/claims')
@async_route
async def api_claims():
    claims = await manager.list_claims()
    return jsonify({
        "count": len(claims),
        "claims": claims
    })

@bp.route('/api/composite-resources')
@async_route
async def api_composite_resources():
    resources = await manager.get_composite_resources()
    return jsonify({
        "count": len(resources),
        "resources": resources
    })

@bp.route('/api/managed-resources')
@async_route
async def api_managed_resources():
    resources = await manager.get_managed_resources()
    # Group resources by kind
    grouped_resources = {}
    total_count = 0
    health_summary = {"healthy": 0, "unhealthy": 0, "unknown": 0}
    
    for resource in resources:
        kind = resource.get('_resource_type', {}).get('kind', 'Unknown')
        if kind not in grouped_resources:
            grouped_resources[kind] = {
                "count": 0,
                "resources": [],
                "health_summary": {"healthy": 0, "unhealthy": 0, "unknown": 0}
            }
        
        grouped_resources[kind]["resources"].append(resource)
        grouped_resources[kind]["count"] += 1
        total_count += 1
        
        # Update health summaries
        health_status = resource.get('_health_status', 'unknown').lower()
        grouped_resources[kind]["health_summary"][health_status] = grouped_resources[kind]["health_summary"].get(health_status, 0) + 1
        health_summary[health_status] = health_summary.get(health_status, 0) + 1
    
    return jsonify({
        "total_count": total_count,
        "resources": grouped_resources,
        "health_summary": health_summary
    })

@bp.route('/')
def index():
    return render_template('index.html')

@bp.route('/dashboard')
def dashboard():
    return render_template('index.html')
