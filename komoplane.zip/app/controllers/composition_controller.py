# app/controllers/composition_controller.py
from flask import Blueprint, jsonify, request
from app.models.crossplane_manager import CrossplaneManager
from app.services.background_worker import operation_queue, operation_results, operation_lock
from functools import wraps
import asyncio
import time

bp = Blueprint('compositions', __name__, url_prefix='/api')
manager = CrossplaneManager()

def async_route(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop.run_until_complete(f(*args, **kwargs))
    return wrapper

async def ensure_manager_initialized():
    """Ensure the Kubernetes client is initialized"""
    if not await manager.verify_connection():
        await manager.initialize_client()

@bp.route('/compositions', methods=['GET'])
@async_route
async def list_compositions():
    try:
        await ensure_manager_initialized()
        compositions = await manager.list_compositions()
        return jsonify({
            'compositions': compositions,
            'count': len(compositions),
            'message': 'No compositions found' if not compositions else None
        })
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list compositions"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Compositions resource not found. Is Crossplane installed?"}), 404
        else:
            return jsonify({"error": f"Failed to list compositions: {error_msg}"}), 500

@bp.route('/compositions/<name>', methods=['GET'])
@async_route
async def get_composition(name):
    """Get a specific composition by name"""
    try:
        await ensure_manager_initialized()
        composition = await manager.get_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=name
        )
        if not composition:
            return jsonify({"error": f"Composition '{name}' not found"}), 404
        return jsonify(composition)
    except Exception as e:
        error_msg = str(e)
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get composition"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": f"Composition '{name}' not found"}), 404
        else:
            return jsonify({"error": f"Failed to get composition: {error_msg}"}), 500

@bp.route('/compositions', methods=['POST'])
@async_route
async def create_composition():
    """Create a new composition"""
    try:
        await ensure_manager_initialized()
        composition_data = request.json
        
        if not composition_data:
            return jsonify({"error": "No composition data provided"}), 400

        # Validate required fields
        if not isinstance(composition_data, dict):
            return jsonify({"error": "Invalid composition format: must be a JSON object"}), 400

        metadata = composition_data.get("metadata", {})
        if not isinstance(metadata, dict):
            return jsonify({"error": "Invalid metadata format: must be a JSON object"}), 400

        name = metadata.get("name")
        if not name:
            return jsonify({"error": "Composition name is required in metadata"}), 400

        if not isinstance(name, str):
            return jsonify({"error": "Composition name must be a string"}), 400

        api_version = composition_data.get("apiVersion")
        if not api_version:
            return jsonify({"error": "apiVersion is required"}), 400

        kind = composition_data.get("kind")
        if not kind:
            return jsonify({"error": "kind is required"}), 400
        if kind != "Composition":
            return jsonify({"error": "kind must be 'Composition'"}), 400

        spec = composition_data.get("spec")
        if not spec:
            return jsonify({"error": "spec is required"}), 400
        if not isinstance(spec, dict):
            return jsonify({"error": "Invalid spec format: must be a JSON object"}), 400

        try:
            result = await manager.create_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                body=composition_data
            )

            if result:
                return jsonify({
                    'message': 'Composition created successfully',
                    'composition': result
                }), 201
            return jsonify({"error": "Failed to create composition: No response from API"}), 500

        except Exception as e:
            error_msg = str(e)
            if "already exists" in error_msg.lower():
                return jsonify({"error": f"Composition '{name}' already exists"}), 409
            elif "forbidden" in error_msg.lower():
                return jsonify({"error": "Permission denied to create composition"}), 403
            elif "invalid" in error_msg.lower():
                return jsonify({"error": f"Invalid composition format: {error_msg}"}), 400
            else:
                return jsonify({"error": f"Failed to create composition: {error_msg}"}), 500

    except Exception as e:
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

@bp.route('/compositions/<name>', methods=['PUT'])
@async_route
async def update_composition(name):
    """Update an existing composition"""
    try:
        await ensure_manager_initialized()
        composition_data = request.json
        
        if not composition_data:
            return jsonify({"error": "No composition data provided"}), 400

        # Validate required fields
        if not isinstance(composition_data, dict):
            return jsonify({"error": "Invalid composition format: must be a JSON object"}), 400

        metadata = composition_data.get("metadata", {})
        if not isinstance(metadata, dict):
            return jsonify({"error": "Invalid metadata format: must be a JSON object"}), 400

        if metadata.get("name") != name:
            return jsonify({"error": "Composition name in URL must match name in metadata"}), 400

        try:
            result = await manager.update_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions",
                name=name,
                body=composition_data
            )

            if result:
                return jsonify({
                    'message': 'Composition updated successfully',
                    'composition': result
                })
            return jsonify({"error": "Failed to update composition: No response from API"}), 500

        except Exception as e:
            error_msg = str(e)
            if "not found" in error_msg.lower():
                return jsonify({"error": f"Composition '{name}' not found"}), 404
            elif "forbidden" in error_msg.lower():
                return jsonify({"error": "Permission denied to update composition"}), 403
            elif "invalid" in error_msg.lower():
                return jsonify({"error": f"Invalid composition format: {error_msg}"}), 400
            else:
                return jsonify({"error": f"Failed to update composition: {error_msg}"}), 500

    except Exception as e:
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

@bp.route('/compositions/<name>', methods=['DELETE'])
@async_route
async def delete_composition(name):
    """Delete a composition"""
    try:
        await ensure_manager_initialized()
        result = await manager.delete_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositions",
            name=name
        )
        if result:
            return jsonify({"message": f"Composition '{name}' deleted successfully"})
        return jsonify({"error": "Failed to delete composition: No response from API"}), 500
    except Exception as e:
        error_msg = str(e)
        if "not found" in error_msg.lower():
            return jsonify({"error": f"Composition '{name}' not found"}), 404
