# app/controllers/resource_controller.py
from flask import Blueprint, jsonify, request
from app.models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('resources', __name__, url_prefix='/api')
manager = CrossplaneManager()
logger = logging.getLogger(__name__)

async def ensure_manager_initialized():
    """Ensure the Kubernetes client is initialized"""
    if not await manager.verify_connection():
        await manager.initialize_client()

def process_resources(resources):
    """Process and group resources by kind with health status summary"""
    if not resources:
        return {}, 0, {'healthy': 0, 'unhealthy': 0, 'unknown': 0}

    resource_groups = {}
    total_count = 0
    health_summary = {'healthy': 0, 'unhealthy': 0, 'unknown': 0}
    kinds = set()

    # Step 1: Collect all available resource kinds
    for resource in resources:
        kind = resource.get('kind', 'Unknown')
        kinds.add(kind)

    # Step 2: Initialize groups for all kinds
    for kind in kinds:
        resource_groups[kind] = {
            'resources': [],
            'count': 0,
            'health_summary': {'healthy': 0, 'unhealthy': 0, 'unknown': 0}
        }

    # Step 3: Process each resource
    for resource in resources:
        kind = resource.get('kind', 'Unknown')
        health_status = resource.get('_health_status', 'Unknown')
        group = resource_groups[kind]
        
        # Add resource to its kind group
        group['resources'].append(resource)
        group['count'] += 1
        total_count += 1
        
        # Update health status counters
        status_key = health_status.lower()
        if status_key == 'healthy':
            group['health_summary']['healthy'] += 1
            health_summary['healthy'] += 1
        elif status_key == 'unhealthy':
            group['health_summary']['unhealthy'] += 1
            health_summary['unhealthy'] += 1
        else:
            group['health_summary']['unknown'] += 1
            health_summary['unknown'] += 1
    
    return resource_groups, total_count, health_summary

@bp.route('/managed-resources', methods=['GET'])
async def get_managed_resources():
    """Get all managed resources with filtering and grouping by kind"""
    try:
        await ensure_manager_initialized()
        logger.info("Fetching managed resources")
        resources = await manager.get_managed_resources()
        
        # Apply filters if they exist
        filters = {k: v for k, v in request.args.items() 
                  if k in ['provider', 'kind', 'status', 'search'] and v}
        
        if filters:
            logger.debug(f"Applying filters: {filters}")
            resources = filter_resources(resources, filters)
        
        # Process and group resources
        grouped_resources, total_count, health_summary = process_resources(resources)
        
        logger.info(f"Retrieved {total_count} managed resources")
        return jsonify({
            'resources': grouped_resources,
            'total_count': total_count,
            'health_summary': health_summary,
            'message': 'No managed resources found' if total_count == 0 else None
        })

    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting managed resources: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list managed resources"}), 403
        else:
            return jsonify({"error": f"Failed to get managed resources: {error_msg}"}), 500

@bp.route('/managed-resources/<name>', methods=['GET'])
async def get_managed_resource(name):
    """Get a specific managed resource by name"""
    try:
        await ensure_manager_initialized()
        logger.info(f"Fetching managed resource: {name}")
        
        namespace = request.args.get('namespace', 'default')
        group = request.args.get('group')
        version = request.args.get('version')
        plural = request.args.get('plural')
        
        if not all([group, version, plural]):
            return jsonify({"error": "group, version, and plural are required query parameters"}), 400
            
        resource = await manager.get_resource(
            group=group,
            version=version,
            plural=plural,
            name=name,
            namespace=namespace
        )
        
        if not resource:
            return jsonify({"error": f"Resource '{name}' not found"}), 404
            
        logger.info(f"Successfully retrieved resource: {name}")
        return jsonify(resource)
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting resource {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get resource"}), 403
        else:
            return jsonify({"error": f"Failed to get resource: {error_msg}"}), 500

@bp.route('/composite-resources', methods=['GET'])
async def get_composite_resources():
    """Get all composite resources"""
    try:
        await ensure_manager_initialized()
        logger.info("Fetching composite resources")
        resources = await manager.get_composite_resources()
        
        count = len(resources) if resources else 0
        logger.info(f"Retrieved {count} composite resources")
        
        return jsonify({
            'resources': resources,
            'count': count,
            'message': None if resources else 'No composite resources found'
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting composite resources: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list composite resources"}), 403
        else:
            return jsonify({"error": f"Failed to get composite resources: {error_msg}"}), 500

@bp.route('/status', methods=['GET'])
async def get_status():
    """Check Crossplane status"""
    try:
        await ensure_manager_initialized()
        logger.info("Checking Crossplane status")
        crds = await manager.get_crossplane_crds()
        
        status = 'ok' if crds else 'no_crossplane'
        logger.info(f"Crossplane status: {status}")
        
        return jsonify({
            'status': status,
            'crds': crds,
            'message': 'Crossplane CRDs found' if crds else 'No Crossplane CRDs found.'
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error checking Crossplane status: {error_msg}")
        return jsonify({
            'status': 'error',
            'error': error_msg,
            'message': 'Failed to check Crossplane status'
        }), 500

def filter_resources(resources, filters):
    """Filter resources based on provided criteria

    Args:
        resources (list): List of resource dictionaries to filter
        filters (dict): Dictionary of filter criteria where:
            - provider: Filter by provider name (exact match or contains)
            - kind: Filter by resource kind (exact match or contains)
            - status: Filter by health or sync status
            - search: General search across multiple fields (name, kind, provider, status)

    Returns:
        list: Filtered list of resources matching all provided criteria
    """
    filtered = resources

    for key, value in filters.items():
        if not value:  # Skip empty filters
            continue
            
        value = value.lower()
        if key == 'provider':
            # Match against both provider and display_provider fields
            filtered = [r for r in filtered if
                any(provider and (provider.lower() == value or value in provider.lower())
                    for provider in [r.get('provider', ''), r.get('display_provider', '')])
            ]
        elif key == 'kind':
            # Match resource kind (exact match or contains)
            filtered = [r for r in filtered if 
                       r.get('kind', '').lower() == value or 
                       value in r.get('kind', '').lower()]
        elif key == 'status':
            # Match either health status or sync status
            filtered = [r for r in filtered if
                r.get('_health_status', '').lower() == value or 
                r.get('_synced_status', '').lower() == value]
        elif key == 'search':  # General search across multiple fields
            filtered = [r for r in filtered if
                any(search_field and value in search_field.lower() for search_field in [
                    r.get('metadata', {}).get('name', ''),
                    r.get('kind', ''),
                    r.get('provider', ''),
                    r.get('display_provider', ''),
                    r.get('_health_status', ''),
                    r.get('_synced_status', '')
                ])
            ]
    
    return filtered
