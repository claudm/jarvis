from flask import Blueprint, jsonify
from app.models.crossplane_manager import CrossplaneManager
import logging

bp = Blueprint('providerconfigs', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)

@bp.route('/providerconfigs', methods=['GET'])
async def list_provider_configs():
    """List all provider configurations"""
    try:
        logger.info("Attempting to list Provider Configurations from Kubernetes API")
        manager = await CrossplaneManager.get_instance()
        configs = await manager.list_provider_configs()
        
        logger.info(f"Retrieved {len(configs)} Provider Configurations")
        return jsonify({
            "items": configs,
            "count": len(configs),
            "message": "No Provider Configurations found" if not configs else None
        })
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error listing Provider Configurations: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to list Provider Configurations"}), 403
        elif "not found" in error_msg.lower():
            return jsonify({"error": "Provider Configurations resource not found"}), 404
        else:
            return jsonify({"error": f"Failed to list Provider Configurations: {error_msg}"}), 500

@bp.route('/providerconfigs/<name>', methods=['GET'])
async def get_provider_config(name):
    """Get a specific provider configuration"""
    try:
        logger.info(f"Attempting to get Provider Configuration: {name}")
        manager = await CrossplaneManager.get_instance()
        config = await manager.get_provider_config(name)
        if not config:
            logger.warning(f"Provider Configuration not found: {name}")
            return jsonify({"error": f"Provider Configuration '{name}' not found"}), 404
        return jsonify(config)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error getting Provider Configuration {name}: {error_msg}")
        if "forbidden" in error_msg.lower():
            return jsonify({"error": "Permission denied to get Provider Configuration"}), 403
        else:
            return jsonify({"error": f"Failed to get Provider Configuration: {error_msg}"}), 500
