from flask import Flask
from controllers.page_controller import page_bp
from controllers.provider_controller import bp as provider_bp
from controllers.composition_controller import bp as composition_bp
from controllers.composite_resource_definition_controller import bp as composite_resource_definition_bp
from controllers.claim_controller import bp as claim_bp
from controllers.resource_controller import bp as resource_bp
from controllers.provider_config_controller import bp as provider_config_bp

app = Flask(__name__, 
    template_folder='views/templates',
    static_folder='views/static'
)

# Register blueprints
app.register_blueprint(page_bp)
app.register_blueprint(provider_bp)
app.register_blueprint(composition_bp)
app.register_blueprint(composite_resource_definition_bp)
app.register_blueprint(claim_bp)
app.register_blueprint(resource_bp)
app.register_blueprint(provider_config_bp)

if __name__ == '__main__':
    app.run(debug=True)
