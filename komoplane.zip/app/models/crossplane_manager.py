from kubernetes_asyncio import client, config, watch
from typing import List, Dict, Optional
import logging
import os
import asyncio
import urllib3

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CrossplaneManager:
    def __init__(self):
        self.api_client = None
        self.custom_api = None
        self.api_ext = None

    async def initialize_client(self):
        """Inicializa o cliente Kubernetes com verificação de ambiente"""
        try:
            # Get environment variables
            k8s_host = os.getenv('KUBERNETES_HOST')
            k8s_token = os.getenv('KUBERNETES_TOKEN')
            cert_config_base64 = os.getenv('CERT_CONFIG_BASE64')
            
            # Get proxy settings if provided
            http_proxy = os.getenv('HTTP_PROXY')
            https_proxy = os.getenv('HTTPS_PROXY')
            proxy_user = os.getenv('PROXY_USER')
            proxy_pass = os.getenv('PROXY_PASS')

            if not k8s_host:
                # Use old configuration method if host is not provided
                if os.path.exists(os.path.expanduser('~/.kube/config')):
                    await config.load_kube_config()
                else:
                    await config.load_incluster_config()
                self.api_client = client.ApiClient()
            else:
                # Configure API client
                configuration = client.Configuration()
                configuration.host = k8s_host
                configuration.verify_ssl = False
                configuration.timeout = 30  # Set default timeout to 30 seconds

                # Set proxy if provided
                if http_proxy:
                    configuration.proxy = http_proxy
                if https_proxy:
                    configuration.proxy = https_proxy

                # Set proxy authentication if provided
                if proxy_user and proxy_pass:
                    configuration.proxy_headers = urllib3.make_headers(
                        proxy_basic_auth=f"{proxy_user}:{proxy_pass}"
                    )

                # Configure authentication
                if k8s_token:
                    configuration.api_key = {"Authorization": f"Bearer {k8s_token}"}
                elif cert_config_base64:
                    # Use certificate-based authentication if provided
                    configuration.cert_file = cert_config_base64

                self.api_client = client.ApiClient(configuration)
            self.custom_api = client.CustomObjectsApi(self.api_client)
            self.api_ext = client.ApiextensionsV1Api(self.api_client)

            # Test connection
            await self.api_ext.get_api_resources()
            logger.info("Successfully connected to Kubernetes cluster")

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}")
            # Não vamos levantar a exceção, apenas logar o erro
            # Isso permite que a aplicação continue funcionando mesmo sem conexão

    async def verify_connection(self) -> bool:
        """Verifica se a conexão com o cluster está funcionando"""
        if not all([self.api_client, self.custom_api, self.api_ext]):
            await self.initialize_client()
            
        try:
            await self.api_ext.get_api_resources()
            return True
        except:
            return False

    async def get_crossplane_crds(self) -> List[dict]:
        """Retorna todos os CRDs relacionados ao Crossplane"""
        if not await self.verify_connection():
            logger.error("No connection to Kubernetes cluster")
            return []

        try:
            # Lista todos os CRDs
            crd_list = await self.api_ext.list_custom_resource_definition()
            
            if not crd_list or not hasattr(crd_list, 'items'):
                logger.warning("No CRDs found in the cluster")
                return []

            # Filtra CRDs do Crossplane
            crossplane_crds = []
            for crd in crd_list.items:
                if not hasattr(crd, 'spec') or not hasattr(crd.spec, 'group'):
                    continue

                # Verifica se é um CRD do Crossplane
                categories = getattr(crd.spec.names, 'categories', []) or []
                is_crossplane = (
                    'crossplane.io' in crd.spec.group or
                    any(cat in ['crossplane', 'managed', 'claim', 'composite']
                        for cat in categories)
                )

                if is_crossplane:
                    crossplane_crds.append({
                        'name': crd.metadata.name,
                        'kind': crd.spec.names.kind,
                        'group': crd.spec.group,
                        'version': crd.spec.versions[0].name if crd.spec.versions else '',
                        'scope': crd.spec.scope,
                        'categories': list(getattr(crd.spec.names, 'categories', []) or [])
                    })

            return crossplane_crds

        except Exception as e:
            logger.error(f"Error getting Crossplane CRDs: {e}")
            return []

    async def list_compositions(self) -> List[dict]:
        """Lista todas as compositions do Crossplane"""
        if not await self.verify_connection():
            return []

        try:
            response = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositions"
            )
            return response.get("items", [])
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Compositions CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing compositions: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing compositions: {e}")
            return []

    async def get_claim_events(self, name: str, namespace: str = "default") -> List[dict]:
        """Get events for a specific claim"""
        if not await self.verify_connection():
            return []

        try:
            core_v1 = client.CoreV1Api(self.api_client)
            field_selector = f'involvedObject.name={name}'
            events = await core_v1.list_namespaced_event(namespace=namespace, field_selector=field_selector)
            return [
                {
                    'type': event.type,
                    'reason': event.reason,
                    'message': event.message,
                    'timestamp': event.last_timestamp.isoformat() if event.last_timestamp else None,
                    'count': event.count
                }
                for event in events.items
            ]
        except Exception as e:
            logger.error(f"Error getting claim events: {e}")
            return []

    async def list_claims(self, namespace: str = "default") -> List[dict]:
        """Lista todas as claims em um namespace específico com dados relacionados"""
        if not await self.verify_connection():
            return []

        try:
            claims = []
            crds = await self.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'claim' in categories:
                    try:
                        response = await self.custom_api.list_namespaced_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            namespace=namespace,
                            plural=crd['name'].split('.')[0].lower()
                        )
                        for item in response.get("items", []):
                            # Add resource type info
                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }

                            # Get composition reference
                            composition_ref = item.get('spec', {}).get('compositionRef', {})
                            if composition_ref and composition_ref.get('name'):
                                try:
                                    composition = await self.custom_api.get_cluster_custom_object(
                                        group="apiextensions.crossplane.io",
                                        version="v1",
                                        plural="compositions",
                                        name=composition_ref['name']
                                    )
                                    item['composition'] = {
                                        'name': composition['metadata']['name'],
                                        'ready': True  # Compositions are always ready if they exist
                                    }
                                except:
                                    item['composition'] = {
                                        'name': composition_ref['name'],
                                        'ready': False
                                    }

                            # Get composite resource reference
                            composite_ref = item.get('spec', {}).get('resourceRef', {})
                            if composite_ref and composite_ref.get('name'):
                                try:
                                    composite = await self.custom_api.get_cluster_custom_object(
                                        group=composite_ref.get('apiVersion', '').split('/')[0],
                                        version=composite_ref.get('apiVersion', '').split('/')[1],
                                        plural=composite_ref['kind'].lower() + 's',
                                        name=composite_ref['name']
                                    )
                                    conditions = composite.get('status', {}).get('conditions', [])
                                    ready_condition = next((c for c in conditions if c['type'] == 'Ready'), {})
                                    item['compositeResource'] = {
                                        'name': composite['metadata']['name'],
                                        'ready': ready_condition.get('status') == 'True'
                                    }
                                except:
                                    item['compositeResource'] = {
                                        'name': composite_ref['name'],
                                        'ready': False
                                    }

                            # Get events for both claim and composite resource
                            claim_events = await self.get_claim_events(item['metadata']['name'], namespace)
                            composite_events = []
                            if item.get('compositeResource', {}).get('name'):
                                composite_events = await self.get_claim_events(
                                    item['compositeResource']['name'],
                                    namespace
                                )
                            
                            # Combine and sort events
                            all_events = [*claim_events, *composite_events]
                            all_events.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
                            
                            # Keep only the 10 most recent events
                            item['events'] = all_events[:10]
                            claims.append(item)
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing claims for {crd['kind']}: {e}")
                    
            return claims
        except Exception as e:
            logger.error(f"Error listing claims: {e}")
            return []

    async def get_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> Optional[dict]:
        """Retorna um recurso específico do Kubernetes"""
        if not await self.verify_connection():
            return None
            
        try:
            if namespace:
                return await self.custom_api.get_namespaced_custom_object(
                    group=group,
                    version=version,
                    namespace=namespace,
                    plural=plural,
                    name=name
                )
            else:
                return await self.custom_api.get_cluster_custom_object(
                    group=group,
                    version=version,
                    plural=plural,
                    name=name
                )
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Resource {name} not found")
            else:
                logger.error(f"Error getting resource: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting resource: {e}")
            return None

    async def get_xrd(self, name: str) -> Optional[dict]:
        """Retorna um XRD específico por nome"""
        return await self.get_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositeresourcedefinitions",
            name=name
        )

    async def get_managed_resources(self) -> List[dict]:
        """Lista todos os recursos gerenciados com status de saúde e descrição"""
        if not await self.verify_connection():
            return []

        try:
            resources = []
            crds = await self.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'managed' in categories:
                    try:
                        response = await self.custom_api.list_cluster_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            plural=crd['name'].split('.')[0].lower()
                        )
                        for item in response.get("items", []):
                            # Get conditions
                            conditions = item.get('status', {}).get('conditions', [])
                            health_status = 'Unknown'
                            synced_status = 'Unknown'
                            
                            for condition in conditions:
                                condition_type = condition.get('type')
                                if condition_type == 'Ready':
                                    health_status = 'Healthy' if condition.get('status') == 'True' else 'Unhealthy'
                                elif condition_type == 'Synced':
                                    synced_status = 'Synced' if condition.get('status') == 'True' else 'Not Synced'

                            # Extract provider from group dynamically
                            group = crd['group']
                            provider = None
                            display_provider = None  # For UI display
                            
                            # Handle different provider group patterns
                            if group.startswith('provider-'):
                                provider = group.split('.')[0]  # Just take provider-aws part
                                display_provider = provider.replace('provider-', '')
                            elif group.endswith('.crossplane.io'):
                                base = group.replace('.crossplane.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"  # provider-aws for filtering
                                    display_provider = base  # s3.aws for display
                                else:
                                    provider = f"provider-{base}"  # provider-aws for filtering
                                    display_provider = base  # aws for display
                            elif '.' in group:
                                parts = group.split('.')
                                if len(parts) >= 2:
                                    provider = f"provider-{parts[1]}"  # provider-aws for filtering
                                    display_provider = f"{parts[0]}.{parts[1]}"  # s3.aws for display

                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }
                            item['_health_status'] = health_status
                            item['_synced_status'] = synced_status
                            item['provider'] = provider  # For filtering (e.g. provider-aws)
                            item['display_provider'] = display_provider or provider  # For UI display (e.g. s3.aws)
                            resources.append(item)
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing managed resources for {crd['kind']}: {e}")
                    
            return resources
        except Exception as e:
            logger.error(f"Error listing managed resources: {e}")
            return []

    async def get_composite_resources(self) -> List[dict]:
        """Lista todos os recursos compostos com status de saúde e descrição"""
        if not await self.verify_connection():
            logger.error("No connection to Kubernetes cluster")
            return []

        try:
            resources = []
            crds = await self.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'composite' in categories:
                    try:
                        response = await self.custom_api.list_cluster_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            plural=crd['name'].split('.')[0].lower()
                        )
                        
                        for item in response.get("items", []):
                            # Get conditions
                            conditions = item.get('status', {}).get('conditions', [])
                            health_status = 'Unknown'
                            synced_status = 'Unknown'
                            
                            for condition in conditions:
                                condition_type = condition.get('type')
                                if condition_type == 'Ready':
                                    health_status = 'Healthy' if condition.get('status') == 'True' else 'Unhealthy'
                                elif condition_type == 'Synced':
                                    synced_status = 'Synced' if condition.get('status') == 'True' else 'Not Synced'
                            
                            # Extract provider from group dynamically
                            group = crd['group']
                            provider = None
                            display_provider = None  # For UI display
                            
                            # Handle different provider group patterns
                            if group.startswith('provider-'):
                                provider = group.split('.')[0]  # Just take provider-aws part
                                display_provider = provider.replace('provider-', '')
                            elif group.endswith('.crossplane.io'):
                                base = group.replace('.crossplane.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"  # provider-aws for filtering
                                    display_provider = base  # s3.aws for display
                                else:
                                    provider = f"provider-{base}"  # provider-aws for filtering
                                    display_provider = base  # aws for display
                            elif '.' in group:
                                parts = group.split('.')
                                if len(parts) >= 2:
                                    provider = f"provider-{parts[1]}"  # provider-aws for filtering
                                    display_provider = f"{parts[0]}.{parts[1]}"  # s3.aws for display

                            # Add resource metadata
                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }
                            item['_health_status'] = health_status
                            item['_synced_status'] = synced_status
                            item['provider'] = provider  # For filtering (e.g. provider-aws)
                            item['display_provider'] = display_provider or provider  # For UI display (e.g. s3.aws)

                            # Get composition reference
                            composition_ref = item.get('spec', {}).get('compositionRef', {})
                            if composition_ref and composition_ref.get('name'):
                                try:
                                    composition = await self.custom_api.get_cluster_custom_object(
                                        group="apiextensions.crossplane.io",
                                        version="v1",
                                        plural="compositions",
                                        name=composition_ref['name']
                                    )
                                    item['composition'] = {
                                        'name': composition['metadata']['name'],
                                        'ready': True
                                    }
                                except:
                                    item['composition'] = {
                                        'name': composition_ref['name'],
                                        'ready': False
                                    }

                            # Get managed resources
                            try:
                                managed_resources = await self.get_managed_resources()
                                related_resources = []
                                for resource in managed_resources:
                                    owner_refs = resource.get('metadata', {}).get('ownerReferences', [])
                                    if any(ref.get('name') == item['metadata']['name'] for ref in owner_refs):
                                        conditions = resource.get('status', {}).get('conditions', [])
                                        synced_condition = next((c for c in conditions if c['type'] == 'Synced'), {})
                                        related_resources.append({
                                            'name': resource['metadata']['name'],
                                            'kind': resource.get('kind', ''),
                                            'synced': synced_condition.get('status') == 'True',
                                            'apiVersion': resource.get('apiVersion', ''),
                                            'spec': resource.get('spec', {}),
                                            'status': resource.get('status', {})
                                        })
                                item['managedResources'] = related_resources
                            except:
                                item['managedResources'] = []

                            # Get related claims
                            try:
                                claims = await self.list_claims()
                                related_claims = [
                                    {
                                        'name': claim['metadata']['name'],
                                        'ready': claim.get('compositeResource', {}).get('ready', False),
                                        'apiVersion': claim.get('apiVersion', ''),
                                        'kind': claim.get('kind', ''),
                                        'spec': claim.get('spec', {}),
                                        'status': claim.get('status', {})
                                    }
                                    for claim in claims
                                    if claim.get('spec', {}).get('resourceRef', {}).get('name') == item['metadata']['name']
                                ]
                                item['claims'] = related_claims
                            except:
                                item['claims'] = []

                            # Include full resource details
                            resources.append({
                                **item,  # Include all existing fields
                                'spec': item.get('spec', {}),
                                'status': item.get('status', {})
                            })
                            
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing composite resources for {crd['kind']}: {e}")
                    
            return resources
        except Exception as e:
            logger.error(f"Error listing composite resources: {e}")
            return []

    async def get_crossplane_status(self) -> Dict:
        """Get Crossplane health status, version, and pod status"""
        if not await self.verify_connection():
            return {
                "health": "Unknown",
                "version": "Unknown",
                "pods": []
            }

        try:
            # Get Crossplane deployment
            apps_v1 = client.AppsV1Api(self.api_client)
            core_v1 = client.CoreV1Api(self.api_client)

            deployment = await apps_v1.read_namespaced_deployment(
                name="crossplane",
                namespace="crossplane-system"
            )

            # Check health based on deployment status
            health = "Healthy"
            if deployment.status.available_replicas != deployment.status.replicas:
                health = "Unhealthy"

            # Get version from image tag
            version = "Unknown"
            if deployment.spec.template.spec.containers:
                image = deployment.spec.template.spec.containers[0].image
                if ':' in image:
                    version = image.split(':')[1]

            # Get pods in crossplane-system namespace
            pod_list = await core_v1.list_namespaced_pod(namespace="crossplane-system")
            pods = []
            
            for pod in pod_list.items:
                # Get container statuses
                container_statuses = []
                for container in (pod.status.container_statuses or []):
                    status = "Unknown"
                    if container.ready:
                        status = "Running"
                    elif container.state.waiting:
                        status = container.state.waiting.reason
                    elif container.state.terminated:
                        status = container.state.terminated.reason

                    container_statuses.append({
                        "name": container.name,
                        "status": status,
                        "ready": container.ready,
                        "restarts": container.restart_count
                    })

                pods.append({
                    "name": pod.metadata.name,
                    "status": pod.status.phase,
                    "containers": container_statuses,
                    "age": pod.metadata.creation_timestamp.isoformat() if pod.metadata.creation_timestamp else None
                })

            return {
                "health": health,
                "version": version,
                "pods": pods
            }
        except Exception as e:
            logger.error(f"Error getting Crossplane status: {e}")
            return {
                "health": "Unknown",
                "version": "Unknown",
                "pods": []
            }

    async def list_providers(self) -> List[dict]:
        """Lista todos os providers instalados no Crossplane"""
        if not await self.verify_connection():
            logger.error("Failed to list providers: No connection to Kubernetes cluster")
            return []

        try:
            logger.info("Attempting to list providers from Kubernetes API")
            response = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            providers = response.get("items", [])
            logger.info(f"Retrieved {len(providers)} providers from Kubernetes API")
            logger.debug(f"Provider response: {response}")
            return providers
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Providers CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing providers: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing providers: {e}")
            return []

    async def get_provider_status(self, provider_name: str) -> Optional[dict]:
        """Retorna o status de um provider específico"""
        if not await self.verify_connection():
            return None

        try:
            provider = await self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            return provider.get("status", {})
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Provider {provider_name} not found")
            else:
                logger.error(f"Error getting provider status: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider status: {e}")
            return None

    async def list_provider_configs(self) -> List[dict]:
        """Lista todas as configurações de providers"""
        if not await self.verify_connection():
            return []

        try:
            response = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providerconfigs"
            )
            return response.get("items", [])
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("ProviderConfigs CRD not found")
            else:
                logger.error(f"Error listing provider configs: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing provider configs: {e}")
            return []

    async def create_provider_config(self, name: str, provider_name: str, credentials: dict) -> Optional[dict]:
        """Cria uma nova configuração de provider"""
        if not await self.verify_connection():
            return None

        try:
            body = {
                "apiVersion": "pkg.crossplane.io/v1",
                "kind": "ProviderConfig",
                "metadata": {
                    "name": name
                },
                "spec": {
                    "provider": provider_name,
                    "credentials": credentials
                }
            }
            
            return await self.create_resource(
                group="pkg.crossplane.io",
                version="v1",
                plural="providerconfigs",
                body=body
            )
        except Exception as e:
            logger.error(f"Error creating provider config: {e}")
            return None

    async def delete_provider_config(self, name: str) -> bool:
        """Deleta uma configuração de provider"""
        return await self.delete_resource(
            group="pkg.crossplane.io",
            version="v1",
            plural="providerconfigs",
            name=name
        )

    async def install_provider(self, name: str, package: str, revision: str = "latest") -> Optional[dict]:
        """Instala um novo provider no cluster"""
        if not await self.verify_connection():
            return None

        try:
            body = {
                "apiVersion": "pkg.crossplane.io/v1",
                "kind": "Provider",
                "metadata": {
                    "name": name
                },
                "spec": {
                    "package": package,
                    "revisionActivationPolicy": "Automatic",
                    "revisionHistoryLimit": 1,
                    "skipDependencyResolution": False
                }
            }
            if revision != "latest":
                body["spec"]["revision"] = revision

            return await self.create_resource(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                body=body
            )
        except Exception as e:
            logger.error(f"Error installing provider: {e}")
            return None

    async def uninstall_provider(self, name: str) -> bool:
        """Remove um provider do cluster"""
        return await self.delete_resource(
            group="pkg.crossplane.io",
            version="v1",
            plural="providers",
            name=name
        )

    async def list_templates(self) -> List[dict]:
        """Lista todos os templates disponíveis"""
        if not await self.verify_connection():
            return []

        try:
            response = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions"
            )
            templates = response.get("items", [])

            # Add relations for each template
            for template in templates:
                # Get composition using this template
                try:
                    composition_name = template.get('metadata', {}).get('ownerReferences', [{}])[0].get('name')
                    if composition_name:
                        composition = await self.custom_api.get_cluster_custom_object(
                            group="apiextensions.crossplane.io",
                            version="v1",
                            plural="compositions",
                            name=composition_name
                        )
                        template['composition'] = {
                            'name': composition['metadata']['name'],
                            'ready': True
                        }
                except:
                    template['composition'] = None

                # Get composite resources using this template's composition
                try:
                    if template.get('composition', {}).get('name'):
                        composite_resources = await self.get_composite_resources()
                        related_resources = [
                            {
                                'name': resource['metadata']['name'],
                                'ready': resource.get('_health_status') == 'Healthy'
                            }
                            for resource in composite_resources
                            if resource.get('spec', {}).get('compositionRef', {}).get('name') == template['composition']['name']
                        ]
                        template['compositeResources'] = related_resources
                except:
                    template['compositeResources'] = []

                # Get claims using this template's composition
                try:
                    if template.get('composition', {}).get('name'):
                        claims = await self.list_claims()
                        related_claims = [
                            {
                                'name': claim['metadata']['name'],
                                'ready': claim.get('compositeResource', {}).get('ready', False)
                            }
                            for claim in claims
                            if claim.get('spec', {}).get('compositionRef', {}).get('name') == template['composition']['name']
                        ]
                        template['claims'] = related_claims
                except:
                    template['claims'] = []

            return templates
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Templates CRD not found")
            else:
                logger.error(f"Error listing templates: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing templates: {e}")
            return []

    async def get_template_details(self, name: str) -> Optional[dict]:
        """Retorna detalhes de um template específico"""
        if not await self.verify_connection():
            return None

        try:
            template = await self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions",
                name=name
            )
            return template
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Template {name} not found")
            else:
                logger.error(f"Error getting template details: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting template details: {e}")
            return None

    async def create_template(self, name: str, xrd_ref: dict, resources: List[dict], patches: List[dict] = None) -> Optional[dict]:
        """Cria um novo template de composição"""
        if not await self.verify_connection():
            return None

        try:
            body = {
                "apiVersion": "apiextensions.crossplane.io/v1",
                "kind": "CompositionRevision",
                "metadata": {
                    "name": name
                },
                "spec": {
                    "compositeTypeRef": xrd_ref,
                    "resources": resources
                }
            }
            
            if patches:
                body["spec"]["patches"] = patches

            return await self.create_resource(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions",
                body=body
            )
        except Exception as e:
            logger.error(f"Error creating template: {e}")
            return None

    async def delete_template(self, name: str) -> bool:
        """Remove um template"""
        return await self.delete_resource(
            group="apiextensions.crossplane.io",
            version="v1",
            plural="compositionrevisions",
            name=name
        )

    async def create_resource(self, group: str, version: str, plural: str, body: dict, namespace: str = None) -> Optional[dict]:
        """Helper method to create a Kubernetes resource"""
        if namespace:
            return await self.custom_api.create_namespaced_custom_object(
                group=group,
                version=version,
                namespace=namespace,
                plural=plural,
                body=body
            )
        else:
            return await self.custom_api.create_cluster_custom_object(
                group=group,
                version=version,
                plural=plural,
                body=body
            )

    async def update_resource(self, group: str, version: str, plural: str, name: str, body: dict, namespace: str = None) -> Optional[dict]:
        """Helper method to update a Kubernetes resource"""
        if namespace:
            return await self.custom_api.replace_namespaced_custom_object(
                group=group,
                version=version,
                namespace=namespace,
                plural=plural,
                name=name,
                body=body
            )
        else:
            return await self.custom_api.replace_cluster_custom_object(
                group=group,
                version=version,
                plural=plural,
                name=name,
                body=body
            )

    async def delete_resource(self, group: str, version: str, plural: str, name: str, namespace: str = None) -> bool:
        """Helper method to delete a Kubernetes resource"""
        try:
            if namespace:
                await self.custom_api.delete_namespaced_custom_object(
                    group=group,
                    version=version,
                    namespace=namespace,
                    plural=plural,
                    name=name
                )
            else:
                await self.custom_api.delete_cluster_custom_object(
                    group=group,
                    version=version,
                    plural=plural,
                    name=name
                )
            return True
        except Exception as e:
            logger.error(f"Error deleting resource: {e}")
            return False

    async def __aenter__(self):
        """Async context manager entry"""
        await self.initialize_client()
        return self
