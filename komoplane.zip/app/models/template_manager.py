from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class TemplateManager(BaseManager):
    async def list_templates(self) -> List[dict]:
        """Lista todos os templates disponíveis"""
        try:
            if not await self._ensure_connection():
                return []

            response = await self.custom_api.list_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions"
            )
            templates = response.get("items", [])

            # Add relations for each template
            for template in templates:
                # Get composition using this template
                try:
                    composition_name = template.get('metadata', {}).get('ownerReferences', [{}])[0].get('name')
                    if composition_name:
                        composition = await self.custom_api.get_cluster_custom_object(
                            group="apiextensions.crossplane.io",
                            version="v1",
                            plural="compositions",
                            name=composition_name
                        )
                        template['composition'] = {
                            'name': composition['metadata']['name'],
                            'ready': True
                        }
                except:
                    template['composition'] = None

                # Get composite resources using this template's composition
                try:
                    if template.get('composition', {}).get('name'):
                        composite_resources = await self.get_composite_resources()
                        related_resources = [
                            {
                                'name': resource['metadata']['name'],
                                'ready': resource.get('_health_status') == 'Healthy'
                            }
                            for resource in composite_resources
                            if resource.get('spec', {}).get('compositionRef', {}).get('name') == template['composition']['name']
                        ]
                        template['compositeResources'] = related_resources
                except:
                    template['compositeResources'] = []

                # Get claims using this template's composition
                try:
                    if template.get('composition', {}).get('name'):
                        claims = await self.list_claims()
                        related_claims = [
                            {
                                'name': claim['metadata']['name'],
                                'ready': claim.get('compositeResource', {}).get('ready', False)
                            }
                            for claim in claims
                            if claim.get('spec', {}).get('compositionRef', {}).get('name') == template['composition']['name']
                        ]
                        template['claims'] = related_claims
                except:
                    template['claims'] = []

            return templates
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Templates CRD not found")
            else:
                logger.error(f"Error listing templates: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing templates: {e}")
            return []

    async def get_template_details(self, name: str) -> Optional[dict]:
        """Retorna detalhes de um template específico"""
        try:
            if not await self._ensure_connection():
                return None

            template = await self.custom_api.get_cluster_custom_object(
                group="apiextensions.crossplane.io",
                version="v1",
                plural="compositionrevisions",
                name=name
            )
            return template
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Template {name} not found")
            else:
                logger.error(f"Error getting template details: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting template details: {e}")
            return None
