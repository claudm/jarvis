from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager
from .resource_manager import ResourceManager
from .claim_manager import ClaimManager

logger = logging.getLogger(__name__)

class CompositeManager(BaseManager):
    def __init__(self):
        super().__init__()
        self.resource_manager = ResourceManager()
        self.claim_manager = ClaimManager()

    async def get_composite_resources(self) -> List[dict]:
        """Lista todos os recursos compostos com status de saúde e descrição"""
        try:
            if not await self._ensure_connection():
                logger.error("No connection to Kubernetes cluster")
                return []

            resources = []
            crds = await self.get_crossplane_crds()
            
            for crd in (crds or []):
                categories = crd.get('categories', []) or []
                if 'composite' in categories:
                    try:
                        response = await self.custom_api.list_cluster_custom_object(
                            group=crd['group'],
                            version=crd['version'],
                            plural=crd['name'].split('.')[0].lower()
                        )
                        
                        for item in response.get("items", []):
                            # Get conditions
                            conditions = item.get('status', {}).get('conditions', [])
                            health_status = 'Unknown'
                            synced_status = 'Unknown'
                            
                            for condition in conditions:
                                condition_type = condition.get('type')
                                if condition_type == 'Ready':
                                    health_status = 'Healthy' if condition.get('status') == 'True' else 'Unhealthy'
                                elif condition_type == 'Synced':
                                    synced_status = 'Synced' if condition.get('status') == 'True' else 'Not Synced'
                            
                            # Extract provider from group dynamically
                            group = crd['group']
                            provider = None
                            display_provider = None  # For UI display
                            
                            # Handle different provider group patterns
                            if group.startswith('provider-'):
                                provider = group.split('.')[0]  # Just take provider-aws part
                                display_provider = provider.replace('provider-', '')
                            elif group.endswith('.crossplane.io'):
                                base = group.replace('.crossplane.io', '')
                                if '.' in base:
                                    provider = f"provider-{base.split('.')[1]}"  # provider-aws for filtering
                                    display_provider = base  # s3.aws for display
                                else:
                                    provider = f"provider-{base}"  # provider-aws for filtering
                                    display_provider = base  # aws for display
                            elif '.' in group:
                                parts = group.split('.')
                                if len(parts) >= 2:
                                    provider = f"provider-{parts[1]}"  # provider-aws for filtering
                                    display_provider = f"{parts[0]}.{parts[1]}"  # s3.aws for display

                            # Add resource metadata
                            item['_resource_type'] = {
                                'kind': crd['kind'],
                                'group': crd['group'],
                                'version': crd['version']
                            }
                            item['_health_status'] = health_status
                            item['_synced_status'] = synced_status
                            item['provider'] = provider  # For filtering (e.g. provider-aws)
                            item['display_provider'] = display_provider or provider  # For UI display (e.g. s3.aws)

                            # Get composition reference
                            composition_ref = item.get('spec', {}).get('compositionRef', {})
                            if composition_ref and composition_ref.get('name'):
                                try:
                                    composition = await self.custom_api.get_cluster_custom_object(
                                        group="apiextensions.crossplane.io",
                                        version="v1",
                                        plural="compositions",
                                        name=composition_ref['name']
                                    )
                                    item['composition'] = {
                                        'name': composition['metadata']['name'],
                                        'ready': True
                                    }
                                except:
                                    item['composition'] = {
                                        'name': composition_ref['name'],
                                        'ready': False
                                    }

                            # Get managed resources
                            try:
                                if not await self.resource_manager.verify_connection():
                                    await self.resource_manager.initialize_client()
                                managed_resources = await self.resource_manager.get_managed_resources()
                                related_resources = []
                                for resource in managed_resources:
                                    owner_refs = resource.get('metadata', {}).get('ownerReferences', [])
                                    if any(ref.get('name') == item['metadata']['name'] for ref in owner_refs):
                                        conditions = resource.get('status', {}).get('conditions', [])
                                        synced_condition = next((c for c in conditions if c['type'] == 'Synced'), {})
                                        related_resources.append({
                                            'name': resource['metadata']['name'],
                                            'kind': resource.get('kind', ''),
                                            'synced': synced_condition.get('status') == 'True',
                                            'apiVersion': resource.get('apiVersion', ''),
                                            'spec': resource.get('spec', {}),
                                            'status': resource.get('status', {})
                                        })
                                item['managedResources'] = related_resources
                            except:
                                item['managedResources'] = []

                            # Get related claims
                            try:
                                if not await self.claim_manager.verify_connection():
                                    await self.claim_manager.initialize_client()
                                claims = await self.claim_manager.list_claims()
                                related_claims = [
                                    {
                                        'name': claim['metadata']['name'],
                                        'ready': claim.get('compositeResource', {}).get('ready', False),
                                        'apiVersion': claim.get('apiVersion', ''),
                                        'kind': claim.get('kind', ''),
                                        'spec': claim.get('spec', {}),
                                        'status': claim.get('status', {})
                                    }
                                    for claim in claims
                                    if claim.get('spec', {}).get('resourceRef', {}).get('name') == item['metadata']['name']
                                ]
                                item['claims'] = related_claims
                            except:
                                item['claims'] = []

                            # Include full resource details
                            resources.append({
                                **item,  # Include all existing fields
                                'spec': item.get('spec', {}),
                                'status': item.get('status', {})
                            })
                            
                    except client.ApiException as e:
                        if e.status != 404:
                            logger.warning(f"Error listing composite resources for {crd['kind']}: {e}")
                    
            return resources
        except Exception as e:
            logger.error(f"Error listing composite resources: {e}")
            return []
