from typing import List, Dict, Optional
import logging
from kubernetes_asyncio import client
from .base_manager import BaseManager

logger = logging.getLogger(__name__)

class ProviderManager(BaseManager):
    async def list_providers(self) -> List[dict]:
        """Lista todos os providers instalados no Crossplane"""
        try:
            if not await self._ensure_connection():
                logger.error("Failed to list providers: No connection to Kubernetes cluster")
                return []

            logger.info("Attempting to list providers from Kubernetes API")
            response = await self.custom_api.list_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers"
            )
            providers = response.get("items", [])
            logger.info(f"Retrieved {len(providers)} providers from Kubernetes API")
            logger.debug(f"Provider response: {response}")
            return providers
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("Providers CRD not found. Is Crossplane installed?")
            else:
                logger.error(f"Error listing providers: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing providers: {e}")
            return []

    async def get_provider_status(self, provider_name: str) -> Optional[dict]:
        """Retorna o status de um provider específico"""
        try:
            if not await self._ensure_connection():
                return None

            provider = await self.custom_api.get_cluster_custom_object(
                group="pkg.crossplane.io",
                version="v1",
                plural="providers",
                name=provider_name
            )
            return provider.get("status", {})
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"Provider {provider_name} not found")
            else:
                logger.error(f"Error getting provider status: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider status: {e}")
            return None

    async def list_provider_configs(self) -> List[dict]:
        """Lista todas as configurações de providers"""
        try:
            if not await self._ensure_connection():
                return []

            response = await self.custom_api.list_cluster_custom_object(
                group="aws.crossplane.io",
                version="v1beta1",
                plural="providerconfigs"
            )
            return response.get("items", [])
        except client.ApiException as e:
            if e.status == 404:
                logger.warning("ProviderConfigs CRD not found")
            else:
                logger.error(f"Error listing provider configs: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error listing provider configs: {e}")
            return []

    async def get_provider_config(self, name: str) -> Optional[dict]:
        """Retorna uma configuração de provider específica"""
        try:
            if not await self._ensure_connection():
                return None

            config = await self.custom_api.get_cluster_custom_object(
                group="aws.crossplane.io",
                version="v1beta1",
                plural="providerconfigs",
                name=name
            )
            return config
        except client.ApiException as e:
            if e.status == 404:
                logger.warning(f"ProviderConfig {name} not found")
            else:
                logger.error(f"Error getting provider config: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting provider config: {e}")
            return None
