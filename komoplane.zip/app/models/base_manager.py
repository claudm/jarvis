from kubernetes_asyncio import client, config
from typing import List, Dict, Optional
import logging
import os
import asyncio
import urllib3

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseManager:
    _instance = None
    _lock = asyncio.Lock()
    _initialized = False
    _connection_retries = 3
    _retry_delay = 1  # seconds

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self._initialized = True
            self._closed = False

    @classmethod
    async def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    await cls._instance.initialize_client()
        elif cls._instance._closed:
            async with cls._lock:
                await cls._instance.initialize_client()
        return cls._instance

    async def __aenter__(self):
        """Async context manager entry"""
        if self._closed:
            await self.initialize_client()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()

    async def close(self):
        """Close all connections"""
        try:
            if self.api_client:
                try:
                    await self.api_client.close()
                except Exception as e:
                    logger.warning(f"Error closing Kubernetes API client: {e}")
                finally:
                    self.api_client = None
                    self.custom_api = None
                    self.api_ext = None
                    self._closed = True
        except Exception as e:
            logger.error(f"Error during connection cleanup: {e}")
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self._closed = True

    async def cleanup(self):
        """Cleanup resources when application shuts down"""
        try:
            await self.close()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
        finally:
            BaseManager._instance = None
            self._initialized = False
            self._closed = True

    async def _ensure_connection(self):
        """Ensure connection is active, retry if needed"""
        for attempt in range(self._connection_retries):
            try:
                if not self._closed and await self.verify_connection():
                    return True
                await self.initialize_client()
                return True
            except Exception as e:
                if attempt == self._connection_retries - 1:
                    raise
                logger.warning(f"Connection attempt {attempt + 1} failed: {e}")
                await asyncio.sleep(self._retry_delay)
        return False

    async def initialize_client(self):
        """Initialize Kubernetes client"""
        try:
            await self.close()

            configuration = client.Configuration()
            
            # SSL settings
            configuration.verify_ssl = False
            configuration.ssl_ca_cert = None
            configuration.assert_hostname = False
            
            # Connection settings
            configuration.connection_pool_maxsize = 32
            configuration.retries = 3
            configuration.timeout = 30
            
            # Proxy settings
            http_proxy = os.getenv('HTTP_PROXY')
            https_proxy = os.getenv('HTTPS_PROXY')
            proxy_user = os.getenv('PROXY_USER')
            proxy_pass = os.getenv('PROXY_PASS')

            if http_proxy or https_proxy:
                if http_proxy:
                    configuration.proxy = http_proxy
                if https_proxy:
                    configuration.proxy = https_proxy
                if proxy_user and proxy_pass:
                    configuration.proxy_headers = urllib3.make_headers(
                        proxy_basic_auth=f"{proxy_user}:{proxy_pass}"
                    )

            try:
                if os.path.exists(os.path.expanduser('~/.kube/config')):
                    await config.load_kube_config(client_configuration=configuration)
                else:
                    await config.load_incluster_config(client_configuration=configuration)
            except Exception as e:
                logger.error(f"Error loading kube config: {e}")
                raise

            # Initialize with retry
            max_retries = 3
            retry_delay = 1
            last_error = None

            for attempt in range(max_retries):
                try:
                    self.api_client = client.ApiClient(configuration)
                    self.custom_api = client.CustomObjectsApi(self.api_client)
                    self.api_ext = client.ApiextensionsV1Api(self.api_client)
                    await self.api_ext.get_api_resources()
                    logger.info("Successfully connected to Kubernetes cluster")
                    self._closed = False
                    return
                except Exception as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        logger.warning(f"Connection attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
                        await self.close()
                        await asyncio.sleep(retry_delay)
                    else:
                        raise last_error

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}")
            raise

    async def verify_connection(self) -> bool:
        """Verify connection is active"""
        try:
            if not all([self.api_client, self.custom_api, self.api_ext]):
                return False
            await self.api_ext.get_api_resources()
            return True
        except:
            return False
