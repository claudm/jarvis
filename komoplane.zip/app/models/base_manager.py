from kubernetes_asyncio import client, config, watch
from typing import List, Dict, Optional, Any
import logging
import os
import asyncio
import urllib3
import ssl
import aiohttp
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseManager:
    _instance = None
    _lock = asyncio.Lock()
    _initialized = False
    _connection_retries = 3
    _retry_delay = 1  # seconds

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.api_client = None
            self.custom_api = None
            self.api_ext = None
            self._initialized = True
            self._closed = False
            self._session = None
            # API configuration
            self.api_mode = os.getenv('API_MODE', 'kubernetes')  # 'kubernetes' or 'direct'
            self.api_endpoint = os.getenv('API_ENDPOINT')
            self.api_key = os.getenv('API_KEY')
            self.api_session = None

    @classmethod
    async def get_instance(cls):
        """Get or create the singleton instance with thread-safe initialization"""
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    await cls._instance.initialize_client()
        elif cls._instance._closed:
            async with cls._lock:
                await cls._instance.initialize_client()
        return cls._instance

    async def __aenter__(self):
        """Async context manager entry"""
        if self._closed:
            await self.initialize_client()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()

    async def close(self):
        """Close all connections"""
        try:
            # Close Kubernetes API client
            if self.api_client:
                try:
                    await self.api_client.close()
                except Exception as e:
                    logger.warning(f"Error closing Kubernetes API client: {e}")
                self.api_client = None

            # Close direct API session
            if self.api_session:
                try:
                    await self.api_session.close()
                except Exception as e:
                    logger.warning(f"Error closing API session: {e}")
                self.api_session = None

            # Close general session
            if self._session:
                try:
                    await self._session.close()
                except Exception as e:
                    logger.warning(f"Error closing session: {e}")
                self._session = None

            # Clear other references
            self.custom_api = None
            self.api_ext = None
            self._closed = True

        except Exception as e:
            logger.error(f"Error during connection cleanup: {e}")
            self.api_client = None
            self.api_session = None
            self._session = None
            self.custom_api = None
            self.api_ext = None
            self._closed = True

    async def cleanup(self):
        """Cleanup resources when application shuts down"""
        try:
            await self.close()
            BaseManager._instance = None
            self._initialized = False
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")

    async def _ensure_connection(self):
        """Ensure connection is active, retry if needed"""
        for attempt in range(self._connection_retries):
            try:
                if not self._closed and await self.verify_connection():
                    return True
                await self.initialize_client()
                return True
            except Exception as e:
                if attempt == self._connection_retries - 1:
                    raise
                logger.warning(f"Connection attempt {attempt + 1} failed: {e}")
                await asyncio.sleep(self._retry_delay)
        return False

    async def initialize_client(self):
        """Initialize client based on mode"""
        try:
            await self.close()

            if self.api_mode == 'direct' and self.api_endpoint and self.api_key:
                await self._initialize_direct_api()
            else:
                await self._initialize_kubernetes()

        except Exception as e:
            logger.error(f"Failed to initialize client: {e}")
            await self.close()
            raise

    async def _initialize_direct_api(self):
        """Initialize direct API access"""
        try:
            self.api_session = aiohttp.ClientSession(
                headers={
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                }
            )
            # Test connection
            async with self.api_session.get(f"{self.api_endpoint}/health") as response:
                if response.status != 200:
                    raise Exception(f"API health check failed: {response.status}")
            logger.info("Successfully connected to API endpoint")
            self._closed = False
        except Exception as e:
            logger.error(f"Failed to initialize direct API access: {e}")
            raise

    async def _initialize_kubernetes(self):
        """Initialize Kubernetes client"""
        try:
            configuration = client.Configuration()
            
            # SSL settings
            configuration.verify_ssl = False
            configuration.ssl_ca_cert = None
            configuration.assert_hostname = False
            
            # Connection settings
            configuration.connection_pool_maxsize = 32
            configuration.retries = 3
            configuration.timeout = 30
            
            # Proxy settings
            http_proxy = os.getenv('HTTP_PROXY')
            https_proxy = os.getenv('HTTPS_PROXY')
            proxy_user = os.getenv('PROXY_USER')
            proxy_pass = os.getenv('PROXY_PASS')

            if http_proxy or https_proxy:
                if http_proxy:
                    configuration.proxy = http_proxy
                if https_proxy:
                    configuration.proxy = https_proxy
                if proxy_user and proxy_pass:
                    configuration.proxy_headers = urllib3.make_headers(
                        proxy_basic_auth=f"{proxy_user}:{proxy_pass}"
                    )

            try:
                if os.path.exists(os.path.expanduser('~/.kube/config')):
                    await config.load_kube_config(client_configuration=configuration)
                else:
                    await config.load_incluster_config(client_configuration=configuration)
            except Exception as e:
                logger.error(f"Error loading kube config: {e}")
                raise

            # Initialize with retry
            max_retries = 3
            retry_delay = 1
            last_error = None

            for attempt in range(max_retries):
                try:
                    self.api_client = client.ApiClient(configuration)
                    self.custom_api = client.CustomObjectsApi(self.api_client)
                    self.api_ext = client.ApiextensionsV1Api(self.api_client)
                    await self.api_ext.get_api_resources()
                    logger.info("Successfully connected to Kubernetes cluster")
                    self._closed = False
                    return
                except Exception as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        logger.warning(f"Connection attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
                        await self.close()
                        await asyncio.sleep(retry_delay)
                    else:
                        raise last_error

        except Exception as e:
            logger.error(f"Failed to initialize Kubernetes client: {e}")
            raise

    async def verify_connection(self) -> bool:
        """Verify connection based on mode"""
        try:
            if self.api_mode == 'direct':
                if not self.api_session:
                    return False
                async with self.api_session.get(f"{self.api_endpoint}/health") as response:
                    return response.status == 200
            else:
                if not all([self.api_client, self.custom_api, self.api_ext]):
                    return False
                await self.api_ext.get_api_resources()
                return True
        except:
            return False

    async def make_request(self, method: str, path: str, data: Any = None) -> Dict:
        """Make API request with fallback"""
        try:
            if self.api_mode == 'direct':
                return await self._make_direct_request(method, path, data)
            else:
                return await self._make_kubernetes_request(method, path, data)
        except Exception as e:
            logger.error(f"Request failed: {e}")
            # Try fallback if direct API fails
            if self.api_mode == 'direct' and self.api_endpoint and self.api_key:
                try:
                    logger.info("Attempting fallback to Kubernetes API")
                    return await self._make_kubernetes_request(method, path, data)
                except Exception as fallback_error:
                    logger.error(f"Fallback request failed: {fallback_error}")
                    raise
            raise

    async def _make_direct_request(self, method: str, path: str, data: Any = None) -> Dict:
        """Make request to direct API"""
        if not self.api_session:
            await self._initialize_direct_api()

        url = f"{self.api_endpoint}{path}"
        async with self.api_session.request(method, url, json=data) as response:
            if response.status >= 400:
                error_text = await response.text()
                raise Exception(f"API request failed: {response.status} - {error_text}")
            return await response.json()

    async def _make_kubernetes_request(self, method: str, path: str, data: Any = None) -> Dict:
        """Make request to Kubernetes API"""
        if not await self._ensure_connection():
            raise Exception("No connection to Kubernetes cluster")

        # Convert REST-style path to Kubernetes API call
        parts = path.strip('/').split('/')
        if len(parts) < 2:
            raise ValueError(f"Invalid path: {path}")

        # Handle group and version
        if '/' in parts[0]:  # e.g. aws.crossplane.io/v1beta1
            group_parts = parts[0].split('/')
            group = group_parts[0]
            version = group_parts[1]
            plural = parts[1]
            name = parts[2] if len(parts) > 2 else None
        else:  # e.g. pkg.crossplane.io
            group = parts[0]
            version = 'v1'
            plural = parts[1]
            name = parts[2] if len(parts) > 2 else None
        
        namespace = None

        if method.upper() == 'GET':
            if name:
                if namespace:
                    return await self.custom_api.get_namespaced_custom_object(
                        group, version, namespace, plural, name)
                return await self.custom_api.get_cluster_custom_object(
                    group, version, plural, name)
            else:
                if namespace:
                    return await self.custom_api.list_namespaced_custom_object(
                        group, version, namespace, plural)
                return await self.custom_api.list_cluster_custom_object(
                    group, version, plural)
        else:
            raise NotImplementedError(f"Method {method} not implemented for Kubernetes API")

    async def get_crossplane_crds(self) -> List[dict]:
        """Get Crossplane CRDs using current mode"""
        try:
            if self.api_mode == 'direct':
                return await self._make_direct_request('GET', '/crds')
            else:
                if not await self._ensure_connection():
                    logger.error("No connection to Kubernetes cluster")
                    return []

                crd_list = await self.api_ext.list_custom_resource_definition()
                
                if not crd_list or not hasattr(crd_list, 'items'):
                    logger.warning("No CRDs found in the cluster")
                    return []

                crossplane_crds = []
                for crd in crd_list.items:
                    if not hasattr(crd, 'spec') or not hasattr(crd.spec, 'group'):
                        continue

                    categories = getattr(crd.spec.names, 'categories', []) or []
                    is_crossplane = (
                        'crossplane.io' in crd.spec.group or
                        any(cat in ['crossplane', 'managed', 'claim', 'composite']
                            for cat in categories)
                    )

                    if is_crossplane:
                        crossplane_crds.append({
                            'name': crd.metadata.name,
                            'kind': crd.spec.names.kind,
                            'group': crd.spec.group,
                            'version': crd.spec.versions[0].name if crd.spec.versions else '',
                            'scope': crd.spec.scope,
                            'categories': list(getattr(crd.spec.names, 'categories', []) or [])
                        })

                return crossplane_crds

        except Exception as e:
            logger.error(f"Error getting Crossplane CRDs: {e}")
            return []
