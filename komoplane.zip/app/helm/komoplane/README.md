# Komoplane Helm Chart

This Helm chart deploys Komoplane, a UI for Crossplane, on a Kubernetes cluster.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- Crossplane installed in the cluster

## Installing the Chart

First, add the Crossplane Helm repository:

```bash
helm repo add crossplane-stable https://charts.crossplane.io/stable
helm repo update
```

To install the chart with the release name `komoplane`:

```bash
helm install komoplane ./komoplane
```

## Configuration

The following table lists the configurable parameters of the Komoplane chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `1` |
| `image.repository` | Image repository | `komoplane` |
| `image.tag` | Image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `config.apiMode` | API mode (kubernetes/direct) | `kubernetes` |
| `config.apiEndpoint` | API endpoint for direct mode | `""` |
| `config.apiKey` | API key for direct mode | `""` |
| `config.debug` | Enable debug mode | `false` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `rbac.create` | Create RBAC resources | `true` |

## Usage

After installing the chart, you can access Komoplane through the service. If you're using `ClusterIP` (default), you can port-forward the service:

```bash
kubectl port-forward svc/komoplane 8080:80
```

Then access Komoplane at `http://localhost:8080`

## Uninstalling the Chart

To uninstall/delete the `komoplane` deployment:

```bash
helm delete komoplane