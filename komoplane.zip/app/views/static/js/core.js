// core.js - Core functionality and utilities
require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' }});

let monacoEditor = null;

function initializeMonacoEditor(elementId, content, language = 'yaml') {
    require(['vs/editor/editor.main'], function() {
        if (monacoEditor) {
            monacoEditor.dispose();
        }

        monacoEditor = monaco.editor.create(document.getElementById(elementId), {
            value: content,
            language: language,
            theme: 'vs-dark',
            readOnly: true,
            automaticLayout: true,
            minimap: { enabled: true },
            scrollBeyondLastLine: false,
            fontSize: 14,
            folding: true,
            lineNumbers: 'on',
            renderWhitespace: 'none',
            tabSize: 2
        });
    });
}

// Função principal para carregar dados
async function loadTabData(tabId, queryParams = '') {
    try {
        console.log(`Fetching data for tab: ${tabId}`);
        const url = `/api/${tabId}${queryParams ? `?${queryParams}` : ''}`;
        console.log('Request URL:', url);
        
        // showLoading(document.querySelector('main'));
        const response = await fetch(url);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        console.log(`Received data for ${tabId}:`, data);
        
        if (!data) throw new Error('No data received from server');
        
        if (tabId === 'overview') {
            console.log('Overview data:', data);
            console.log('Crossplane status:', data.data?.crossplane);
        }
        
        updateTabContent(tabId, data);
        
    } catch (error) {
        console.error('Error loading data:', error);
        showError(`Failed to load ${tabId}: ${error.message}`);
    } finally {
        hideLoading(document.querySelector('main'));
    }
}

// Function to update tab content
function updateTabContent(tabId, data) {
    // Call the appropriate render function based on the tab
    switch (tabId) {
        case 'overview':
            renderOverview(data);
            break;
            
        default: {
            const listElement = document.getElementById(`${tabId}-list`);
            if (!listElement) {
                console.error(`List element not found for tab: ${tabId}`);
                return;
            }

            // Clear existing content
            listElement.innerHTML = '';
            
            switch (tabId) {
                case 'managed-resources':
                    renderManagedResources(data);
                    break;
                    
                case 'compositions':
                    renderCompositions(listElement, data.compositions || []);
                    break;
                    
                case 'claims':
                    renderClaims(listElement, data.claims || []);
                    break;
                    
                case 'composite-resources':
                    renderCompositeResources(listElement, data.resources || []);
                    break;
                    
                case 'providers':
                    renderProviders(listElement, data.providers || []);
                    break;
                    
                case 'composite-resource-definitions':
                    renderCompositeResourceDefinitions(listElement, data);
                    break;

                case 'providerconfigs':
                    renderProviderConfigs(listElement, data || []);
                    break;
                    
                default:
                    console.warn(`Unknown tab type: ${tabId}`);
                    listElement.innerHTML = '<div class="p-4 text-center text-gray-500">Unknown tab type</div>';
            }
        }
    }
}

function createElement(tag, options = {}) {
    const element = document.createElement(tag);
    
    if (options.className) element.className = options.className;
    if (options.textContent) element.textContent = options.textContent;
    if (options.innerHTML) element.innerHTML = options.innerHTML;
    if (options.onclick) element.onclick = options.onclick;
    
    return element;
}

function showError(message) {
    const notification = createElement('div', {
        className: 'fixed top-4 right-4 bg-red-100 dark:bg-red-900/30 border border-red-400 dark:border-red-500 text-red-700 dark:text-red-200 px-4 py-3 rounded z-50'
    });

    notification.innerHTML = `
        <div class="flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            ${message}
        </div>
    `;

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}

function showSuccess(message) {
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-100 dark:bg-green-900/30 border border-green-400 dark:border-green-500 text-green-700 dark:text-green-200 px-4 py-3 rounded z-50';
    notification.innerHTML = `
        <div class="flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            ${message}
        </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

// Loading state functions
function showLoading(element) {
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'loading-overlay';
    loadingDiv.innerHTML = `
        <svg class="loading-spinner" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    `;
    element.appendChild(loadingDiv);
}

function hideLoading(element) {
    const loadingDiv = element.querySelector('.loading-overlay');
    if (loadingDiv) {
        loadingDiv.remove();
    }
}

function formatDate(timestamp) {
    if (!timestamp) return 'Unknown';
    return new Date(timestamp).toLocaleString();
}

function getHealthStatusClass(status) {
    if (!status) return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200';
    switch (status.toLowerCase()) {
        case 'healthy':
            return 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200';
        case 'unhealthy':
            return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200';
        case 'unknown':
            return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200';
        default:
            console.log('Unknown health status:', status);
            return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200';
    }
}

// Export functions
window.initializeMonacoEditor = initializeMonacoEditor;
window.loadTabData = loadTabData;
window.updateTabContent = updateTabContent;
window.createElement = createElement;
window.showError = showError;
window.showSuccess = showSuccess;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.formatDate = formatDate;
window.getHealthStatusClass = getHealthStatusClass;
