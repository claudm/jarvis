// tabs.js - Tab switching functionality
function switchTab(tabId) {
    console.log('Switching to tab:', tabId);
    
    // Update active tab
    document.querySelectorAll('[data-tab]').forEach(tab => {
        const isActive = tab.dataset.tab === tabId;
        tab.classList.toggle('active', isActive);
        tab.classList.toggle('text-blue-600', isActive);
        tab.classList.toggle('bg-blue-50', isActive);
        tab.classList.toggle('text-gray-600', !isActive);
    });

    // Update visible panel
    document.querySelectorAll('.tab-panel').forEach(panel => {
        const shouldShow = panel.id === `${tabId}-panel`;
        panel.classList.toggle('hidden', !shouldShow);
        if (shouldShow) {
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    });

    // Update header text
    const sectionTitle = {
        'overview': 'Overview',
        'compositions': 'Compositions',
        'claims': 'Claims',
        'composite-resources': 'Composite Resources',
        'managed-resources': 'Managed Resources',
        'providers': 'Providers',
        'xrds': 'XRDs'
    }[tabId];
    
    const headerElement = document.getElementById('current-section');
    if (headerElement) {
        headerElement.textContent = sectionTitle;
    }

    // Show/hide namespace selector based on tab
    const namespaceContainer = document.getElementById('namespace-container');
    if (namespaceContainer) {
        namespaceContainer.classList.toggle('hidden', tabId !== 'claims');
    }

    // Load data for the tab
    loadTabData(tabId);
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    // Initialize navigation links
    document.querySelectorAll('[data-tab]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = link.dataset.tab;
            
            // Update active state
            document.querySelectorAll('[data-tab]').forEach(el => {
                el.classList.remove('text-blue-600', 'bg-blue-50');
                el.classList.add('text-gray-600', 'hover:bg-gray-50', 'hover:text-gray-900');
            });
            link.classList.remove('text-gray-600', 'hover:bg-gray-50', 'hover:text-gray-900');
            link.classList.add('text-blue-600', 'bg-blue-50');
            
            switchTab(tabId);
        });
    });

    // Load initial data for active tab if any
    const activeTab = document.querySelector('.tab-button.active');
    if (activeTab) {
        loadTabData(activeTab.dataset.tab);
    }
});

// Export functions
window.switchTab = switchTab;
