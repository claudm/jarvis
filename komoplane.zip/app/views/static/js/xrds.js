// xrds.js - XRD (Composite Resource Definition) functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderXRDDetails(xrd) {
    const status = xrd.status || {};
    const conditions = status.conditions || [];
    const establishedCondition = conditions.find(c => c.type === 'Established') || {};
    
    const establishedTime = establishedCondition.lastTransitionTime ? 
        formatTimeAgo(establishedCondition.lastTransitionTime) : '';

    const schema = xrd.spec?.validation?.openAPIV3Schema || {};
    const description = schema.description || 'No description available';

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${xrd.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Group</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${xrd.spec?.group || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${xrd.spec?.versions?.[0]?.name || 'v1'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(xrd.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            establishedCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${establishedCondition.status === 'True' ? 'Established' : 'Not Established'}
                        </span>
                        ${establishedTime ? `<span class="text-xs text-gray-500">${establishedTime}</span>` : ''}
                        ${establishedCondition.message ? `<span class="text-sm text-gray-600">${establishedCondition.message}</span>` : ''}
                    </div>
                </div>
            </div>

            ${xrd.events && xrd.events.length > 0 ? `
                <div>
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                    <div class="space-y-3">
                        ${xrd.events.slice(0, 10).map(event => `
                            <div class="flex items-start space-x-3">
                                <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                                    event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                                }"></span>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                                        ${event.reason}
                                        <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.timestamp)}</span>
                                    </p>
                                    <p class="text-sm text-gray-500">${event.message}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function renderXRDs(container, data) {
    const xrds = data.xrds || [];
    if (!xrds.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No XRDs found</div>';
        return;
    }

    xrds.forEach(xrd => {
        const card = createXRDCard(xrd);
        container.appendChild(card);
    });
}

function createXRDCard(xrd) {
    const card = createElement('div', {
        className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
    });

    // Get XRD metadata
    const name = xrd.metadata?.name || 'Unknown';
    const kind = xrd.spec?.names?.kind || 'Unknown Kind';
    const group = xrd.spec?.group || '';
    const version = xrd.spec?.versions?.[0]?.name || 'v1';
    const scope = xrd.spec?.scope || 'Unknown Scope';
    const claimNames = xrd.spec?.claimNames || {};
    const categories = xrd.spec?.names?.categories || [];
    const creationTime = xrd.metadata?.creationTimestamp ? 
        formatTimeAgo(xrd.metadata.creationTimestamp) : 'Unknown';

    // Get status
    const status = xrd.status || {};
    const conditions = status.conditions || [];
    const establishedCondition = conditions.find(c => c.type === 'Established') || {};
    const isEstablished = establishedCondition.status === 'True';

    let isExpanded = false;
    const expandedContent = renderXRDDetails(xrd);
    
    // Add click handler to the entire card
    card.addEventListener('click', () => {
        isExpanded = !isExpanded;
        const contentSection = card.querySelector('.xrd-details');
        if (isExpanded) {
            contentSection.style.display = 'block';
            card.classList.add('expanded');
        } else {
            contentSection.style.display = 'none';
            card.classList.remove('expanded');
        }
    });

    card.innerHTML = `
        <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700 sm:px-6">
            <div class="flex items-center justify-between">
                <div class="flex-grow">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                        ${kind}
                        <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${group}/${version}</span>
                    </h3>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        Name: ${name} | Created: ${creationTime}
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex flex-col space-y-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            isEstablished ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${isEstablished ? 'Established' : 'Not Established'}
                        </span>
                    </div>
                    <button onclick="event.stopPropagation(); showDetailsInMonaco(${JSON.stringify(xrd).replace(/"/g, '&quot;')})" 
                            class="p-1 text-gray-400 hover:text-gray-500"
                            title="View YAML">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        <div class="xrd-details" style="display: none;">
            ${expandedContent}
        </div>`;

    return card;
}

// Export functions
window.renderXRDs = renderXRDs;
