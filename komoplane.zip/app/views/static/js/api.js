// api.js - Parte 1: Funções Core e Inicialização
require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' }});

let monacoEditor = null;

function initializeMonacoEditor(elementId, content, language = 'yaml') {
    require(['vs/editor/editor.main'], function() {
        if (monacoEditor) {
            monacoEditor.dispose();
        }

        monacoEditor = monaco.editor.create(document.getElementById(elementId), {
            value: content,
            language: language,
            theme: 'vs-dark',
            readOnly: true,
            automaticLayout: true,
            minimap: { enabled: true },
            scrollBeyondLastLine: false,
            fontSize: 14,
            folding: true,
            lineNumbers: 'on',
            renderWhitespace: 'none',
            tabSize: 2
        });
    });
}

// Função principal para carregar dados
async function loadTabData(tabId, queryParams = '') {
    try {
        console.log(`Fetching data for tab: ${tabId}`);
        const url = `/api/${tabId}${queryParams ? `?${queryParams}` : ''}`;
        console.log('Request URL:', url);
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        console.log(`Received data for ${tabId}:`, data);
        
        // Se não houver dados, lança erro
        if (!data) throw new Error('No data received from server');
        
        // Atualiza o conteúdo da tab
        updateTabContent(tabId, data);
        
    } catch (error) {
        console.error('Error loading data:', error);
        showError(`Failed to load ${tabId}: ${error.message}`);
    }
}


// Função para atualizar o conteúdo das tabs
function updateTabContent(tabId, data) {

    const listElement = document.getElementById(`${tabId}-list`);
    if (!listElement) {
        console.error(`List element not found for tab: ${tabId}`);
        return;
    }

    // Limpa o conteúdo existente
    listElement.innerHTML = '';
    
    // Chama a função de renderização apropriada baseada na tab
    switch (tabId) {
        case 'overview':
            renderOverview(data);
            break;
            
        case 'managed-resources':
            renderManagedResources(data);
            break;
            
        case 'compositions':
            renderCompositions(listElement, data.compositions || []);
            break;
            
        case 'claims':
            renderClaims(listElement, data.claims || []);
            break;
            
        case 'composite-resources':
            renderCompositeResources(listElement, data.resources || []);
            break;
            
        case 'providers':
            renderProviders(listElement, data.providers || []);
            break;
            
        case 'xrds':
            renderXRDs(listElement, data);
            break;
            
        default:
            console.warn(`Unknown tab type: ${tabId}`);
            if (listElement) {
                listElement.innerHTML = '<div class="p-4 text-center text-gray-500">Unknown tab type</div>';
            }
    }
}

// Funções Utilitárias
function createElement(tag, options = {}) {
    const element = document.createElement(tag);
    
    if (options.className) element.className = options.className;
    if (options.textContent) element.textContent = options.textContent;
    if (options.innerHTML) element.innerHTML = options.innerHTML;
    if (options.onclick) element.onclick = options.onclick;
    
    return element;
}

function showError(message) {
    const notification = createElement('div', {
        className: 'fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded z-50'
    });

    notification.innerHTML = `
        <div class="flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            ${message}
        </div>
    `;

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}
// Função para mostrar mensagens de sucesso
function showSuccess(message) {
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded z-50';
    notification.innerHTML = `
        <div class="flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            ${message}
        </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

// api.js - Parte 2: Renderização de Managed Resources

function renderManagedResources(data) {
    if (!data) {
        console.error('No data provided to renderManagedResources');
        return;
    }

    // Atualiza os contadores do sumário
    updateSummaryCounts(data);

    // Obtém o container das abas e do conteúdo
    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'border-b border-gray-200';
    
    const tabsList = document.createElement('nav');
    tabsList.className = 'flex -mb-px';
    tabsContainer.appendChild(tabsList);

    const contentContainer = document.createElement('div');
    contentContainer.className = 'mt-4';

    const container = document.getElementById('managed-resources-list');
    if (!container) return;

    // Limpa o conteúdo existente
    container.innerHTML = '';
    container.appendChild(tabsContainer);
    container.appendChild(contentContainer);

    // Se não houver recursos
    if (!data.resources || Object.keys(data.resources).length === 0) {
        contentContainer.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        return;
    }

    let isFirstTab = true;
    Object.entries(data.resources).forEach(([kind, groupData]) => {
        // Criar aba
        const tab = document.createElement('button');
        tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
            isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
        }`;
        tab.setAttribute('data-tab', kind);
        tab.innerHTML = `
            <span>${kind}</span>
            <span class="ml-2 text-sm text-gray-400">(${groupData.count || 0})</span>
        `;

        // Criar painel de conteúdo
        const contentPanel = document.createElement('div');
        contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
        contentPanel.setAttribute('data-tab-content', kind);

        // Renderizar recursos do grupo
        contentPanel.innerHTML = `
            <div class="divide-y divide-gray-200">
                ${groupData.resources.map(resource => `
                    <div class="p-4 hover:bg-gray-50">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <h4 class="text-lg font-medium text-gray-900">${resource.metadata?.name || 'Unnamed'}</h4>
                                <div class="mt-1 text-sm text-gray-500">
                                    <p>Provider: ${resource.provider || resource.display_provider || 'Unknown'}</p>
                                    <p class="mt-1 text-xs text-gray-400">
                                        Created: ${formatDate(resource.metadata?.creationTimestamp)}
                                    </p>
                                </div>
                            </div>
                            <div class="ml-4 flex items-center space-x-2">
                                <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                                    ${resource._health_status || 'Unknown'}
                                </span>
                <button 
                    class="ml-2 p-1 text-gray-400 hover:text-gray-500"
                    onclick='showDetailsInMonaco(${JSON.stringify(resource)})'>
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;

        // Adicionar evento de clique na aba
        tab.addEventListener('click', () => {
            // Atualizar estados das abas
            document.querySelectorAll('[data-tab]').forEach(t => {
                t.classList.remove('text-blue-600', 'border-blue-600');
                t.classList.add('text-gray-500', 'border-transparent');
            });
            tab.classList.remove('text-gray-500', 'border-transparent');
            tab.classList.add('text-blue-600', 'border-blue-600');

            // Atualizar visibilidade dos painéis
            document.querySelectorAll('[data-tab-content]').forEach(p => {
                p.classList.add('hidden');
            });
            contentPanel.classList.remove('hidden');
        });

        // Adicionar elementos à página
        tabsList.appendChild(tab);
        contentContainer.appendChild(contentPanel);
        
        isFirstTab = false;
    });
}

function updateSummaryCounts(data) {
    const elements = {
        total: document.getElementById('total-resources-count'),
        healthy: document.getElementById('healthy-resources-count'),
        unhealthy: document.getElementById('unhealthy-resources-count'),
        unknown: document.getElementById('unknown-resources-count')
    };

    if (elements.total) elements.total.textContent = data.total_count || '0';
    if (elements.healthy) elements.healthy.textContent = data.health_summary?.healthy || '0';
    if (elements.unhealthy) elements.unhealthy.textContent = data.health_summary?.unhealthy || '0';
    if (elements.unknown) elements.unknown.textContent = data.health_summary?.unknown || '0';
}

function processProviderFilter(data, container) {
    const providerFilter = localStorage.getItem('providerFilter');
    if (!providerFilter) return data;

    // Filtra os recursos pelo provider
    const filteredData = {
        ...data,
        resources: Object.fromEntries(
            Object.entries(data.resources || {}).filter(([_, group]) =>
                group.resources.some(resource =>
                    resource.provider === providerFilter ||
                    resource.display_provider === providerFilter
                )
            )
        )
    };

    // Limpa o filtro após uso
    localStorage.removeItem('providerFilter');

    // Adiciona o indicador de filtro
    const filterIndicator = createElement('div', {
        className: 'px-4 py-2 bg-blue-50 text-blue-700 mb-4 flex justify-between items-center'
    });
    
    filterIndicator.innerHTML = `
        <span>Filtered by Provider: ${providerFilter}</span>
        <button class="text-sm bg-blue-100 px-2 py-1 rounded hover:bg-blue-200" onclick="clearProviderFilter()">
            Clear Filter
        </button>
    `;
    
    container.appendChild(filterIndicator);
    
    return filteredData;
}

function renderResourceGroup(container, kind, groupData) {
    const groupElement = document.createElement('div');
    groupElement.className = 'bg-white shadow rounded-lg mb-4';

    // Renderiza o cabeçalho do grupo
    groupElement.innerHTML = `
        <div class="px-4 py-3 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-lg font-medium text-gray-900">
                    ${kind}
                    <span class="ml-2 text-sm text-gray-500">(${groupData.count || 0})</span>
                </h3>
                <div class="flex items-center space-x-4">
                    <span class="px-2.5 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                        Healthy: ${groupData.health_summary?.healthy || 0}
                    </span>
                    <span class="px-2.5 py-0.5 rounded-full text-sm font-medium bg-red-100 text-red-800">
                        Unhealthy: ${groupData.health_summary?.unhealthy || 0}
                    </span>
                    <span class="px-2.5 py-0.5 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">
                        Unknown: ${groupData.health_summary?.unknown || 0}
                    </span>
                </div>
            </div>
        </div>
    `;

    // Cria o container para os recursos
    const resourcesList = document.createElement('div');
    resourcesList.className = 'divide-y divide-gray-200';

    // Adiciona cada recurso
    groupData.resources?.forEach(resource => {
        if (!resource) return;
        const resourceElement = createResourceElement(resource);
        resourcesList.appendChild(resourceElement);
    });

    groupElement.appendChild(resourcesList);
    container.appendChild(groupElement);
}

function createResourceElement(resource) {
    const resourceElement = document.createElement('div');
    resourceElement.className = 'p-4 hover:bg-gray-50';
    
    const healthStatus = resource._health_status || 'Unknown';
    const healthClass = getHealthStatusClass(healthStatus);
    
    resourceElement.innerHTML = `
        <div class="flex justify-between items-start">
            <div class="flex-1">
                <h4 class="text-lg font-medium text-gray-900">${resource.metadata?.name || 'Unnamed'}</h4>
                <div class="mt-1 text-sm text-gray-500">
                    <p>Provider: ${resource.provider || resource.display_provider || 'Unknown'}</p>
                    <p class="mt-1 text-xs text-gray-400">
                        Created: ${formatDate(resource.metadata?.creationTimestamp)}
                    </p>
                </div>
            </div>
            <div class="ml-4 flex items-center space-x-2">
                <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${healthClass}">
                    ${healthStatus}
                </span>
                <button 
                    class="ml-2 p-1 text-gray-400 hover:text-gray-500"
                    onclick='showResourceDetails(${JSON.stringify(resource)})'>
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </div>
        </div>
    `;

    return resourceElement;
}

function getHealthStatusClass(status) {
    if (!status) return 'bg-yellow-100 text-yellow-800';
    switch (status.toLowerCase()) {
        case 'healthy':
            return 'bg-green-100 text-green-800';
        case 'unhealthy':
            return 'bg-red-100 text-red-800';
        default:
            return 'bg-yellow-100 text-yellow-800';
    }
}

function formatDate(timestamp) {
    if (!timestamp) return 'Unknown';
    return new Date(timestamp).toLocaleString();
}
// api.js - Parte 3: Renderização de Outros Recursos

function renderCompositions(container, compositions) {
    if (!compositions.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No compositions found</div>';
        return;
    }

    compositions.forEach(comp => {
        const div = createElement('div', {
            className: 'px-4 py-4 hover:bg-gray-50'
        });

        div.innerHTML = `
            <div class="flex justify-between items-start">
                <div>
                    <h3 class="text-lg font-medium">${comp.metadata?.name || 'Unnamed'}</h3>
                    <p class="text-sm text-gray-600">
                        Created: ${formatDate(comp.metadata?.creationTimestamp)}
                    </p>
                </div>
                <button onclick='showDetailsInMonaco(${JSON.stringify(comp).replace(/'/g, "\\'").replace(/"/g, "&quot;")})' 
                        class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    View Details
                    <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M4 5a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" clip-rule="evenodd" />
                    </svg>
                </button>
            </div>
        `;

        container.appendChild(div);
    });
}

function renderClaims(container, claims) {
    if (!claims.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No claims found</div>';
        return;
    }

    claims.forEach(claim => {
        const card = createElement('div', {
            className: 'bg-white shadow rounded-lg overflow-hidden mb-4'
        });

        const status = claim.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';

        const creationTime = claim.metadata?.creationTimestamp ? 
            new Date(claim.metadata.creationTimestamp).toLocaleString() : 'Unknown';

        card.innerHTML = `
            <div class="px-4 py-5 border-b border-gray-200 sm:px-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900">
                            ${claim.metadata?.name || 'Unnamed'}
                            <span class="ml-2 text-sm text-gray-500">${claim.apiVersion || ''}</span>
                        </h3>
                        <p class="mt-1 text-sm text-gray-500">
                            Kind: ${claim.kind || 'Unknown'} | Namespace: ${claim.metadata?.namespace || 'default'}
                        </p>
                    </div>
                    <div class="flex space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            isSynced ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }">
                            ${isSynced ? 'Synced' : 'Not Synced'}
                        </span>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            isReady ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }">
                            ${isReady ? 'Ready' : 'Not Ready'}
                        </span>
                    </div>
                </div>
            </div>
            <div class="px-4 py-4 sm:px-6">
                <dl class="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2">
                    <div class="sm:col-span-1">
                        <dt class="text-sm font-medium text-gray-500">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900">${creationTime}</dd>
                    </div>
                    ${(syncedCondition.message || readyCondition.message) ? `
                        <div class="sm:col-span-2">
                            <dt class="text-sm font-medium text-gray-500">Status Messages</dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                ${syncedCondition.message ? `<p class="mb-1">Sync: ${syncedCondition.message}</p>` : ''}
                                ${readyCondition.message ? `<p>Ready: ${readyCondition.message}</p>` : ''}
                            </dd>
                        </div>
                    ` : ''}
                </dl>
                <div class="mt-4 flex space-x-3">
                    <button onclick='showDetailsInMonaco(${JSON.stringify(claim).replace(/'/g, "\\'").replace(/"/g, "&quot;")})'
                            class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        View Details
                        <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M4 5a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" clip-rule="evenodd" />
                        </svg>
                    </button>            
                </div>
            </div>
        `;

        container.appendChild(card);
    });
}

async function deleteClaim(name, namespace) {
    if (!confirm(`Are you sure you want to delete claim "${name}"?`)) {
        return;
    }

    try {
        const response = await fetch(`/api/claims/${name}?namespace=${namespace}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to delete claim');
        }

        showSuccess(`Claim "${name}" deleted successfully`);
        loadTabData('claims'); // Reload claims list
    } catch (error) {
        console.error('Error deleting claim:', error);
        showError(error.message || 'Failed to delete claim');
    }
}

function renderCompositeResources(container, resources) {
    if (!resources || !resources.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No composite resources found</div>';
        return;
    }

    resources.forEach(resource => {
        const card = createElement('div', {
            className: 'bg-white shadow rounded-lg overflow-hidden mb-4'
        });

        // Get metadata
        const name = resource.metadata?.name || 'Unknown';
        const kind = resource._resource_type?.kind || 'Unknown Kind';
        const group = resource._resource_type?.group || '';
        const version = resource._resource_type?.version || 'v1';
        
        // Get status information
        const status = resource.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';
        const healthStatus = resource._health_status || 'Unknown';

        card.innerHTML = `
            <div class="px-4 py-5 border-b border-gray-200 sm:px-6">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                        ${kind}
                        <span class="ml-2 text-sm text-gray-500">${group}/${version}</span>
                    </h3>
                    <div class="flex space-x-2">
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getStatusBadgeClass(healthStatus)}">
                            ${healthStatus}
                        </span>
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${isSynced ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                            ${isSynced ? 'Synced' : 'Not Synced'}
                        </span>
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${isReady ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                            ${isReady ? 'Ready' : 'Not Ready'}
                        </span>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-500">${name}</p>
                </div>
            </div>
            <div class="px-4 py-4 sm:px-6">
                <dl class="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2">
                    <div class="sm:col-span-1">
                        <dt class="text-sm font-medium text-gray-500">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900">${formatDate(resource.metadata?.creationTimestamp)}</dd>
                    </div>
                    ${syncedCondition.message || readyCondition.message ? `
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-medium text-gray-500">Status Messages</dt>
                        <dd class="mt-1 text-sm text-gray-900">
                            ${syncedCondition.message ? `<p>Sync: ${syncedCondition.message}</p>` : ''}
                            ${readyCondition.message ? `<p>Ready: ${readyCondition.message}</p>` : ''}
                        </dd>
                    </div>
                    ` : ''}
                </dl>
                <div class="mt-4">
                    <button onclick='showDetailsInMonaco(${JSON.stringify(resource).replace(/'/g, "\\'").replace(/"/g, "&quot;")})' 
                            class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        View Details
                        <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M4 5a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" clip-rule="evenodd" />
                        </svg>
                    </button>
                </div>
            </div>`;

        container.appendChild(card);
    });
}

function showResourceDetailsInMonaco(resource) {
    try {
        // Show the modal first
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="relative bg-white rounded-lg shadow-xl mx-4 w-full max-w-4xl">
                <div class="flex items-start justify-between p-4 border-b">
                    <h3 class="text-lg font-semibold text-gray-900">
                        Resource Details: ${resource.metadata?.name || 'Unnamed'}
                    </h3>
                    <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-gray-500">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                <div class="p-4" style="height: 600px;">
                    <div id="resource-details-editor" style="width: 100%; height: 100%;"></div>
                </div>
                <div class="flex items-center justify-end p-4 border-t">
                    <button onclick="this.closest('.fixed').remove()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">
                        Close
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Format the data as YAML
        const yaml = jsyaml.dump(resource);
        
        // Initialize Monaco editor after modal is shown
        setTimeout(() => {
            initializeMonacoEditor('resource-details-editor', yaml, 'yaml');
        }, 100);
        
    } catch (error) {
        console.error('Error showing resource details:', error);
        showError('Failed to show resource details');
    }
}

function getStatusBadgeClass(status) {
    switch (status.toLowerCase()) {
        case 'healthy':
            return 'bg-green-100 text-green-800';
        case 'unhealthy':
            return 'bg-red-100 text-red-800';
        default:
            return 'bg-yellow-100 text-yellow-800';
    }
}


function renderProviders(container, providers) {
    if (!providers.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No providers found</div>';
        return;
    }

    providers.forEach(provider => {
        const div = createElement('div', {
            className: 'px-4 py-4 hover:bg-gray-50 cursor-pointer',
            onclick: () => {
                localStorage.setItem('providerFilter', provider.metadata?.name);
                switchTab('managed-resources');
            }
        });

        const status = provider.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isReady = readyCondition.status === 'True';

        div.innerHTML = `
            <div class="flex justify-between items-start">
                <div>
                    <h3 class="text-lg font-medium">${provider.metadata?.name || 'Unnamed'}</h3>
                    <p class="text-sm text-gray-600">Package: ${provider.spec?.package || 'Unknown'}</p>
                </div>
                <span class="px-2 py-1 text-sm rounded-full ${isReady ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                    ${isReady ? 'Ready' : 'Not Ready'}
                </span>
            </div>
        `;

        container.appendChild(div);
    });
}

// Funções de Renderização
// api.js - Parte 4: Funções Utilitárias e Operações

function showResourceDetails(resource) {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="relative bg-white rounded-lg shadow-xl mx-4 w-full max-w-2xl">
            <div class="flex items-start justify-between p-4 border-b">
                <h3 class="text-lg font-semibold text-gray-900">
                    Resource Details: ${resource.metadata?.name || resource.name || 'Unnamed'}
                </h3>
                <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-gray-500">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="p-4 max-h-[70vh] overflow-y-auto">
                <pre class="bg-gray-50 p-3 rounded-lg overflow-x-auto text-sm">
${JSON.stringify(resource, null, 2)}
                </pre>
            </div>
            <div class="flex items-center justify-end p-4 border-t">
                <button onclick="this.closest('.fixed').remove()" 
                        class="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">
                    Close
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function clearProviderFilter() {
    localStorage.removeItem('providerFilter');
    loadTabData('managed-resources');
}

// Funções para manipulação do YAML
async function saveYamlContent(content) {
    try {
        if (!content || content.trim() === '') {
            throw new Error('YAML content cannot be empty');
        }

        let data;
        try {
            data = jsyaml.load(content);
        } catch (yamlError) {
            throw new Error(`Invalid YAML format: ${yamlError.message}`);
        }

        // Validações básicas
        if (!data) throw new Error('Invalid YAML content: Failed to parse');
        if (!data.apiVersion) throw new Error('Missing required field: apiVersion');
        if (!data.kind || data.kind !== 'Composition') throw new Error('Invalid or missing kind: Must be "Composition"');
        if (!data.metadata?.name) throw new Error('Missing required field: metadata.name');
        if (!data.spec) throw new Error('Missing required field: spec');

        const response = await fetch('/api/compositions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const responseData = await response.json();
        if (!response.ok) throw new Error(responseData.error || 'Failed to save composition');

        hideEditor();
        showSuccess('Composition saved successfully');
        
        // Recarrega os dados
        const activeTab = document.querySelector('.tab-button.active');
        if (activeTab) loadTabData(activeTab.dataset.tab);
        
    } catch (error) {
        console.error('Error saving composition:', error);
        showError(error.message || 'Failed to save composition');
    }
}

function renderOverview(data) {
    if (!data || !data.data) {
        console.error('Invalid overview data');
        return;
    }

    const overview = data.data;

    // Update counts
    const updateCount = (id, value) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value || '0';
        }
    };

    updateCount('claims-count', overview.claims?.count);
    updateCount('composite-resources-count', overview.composite_resources?.count);
    updateCount('managed-resources-count', overview.managed_resources?.total_count);
    updateCount('providers-count', overview.providers?.count);
    updateCount('compositions-count', overview.compositions?.count);
    updateCount('xrds-count', overview.xrds?.count);

    // Update health status
    const healthSummary = overview.managed_resources?.health_summary || {};
    const total = (healthSummary.healthy || 0) + (healthSummary.unhealthy || 0) + (healthSummary.unknown || 0);

    ['healthy', 'unhealthy', 'unknown'].forEach(status => {
        const percentElement = document.getElementById(`${status}-percentage`);
        const countElement = document.getElementById(`${status}-count`);
        
        if (percentElement) {
            percentElement.style.width = total > 0 ? 
                `${((healthSummary[status] || 0) / total * 100).toFixed(1)}%` : '0%';
        }
        if (countElement) {
            countElement.textContent = healthSummary[status] || '0';
        }
    });

    // Update recent activity
    const recentActivity = document.getElementById('recent-activity');
    if (recentActivity) {
        recentActivity.innerHTML = '';

        const allResources = [
            ...(overview.claims?.items || []),
            ...(overview.composite_resources?.items || []),
            ...(overview.managed_resources?.items || [])
        ].filter(Boolean)
         .sort((a, b) => {
            const dateA = a?.metadata?.creationTimestamp ? new Date(a.metadata.creationTimestamp) : new Date(0);
            const dateB = b?.metadata?.creationTimestamp ? new Date(b.metadata.creationTimestamp) : new Date(0);
            return dateB - dateA;
         })
         .slice(0, 5);

        if (allResources.length === 0) {
            recentActivity.innerHTML = '<div class="text-sm text-gray-500 text-center p-4">No recent activity</div>';
            return;
        }

        allResources.forEach(resource => {
            const activityItem = document.createElement('div');
            activityItem.className = 'flex items-center space-x-3';
            activityItem.innerHTML = `
                <div class="flex-shrink-0">
                    <div class="w-2 h-2 rounded-full ${getStatusColor(resource._health_status)}"></div>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 truncate">
                        ${resource.metadata?.name || 'Unnamed'}
                        <span class="text-xs text-gray-500 ml-1">(${getResourceType(resource)})</span>
                    </p>
                    <p class="text-sm text-gray-500">Created ${formatTimeAgo(resource.metadata?.creationTimestamp)}</p>
                </div>
            `;
            recentActivity.appendChild(activityItem);
        });
    }
}

function renderXRDs(container, data) {
    const xrds = data.xrds || [];
    if (!xrds.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No XRDs found</div>';
        return;
    }

    xrds.forEach(xrd => {
        const card = createXRDCard(xrd);
        container.appendChild(card);
    });
}

function createXRDCard(xrd) {
    const card = createElement('div', {
        className: 'bg-white shadow rounded-lg overflow-hidden mb-4'
    });

    // Get XRD metadata
    const name = xrd.metadata?.name || 'Unknown';
    const kind = xrd.spec?.names?.kind || 'Unknown Kind';
    const group = xrd.spec?.group || '';
    const version = xrd.spec?.versions?.[0]?.name || 'v1';
    const scope = xrd.spec?.scope || 'Unknown Scope';
    const claimNames = xrd.spec?.claimNames || {};
    const categories = xrd.spec?.names?.categories || [];

    // Get validation schema if available
    const schema = xrd.spec?.validation?.openAPIV3Schema || {};
    const description = schema.description || 'No description available';

    card.innerHTML = `
        <div class="px-4 py-5 border-b border-gray-200 sm:px-6">
            <div class="flex items-center justify-between">
                <h3 class="text-lg leading-6 font-medium text-gray-900">
                    ${kind}
                    <span class="ml-2 text-sm text-gray-500">${group}/${version}</span>
                </h3>
                <div class="flex space-x-2">
                    ${categories.map(category => 
                        `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                            ${category}
                        </span>`
                    ).join('')}
                </div>
            </div>
            <div class="mt-2">
                <p class="text-sm text-gray-500">${description}</p>
            </div>
        </div>
        <div class="px-4 py-4 sm:px-6">
            <dl class="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2">
                <div class="sm:col-span-1">
                    <dt class="text-sm font-medium text-gray-500">Name</dt>
                    <dd class="mt-1 text-sm text-gray-900">${name}</dd>
                </div>
                <div class="sm:col-span-1">
                    <dt class="text-sm font-medium text-gray-500">Scope</dt>
                    <dd class="mt-1 text-sm text-gray-900">${scope}</dd>
                </div>
                ${claimNames.kind ? `
                <div class="sm:col-span-1">
                    <dt class="text-sm font-medium text-gray-500">Claim Kind</dt>
                    <dd class="mt-1 text-sm text-gray-900">${claimNames.kind}</dd>
                </div>
                ` : ''}
            </dl>
            <div class="mt-4">
                <button onclick="showDetailsInMonaco(${JSON.stringify(xrd).replace(/"/g, '&quot;')})" 
                        class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    View Details
                    <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M4 5a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" clip-rule="evenodd" />
                    </svg>
                </button>
            </div>
        </div>`;

    return card;
}


async function showXRDDetails(name) {
    try {
        const response = await fetch(`/api/xrds/${name}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const xrd = await response.json();
        
        // Show the modal first
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="relative bg-white rounded-lg shadow-xl mx-4 w-full max-w-4xl">
                <div class="flex items-start justify-between p-4 border-b">
                    <h3 class="text-lg font-semibold text-gray-900">
                        XRD Details: ${xrd.metadata?.name || 'Unnamed'}
                    </h3>
                    <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-gray-500">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                <div class="p-4" style="height: 600px;">
                    <div id="xrd-details-editor" style="width: 100%; height: 100%;"></div>
                </div>
                <div class="flex items-center justify-end p-4 border-t">
                    <button onclick="this.closest('.fixed').remove()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">
                        Close
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Format the XRD data as YAML
        const yaml = jsyaml.dump(xrd);
        
        // Initialize Monaco editor after modal is shown
        setTimeout(() => {
            initializeMonacoEditor('xrd-details-editor', yaml, 'yaml');
        }, 100);
        
    } catch (error) {
        console.error('Error loading XRD details:', error);
        showError('Failed to load XRD details');
    }
}

// Tab switching functionality
function switchTab(tabId) {
    console.log('Switching to tab:', tabId);
    
    // Update active tab
    document.querySelectorAll('[data-tab]').forEach(tab => {
        const isActive = tab.dataset.tab === tabId;
        tab.classList.toggle('active', isActive);
        tab.classList.toggle('text-blue-600', isActive);
        tab.classList.toggle('bg-blue-50', isActive);
        tab.classList.toggle('text-gray-600', !isActive);
    });

    // Update visible panel
    document.querySelectorAll('.tab-panel').forEach(panel => {
        const shouldShow = panel.id === `${tabId}-panel`;
        panel.classList.toggle('hidden', !shouldShow);
        if (shouldShow) {
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    });

    // Update header text
    const sectionTitle = {
        'overview': 'overview',
        'compositions': 'Compositions',
        'claims': 'Claims',
        'composite-resources': 'Composite Resources',
        'managed-resources': 'Managed Resources',
        'providers': 'Providers',
        'xrds': 'XRDs'
    }[tabId];
    
    const headerElement = document.getElementById('current-section');
    if (headerElement) {
        headerElement.textContent = sectionTitle;
    }

    // Show/hide namespace selector based on tab
    const namespaceContainer = document.getElementById('namespace-container');
    if (namespaceContainer) {
        namespaceContainer.classList.toggle('hidden', tabId !== 'claims');
    }

    // Load data for the tab
    loadTabData(tabId);
}

// Export functions to global scope
window.showXRDDetails = showXRDDetails;
window.initializeMonacoEditor = initializeMonacoEditor;
window.showResourceDetailsInMonaco = showResourceDetailsInMonaco;
window.showDetailsInMonaco = showResourceDetailsInMonaco; // Alias for compatibility
window.loadTabData = loadTabData;
window.showResourceDetails = showResourceDetails;
window.switchTab = switchTab;

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    // Load initial data for active tab if any
    const activeTab = document.querySelector('.tab-button.active');
    if (activeTab) {
        loadTabData(activeTab.dataset.tab);
    }
});
