function renderCompositions(container, compositions) {
    if (!compositions || compositions.length === 0) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500 dark:text-gray-400">No compositions found</div>';
        return;
    }

    compositions.forEach(comp => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
        });
        
        let isExpanded = false;
        
        // Add click handler to the entire card
        card.addEventListener('click', () => {
            isExpanded = !isExpanded;
            const contentSection = card.querySelector('.composition-details');
            if (isExpanded) {
                contentSection.style.display = 'block';
                card.classList.add('expanded');
            } else {
                contentSection.style.display = 'none';
                card.classList.remove('expanded');
            }
        });

        const status = comp.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';

        card.innerHTML = `
            <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700 sm:px-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <div>
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                                ${comp.metadata?.name || 'Unnamed'}
                                <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${comp.apiVersion || ''}</span>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                Kind: ${comp.kind || 'Unknown'}
                            </p>
                        </div>
                        <button onclick="event.stopPropagation(); showDetailsInMonaco(${JSON.stringify(comp).replace(/'/g, "\\'").replace(/"/g, "&quot;")})"
                                class="p-1 text-gray-400 hover:text-gray-500" title="View YAML">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                    <div class="flex flex-col space-y-2">
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                isSynced ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                            }">
                                ${isSynced ? 'Synced' : 'Not Synced'}
                            </span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                            }">
                                ${isReady ? 'Ready' : 'Not Ready'}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="composition-details" style="display: none;">
                <div class="px-6 py-4">
                    ${comp.spec?.resources ? `
                        <div class="mb-6">
                            <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Resources</h3>
                            <div class="space-y-4">
                                ${comp.spec.resources.map((resource, index) => `
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm text-gray-900 dark:text-white">${resource.name || `Resource ${index + 1}`}</span>
                                        <span class="text-sm text-gray-500">${resource.base?.kind || 'Unknown Kind'}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        container.appendChild(card);
    });
}

// Export functions
window.renderCompositions = renderCompositions;
window.saveYamlContent = saveYamlContent;
