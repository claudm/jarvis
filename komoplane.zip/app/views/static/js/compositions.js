function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderCompositionGraph(composition, containerId) {
    try {
        const graphElement = document.getElementById(containerId);
        if (!graphElement) {
            console.error(`Graph container ${containerId} not found`);
            return null;
        }

        const chart = echarts.init(graphElement);
        const isDarkMode = document.documentElement.classList.contains('dark');
        
        // Prepare nodes and links data
        const nodes = [];
        const links = [];

        // Icons for nodes using path notation
        const icons = {
            claim: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
            composition: 'path://M3 3h18v18H3z M7 7h10v10H7z',
            resource: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
        };

        // Node colors with improved contrast
        const colors = {
            claim: '#6B7CFF',      // Light purple for claims
            composition: '#4ADE80', // Light green for compositions
            resource: '#FBBF24'    // Light orange/yellow for composite resources
        };

        // Get composition status
        const status = composition.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const isReady = readyCondition.status === 'True';

        // Add composition node with improved styling
        nodes.push({
            id: composition.metadata?.name,
            name: composition.metadata?.name || 'Unnamed',
            symbol: icons.composition,
            symbolSize: [50, 50],
            category: 0,
            itemStyle: {
                color: colors.composition,
                opacity: isReady ? 1 : 0.7
            },
            label: {
                show: true,
                formatter: '{b}',
                position: 'right',
                distance: 5,
                color: isReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
            },
            tooltip: {
                formatter: () => `
                    ${composition.metadata?.name}
                    Status: ${isReady ? 'Ready' : 'Not Ready'}
                `
            }
        });

        // Add resource nodes
        if (composition.spec?.resources) {
            composition.spec.resources.forEach((resource, index) => {
                const resourceName = resource.name || `Resource ${index + 1}`;
                const resourceKind = resource.base?.kind || 'Unknown Kind';
                const resourceReady = resource.status?.ready || false;
                
                nodes.push({
                    id: resourceName,
                    name: resourceName,
                    symbol: icons.resource,
                    symbolSize: [45, 45],
                    category: 1,
                    itemStyle: {
                        color: colors.resource,
                        opacity: resourceReady ? 1 : 0.7
                    },
                    label: {
                        show: true,
                        formatter: `{b}\n(${resourceKind})`,
                        position: 'right',
                        distance: 5,
                        color: resourceReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
                    },
                    tooltip: {
                        formatter: () => `
                            ${resourceName}
                            Kind: ${resourceKind}
                            Status: ${resourceReady ? 'Ready' : 'Not Ready'}
                        `
                    }
                });

                // Determine relationship type and style accordingly
                const relationshipType = resource.base?.kind?.toLowerCase().includes('bucket') ? 'composite' : 'uses';
                
                links.push({
                    source: composition.metadata?.name,
                    target: resourceName,
                    lineStyle: {
                        color: relationshipType === 'uses' ? '#4ADE80' : '#60A5FA', // Green for uses, Blue for composite
                        width: 2,
                        opacity: 0.8,
                        type: relationshipType === 'uses' ? 'dashed' : 'solid',
                        curveness: 0.4
                    }
                });

                // Add claims relationship if it exists
                if (resource.claims) {
                    links.push({
                        source: resourceName,
                        target: resource.claims,
                        lineStyle: {
                            color: '#A78BFA', // Purple for claims
                            width: 2,
                            opacity: 0.8,
                            type: 'solid',
                            curveness: 0.4
                        }
                    });
                }
            });
        }

        const option = {
            backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
            tooltip: {
                trigger: 'item',
                formatter: (params) => {
                    if (params.dataType === 'node') {
                        return params.data.tooltip?.formatter() || params.name;
                    }
                    return params.name;
                }
            },
            legend: {
                show: true,
                top: '20',
                left: '20',
                orient: 'vertical',
                itemGap: 20,
                itemWidth: 30,
                itemHeight: 16,
                data: [
                    {
                        name: 'Composition',
                        icon: icons.composition,
                        itemStyle: { color: colors.composition }
                    },
                    {
                        name: 'Resource',
                        icon: icons.resource,
                        itemStyle: { color: colors.resource }
                    }
                ],
                textStyle: {
                    color: isDarkMode ? '#e5e7eb' : '#374151'
                }
            },
            animationDurationUpdate: 1500,
            animationEasingUpdate: 'quinticInOut',
            series: [{
                type: 'graph',
                layout: 'force',
                data: nodes,
                links: links,
                edgeSymbol: ['circle', 'arrow'],
                edgeSymbolSize: [4, 10],
                lineStyle: {
                    curveness: 0.4,
                    width: 2,
                    opacity: 0.8
                },
                categories: [
                    { name: 'Composition' },
                    { name: 'Resource' }
                ],
                roam: true,
                force: {
                    repulsion: 1500,
                    edgeLength: 200,
                    gravity: 0.05,
                    friction: 0.3,
                    layoutAnimation: true
                },
                draggable: true,
                emphasis: {
                    focus: 'adjacency',
                    scale: 1.1
                },
                label: {
                    show: true,
                    position: 'right',
                    color: isDarkMode ? '#e5e7eb' : '#374151',
                    formatter: '{b}'
                }
            }]
        };

        chart.setOption(option);
        
        // Handle window resize
        const resizeHandler = () => {
            if (chart) {
                chart.resize();
            }
        };
        window.addEventListener('resize', resizeHandler);

        // Prevent graph clicks from propagating to card
        graphElement.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        return chart;
    } catch (error) {
        console.error('Error rendering graph:', error);
        return null;
    }
}

let lastCompositionsState = [];
let compositionsPollingInterval;

// Initialize event listeners
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('compositions-search');
    const statusFilter = document.getElementById('compositions-status-filter');

    if (searchInput) {
        searchInput.addEventListener('input', _.debounce(() => applyFilters(), 300));
    }
    if (statusFilter) {
        statusFilter.addEventListener('change', () => applyFilters());
    }
});

function renderCompositions(container, compositions) {
    // Store current state for comparison
    const previousState = lastCompositionsState;
    lastCompositionsState = JSON.parse(JSON.stringify(compositions || []));

    // Start polling for changes if not already started
    if (!compositionsPollingInterval) {
        compositionsPollingInterval = setInterval(pollForChanges, 30000); // Poll every 30 seconds
    }

    if (!compositions || compositions.length === 0) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500 dark:text-gray-400">No compositions found</div>';
        return;
    }

    compositions.forEach(comp => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
        });
        
        let isExpanded = false;
        let chart = null;
        
        // Add click handler to the entire card
        card.addEventListener('click', () => {
            isExpanded = !isExpanded;
            const contentSection = card.querySelector('.composition-details');
            if (isExpanded) {
                contentSection.style.display = 'block';
                card.classList.add('expanded');
                // Initialize graph after content is visible
                requestAnimationFrame(() => {
                    const graphId = `composition-graph-${comp.metadata?.name}`;
                    chart = renderCompositionGraph(comp, graphId);
                });
            } else {
                contentSection.style.display = 'none';
                card.classList.remove('expanded');
                if (chart) {
                    chart.dispose();
                    chart = null;
                }
            }
        });

        const status = comp.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';

        card.innerHTML = `
            <div class="px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700">
                <div class="flex items-center min-w-0">
                    <div class="min-w-0">
                        <h3 class="text-sm font-medium text-gray-900 dark:text-white truncate">
                            ${comp.metadata?.name || 'Unnamed'}
                        </h3>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                            ${comp.kind || 'Unknown'} • ${comp.apiVersion || ''} • Created: ${formatTimeAgo(comp.metadata?.creationTimestamp)}
                        </p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button onclick="event.stopPropagation(); window.showDetailsInMonaco(this.getAttribute('data-comp'))"
                                data-comp="${encodeURIComponent(JSON.stringify(comp))}"
                                class="p-1 text-gray-400 hover:text-gray-500" title="View YAML">
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                        <button onclick="event.stopPropagation(); toggleResources(this, ${JSON.stringify(comp.spec?.resources || [])})" 
                                class="p-1 text-gray-400 hover:text-gray-500" title="Show Resources">
                            <svg class="h-4 w-4 transform transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isSynced ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                    }">
                        ${isSynced ? 'Synced' : 'Not Synced'}
                    </span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isReady ? 'Ready' : 'Not Ready'}
                    </span>
                </div>
            </div>
            <div class="composition-details" style="display: none;">
                <div class="px-6 py-4">
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Relations Graph</h3>
                        <div class="overflow-auto" style="max-height: 600px;">
                            <div id="composition-graph-${comp.metadata?.name}" style="width: 100%; height: 500px;"></div>
                        </div>
                    </div>
                    ${comp.spec?.resources ? `
                        <div class="mb-6">
                            <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Resources</h3>
                            <div class="space-y-4">
                                ${comp.spec.resources.map((resource, index) => `
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm text-gray-900 dark:text-white">${resource.name || `Resource ${index + 1}`}</span>
                                        <span class="text-sm text-gray-500">${resource.base?.kind || 'Unknown Kind'}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        container.appendChild(card);
    });
}

// Poll for changes in compositions
async function pollForChanges() {
    try {
        const response = await fetch('/api/compositions');
        if (!response.ok) throw new Error('Failed to fetch compositions');
        const data = await response.json();
        
        // Update the compositions list
        const container = document.getElementById('compositions-list');
        if (container) {
            renderCompositions(container, data.compositions || []);
        }
    } catch (error) {
        console.error('Error polling for changes:', error);
    }
}

// Cleanup when switching tabs
function cleanup() {
    if (compositionsPollingInterval) {
        clearInterval(compositionsPollingInterval);
        compositionsPollingInterval = null;
    }
}

// Toggle resources visibility
function toggleResources(button, resources) {
    // Toggle arrow rotation
    const arrow = button.querySelector('svg');
    const isExpanded = arrow.classList.contains('rotate-90');
    
    if (isExpanded) {
        arrow.classList.remove('rotate-90');
    } else {
        arrow.classList.add('rotate-90');
    }

    // Find or create resources container
    let resourcesContainer = button.parentElement.nextElementSibling;
    if (!resourcesContainer || !resourcesContainer.classList.contains('resources-list')) {
        resourcesContainer = document.createElement('div');
        resourcesContainer.className = 'resources-list pl-4 py-2 space-y-2 border-l-2 border-gray-200 dark:border-gray-700 ml-4';
        button.parentElement.parentElement.insertBefore(resourcesContainer, button.parentElement.nextElementSibling);
    }

    if (isExpanded) {
        resourcesContainer.style.display = 'none';
    } else {
        resourcesContainer.style.display = 'block';
        resourcesContainer.innerHTML = resources.map(resource => `
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-900 dark:text-white">${resource.name || 'Unnamed'}</span>
                <span class="text-gray-500">${resource.base?.kind || 'Unknown Kind'}</span>
            </div>
        `).join('');
    }
}

// Export functions
window.renderCompositions = renderCompositions;
window.cleanup = cleanup;
window.toggleResources = toggleResources;
