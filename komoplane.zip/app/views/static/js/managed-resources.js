// managed-resources.js - Managed Resources functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderManagedResourceDetails(resource) {
    const status = resource.status || {};
    const conditions = status.conditions || [];
    const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    
    const syncedTime = syncedCondition.lastTransitionTime ? 
        formatTimeAgo(syncedCondition.lastTransitionTime) : '';
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Provider</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${resource.provider || resource.display_provider || 'Unknown'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(resource.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            syncedCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${syncedCondition.status === 'True' ? 'Synced' : 'Not Synced'}
                        </span>
                        ${syncedTime ? `<span class="text-xs text-gray-500">${syncedTime}</span>` : ''}
                        ${syncedCondition.message ? `<span class="text-sm text-gray-600">${syncedCondition.message}</span>` : ''}
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            readyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${readyCondition.status === 'True' ? 'Ready' : 'Not Ready'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500">${readyTime}</span>` : ''}
                    </div>
                </div>
            </div>

            ${resource.events && resource.events.length > 0 ? `
                <div>
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                    <div class="space-y-3">
                        ${resource.events.slice(0, 10).map(event => `
                            <div class="flex items-start space-x-3">
                                <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                                    event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                                }"></span>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                                        ${event.reason}
                                        <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.timestamp)}</span>
                                    </p>
                                    <p class="text-sm text-gray-500">${event.message}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function renderManagedResources(data) {
    if (!data) {
        console.error('No data provided to renderManagedResources');
        return;
    }

    updateSummaryCounts(data);

    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'border-b border-gray-200';
    
    const tabsList = document.createElement('nav');
    tabsList.className = 'flex -mb-px';
    tabsContainer.appendChild(tabsList);

    const contentContainer = document.createElement('div');
    contentContainer.className = 'mt-4';

    const container = document.getElementById('managed-resources-list');
    if (!container) return;

    container.innerHTML = '';
    container.appendChild(tabsContainer);
    container.appendChild(contentContainer);

    if (!data.resources || Object.keys(data.resources).length === 0) {
        contentContainer.innerHTML = `
            <div class="p-4 text-center text-gray-500">
                No resources found
            </div>
        `;
        return;
    }

    let isFirstTab = true;
    Object.entries(data.resources).forEach(([kind, groupData]) => {
        const tab = document.createElement('button');
        tab.className = `group relative min-w-0 flex-1 overflow-hidden bg-white py-4 px-4 text-sm font-medium text-center hover:bg-gray-50 focus:z-10 ${
            isFirstTab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 border-b-2 border-transparent'
        }`;
        tab.setAttribute('data-tab', kind);
        tab.innerHTML = `
            <span>${kind}</span>
            <span class="ml-2 text-sm text-gray-400">(${groupData.count || 0})</span>
        `;

        const contentPanel = document.createElement('div');
        contentPanel.className = `${isFirstTab ? '' : 'hidden'} bg-white rounded-lg shadow`;
        contentPanel.setAttribute('data-tab-content', kind);

        contentPanel.innerHTML = `
            <div class="divide-y divide-gray-200">
                ${groupData.resources.map(resource => {
                    const resourceData = btoa(JSON.stringify(resource));
                    return `
                    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150" onclick="(() => {
                        const details = this.querySelector('.managed-resource-details');
                        if (details) {
                            const isExpanded = details.style.display !== 'none';
                            details.style.display = isExpanded ? 'none' : 'block';
                            this.classList.toggle('expanded', !isExpanded);
                        }
                    }).call(this)">
                        <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700">
                            <div class="flex justify-between items-start">
                                <div class="flex-1">
                                    <h4 class="text-lg font-medium text-gray-900 dark:text-white">
                                        ${resource.metadata?.name || 'Unnamed'}
                                        <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${resource.apiVersion || ''}</span>
                                    </h4>
                                    <div class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                        <p>Provider: ${resource.provider || resource.display_provider || 'Unknown'}</p>
                                        <p class="mt-1 text-xs text-gray-400">
                                            Created: ${formatTimeAgo(resource.metadata?.creationTimestamp)}
                                        </p>
                                    </div>
                                </div>
                                <div class="ml-4 flex items-center space-x-2">
                                    <span class="px-2.5 py-0.5 rounded-full text-sm font-medium ${getHealthStatusClass(resource._health_status)}">
                                        ${resource._health_status || 'Unknown'}
                                    </span>
                                    <button 
                                        class="ml-2 p-1 text-gray-400 hover:text-gray-500"
                                        data-resource="${resourceData}"
                                        onclick="event.stopPropagation(); showDetailsInMonaco(JSON.parse(atob(this.dataset.resource)))"
                                        title="View YAML">
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="managed-resource-details" style="display: none;">
                            ${renderManagedResourceDetails(resource)}
                        </div>
                    </div>
                    `;
                }).join('')}
            </div>
        `;

        tab.addEventListener('click', () => {
            document.querySelectorAll('[data-tab]').forEach(t => {
                t.classList.remove('text-blue-600', 'border-blue-600');
                t.classList.add('text-gray-500', 'border-transparent');
            });
            tab.classList.remove('text-gray-500', 'border-transparent');
            tab.classList.add('text-blue-600', 'border-blue-600');

            document.querySelectorAll('[data-tab-content]').forEach(p => {
                p.classList.add('hidden');
            });
            contentPanel.classList.remove('hidden');
        });

        tabsList.appendChild(tab);
        contentContainer.appendChild(contentPanel);
        
        isFirstTab = false;
    });
}

function updateSummaryCounts(data) {
    const elements = {
        total: document.getElementById('total-resources-count'),
        healthy: document.getElementById('healthy-resources-count'),
        unhealthy: document.getElementById('unhealthy-resources-count'),
        unknown: document.getElementById('unknown-resources-count')
    };

    if (elements.total) elements.total.textContent = data.total_count || '0';
    if (elements.healthy) elements.healthy.textContent = data.health_summary?.healthy || '0';
    if (elements.unhealthy) elements.unhealthy.textContent = data.health_summary?.unhealthy || '0';
    if (elements.unknown) elements.unknown.textContent = data.health_summary?.unknown || '0';
}

function processProviderFilter(data, container) {
    const providerFilter = localStorage.getItem('providerFilter');
    if (!providerFilter) return data;

    const filteredData = {
        ...data,
        resources: Object.fromEntries(
            Object.entries(data.resources || {}).filter(([_, group]) =>
                group.resources.some(resource =>
                    resource.provider === providerFilter ||
                    resource.display_provider === providerFilter
                )
            )
        )
    };

    localStorage.removeItem('providerFilter');

    const filterIndicator = createElement('div', {
        className: 'px-4 py-2 bg-blue-50 text-blue-700 mb-4 flex justify-between items-center'
    });
    
    filterIndicator.innerHTML = `
        <span>Filtered by Provider: ${providerFilter}</span>
        <button class="text-sm bg-blue-100 px-2 py-1 rounded hover:bg-blue-200" onclick="clearProviderFilter()">
            Clear Filter
        </button>
    `;
    
    container.appendChild(filterIndicator);
    
    return filteredData;
}

function clearProviderFilter() {
    localStorage.removeItem('providerFilter');
    loadTabData('managed-resources');
}

// Export functions
window.renderManagedResources = renderManagedResources;
window.clearProviderFilter = clearProviderFilter;
