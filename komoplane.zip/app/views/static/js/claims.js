// claims.js - Claims functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderClaimDetails(claim) {
    const status = claim.status || {};
    const conditions = status.conditions || [];
    const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const reconcileCondition = conditions.find(c => c.type === 'ReconcileSuccess') || {};
    
    const syncedTime = syncedCondition.lastTransitionTime ? 
        formatTimeAgo(syncedCondition.lastTransitionTime) : '';
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${claim.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${claim.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Namespace</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${claim.metadata?.namespace || 'default'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(claim.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            syncedCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${syncedCondition.status === 'True' ? 'Synced' : 'Not Synced'}
                        </span>
                        ${syncedTime ? `<span class="text-xs text-gray-500">${syncedTime}</span>` : ''}
                        ${syncedCondition.message ? `<span class="text-sm text-gray-600">${syncedCondition.message}</span>` : ''}
                    </div>
                    ${reconcileCondition.status === 'True' ? `
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                                ReconcileSuccess
                            </span>
                        </div>
                    ` : ''}
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            readyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${readyCondition.status === 'True' ? 'Ready' : 'Not Ready'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500">${readyTime}</span>` : ''}
                        ${!readyCondition.status === 'True' ? `
                            <span class="text-sm text-yellow-600">Waiting: Claim is waiting for composite resource to become Ready</span>
                        ` : ''}
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Relations Graph</h3>
                <div class="overflow-auto" style="max-height: 600px;">
                    <div id="relations-graph-${claim.metadata?.name}" style="width: 100%; height: 500px;"></div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Relations Details</h3>
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Composition</h4>
                        ${claim.composition ? `
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-900 dark:text-white">${claim.composition.name}</span>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                    claim.composition.ready ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                                }">
                                    ${claim.composition.ready ? 'Ready' : 'Not Ready'}
                                </span>
                            </div>
                        ` : '<p class="text-sm text-gray-500">No composition</p>'}
                    </div>
                    <div>
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Composite Resource</h4>
                        ${claim.compositeResource ? `
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-900 dark:text-white">${claim.compositeResource.name}</span>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                    claim.compositeResource.ready ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                                }">
                                    ${claim.compositeResource.ready ? 'Ready' : 'Not Ready'}
                                </span>
                            </div>
                        ` : '<p class="text-sm text-gray-500">No composite resource</p>'}
                    </div>
                </div>
            </div>

                ${claim.events && claim.events.length > 0 ? `
                    <div>
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                        <div class="space-y-3">
                            ${claim.events.slice(0, 10).map(event => `
                                <div class="flex items-start space-x-3">
                                    <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                                        event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                                    }"></span>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                                            ${event.reason}
                                            <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.timestamp)}</span>
                                        </p>
                                        <p class="text-sm text-gray-500">${event.message}</p>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

function renderClaimGraph(claim, containerId) {
    const chart = echarts.init(document.getElementById(containerId));
    const isDarkMode = document.documentElement.classList.contains('dark');
    
    // Prepare nodes and links data
    const nodes = [];
    const links = [];
    
    // Simple SVG paths for icons
    const icons = {
        base: {
            claim: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
            composition: 'path://M3 3h18v18H3z M7 7h10v10H7z',
            resource: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
        },
        status: {
            on: 'path://M25 0L23.6 1.4 27.2 5 23.6 8.6 25 10 30 5z',
            off: 'path://M30 1.4L28.6 0 25 3.6 21.4 0 20 1.4 23.6 5 20 8.6 21.4 10 25 6.4 28.6 10 30 8.6 26.4 5z'
        },
        combined: {
            claim: {
                on: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5 M25 0L23.6 1.4 27.2 5 23.6 8.6 25 10 30 5z',
                off: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5 M30 1.4L28.6 0 25 3.6 21.4 0 20 1.4 23.6 5 20 8.6 21.4 10 25 6.4 28.6 10 30 8.6 26.4 5z'
            },
            composition: {
                on: 'path://M3 3h18v18H3z M7 7h10v10H7z M25 0L23.6 1.4 27.2 5 23.6 8.6 25 10 30 5z',
                off: 'path://M3 3h18v18H3z M7 7h10v10H7z M30 1.4L28.6 0 25 3.6 21.4 0 20 1.4 23.6 5 20 8.6 21.4 10 25 6.4 28.6 10 30 8.6 26.4 5z'
            },
            resource: {
                on: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z M25 0L23.6 1.4 27.2 5 23.6 8.6 25 10 30 5z',
                off: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z M30 1.4L28.6 0 25 3.6 21.4 0 20 1.4 23.6 5 20 8.6 21.4 10 25 6.4 28.6 10 30 8.6 26.4 5z'
            }
        }
    };

    // Node colors
    const colors = {
        claim: '#6B7CFF',      // Light purple for claims
        composition: '#4ADE80', // Light green for compositions
        resource: '#FBBF24'    // Light orange/yellow for composite resources
    };

    // Get claim status
    const status = claim.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const isReady = readyCondition.status === 'True';

    // Add claim node
    nodes.push({
        id: claim.metadata?.name,
        name: claim.metadata?.name,
            symbol: isReady ? icons.combined.claim.on : icons.combined.claim.off,
        symbolSize: 40,
        category: 0,
        itemStyle: {
            color: colors.claim,
            opacity: 1
        },
        label: {
            show: true,
            formatter: '{b}',
            position: 'right',
            distance: 5,
            color: isDarkMode ? '#e5e7eb' : '#374151'
        },
        tooltip: {
            formatter: () => `
                ${claim.metadata?.name}
                Status: ${isReady ? '✓ Ready' : '⧖ Not Ready'}
            `
        }
    });

    // Add composition node and link if exists
    if (claim.composition?.name) {
        nodes.push({
            id: claim.composition.name,
            name: claim.composition.name,
            symbol: claim.composition.ready ? icons.combined.composition.on : icons.combined.composition.off,
            symbolSize: 35,
            category: 1,
            itemStyle: {
                color: colors.composition,
                opacity: 1
            },
            label: {
                show: true,
                formatter: '{b}',
                position: 'right',
                distance: 5,
                color: isDarkMode ? '#e5e7eb' : '#374151'
            },
            tooltip: {
                formatter: () => `
                    ${claim.composition.name}
                    Status: ${claim.composition.ready ? '✓ Ready' : '⧖ Not Ready'}
                `
            }
        });
        links.push({
            source: claim.metadata?.name,
            target: claim.composition.name,
            lineStyle: {
                color: '#6b7280',
                width: 2,
                opacity: 0.8,
                type: 'solid'
            }
        });
    }

    // Add composite resource node and link if exists
    if (claim.compositeResource?.name) {
        nodes.push({
            id: claim.compositeResource.name,
            name: claim.compositeResource.name,
            symbol: claim.compositeResource.ready ? icons.combined.resource.on : icons.combined.resource.off,
            symbolSize: 35,
            category: 2,
            itemStyle: {
                color: colors.resource,
                opacity: 1
            },
            label: {
                show: true,
                formatter: '{b}',
                position: 'right',
                distance: 5,
                color: isDarkMode ? '#e5e7eb' : '#374151'
            },
            tooltip: {
                formatter: () => `
                    ${claim.compositeResource.name}
                    Status: ${claim.compositeResource.ready ? '✓ Ready' : '⧖ Not Ready'}
                `
            }
        });
        links.push({
            source: claim.metadata?.name,
            target: claim.compositeResource.name,
            lineStyle: {
                color: '#6b7280',
                width: 2,
                opacity: 0.8,
                type: 'solid'
            }
        });
    }

    const option = {
        backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
        tooltip: {
            trigger: 'item',
            formatter: (params) => {
                if (params.dataType === 'node') {
                    return params.data.tooltip?.formatter() || params.name;
                }
                return params.name;
            }
        },
        legend: {
            show: true,
            top: '5%',
            left: 'center',
            orient: 'horizontal',
            itemGap: 30,
            itemWidth: 30,
            itemHeight: 16,
            data: [
                {
                    name: 'Claim',
                    icon: icons.base.claim,
                    itemStyle: { color: colors.claim }
                },
                {
                    name: 'Composition',
                    icon: icons.base.composition,
                    itemStyle: { color: colors.composition }
                },
                {
                    name: 'Composite Resource',
                    icon: icons.base.resource,
                    itemStyle: { color: colors.resource }
                }
            ],
            textStyle: {
                color: isDarkMode ? '#e5e7eb' : '#374151'
            }
        },
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',
        series: [{
            type: 'graph',
            layout: 'force',
            data: nodes,
            links: links,
            categories: [
                { name: 'Claim' },
                { name: 'Composition' },
                { name: 'Composite Resource' }
            ],
            roam: true,
            force: {
                repulsion: 1000,
                edgeLength: [150, 200],
                gravity: 0.2
            },
            lineStyle: {
                color: '#6b7280',
                width: 2,
                opacity: 0.8,
                type: 'solid',
                curveness: 0.3
            },
            symbol: ['none', 'arrow'],
            symbolSize: [10, 15]
        }]
    };

    chart.setOption(option);
    
    // Handle window resize
    window.addEventListener('resize', () => {
        chart.resize();
    });

    // Prevent graph clicks from propagating to card
    const graphElement = document.getElementById(containerId);
    graphElement.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    return chart;
}

window.renderClaims = function(container, claims) {
    if (!claims || claims.length === 0) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500 dark:text-gray-400">No claims found</div>';
        return;
    }

    claims.forEach(claim => {
        const card = window.createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
        });
        
        let isExpanded = false;
        let chart = null;
        const expandedContent = renderClaimDetails(claim);
        
        // Add click handler to the entire card
        card.addEventListener('click', () => {
            isExpanded = !isExpanded;
            const contentSection = card.querySelector('.claim-details');
            if (isExpanded) {
                contentSection.style.display = 'block';
                card.classList.add('expanded');
                // Initialize graph after content is visible
                setTimeout(() => {
                    const graphId = `relations-graph-${claim.metadata?.name}`;
                    chart = renderClaimGraph(claim, graphId);
                }, 100);
            } else {
                contentSection.style.display = 'none';
                card.classList.remove('expanded');
                if (chart) {
                    chart.dispose();
                    chart = null;
                }
            }
        });

        const status = claim.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const reconcileCondition = conditions.find(c => c.type === 'ReconcileSuccess') || {};
        
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';
        const isReconciled = reconcileCondition.status === 'True';

        const creationTime = claim.metadata?.creationTimestamp ? 
            formatTimeAgo(claim.metadata.creationTimestamp) : 'Unknown';
        
        const syncedTime = syncedCondition.lastTransitionTime ? 
            formatTimeAgo(syncedCondition.lastTransitionTime) : '';
        const readyTime = readyCondition.lastTransitionTime ? 
            formatTimeAgo(readyCondition.lastTransitionTime) : '';

        card.innerHTML = `
            <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700 sm:px-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <div>
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                                ${claim.metadata?.name || 'Unnamed'}
                                <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${claim.apiVersion || ''}</span>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                Kind: ${claim.kind || 'Unknown'} | Namespace: ${claim.metadata?.namespace || 'default'} | Created: ${creationTime}
                            </p>
                        </div>
                        <button onclick="event.stopPropagation(); showDetailsInMonaco(${JSON.stringify(claim).replace(/'/g, "\\'").replace(/"/g, "&quot;")})"
                                class="p-1 text-gray-400 hover:text-gray-500" title="View YAML">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                    <div class="flex flex-col space-y-2">
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                isSynced ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                            }">
                                ${isSynced ? 'Synced' : 'Not Synced'}
                            </span>
                            ${syncedTime ? `<span class="text-xs text-gray-500 dark:text-gray-400">${syncedTime}</span>` : ''}
                        </div>
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                            }">
                                ${isReady ? 'Ready' : 'Not Ready'}
                            </span>
                            ${readyTime ? `<span class="text-xs text-gray-500 dark:text-gray-400">${readyTime}</span>` : ''}
                        </div>
                        ${isReconciled ? `
                            <div class="flex items-center space-x-2">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                                    ReconcileSuccess
                                </span>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
            <div class="claim-details" style="display: none;">
                ${expandedContent}
            </div>
        `;

        container.appendChild(card);
    });
}

// Export functions
window.renderClaims = renderClaims;
