// composite-resources.js
let lastResourcesState = [];
let eventsPollingInterval;

// Helper function to format timestamps in a human-readable way
function formatTimeAgo(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
        return `${days}d ago`;
    } else if (hours > 0) {
        return `${hours}h ago`;
    } else if (minutes > 0) {
        return `${minutes}m ago`;
    } else {
        return 'just now';
    }
}

// Helper function to create DOM elements with attributes
function createElement(tag, attributes = {}) {
    const element = document.createElement(tag);
    Object.entries(attributes).forEach(([key, value]) => {
        if (key === 'className') {
            element.className = value;
        } else {
            element.setAttribute(key, value);
        }
    });
    return element;
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('composite-resources-search');
    const statusFilter = document.getElementById('composite-resources-status-filter');

    if (searchInput) {
        searchInput.addEventListener('input', _.debounce(() => applyFilters(), 300));
    }
    if (statusFilter) {
        statusFilter.addEventListener('change', () => applyFilters());
    }
});

function renderCompositeResources(container, resources) {
    // Store current state for comparison
    const previousState = lastResourcesState;
    lastResourcesState = JSON.parse(JSON.stringify(resources || []));

    // Compare states and generate events
    if (previousState.length > 0) {
        generateEvents(previousState, lastResourcesState);
    }

    // Start polling for changes if not already started
    if (!eventsPollingInterval) {
        eventsPollingInterval = setInterval(pollForChanges, 30000); // Poll every 30 seconds
    }

    // Apply filters before rendering
    const filteredResources = filterResources(resources || []);
    
    if (!filteredResources || filteredResources.length === 0) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500 dark:text-gray-400">No composite resources found</div>';
        return;
    }

    filteredResources.forEach(resource => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4'
        });

        // Header content
        const status = resource.status || {};
        const conditions = status.conditions || [];
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        
        const isSynced = syncedCondition.status === 'True';
        const isReady = readyCondition.status === 'True';
        const creationTime = resource.metadata?.creationTimestamp ? 
            formatTimeAgo(resource.metadata.creationTimestamp) : 'Unknown';

        // Create the header section
        const headerHTML = `
            <div class="px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700">
                <div class="flex items-center min-w-0">
                    <div class="min-w-0">
                        <h3 class="text-sm font-medium truncate ${isReady ? 'text-gray-900 dark:text-white' : 'text-red-600 dark:text-red-400'}">
                            ${resource.metadata?.name || 'Unnamed'}
                        </h3>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                            ${resource.kind || 'Unknown'} • ${resource.apiVersion || ''} • Created: ${creationTime}
                        </p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button class="view-yaml-btn ml-2 p-1 text-gray-400 hover:text-gray-500" title="View YAML">
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                        <button class="toggle-content-btn p-1 text-gray-400 hover:text-gray-500" title="Toggle Details">
                            <svg class="h-4 w-4 transform transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isSynced ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                    }">
                        ${isSynced ? 'Synced' : 'Not Synced'}
                    </span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                    }">
                        ${isReady ? 'Ready' : 'Not Ready'}
                    </span>
                </div>
            </div>`;

        // Details container section
        const detailsContainerHTML = `
            <div class="graph-content hidden">
                <div class="px-6 py-4">
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Relations Graph</h3>
                        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4" style="height: 800px;">
                            <div id="relations-graph-${resource.metadata?.name}" style="width: 100%; height: 100%;"></div>
                        </div>
                    </div>

                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                        <div id="resource-events-${resource.metadata?.name}" class="space-y-3">
                            <!-- Events will be dynamically inserted here -->
                        </div>
                    </div>
                </div>
            </div>`;

        // Combine sections
        card.innerHTML = headerHTML + detailsContainerHTML;

        // Add event listeners
        const viewYamlBtn = card.querySelector('.view-yaml-btn');
        const toggleBtn = card.querySelector('.toggle-content-btn');
        const graphContent = card.querySelector('.graph-content');
        const toggleIcon = toggleBtn.querySelector('svg');
        let chart = null;

        viewYamlBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showDetailsInMonaco(resource);
        });

        toggleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isExpanded = !graphContent.classList.contains('hidden');
            if (!isExpanded) {
                graphContent.classList.remove('hidden');
                toggleIcon.classList.add('rotate-180');
                
                // Initialize graph
                const graphContainer = document.getElementById(`relations-graph-${resource.metadata?.name}`);
                if (graphContainer && !chart) {
                    setTimeout(() => {
                        chart = renderCompositeResourceGraph(resource, `relations-graph-${resource.metadata?.name}`);
                        if (chart) {
                            chart.resize();
                        }
                    }, 100);
                }
            } else {
                graphContent.classList.add('hidden');
                toggleIcon.classList.remove('rotate-180');
                if (chart) {
                    chart.dispose();
                    chart = null;
                }
            }
        });

        container.appendChild(card);

        // Add initial event
        const eventsContainer = document.getElementById(`resource-events-${resource.metadata?.name}`);
        if (eventsContainer) {
            const event = {
                type: 'Normal',
                reason: 'ComposeResources',
                message: 'Successfully composed resources',
                time: new Date(),
                resource: resource
            };
            renderEvents(eventsContainer, [event]);
        }
    });
}

function renderCompositeResourceGraph(resource, containerId) {
    const graphContainer = document.getElementById(containerId);
    if (!graphContainer) {
        console.error('Graph container not found');
        return null;
    }

    const chart = echarts.init(graphContainer);
    const isDarkMode = document.documentElement.classList.contains('dark');

    // Get resource status
    const status = resource.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const isReady = readyCondition.status === 'True';

    // Prepare nodes and links data
    const nodes = [];
    const links = [];

    // Icons for nodes
    const icons = {
        claim: 'path://M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
        composition: 'path://M3 3h18v18H3z M7 7h10v10H7z',
        resource: 'path://M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
    };

    // Add composite resource node (centered)
    const compositeNode = {
        id: resource.metadata?.name,
        name: resource.metadata?.name,
        symbolSize: [60, 60],
        symbol: icons.resource,
        category: 0,
        x: graphContainer.clientWidth / 2,
        y: graphContainer.clientHeight / 2,
        itemStyle: {
            color: '#FBBF24',
            borderColor: isDarkMode ? '#374151' : '#D1D5DB',
            borderWidth: 2
        },
        label: {
            show: true,
            position: 'right',
            formatter: [
                '{b}',
                `(${resource.kind})`
            ].join('\n'),
            color: isReady ? (isDarkMode ? '#E5E7EB' : '#374151') : (isDarkMode ? '#F87171' : '#DC2626')
        }
    };
    nodes.push(compositeNode);

    // Add claim if exists
    if (resource.spec?.claimRef) {
        const claimNode = {
            id: 'claim-' + resource.spec.claimRef.name,
            name: resource.spec.claimRef.name,
            symbolSize: [50, 50],
            symbol: icons.claim,
            category: 1,
            itemStyle: {
                color: '#A78BFA',
                borderColor: isDarkMode ? '#374151' : '#D1D5DB',
                borderWidth: 2
            },
            label: {
                show: true,
                position: 'top',
                formatter: [
                    '{b}',
                    '(Claim)'
                ].join('\n'),
                color: isDarkMode ? '#E5E7EB' : '#374151'
            }
        };
        nodes.push(claimNode);
        links.push({
            source: claimNode.id,
            target: compositeNode.id,
            symbolSize: [5, 12],
            lineStyle: {
                color: '#A78BFA',
                width: 2,
                type: 'solid',
                curveness: 0.2
            },
            label: {
                show: true,
                formatter: 'claims'
            }
        });
    }

    // Add composition if exists
    if (resource.spec?.compositionRef) {
        const compositionNode = {
            id: 'composition-' + resource.spec.compositionRef.name,
            name: resource.spec.compositionRef.name,
            symbolSize: [50, 50],
            symbol: icons.composition,
            category: 2,
            itemStyle: {
                color: '#4ADE80',
                borderColor: isDarkMode ? '#374151' : '#D1D5DB',
                borderWidth: 2
            },
            label: {
                show: true,
                position: 'right',
                formatter: [
                    '{b}',
                    '(Composition)'
                ].join('\n'),
                color: isDarkMode ? '#E5E7EB' : '#374151'
            }
        };
        nodes.push(compositionNode);
        links.push({
            source: compositeNode.id,
            target: compositionNode.id,
            symbolSize: [5, 12],
            lineStyle: {
                color: '#4ADE80',
                width: 2,
                type: 'dashed',
                curveness: 0.2
            },
            label: {
                show: true,
                formatter: 'uses'
            }
        });
    }

    // Add managed resources
    if (resource.spec?.resourceRefs) {
        resource.spec.resourceRefs.forEach((ref, index) => {
            const managedNode = {
                id: 'managed-' + ref.name,
                name: ref.name,
                symbolSize: [50, 50],
                symbol: icons.resource,
                category: 3,
                itemStyle: {
                    color: '#60A5FA',
                    borderColor: isDarkMode ? '#374151' : '#D1D5DB',
                    borderWidth: 2
                },
                label: {
                    show: true,
                    position: 'right',
                    formatter: [
                        '{b}',
                        `(${ref.kind})`
                    ].join('\n'),
                    color: isDarkMode ? '#E5E7EB' : '#374151'
                }
            };
            nodes.push(managedNode);
            links.push({
                source: compositeNode.id,
                target: managedNode.id,
                symbolSize: [5, 12],
                lineStyle: {
                    color: '#60A5FA',
                    width: 2,
                    type: 'solid',
                    curveness: 0.2
                },
                label: {
                    show: true,
                    formatter: 'manages'
                }
            });
        });
    }

    const option = {
        backgroundColor: isDarkMode ? '#1F2937' : '#FFFFFF',
        tooltip: {
            show: true,
            trigger: 'item',
            formatter: '{b}'
        },
        legend: {
            show: true,
            top: '20',
            left: '20',
            orient: 'vertical',
            itemGap: 20,
            itemWidth: 30,
            itemHeight: 16,
            data: [
                {
                    name: 'Composite',
                    icon: icons.resource,
                    itemStyle: { color: '#FBBF24' }
                },
                {
                    name: 'Claim',
                    icon: icons.claim,
                    itemStyle: { color: '#A78BFA' }
                },
                {
                    name: 'Composition',
                    icon: icons.composition,
                    itemStyle: { color: '#4ADE80' }
                },
                {
                    name: 'Managed',
                    icon: icons.resource,
                    itemStyle: { color: '#60A5FA' }
                }
            ],
            textStyle: {
                color: isDarkMode ? '#e5e7eb' : '#374151'
            }
        },
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',
        series: [{
            type: 'graph',
            layout: 'force',
            force: {
                repulsion: 2500,
                edgeLength: 300,
                gravity: 0.05,
                layoutAnimation: true
            },
            data: nodes,
            links: links,
            categories: ['Composite', 'Claim', 'Composition', 'Managed'].map(name => ({
                name: name
            })),
            roam: true,
            label: {
                position: 'right',
                formatter: '{b}'
            },
            lineStyle: {
                color: 'source',
                curveness: 0.3
            },
            emphasis: {
                focus: 'adjacency',
                lineStyle: {
                    width: 10
                }
            },
            edgeSymbol: ['circle', 'arrow'],
            edgeSymbolSize: [4, 10]
        }]
    };

    chart.setOption(option);

    // Prevent clicks on the graph from bubbling up
    graphContainer.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
    });

    // Handle resize
    window.addEventListener('resize', () => chart.resize());

    return chart;
}

// Helper function to render events in a container
function renderEvents(container, events) {
    if (events.length > 0) {
        events.forEach(event => {
            const eventElement = document.createElement('div');
            eventElement.className = 'flex items-start space-x-3';
            eventElement.innerHTML = `
                <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                    event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                }"></span>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                        ${event.reason}
                        <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.time)}</span>
                    </p>
                    <p class="text-sm text-gray-500">${event.message}</p>
                </div>
            `;
            container.insertBefore(eventElement, container.firstChild);
        });

        // Limit the number of events shown
        while (container.children.length > 10) {
            container.removeChild(container.lastChild);
        }
    }
}

// Generate events by comparing previous and current states
function generateEvents(previousState, currentState) {
    // Check for new or modified resources
    currentState.forEach(current => {
        const eventsContainer = document.getElementById(`resource-events-${current.metadata?.name}`);
        if (!eventsContainer) return;

        const events = [];
        const previous = previousState.find(p => p.metadata?.name === current.metadata?.name);
        
        if (!previous) {
            events.push({
                type: 'Normal',
                reason: 'ComposeResources',
                message: 'Successfully composed resources',
                time: new Date(),
                resource: current
            });
        } else {
            // Check for status changes
            const prevStatus = previous.status?.conditions || [];
            const currStatus = current.status?.conditions || [];
            const prevReady = prevStatus.find(c => c.type === 'Ready')?.status;
            const currReady = currStatus.find(c => c.type === 'Ready')?.status;
            const prevSynced = prevStatus.find(c => c.type === 'Synced')?.status;
            const currSynced = currStatus.find(c => c.type === 'Synced')?.status;

            if (prevReady !== currReady || prevSynced !== currSynced) {
                events.push({
                    type: 'Normal',
                    reason: 'ComposeResources',
                    message: 'Successfully composed resources',
                    time: new Date(),
                    resource: current
                });
            }
        }

        renderEvents(eventsContainer, events);
    });

    // Check for deleted resources
    previousState.forEach(previous => {
        const stillExists = currentState.some(c => c.metadata?.name === previous.metadata?.name);
        if (!stillExists) {
            const eventsContainer = document.getElementById(`resource-events-${previous.metadata?.name}`);
            if (eventsContainer) {
                const events = [{
                    type: 'Warning',
                    reason: 'Deleted',
                    message: 'Resource was deleted',
                    time: new Date(),
                    resource: previous
                }];
                renderEvents(eventsContainer, events);
            }
        }
    });
}

// Filter resources based on search and status
function filterResources(resources) {
    const searchTerm = document.getElementById('composite-resources-search')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('composite-resources-status-filter')?.value || '';

    return resources.filter(resource => {
        // Apply search filter
        const name = resource.metadata?.name?.toLowerCase() || '';
        const kind = resource.kind?.toLowerCase() || '';
        const matchesSearch = !searchTerm || 
            name.includes(searchTerm) || 
            kind.includes(searchTerm);

        // Apply status filter
        const status = resource.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const syncedCondition = conditions.find(c => c.type === 'Synced') || {};
        const isReady = readyCondition.status === 'True';
        const isSynced = syncedCondition.status === 'True';

        let matchesStatus = true;
        if (statusFilter) {
            switch (statusFilter) {
                case 'Ready':
                    matchesStatus = isReady;
                    break;
                case 'NotReady':
                    matchesStatus = !isReady;
                    break;
                case 'Synced':
                    matchesStatus = isSynced;
                    break;
                case 'NotSynced':
                    matchesStatus = !isSynced;
                    break;
            }
        }

        return matchesSearch && matchesStatus;
    });
}

// Poll for changes in resources
async function pollForChanges() {
    try {
        const response = await fetch('/api/composite-resources');
        if (!response.ok) throw new Error('Failed to fetch resources');
        const data = await response.json();
        
        // Update the resources list
        const container = document.getElementById('composite-resources-list');
        if (container) {
            renderCompositeResources(container, data.resources || []);
        }
    } catch (error) {
        console.error('Error polling for changes:', error);
    }
}

// Cleanup when switching tabs
function cleanup() {
    if (eventsPollingInterval) {
        clearInterval(eventsPollingInterval);
        eventsPollingInterval = null;
    }
}

// Apply filters and re-render resources
function applyFilters() {
    const container = document.getElementById('composite-resources-list');
    if (container && lastResourcesState.length > 0) {
        container.innerHTML = ''; // Clear current content
        renderCompositeResources(container, lastResourcesState);
    }
}

// Make functions globally available
window.renderCompositeResources = renderCompositeResources;
window.renderCompositeResourceGraph = renderCompositeResourceGraph;
window.cleanup = cleanup;
window.applyFilters = applyFilters;
