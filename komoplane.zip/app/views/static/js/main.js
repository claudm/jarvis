// main.js
document.addEventListener('DOMContentLoaded', () => {
    loadInitialData();
});

// Carrega os dados iniciais (por padrão, carrega as compositions)
function loadInitialData() {
    // Encontra a tab ativa ou usa 'compositions' como padrão
    const activeTab = document.querySelector('.tab-button.active');
    const tabId = activeTab ? activeTab.dataset.tab : 'compositions';
    
    // Carrega os dados para a tab ativa
    loadTabData(tabId);
}
