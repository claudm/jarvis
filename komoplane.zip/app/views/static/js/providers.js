// providers.js - Providers functionality
function formatTimeAgo(timestamp) {
    if (!timestamp) return '';
    const now = new Date();
    const past = new Date(timestamp);
    const diffInHours = Math.floor((now - past) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
}

function renderProviderDetails(provider) {
    const status = provider.status || {};
    const conditions = status.conditions || [];
    const readyCondition = conditions.find(c => c.type === 'Ready') || {};
    const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
    
    const readyTime = readyCondition.lastTransitionTime ? 
        formatTimeAgo(readyCondition.lastTransitionTime) : '';
    const healthyTime = healthyCondition.lastTransitionTime ? 
        formatTimeAgo(healthyCondition.lastTransitionTime) : '';

    return `
        <div class="px-6 py-4">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Configuration</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">API Version</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${provider.apiVersion || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Kind</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${provider.kind || ''}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Package</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${provider.spec?.package || 'Unknown'}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">${formatTimeAgo(provider.metadata?.creationTimestamp)}</dd>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Status</h3>
                <div class="space-y-4">
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            readyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        }">
                            ${readyCondition.status === 'True' ? 'Ready' : 'Not Ready'}
                        </span>
                        ${readyTime ? `<span class="text-xs text-gray-500">${readyTime}</span>` : ''}
                        ${readyCondition.message ? `<span class="text-sm text-gray-600">${readyCondition.message}</span>` : ''}
                    </div>
                    ${healthyCondition ? `
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                healthyCondition.status === 'True' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                            }">
                                ${healthyCondition.status === 'True' ? 'Healthy' : 'Not Healthy'}
                            </span>
                            ${healthyTime ? `<span class="text-xs text-gray-500">${healthyTime}</span>` : ''}
                        </div>
                    ` : ''}
                </div>
            </div>

            ${provider.events && provider.events.length > 0 ? `
                <div>
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Recent Events</h3>
                    <div class="space-y-3">
                        ${provider.events.slice(0, 10).map(event => `
                            <div class="flex items-start space-x-3">
                                <span class="flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                                    event.type === 'Normal' ? 'bg-green-400' : 'bg-yellow-400'
                                }"></span>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                                        ${event.reason}
                                        <span class="ml-2 text-xs text-gray-500">${formatTimeAgo(event.timestamp)}</span>
                                    </p>
                                    <p class="text-sm text-gray-500">${event.message}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function renderProviders(container, providers) {
    if (!providers.length) {
        container.innerHTML = '<div class="p-4 text-center text-gray-500">No providers found</div>';
        return;
    }

    providers.forEach(provider => {
        const card = createElement('div', {
            className: 'bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150'
        });
        
        let isExpanded = false;
        const expandedContent = renderProviderDetails(provider);
        
        // Add click handler to the entire card
        card.addEventListener('click', () => {
            isExpanded = !isExpanded;
            const contentSection = card.querySelector('.provider-details');
            if (isExpanded) {
                contentSection.style.display = 'block';
                card.classList.add('expanded');
            } else {
                contentSection.style.display = 'none';
                card.classList.remove('expanded');
            }
        });

        const status = provider.status || {};
        const conditions = status.conditions || [];
        const readyCondition = conditions.find(c => c.type === 'Ready') || {};
        const healthyCondition = conditions.find(c => c.type === 'Healthy') || {};
        
        const isReady = readyCondition.status === 'True';
        const isHealthy = healthyCondition?.status === 'True';

        const creationTime = provider.metadata?.creationTimestamp ? 
            formatTimeAgo(provider.metadata.creationTimestamp) : 'Unknown';

        card.innerHTML = `
            <div class="px-4 py-5 border-b border-gray-200 dark:border-gray-700 sm:px-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <div>
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                                ${provider.metadata?.name || 'Unnamed'}
                                <span class="ml-2 text-sm text-gray-500 dark:text-gray-400">${provider.apiVersion || ''}</span>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                Package: ${provider.spec?.package || 'Unknown'} | Created: ${creationTime}
                            </p>
                        </div>
                        <button onclick="event.stopPropagation(); showDetailsInMonaco(${JSON.stringify(provider).replace(/'/g, "\\'").replace(/"/g, "&quot;")})" 
                                class="p-1 text-gray-400 hover:text-gray-500"
                                title="View YAML">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                    <div class="flex flex-col space-y-2">
                        <div class="flex items-center space-x-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                isReady ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                            }">
                                ${isReady ? 'Ready' : 'Not Ready'}
                            </span>
                        </div>
                        ${healthyCondition ? `
                            <div class="flex items-center space-x-2">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                    isHealthy ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                                }">
                                    ${isHealthy ? 'Healthy' : 'Not Healthy'}
                                </span>
                            </div>
                        ` : ''}
                        <button onclick="event.stopPropagation(); localStorage.setItem('providerFilter', '${provider.metadata?.name}'); switchTab('managed-resources');" 
                                class="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
                            View Managed Resources
                        </button>
                    </div>
                </div>
            </div>
            <div class="provider-details" style="display: none;">
                ${expandedContent}
            </div>
        `;

        container.appendChild(card);
    });

    // Initialize provider search
    initializeProviderSearch();
}

function initializeProviderSearch() {
    const providerSearch = document.getElementById('provider-search');
    if (providerSearch) {
        // Show the search container when on providers tab
        const searchContainer = document.getElementById('provider-search-container');
        if (searchContainer) {
            searchContainer.classList.remove('hidden');
        }

        providerSearch.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const providersList = document.getElementById('providers-list');
            if (providersList) {
                const providers = providersList.children;
                Array.from(providers).forEach(provider => {
                    const name = provider.querySelector('h3').textContent.toLowerCase();
                    const package = provider.querySelector('p').textContent.toLowerCase();
                    if (name.includes(searchTerm) || package.includes(searchTerm)) {
                        provider.style.display = '';
                    } else {
                        provider.style.display = 'none';
                    }
                });
            }
        });
    }
}

// Export functions
window.renderProviders = renderProviders;
