// overview.js - Overview functionality
function renderOverview(data) {
    if (!data || !data.data) {
        console.error('Invalid overview data');
        return;
    }

    const overview = data.data;

    // Update Crossplane status
    const crossplaneHealth = document.getElementById('crossplane-health');
    const crossplaneVersion = document.getElementById('crossplane-version');
    
    if (crossplaneHealth) {
        const health = overview.crossplane?.health || 'Unknown';
        console.log('Crossplane health status:', health);
        crossplaneHealth.textContent = health;
        const statusClass = getHealthStatusClass(health);
        console.log('Applied health status class:', statusClass);
        crossplaneHealth.className = `px-3 py-1 rounded-full text-sm font-medium ${statusClass}`;
    }
    
    if (crossplaneVersion) {
        crossplaneVersion.textContent = `Version: ${overview.crossplane?.version || 'Unknown'}`;
    }

    // Update pod status
    const podsContainer = document.getElementById('crossplane-pods');
    if (podsContainer && overview.crossplane?.pods) {
        podsContainer.innerHTML = '';
        overview.crossplane.pods.forEach(pod => {
            const podElement = document.createElement('div');
            podElement.className = 'bg-white rounded-lg shadow-sm p-3';
            
            // Pod header with name and status
            const podHeader = document.createElement('div');
            podHeader.className = 'flex items-center justify-between mb-2';
            podHeader.innerHTML = `
                <span class="font-medium text-gray-900">${pod.name}</span>
                <span class="px-2 py-1 rounded-full text-xs font-medium ${getHealthStatusClass(pod.status)}">${pod.status}</span>
            `;
            podElement.appendChild(podHeader);

            // Container statuses
            pod.containers.forEach(container => {
                const containerElement = document.createElement('div');
                containerElement.className = 'flex items-center justify-between text-sm mt-2 border-t pt-2';
                containerElement.innerHTML = `
                    <span class="text-gray-600">${container.name}</span>
                    <div class="flex items-center space-x-2">
                        <span class="${getHealthStatusClass(container.status)} px-2 py-0.5 rounded-full text-xs">${container.status}</span>
                        ${container.restarts > 0 ? 
                            `<span class="text-gray-500 text-xs">Restarts: ${container.restarts}</span>` : 
                            ''}
                    </div>
                `;
                podElement.appendChild(containerElement);
            });

            podsContainer.appendChild(podElement);
        });
    }

    // Update counts
    const updateCount = (id, value) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value || '0';
        }
    };

    updateCount('claims-count', overview.claims?.count);
    updateCount('composite-resources-count', overview.composite_resources?.count);
    updateCount('managed-resources-count', overview.managed_resources?.total_count);
    updateCount('providers-count', overview.providers?.count);
    updateCount('compositions-count', overview.compositions?.count);
    updateCount('composite-resource-definitions-count', overview.composite_resource_definitions?.count);

    // Update health status
    const healthSummary = overview.managed_resources?.health_summary || {};
    const total = (healthSummary.healthy || 0) + (healthSummary.unhealthy || 0) + (healthSummary.unknown || 0);

    ['healthy', 'unhealthy', 'unknown'].forEach(status => {
        const percentElement = document.getElementById(`${status}-percentage`);
        const countElement = document.getElementById(`${status}-count`);
        
        if (percentElement) {
            percentElement.style.width = total > 0 ? 
                `${((healthSummary[status] || 0) / total * 100).toFixed(1)}%` : '0%';
        }
        if (countElement) {
            countElement.textContent = healthSummary[status] || '0';
        }
    });

    // Update recent activity
    const recentActivity = document.getElementById('recent-activity');
    if (recentActivity) {
        recentActivity.innerHTML = '';

        const allResources = [
            ...(overview.claims?.items || []),
            ...(overview.composite_resources?.items || []),
            ...(overview.managed_resources?.items || [])
        ].filter(Boolean)
         .sort((a, b) => {
            const dateA = a?.metadata?.creationTimestamp ? new Date(a.metadata.creationTimestamp) : new Date(0);
            const dateB = b?.metadata?.creationTimestamp ? new Date(b.metadata.creationTimestamp) : new Date(0);
            return dateB - dateA;
         })
         .slice(0, 5);

        if (allResources.length === 0) {
            recentActivity.innerHTML = '<div class="text-sm text-gray-500 text-center p-4">No recent activity</div>';
            return;
        }

        allResources.forEach(resource => {
            const activityItem = document.createElement('div');
            activityItem.className = 'flex items-center space-x-3';
            activityItem.innerHTML = `
                <div class="flex-shrink-0">
                    <div class="w-2 h-2 rounded-full ${getStatusColor(resource._health_status)}"></div>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 truncate">
                        ${resource.metadata?.name || 'Unnamed'}
                        <span class="text-xs text-gray-500 ml-1">(${getResourceType(resource)})</span>
                    </p>
                    <p class="text-sm text-gray-500">Created ${formatTimeAgo(resource.metadata?.creationTimestamp)}</p>
                </div>
            `;
            recentActivity.appendChild(activityItem);
        });
    }
}

function getStatusColor(status) {
    if (!status) return 'bg-yellow-400';
    switch (status.toLowerCase()) {
        case 'healthy':
            return 'bg-green-400';
        case 'unhealthy':
            return 'bg-red-400';
        default:
            return 'bg-yellow-400';
    }
}

function getResourceType(resource) {
    if (resource.kind?.includes('Claim')) return 'Claim';
    if (resource._resource_type?.kind) return 'Composite';
    return 'Managed';
}

function formatTimeAgo(timestamp) {
    if (!timestamp) return 'Unknown';
    
    const date = new Date(timestamp);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'just now';
    
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days}d ago`;
    
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}mo ago`;
    
    const years = Math.floor(months / 12);
    return `${years}y ago`;
}

// Export functions
window.renderOverview = renderOverview;
