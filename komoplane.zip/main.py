from flask import Flask, render_template
from asgiref.wsgi import WsgiToAsgi
import asyncio
from functools import wraps
from app.controllers import (
    composition_controller, 
    claim_controller, 
    resource_controller,
    provider_controller,
    xrd_controller,
    page_controller
)

def create_app():
    app = Flask(__name__, 
                template_folder='app/views/templates',
                static_folder='app/views/static')
    
    # Helper for async routes
    def async_route(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            return loop.run_until_complete(f(*args, **kwargs))
        return wrapper
    
    # Add async support to the app
    app.async_route = async_route
    
    # Rota principal
    @app.route('/')
    def index():
        return render_template('index.html')
    
    # Register blueprints
    app.register_blueprint(composition_controller.bp)  # Rotas /api/compositions
    app.register_blueprint(claim_controller.bp)  # Rotas /api/claims
    app.register_blueprint(resource_controller.bp)  # Rotas /api/managed-resources e /api/status
    app.register_blueprint(provider_controller.bp)  # Rotas /api/providers
    app.register_blueprint(xrd_controller.bp)  # Rotas /api/xrds
    app.register_blueprint(page_controller.bp)  # Rotas de páginas e /api/overview
    
    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        app.logger.error(f'Route not found: {error}')
        return {'error': 'Route not found'}, 404

    @app.errorhandler(Exception)
    def handle_exception(error):
        app.logger.error(f'Unhandled exception: {error}')
        return {'error': str(error)}, 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    asgi_app = WsgiToAsgi(app)
    
    import uvicorn
    
    # Imprimir as rotas registradas no startup
    print("\nRegistered URLs:")
    for rule in app.url_map.iter_rules():
        print(f"{rule.endpoint}: {rule.rule} [{', '.join(rule.methods)}]")
    
    uvicorn.run(asgi_app, host='0.0.0.0', port=5000)
