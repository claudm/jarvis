from flask import Flask
from app.controllers.page_controller import page_bp
from app.controllers.provider_controller import bp as provider_bp
from app.controllers.composition_controller import bp as composition_bp
from app.controllers.composite_resource_definition_controller import bp as composite_resource_definition_bp
from app.controllers.claim_controller import bp as claim_bp
from app.controllers.resource_controller import bp as resource_bp
from app.controllers.provider_config_controller import bp as provider_config_bp

app = Flask(__name__, 
    template_folder='app/views/templates',
    static_folder='app/views/static'
)

# Register blueprints
app.register_blueprint(page_bp)
app.register_blueprint(provider_bp)
app.register_blueprint(composition_bp)
app.register_blueprint(composite_resource_definition_bp)
app.register_blueprint(claim_bp)
app.register_blueprint(resource_bp)
app.register_blueprint(provider_config_bp)

if __name__ == '__main__':
    app.run(debug=True)
